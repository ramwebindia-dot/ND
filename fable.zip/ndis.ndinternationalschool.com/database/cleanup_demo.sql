-- ============================================================
-- cleanup_demo.sql — WIPE all demo/previous data, keep a clean system.
-- Use this ONLY if your database ALREADY has demo data and you want to
-- start fresh WITHOUT re-importing. Keeps: roles, settings, Super Admin.
-- ⚠️  DELETES ALL students, staff, fees, payments, ledgers, etc. Take a backup first!
-- ============================================================
SET FOREIGN_KEY_CHECKS=0;

-- keep only the Super Admin login (remove any other/demo users)
DELETE FROM `users` WHERE id <> 1;

-- wipe every data table (roles + settings are preserved)
TRUNCATE TABLE `academic_sessions`;
TRUNCATE TABLE `audit_logs`;
TRUNCATE TABLE `bank_accounts`;
TRUNCATE TABLE `bank_ledger`;
TRUNCATE TABLE `book_categories`;
TRUNCATE TABLE `book_issues`;
TRUNCATE TABLE `books`;
TRUNCATE TABLE `cash_ledger`;
TRUNCATE TABLE `class_subjects`;
TRUNCATE TABLE `classes`;
TRUNCATE TABLE `departments`;
TRUNCATE TABLE `exam_schedules`;
TRUNCATE TABLE `exams`;
TRUNCATE TABLE `expenses`;
TRUNCATE TABLE `fee_additional_charges`;
TRUNCATE TABLE `fee_cash_closing`;
TRUNCATE TABLE `fee_categories`;
TRUNCATE TABLE `fee_collections`;
TRUNCATE TABLE `fee_credit_balance`;
TRUNCATE TABLE `fee_discounts`;
TRUNCATE TABLE `fee_installments`;
TRUNCATE TABLE `fee_late_fee_rules`;
TRUNCATE TABLE `fee_ledger`;
TRUNCATE TABLE `fee_month_status`;
TRUNCATE TABLE `fee_payment_items`;
TRUNCATE TABLE `fee_payment_reversals`;
TRUNCATE TABLE `fee_payment_transactions`;
TRUNCATE TABLE `fee_reconciliation_log`;
TRUNCATE TABLE `fee_refunds`;
TRUNCATE TABLE `fee_schedule`;
TRUNCATE TABLE `fee_scholarships`;
TRUNCATE TABLE `fee_structures`;
TRUNCATE TABLE `fee_student_discounts`;
TRUNCATE TABLE `grade_scales`;
TRUNCATE TABLE `homework`;
TRUNCATE TABLE `homework_submissions`;
TRUNCATE TABLE `income`;
TRUNCATE TABLE `journal_entries`;
TRUNCATE TABLE `learning_materials`;
TRUNCATE TABLE `leave_quotas`;
TRUNCATE TABLE `leave_settings`;
TRUNCATE TABLE `login_attempts`;
TRUNCATE TABLE `marks`;
TRUNCATE TABLE `messages`;
TRUNCATE TABLE `non_teaching_staff`;
TRUNCATE TABLE `notices`;
TRUNCATE TABLE `notifications`;
TRUNCATE TABLE `online_class_attendance`;
TRUNCATE TABLE `online_classes`;
TRUNCATE TABLE `parents`;
TRUNCATE TABLE `password_reset_tokens`;
TRUNCATE TABLE `question_bank`;
TRUNCATE TABLE `question_paper_items`;
TRUNCATE TABLE `question_papers`;
TRUNCATE TABLE `role_permissions`;
TRUNCATE TABLE `salary_advances`;
TRUNCATE TABLE `salary_payments`;
TRUNCATE TABLE `salary_structures`;
TRUNCATE TABLE `sections`;
TRUNCATE TABLE `sms_logs`;
TRUNCATE TABLE `student_attendance`;
TRUNCATE TABLE `student_documents`;
TRUNCATE TABLE `student_scholarships`;
TRUNCATE TABLE `student_transport_assignments`;
TRUNCATE TABLE `students`;
TRUNCATE TABLE `subjects`;
TRUNCATE TABLE `teacher_attendance`;
TRUNCATE TABLE `teacher_leaves`;
TRUNCATE TABLE `teachers`;
TRUNCATE TABLE `timetables`;
TRUNCATE TABLE `transactions`;
TRUNCATE TABLE `transport_fee_rates`;
TRUNCATE TABLE `transport_fees`;
TRUNCATE TABLE `transport_pickup_points`;
TRUNCATE TABLE `transport_routes`;
TRUNCATE TABLE `transport_vehicles`;

SET FOREIGN_KEY_CHECKS=1;
