-- ============================================================
-- toni_data.sql  — SEED / DEFAULT DATA for a FRESH install
-- Import AFTER toni_schema.sql.  Uses INSERT IGNORE so rows already
-- seeded by schema migrations (e.g. settings) don't abort the import.
-- Default logins (password: Admin@123):  superadmin  /  admin
-- ============================================================
SET FOREIGN_KEY_CHECKS=0;

-- =====================================================
-- ND International School Dinod - Sample Data
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+05:30";
SET NAMES utf8mb4;

-- =====================================================
-- ROLES
-- =====================================================
INSERT IGNORE INTO `roles` (`id`, `name`, `description`, `is_system`) VALUES
(1, 'Super Admin', 'Full system access', 1),
(2, 'School Admin', 'School administration access', 1),
(3, 'Principal', 'Principal access', 1),
(4, 'Teacher', 'Teacher access', 1),
(5, 'Accountant', 'Fee and accounting access', 1),
(6, 'Receptionist', 'Front desk access', 1),
(7, 'Librarian', 'Library management access', 1),
(8, 'Student', 'Student portal access', 1),
(9, 'Parent', 'Parent portal access', 1);

-- =====================================================
-- USERS (password for all: Admin@123)
-- =====================================================
INSERT IGNORE INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `is_active`) VALUES
(1, 1, 'superadmin', 'superadmin@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Super Admin', '9999999999', 1),
(2, 2, 'admin', 'admin@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'School Admin', '9999999998', 1),
(3, 3, 'principal', 'principal@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Dr. Rajesh Kumar', '9999999997', 1),
(4, 4, 'teacher1', 'teacher1@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Anita Sharma', '9999999996', 1),
(5, 4, 'teacher2', 'teacher2@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Vikram Singh', '9999999995', 1),
(6, 5, 'accountant', 'accountant@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Ramesh Gupta', '9999999994', 1),
(7, 6, 'receptionist', 'receptionist@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Pooja Verma', '9999999993', 1),
(8, 7, 'librarian', 'librarian@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Suresh Patel', '9999999992', 1);

-- =====================================================
-- SETTINGS
-- =====================================================
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES
('school_name', 'ND International School Dinod'),
('school_address', 'Village Dinod, District Bhiwani, Haryana'),
('school_phone', '9999999900'),
('school_email', 'info@ndinternationalschool.com'),
('school_logo', ''),
('school_website', ''),
('currency_symbol', '₹'),
('currency_code', 'INR'),
('timezone', 'Asia/Kolkata'),
('academic_year_format', 'YYYY-YYYY'),
('email_from_name', 'ND International School Dinod'),
('email_from_address', 'noreply@ndinternationalschool.com'),
('smtp_host', ''),
('smtp_port', '587'),
('smtp_username', ''),
('smtp_password', ''),
('smtp_encryption', 'tls'),
('sms_provider', ''),
('sms_api_key', ''),
('sms_sender_id', ''),
('fee_receipt_prefix', 'RCP'),
('refund_voucher_prefix', 'RFV'),
('attendance_enabled', '1'),
('library_fine_per_day', '5.00'),
('max_book_issue_days', '15'),
('max_books_per_student', '3');

-- =====================================================
-- ACADEMIC SESSIONS
-- =====================================================
INSERT IGNORE INTO `academic_sessions` (`id`, `name`, `start_date`, `end_date`, `is_active`, `is_archived`) VALUES
(1, '2025-2026', '2025-04-01', '2026-03-31', 1, 0),
(2, '2024-2025', '2024-04-01', '2025-03-31', 0, 1);

-- =====================================================
-- DEPARTMENTS
-- =====================================================
INSERT IGNORE INTO `departments` (`id`, `name`) VALUES
(1, 'Science'),
(2, 'Mathematics'),
(3, 'English'),
(4, 'Hindi'),
(5, 'Social Studies'),
(6, 'Physical Education'),
(7, 'Computer Science');

-- =====================================================
-- CLASSES (class_teacher_id set to NULL initially, updated after teachers are inserted)
-- =====================================================
INSERT IGNORE INTO `classes` (`id`, `session_id`, `name`, `numeric_value`, `class_teacher_id`) VALUES
(1, 1, 'Class 1', 1, NULL),
(2, 1, 'Class 2', 2, NULL),
(3, 1, 'Class 3', 3, NULL),
(4, 1, 'Class 4', 4, NULL),
(5, 1, 'Class 5', 5, NULL),
(6, 1, 'Class 6', 6, NULL),
(7, 1, 'Class 7', 7, NULL),
(8, 1, 'Class 8', 8, NULL),
(9, 1, 'Class 9', 9, NULL),
(10, 1, 'Class 10', 10, NULL),
(11, 1, 'Class 11', 11, NULL),
(12, 1, 'Class 12', 12, NULL);

-- =====================================================
-- SECTIONS
-- =====================================================
INSERT IGNORE INTO `sections` (`id`, `class_id`, `name`, `capacity`) VALUES
(1, 1, 'A', 40),
(2, 1, 'B', 40),
(3, 2, 'A', 40),
(4, 2, 'B', 40),
(5, 3, 'A', 40),
(6, 4, 'A', 40),
(7, 5, 'A', 40),
(8, 6, 'A', 40),
(9, 7, 'A', 40),
(10, 8, 'A', 40),
(11, 9, 'A', 40),
(12, 10, 'A', 40),
(13, 11, 'A', 35),
(14, 12, 'A', 35);

-- =====================================================
-- SUBJECTS
-- =====================================================
INSERT IGNORE INTO `subjects` (`id`, `name`, `code`, `type`) VALUES
(1, 'English', 'ENG', 'Theory'),
(2, 'Hindi', 'HIN', 'Theory'),
(3, 'Mathematics', 'MATH', 'Theory'),
(4, 'Science', 'SCI', 'Theory'),
(5, 'Social Studies', 'SST', 'Theory'),
(6, 'Computer Science', 'CS', 'Practical'),
(7, 'Physical Education', 'PE', 'Practical'),
(8, 'Physics', 'PHY', 'Theory'),
(9, 'Chemistry', 'CHEM', 'Theory'),
(10, 'Biology', 'BIO', 'Theory'),
(11, 'Accountancy', 'ACC', 'Theory'),
(12, 'Business Studies', 'BST', 'Theory'),
(13, 'Economics', 'ECO', 'Theory'),
(14, 'Sanskrit', 'SANS', 'Theory'),
(15, 'Art', 'ART', 'Practical'),
(16, 'Music', 'MUS', 'Practical');

-- =====================================================
-- TEACHERS
-- =====================================================
INSERT IGNORE INTO `teachers` (`id`, `user_id`, `department_id`, `employee_id`, `first_name`, `last_name`, `dob`, `gender`, `phone`, `email`, `qualification`, `specialization`, `experience_years`, `join_date`, `salary`, `status`) VALUES
(1, 4, 2, 'EMP0001', 'Anita', 'Sharma', '1985-05-15', 'Female', '9876543210', 'anita.sharma@ndinternationalschool.com', 'M.Sc, B.Ed', 'Mathematics', 10, '2020-07-01', 35000.00, 'Active'),
(2, 5, 1, 'EMP0002', 'Vikram', 'Singh', '1980-08-20', 'Male', '9876543211', 'vikram.singh@ndinternationalschool.com', 'M.Sc, B.Ed', 'Physics', 12, '2019-07-01', 38000.00, 'Active');

-- Assign class teachers now that teachers table is populated
UPDATE `classes` SET `class_teacher_id` = 1 WHERE `id` = 1;
UPDATE `classes` SET `class_teacher_id` = 2 WHERE `id` = 2;

-- =====================================================
-- CLASS SUBJECTS
-- =====================================================
INSERT IGNORE INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`, `session_id`) VALUES
(1, 1, NULL, 1),
(1, 2, NULL, 1),
(1, 3, 1, 1),
(1, 4, NULL, 1),
(1, 5, NULL, 1),
(1, 6, NULL, 1),
(2, 1, NULL, 1),
(2, 2, NULL, 1),
(2, 3, 1, 1),
(2, 4, NULL, 1),
(2, 5, NULL, 1),
(10, 1, NULL, 1),
(10, 2, NULL, 1),
(10, 3, 1, 1),
(10, 4, 2, 1),
(10, 5, NULL, 1),
(10, 6, NULL, 1);

-- =====================================================
-- FEE CATEGORIES
-- =====================================================
INSERT IGNORE INTO `fee_categories` (`id`, `name`, `description`, `is_mandatory`) VALUES
(1, 'Tuition Fee', 'Monthly tuition fee', 1),
(2, 'Admission Fee', 'One-time admission fee', 1),
(3, 'Exam Fee', 'Examination fee', 1),
(4, 'Transport Fee', 'School transport fee', 0),
(5, 'Lab Fee', 'Laboratory fee', 0),
(6, 'Library Fee', 'Library access fee', 0),
(7, 'Sports Fee', 'Sports and games fee', 0),
(8, 'Development Fee', 'School development fee', 1);

-- =====================================================
-- FEE STRUCTURES
-- =====================================================
INSERT IGNORE INTO `fee_structures` (`class_id`, `session_id`, `fee_category_id`, `amount`) VALUES
(1, 1, 1, 1500.00),
(1, 1, 2, 5000.00),
(1, 1, 3, 500.00),
(1, 1, 8, 500.00),
(2, 1, 1, 1800.00),
(2, 1, 2, 5000.00),
(2, 1, 3, 600.00),
(2, 1, 8, 600.00),
(10, 1, 1, 3000.00),
(10, 1, 2, 8000.00),
(10, 1, 3, 1000.00),
(10, 1, 5, 500.00),
(10, 1, 8, 1000.00);

-- =====================================================
-- BANK ACCOUNTS
-- =====================================================
INSERT IGNORE INTO `bank_accounts` (`id`, `bank_name`, `account_number`, `account_name`, `branch`, `ifsc_code`, `balance`, `is_active`) VALUES
(1, 'State Bank of India', '1234567890123', 'ND International School Dinod', 'Dinod Branch', 'SBIN0001234', 500000.00, 1),
(2, 'Punjab National Bank', '9876543210987', 'ND International School Dinod', 'Bhiwani Branch', 'PUNB0005678', 250000.00, 1);

-- =====================================================
-- TRANSPORT ROUTES
-- =====================================================
INSERT IGNORE INTO `transport_routes` (`name`, `description`, `stops`, `fare`, `vehicle_number`, `driver_name`, `driver_phone`) VALUES
('Route A - Bhiwani City',  'Covers Bhiwani city area',        'Bus Stand, Civil Hospital, Court Road, School', 800.00, 'HR-18-A-1234', 'Ramesh Kumar', '9876500001'),
('Route B - Dinod Village', 'Covers Dinod and nearby villages','Dinod Chowk, Rampura, Dhani, School',           600.00, 'HR-18-B-5678', 'Suresh Singh', '9876500002'),
('Route C - Loharu Road',   'Covers Loharu road villages',     'Loharu Crossing, Kairu, Mandola, School',       700.00, 'HR-18-C-9101', 'Mohan Yadav',  '9876500003');

-- =====================================================
-- GRADE SCALES
-- =====================================================
INSERT IGNORE INTO `grade_scales` (`name`, `min_percentage`, `max_percentage`, `grade`, `grade_point`, `remark`) VALUES
('Outstanding', 91.00, 100.00, 'A1', 10.0, 'Outstanding'),
('Excellent', 81.00, 90.99, 'A2', 9.0, 'Excellent'),
('Very Good', 71.00, 80.99, 'B1', 8.0, 'Very Good'),
('Good', 61.00, 70.99, 'B2', 7.0, 'Good'),
('Above Average', 51.00, 60.99, 'C1', 6.0, 'Above Average'),
('Average', 41.00, 50.99, 'C2', 5.0, 'Average'),
('Below Average', 33.00, 40.99, 'D', 4.0, 'Below Average'),
('Fail', 0.00, 32.99, 'E', 0.0, 'Fail');

-- =====================================================
-- BOOK CATEGORIES
-- =====================================================
INSERT IGNORE INTO `book_categories` (`id`, `name`, `description`) VALUES
(1, 'Fiction', 'Fiction books'),
(2, 'Non-Fiction', 'Non-fiction books'),
(3, 'Science', 'Science textbooks'),
(4, 'Mathematics', 'Mathematics textbooks'),
(5, 'Literature', 'Literature books'),
(6, 'Reference', 'Reference books'),
(7, 'General Knowledge', 'GK books');

-- =====================================================
-- BOOKS
-- =====================================================
INSERT IGNORE INTO `books` (`id`, `category_id`, `title`, `author`, `isbn`, `publisher`, `quantity`, `available_quantity`, `shelf_location`) VALUES
(1, 3, 'Science for Class 10', 'NCERT', '9788174505678', 'NCERT', 30, 28, 'A-1'),
(2, 4, 'Mathematics for Class 10', 'NCERT', '9788174505692', 'NCERT', 30, 29, 'A-2'),
(3, 5, 'English Communicative', 'NCERT', '9788174505708', 'NCERT', 30, 27, 'A-3'),
(4, 1, 'The Adventure of Tom Sawyer', 'Mark Twain', '9780141321103', 'Penguin', 10, 10, 'B-1'),
(5, 2, 'Wings of Fire', 'APJ Abdul Kalam', '9788173711466', 'Universities Press', 15, 14, 'B-2'),
(6, 7, 'General Knowledge 2025', 'Manohar Pandey', '9789353160065', 'Arihant', 20, 20, 'C-1');

-- =====================================================
-- NOTICES
-- =====================================================
INSERT IGNORE INTO `notices` (`id`, `title`, `content`, `target_audience`, `is_active`, `priority`, `created_by`) VALUES
(1, 'Welcome to New Academic Session 2025-2026', 'We welcome all students and parents to the new academic session 2025-2026. Classes will commence from 1st April 2025.', 'All', 1, 'High', 1),
(2, 'Annual Day Celebration', 'Annual Day will be celebrated on 15th December 2025. All students are requested to participate actively.', 'All', 1, 'Normal', 3);

COMMIT;

-- =====================================================
-- DEFAULT BILLING FREQUENCIES
-- The fee_structures.frequency column defaults to 'Manual', and 'Manual'
-- fees are NOT auto-listed on the Collect Fee grid. Set sensible defaults so
-- a fresh install bills correctly. Review/adjust in Fee Structure per your policy.
-- =====================================================
UPDATE `fee_structures` SET `frequency` = 'Monthly' WHERE `fee_category_id` IN (1, 11);      -- Tuition, Transport
UPDATE `fee_structures` SET `frequency` = 'Yearly'  WHERE `fee_category_id` IN (2,3,4,5,6,7,8,9,10); -- Admission/Annual/one-time heads
COMMIT;   -- AUTOCOMMIT was turned off above; commit the frequency updates too.

SET FOREIGN_KEY_CHECKS=1;
