-- ============================================================
-- toni_data.sql  — CLEAN PRODUCTION SEED (fresh install)
-- Import AFTER toni_schema.sql. Contains ONLY the essentials:
--   • 9 system roles
--   • 1 Super Admin login
--   • default settings (school config)
-- NO demo classes / students / teachers / fees — add your own from the app.
--
-- Default login (CHANGE THE PASSWORD after first login):
--   superadmin@ndinternationalschool.com   /   Admin@123
--
-- (The old demo dataset is preserved in toni_data_sample.sql.)
-- ============================================================
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+05:30";
SET NAMES utf8mb4;

-- =====================================================
-- ROLES (system RBAC — required)
-- =====================================================
INSERT IGNORE INTO `roles` (`id`, `name`, `description`, `is_system`) VALUES
(1, 'Super Admin', 'Full system access', 1),
(2, 'School Admin', 'School administration access', 1),
(3, 'Principal', 'Principal access', 1),
(4, 'Teacher', 'Teacher access', 1),
(5, 'Accountant', 'Fee and accounting access', 1),
(6, 'Receptionist', 'Front desk access', 1),
(7, 'Librarian', 'Library management access', 1),
(8, 'Student', 'Student portal access', 1),
(9, 'Parent', 'Parent portal access', 1);

-- =====================================================
-- STAFF LOGINS (one per role — password for ALL: Admin@123)
-- ⚠️ CHANGE every password after first login. Login is by EMAIL.
-- Student & Parent logins are created automatically when you add a
-- student / parent from the app (they get their own credentials).
-- =====================================================
INSERT IGNORE INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `is_active`) VALUES
(1, 1, 'superadmin',   'superadmin@ndinternationalschool.com',   '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Super Admin',  '9999999901', 1),
(2, 2, 'admin',        'admin@ndinternationalschool.com',        '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'School Admin', '9999999902', 1),
(3, 3, 'principal',    'principal@ndinternationalschool.com',    '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Principal',    '9999999903', 1),
(4, 4, 'teacher',      'teacher@ndinternationalschool.com',      '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Teacher',      '9999999904', 1),
(5, 5, 'accountant',   'accountant@ndinternationalschool.com',   '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Accountant',   '9999999905', 1),
(6, 6, 'receptionist', 'receptionist@ndinternationalschool.com', '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Receptionist', '9999999906', 1),
(7, 7, 'librarian',    'librarian@ndinternationalschool.com',    '$2y$10$ohlYjR0CCW9uGS7qEie4WO5ySLxFoLUe7jL7Xk3Db76PJnH1NPzJC', 'Librarian',    '9999999907', 1);

-- =====================================================
-- SETTINGS (default school configuration — edit in Settings → School Settings)
-- =====================================================
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES
('school_name', 'ND International School'),
('school_address', ''),
('school_phone', ''),
('school_email', 'info@ndinternationalschool.com'),
('school_logo', ''),
('school_website', ''),
('currency_symbol', '₹'),
('currency_code', 'INR'),
('timezone', 'Asia/Kolkata'),
('academic_year_format', 'YYYY-YYYY'),
('email_from_name', 'ND International School'),
('email_from_address', 'noreply@ndinternationalschool.com'),
('smtp_host', ''),
('smtp_port', '587'),
('smtp_username', ''),
('smtp_password', ''),
('smtp_encryption', 'tls'),
('sms_provider', ''),
('sms_api_key', ''),
('sms_sender_id', ''),
('fee_receipt_prefix', 'RCP'),
('refund_voucher_prefix', 'RFV'),
('attendance_enabled', '1'),
('library_fine_per_day', '5.00'),
('max_book_issue_days', '15'),
('max_books_per_student', '3');

-- =====================================================
-- ACADEMIC SESSION (current year — rename in Academic → Sessions if needed)
-- =====================================================
INSERT IGNORE INTO `academic_sessions` (`id`, `name`, `start_date`, `end_date`, `is_active`, `is_archived`) VALUES
(1, '2026-2027', '2026-04-01', '2027-03-31', 1, 0);

-- =====================================================
-- CLASSES (ND International School — 21 classes incl. 11th/12th streams)
-- numeric_value keeps them sorted in the correct order.
-- =====================================================
INSERT IGNORE INTO `classes` (`session_id`, `name`, `numeric_value`) VALUES
(1, 'Nursery',            1),
(1, 'LKG',                2),
(1, 'UKG',                3),
(1, '1st Class',          4),
(1, '2nd Class',          5),
(1, '3rd Class',          6),
(1, '4th Class',          7),
(1, '5th Class',          8),
(1, '6th Class',          9),
(1, '7th Class',          10),
(1, '8th Class',          11),
(1, '9th Class',          12),
(1, '10th Class',         13),
(1, '11th ARTS',          14),
(1, '11th Commerce',      15),
(1, '11th Medical',       16),
(1, '11th NON Medical',   17),
(1, '12th Arts',          18),
(1, '12th Commerce',      19),
(1, '12th NON Medical',   20),
(1, '12th Medical',       21);


-- =====================================================
-- SECTIONS (A, B, C for every class)
-- =====================================================
INSERT IGNORE INTO `sections` (`class_id`, `name`, `capacity`) VALUES
(1, 'A', 40),
(1, 'B', 40),
(1, 'C', 40),
(2, 'A', 40),
(2, 'B', 40),
(2, 'C', 40),
(3, 'A', 40),
(3, 'B', 40),
(3, 'C', 40),
(4, 'A', 40),
(4, 'B', 40),
(4, 'C', 40),
(5, 'A', 40),
(5, 'B', 40),
(5, 'C', 40),
(6, 'A', 40),
(6, 'B', 40),
(6, 'C', 40),
(7, 'A', 40),
(7, 'B', 40),
(7, 'C', 40),
(8, 'A', 40),
(8, 'B', 40),
(8, 'C', 40),
(9, 'A', 40),
(9, 'B', 40),
(9, 'C', 40),
(10, 'A', 40),
(10, 'B', 40),
(10, 'C', 40),
(11, 'A', 40),
(11, 'B', 40),
(11, 'C', 40),
(12, 'A', 40),
(12, 'B', 40),
(12, 'C', 40),
(13, 'A', 40),
(13, 'B', 40),
(13, 'C', 40),
(14, 'A', 40),
(14, 'B', 40),
(14, 'C', 40),
(15, 'A', 40),
(15, 'B', 40),
(15, 'C', 40),
(16, 'A', 40),
(16, 'B', 40),
(16, 'C', 40),
(17, 'A', 40),
(17, 'B', 40),
(17, 'C', 40),
(18, 'A', 40),
(18, 'B', 40),
(18, 'C', 40),
(19, 'A', 40),
(19, 'B', 40),
(19, 'C', 40),
(20, 'A', 40),
(20, 'B', 40),
(20, 'C', 40),
(21, 'A', 40),
(21, 'B', 40),
(21, 'C', 40);

-- =====================================================
-- FEE HEADS (fee categories). The AMOUNT and FREQUENCY are set per class in
-- Fee Structure (Finance → Fee Structure). Intended frequency per head:
--   Registration Fee ............. one-time   (Yearly = once per session)
--   Admission Charges ............ Annually   (Yearly)
--   Development & Building Fund ... Annually   (Yearly)
--   Exam Fee ..................... Annually   (Yearly)
--   Computer & Lab Charges ....... Monthly
--   Tuition Fee .................. Monthly
-- =====================================================
INSERT IGNORE INTO `fee_categories` (`id`, `name`, `head_type`, `description`, `is_mandatory`, `sort_order`) VALUES
(1, 'Registration Fee',           'Custom',    'One-time registration fee',  1, 1),
(2, 'Admission Charges',          'Admission', 'Annual admission charges',   1, 2),
(3, 'Development & Building Fund', 'Annual',    'Annual development fund',    1, 3),
(4, 'Exam Fee',                   'Exam',      'Annual examination fee',     1, 4),
(5, 'Computer & Lab Charges',     'Computer',  'Monthly computer & lab',     1, 5),
(6, 'Tuition Fee',                'Tuition',   'Monthly tuition fee',        1, 6);


-- =====================================================
-- FEE STRUCTURE (per-class amounts, from school's fee structor.xlsx)
-- Frequency: Registration/Development/Exam = Yearly (annual/one-time),
--            Computer & Lab + Tuition = Monthly. Zero-amount heads skipped.
-- =====================================================
INSERT IGNORE INTO `fee_structures` (`class_id`,`session_id`,`fee_category_id`,`amount`,`frequency`) VALUES
(1,1,1,2000.00,'Yearly'),
(1,1,3,4000.00,'Yearly'),
(1,1,4,500.00,'Yearly'),
(1,1,6,1500.00,'Monthly'),
(2,1,1,2000.00,'Yearly'),
(2,1,3,5000.00,'Yearly'),
(2,1,4,500.00,'Yearly'),
(2,1,6,1700.00,'Monthly'),
(3,1,1,2000.00,'Yearly'),
(3,1,3,5000.00,'Yearly'),
(3,1,4,500.00,'Yearly'),
(3,1,6,1800.00,'Monthly'),
(4,1,1,2000.00,'Yearly'),
(4,1,3,5000.00,'Yearly'),
(4,1,4,600.00,'Yearly'),
(4,1,5,100.00,'Monthly'),
(4,1,6,2000.00,'Monthly'),
(5,1,1,2000.00,'Yearly'),
(5,1,3,5000.00,'Yearly'),
(5,1,4,600.00,'Yearly'),
(5,1,5,100.00,'Monthly'),
(5,1,6,2200.00,'Monthly'),
(6,1,1,2000.00,'Yearly'),
(6,1,3,5000.00,'Yearly'),
(6,1,4,600.00,'Yearly'),
(6,1,5,100.00,'Monthly'),
(6,1,6,2500.00,'Monthly'),
(7,1,1,2000.00,'Yearly'),
(7,1,3,5000.00,'Yearly'),
(7,1,4,700.00,'Yearly'),
(7,1,5,100.00,'Monthly'),
(7,1,6,2750.00,'Monthly'),
(8,1,1,2000.00,'Yearly'),
(8,1,3,5000.00,'Yearly'),
(8,1,4,700.00,'Yearly'),
(8,1,5,100.00,'Monthly'),
(8,1,6,2750.00,'Monthly'),
(9,1,1,2000.00,'Yearly'),
(9,1,3,5500.00,'Yearly'),
(9,1,4,700.00,'Yearly'),
(9,1,5,100.00,'Monthly'),
(9,1,6,2850.00,'Monthly'),
(10,1,1,2000.00,'Yearly'),
(10,1,3,5500.00,'Yearly'),
(10,1,4,800.00,'Yearly'),
(10,1,5,100.00,'Monthly'),
(10,1,6,3150.00,'Monthly'),
(11,1,1,2000.00,'Yearly'),
(11,1,3,5500.00,'Yearly'),
(11,1,4,800.00,'Yearly'),
(11,1,5,100.00,'Monthly'),
(11,1,6,3400.00,'Monthly'),
(12,1,1,2000.00,'Yearly'),
(12,1,3,6000.00,'Yearly'),
(12,1,4,1000.00,'Yearly'),
(12,1,5,200.00,'Monthly'),
(12,1,6,3700.00,'Monthly'),
(13,1,1,2000.00,'Yearly'),
(13,1,3,6000.00,'Yearly'),
(13,1,4,1000.00,'Yearly'),
(13,1,5,200.00,'Monthly'),
(13,1,6,4000.00,'Monthly'),
(14,1,1,2000.00,'Yearly'),
(14,1,3,6500.00,'Yearly'),
(14,1,4,1100.00,'Yearly'),
(14,1,5,500.00,'Monthly'),
(14,1,6,4200.00,'Monthly'),
(15,1,1,2000.00,'Yearly'),
(15,1,3,6500.00,'Yearly'),
(15,1,4,1100.00,'Yearly'),
(15,1,5,500.00,'Monthly'),
(15,1,6,4200.00,'Monthly'),
(16,1,1,2000.00,'Yearly'),
(16,1,3,6500.00,'Yearly'),
(16,1,4,1100.00,'Yearly'),
(16,1,5,500.00,'Monthly'),
(16,1,6,4500.00,'Monthly'),
(17,1,1,2000.00,'Yearly'),
(17,1,3,6500.00,'Yearly'),
(17,1,4,1100.00,'Yearly'),
(17,1,5,500.00,'Monthly'),
(17,1,6,4500.00,'Monthly'),
(18,1,1,2000.00,'Yearly'),
(18,1,3,7000.00,'Yearly'),
(18,1,4,1200.00,'Yearly'),
(18,1,5,500.00,'Monthly'),
(18,1,6,4800.00,'Monthly'),
(19,1,1,2000.00,'Yearly'),
(19,1,3,7000.00,'Yearly'),
(19,1,4,1200.00,'Yearly'),
(19,1,5,500.00,'Monthly'),
(19,1,6,4800.00,'Monthly'),
(20,1,1,2000.00,'Yearly'),
(20,1,3,7000.00,'Yearly'),
(20,1,4,1200.00,'Yearly'),
(20,1,5,500.00,'Monthly'),
(20,1,6,5000.00,'Monthly'),
(21,1,1,2000.00,'Yearly'),
(21,1,3,7000.00,'Yearly'),
(21,1,4,1200.00,'Yearly'),
(21,1,5,500.00,'Monthly'),
(21,1,6,5000.00,'Monthly');


-- =====================================================
-- BANK ACCOUNT (school's HDFC account — set account no / IFSC / opening balance)
-- =====================================================
INSERT IGNORE INTO `bank_accounts` (`id`, `bank_name`, `account_name`, `account_number`, `branch`, `ifsc_code`, `balance`, `is_active`) VALUES
(1, 'HDFC Bank', 'ND International School', '', '', '', 0.00, 1);

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
