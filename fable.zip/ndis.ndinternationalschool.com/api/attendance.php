<?php
/**
 * ND International School Dinod - Attendance API
 * GET /api/attendance - Get attendance records
 * POST /api/attendance - Mark attendance (batch)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Authenticate
$authUser = getAuthUser();
if (!$authUser) {
    apiResponse(['success' => false, 'message' => 'Unauthorized. Provide a valid Bearer token.'], 401);
}

$method = $_SERVER['REQUEST_METHOD'];
$attendanceModel = new Attendance();

switch ($method) {
    case 'GET':
        $classId = (int) ($_GET['class_id'] ?? 0);
        $date = $_GET['date'] ?? date('Y-m-d');
        $studentId = (int) ($_GET['student_id'] ?? 0);

        if ($studentId > 0) {
            // Get attendance for a specific student
            $records = $attendanceModel->raw(
                "SELECT sa.*, s.name as student_name FROM student_attendance sa JOIN students s ON sa.student_id = s.id WHERE sa.student_id = :sid ORDER BY sa.date DESC LIMIT 100",
                ['sid' => $studentId]
            );
            apiResponse(['success' => true, 'data' => $records]);
        }

        if ($classId > 0) {
            // Get attendance for a class on a date
            $sessionModel = new AcademicSession();
            $session = $sessionModel->getActive();
            $sessionId = $session['id'] ?? 0;

            $records = $attendanceModel->raw(
                "SELECT sa.*, s.name as student_name, s.admission_no FROM student_attendance sa JOIN students s ON sa.student_id = s.id WHERE s.class_id = :cid AND sa.date = :date AND s.session_id = :sid ORDER BY s.name",
                ['cid' => $classId, 'date' => $date, 'sid' => $sessionId]
            );
            apiResponse(['success' => true, 'data' => $records]);
        }

        apiResponse(['success' => false, 'message' => 'Provide class_id or student_id parameter.'], 400);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        $classId = (int) ($input['class_id'] ?? 0);
        $date = $input['date'] ?? date('Y-m-d');
        $records = $input['attendance'] ?? [];

        if (empty($classId) || empty($records) || !is_array($records)) {
            apiResponse(['success' => false, 'message' => 'class_id and attendance array are required.'], 400);
        }

        $sessionModel = new AcademicSession();
        $session = $sessionModel->getActive();
        $sessionId = $session['id'] ?? 0;

        try {
            $attendanceModel->beginTransaction();

            foreach ($records as $record) {
                $studentId = (int) ($record['student_id'] ?? 0);
                $status = $record['status'] ?? 'absent';

                if ($studentId <= 0) continue;

                // Check if already exists
                $existing = $attendanceModel->rawOne(
                    "SELECT id FROM student_attendance WHERE student_id = :sid AND date = :date",
                    ['sid' => $studentId, 'date' => $date]
                );

                if ($existing) {
                    $attendanceModel->update($existing['id'], [
                        'status' => $status,
                        'remark' => $record['remark'] ?? '',
                        'marked_by' => $authUser['id']
                    ]);
                } else {
                    $attendanceModel->create([
                        'student_id' => $studentId,
                        'date' => $date,
                        'status' => $status,
                        'remark' => $record['remark'] ?? '',
                        'marked_by' => $authUser['id'],
                        'session_id' => $sessionId,
                        'class_id' => $classId
                    ]);
                }
            }

            $attendanceModel->commit();
            Audit::log('attendance', 'api_mark', null, ['class_id' => $classId, 'date' => $date, 'count' => count($records)]);
            apiResponse(['success' => true, 'message' => 'Attendance marked successfully.', 'data' => ['records_processed' => count($records)]]);
        } catch (Exception $e) {
            $attendanceModel->rollback();
            apiResponse(['success' => false, 'message' => 'Error marking attendance: ' . $e->getMessage()], 500);
        }
        break;

    default:
        apiResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}
