<?php
/**
 * ND International School Dinod - Results API
 * GET /api/results - Get exam results
 * POST /api/results - Enter/update marks
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Authenticate
$authUser = getAuthUser();
if (!$authUser) {
    apiResponse(['success' => false, 'message' => 'Unauthorized. Provide a valid Bearer token.'], 401);
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $studentId = (int) ($_GET['student_id'] ?? 0);
        $examId = (int) ($_GET['exam_id'] ?? 0);
        $classId = (int) ($_GET['class_id'] ?? 0);

        $examModel = new Exam();

        if ($studentId > 0 && $examId > 0) {
            // Get marks for a specific student and exam
            $marks = $examModel->raw(
                "SELECT m.*, sub.name as subject_name, e.name as exam_name, e.total_marks FROM marks m JOIN subjects sub ON m.subject_id = sub.id JOIN exams e ON m.exam_id = e.id WHERE m.student_id = :sid AND m.exam_id = :eid ORDER BY sub.name",
                ['sid' => $studentId, 'eid' => $examId]
            );

            // Calculate totals
            $totalObtained = array_sum(array_column($marks, 'marks_obtained'));
            $totalMarks = array_sum(array_column($marks, 'total_marks'));
            $percentage = $totalMarks > 0 ? round(($totalObtained / $totalMarks) * 100, 2) : 0;

            apiResponse([
                'success' => true,
                'data' => [
                    'marks' => $marks,
                    'summary' => [
                        'total_obtained' => $totalObtained,
                        'total_marks' => $totalMarks,
                        'percentage' => $percentage,
                        'grade' => calculateGrade($percentage)
                    ]
                ]
            ]);
        }

        if ($examId > 0 && $classId > 0) {
            // Get results for a class in an exam
            $marks = $examModel->raw(
                "SELECT m.*, s.name as student_name, s.admission_no, sub.name as subject_name FROM marks m JOIN students s ON m.student_id = s.id JOIN subjects sub ON m.subject_id = sub.id WHERE m.exam_id = :eid AND s.class_id = :cid ORDER BY s.name, sub.name",
                ['eid' => $examId, 'cid' => $classId]
            );
            apiResponse(['success' => true, 'data' => $marks]);
        }

        if ($studentId > 0) {
            // Get all exam results for a student
            $marks = $examModel->raw(
                "SELECT m.*, sub.name as subject_name, e.name as exam_name, e.total_marks as exam_total FROM marks m JOIN subjects sub ON m.subject_id = sub.id JOIN exams e ON m.exam_id = e.id WHERE m.student_id = :sid ORDER BY e.exam_date DESC, sub.name",
                ['sid' => $studentId]
            );
            apiResponse(['success' => true, 'data' => $marks]);
        }

        apiResponse(['success' => false, 'message' => 'Provide student_id, or exam_id + class_id parameters.'], 400);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        $examId = (int) ($input['exam_id'] ?? 0);
        $classId = (int) ($input['class_id'] ?? 0);
        $marksData = $input['marks'] ?? [];

        if ($examId <= 0 || empty($marksData) || !is_array($marksData)) {
            apiResponse(['success' => false, 'message' => 'exam_id and marks array are required.'], 400);
        }

        $examModel = new Exam();

        try {
            $examModel->beginTransaction();

            $count = 0;
            foreach ($marksData as $entry) {
                $studentId = (int) ($entry['student_id'] ?? 0);
                $subjectId = (int) ($entry['subject_id'] ?? 0);
                $marksObtained = (float) ($entry['marks_obtained'] ?? 0);

                if ($studentId <= 0 || $subjectId <= 0) continue;

                // Check if marks already exist
                $existing = $examModel->rawOne(
                    "SELECT id FROM marks WHERE exam_id = :eid AND student_id = :sid AND subject_id = :subid",
                    ['eid' => $examId, 'sid' => $studentId, 'subid' => $subjectId]
                );

                if ($existing) {
                    $examModel->query(
                        "UPDATE marks SET marks_obtained = :marks, remark = :remark, updated_at = :updated WHERE id = :id",
                        [
                            'marks' => $marksObtained,
                            'remark' => $entry['remark'] ?? '',
                            'updated' => date('Y-m-d H:i:s'),
                            'id' => $existing['id']
                        ]
                    );
                } else {
                    $examModel->query(
                        "INSERT INTO marks (exam_id, student_id, subject_id, marks_obtained, remark, created_at) VALUES (:eid, :sid, :subid, :marks, :remark, :created)",
                        [
                            'eid' => $examId,
                            'sid' => $studentId,
                            'subid' => $subjectId,
                            'marks' => $marksObtained,
                            'remark' => $entry['remark'] ?? '',
                            'created' => date('Y-m-d H:i:s')
                        ]
                    );
                }
                $count++;
            }

            $examModel->commit();
            Audit::log('exams', 'api_marks_entry', $examId, ['count' => $count]);
            apiResponse(['success' => true, 'message' => 'Marks saved successfully.', 'data' => ['records_processed' => $count]]);
        } catch (Exception $e) {
            $examModel->rollback();
            apiResponse(['success' => false, 'message' => 'Error saving marks: ' . $e->getMessage()], 500);
        }
        break;

    default:
        apiResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

/**
 * Calculate grade based on percentage
 */
function calculateGrade(float $percentage): string
{
    if ($percentage >= 90) return 'A+';
    if ($percentage >= 80) return 'A';
    if ($percentage >= 70) return 'B+';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C';
    if ($percentage >= 40) return 'D';
    return 'F';
}
