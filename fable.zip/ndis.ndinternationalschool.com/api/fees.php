<?php
/**
 * ND International School Dinod - Fees API
 * GET /api/fees - Get fee records
 * POST /api/fees - Collect fee payment
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Authenticate
$authUser = getAuthUser();
if (!$authUser) {
    apiResponse(['success' => false, 'message' => 'Unauthorized. Provide a valid Bearer token.'], 401);
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $studentId = (int) ($_GET['student_id'] ?? 0);
        $classId = (int) ($_GET['class_id'] ?? 0);
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo = $_GET['date_to'] ?? '';

        if ($studentId > 0) {
            // Get fee ledger for a student
            $feeModel = new Fee();
            $collections = $feeModel->raw(
                "SELECT fc.*, fc2.name as category_name FROM fee_collections fc LEFT JOIN fee_categories fc2 ON fc.fee_category_id = fc2.id WHERE fc.student_id = :sid ORDER BY fc.payment_date DESC",
                ['sid' => $studentId]
            );

            // Calculate outstanding
            $structure = $feeModel->rawOne(
                "SELECT COALESCE(SUM(fs.amount), 0) as total_fee FROM fee_structures fs JOIN students s ON s.class_id = fs.class_id WHERE s.id = :sid AND fs.session_id = s.session_id",
                ['sid' => $studentId]
            );
            $paid = $feeModel->rawOne(
                "SELECT COALESCE(SUM(fc.amount), 0) as total_paid FROM fee_collections fc WHERE fc.student_id = :sid AND fc.status = 'paid'",
                ['sid' => $studentId]
            );

            $totalFee = (float) ($structure['total_fee'] ?? 0);
            $totalPaid = (float) ($paid['total_paid'] ?? 0);

            apiResponse([
                'success' => true,
                'data' => [
                    'collections' => $collections,
                    'summary' => [
                        'total_fee' => $totalFee,
                        'total_paid' => $totalPaid,
                        'outstanding' => $totalFee - $totalPaid
                    ]
                ]
            ]);
        }

        if ($classId > 0) {
            $feeModel = new Fee();
            $sessionModel = new AcademicSession();
            $session = $sessionModel->getActive();
            $sessionId = $session['id'] ?? 0;

            $where = "s.class_id = :cid AND s.session_id = :sid";
            $params = ['cid' => $classId, 'sid' => $sessionId];

            if ($dateFrom) {
                $where .= " AND fc.payment_date >= :date_from";
                $params['date_from'] = $dateFrom;
            }
            if ($dateTo) {
                $where .= " AND fc.payment_date <= :date_to";
                $params['date_to'] = $dateTo;
            }

            $collections = $feeModel->raw(
                "SELECT fc.*, s.name as student_name, s.admission_no FROM fee_collections fc JOIN students s ON fc.student_id = s.id WHERE $where ORDER BY fc.payment_date DESC, s.name",
                $params
            );

            apiResponse(['success' => true, 'data' => $collections]);
        }

        apiResponse(['success' => false, 'message' => 'Provide student_id or class_id parameter.'], 400);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        $studentId = (int) ($input['student_id'] ?? 0);
        $amount = (float) ($input['amount'] ?? 0);
        $receiptNo = $input['receipt_no'] ?? '';
        $paymentMethod = $input['payment_method'] ?? 'cash';
        $feeCategoryId = (int) ($input['fee_category_id'] ?? 0);

        if ($studentId <= 0 || $amount <= 0 || empty($receiptNo)) {
            apiResponse(['success' => false, 'message' => 'student_id, amount, and receipt_no are required.'], 400);
        }

        $feeModel = new Fee();

        // Check unique receipt number
        $existing = $feeModel->rawOne("SELECT id FROM fee_collections WHERE receipt_no = :rn", ['rn' => $receiptNo]);
        if ($existing) {
            apiResponse(['success' => false, 'message' => 'Receipt number already exists.'], 409);
        }

        try {
            $feeModel->beginTransaction();

            $collectionData = [
                'student_id' => $studentId,
                'fee_category_id' => $feeCategoryId,
                'amount' => $amount,
                'receipt_no' => $receiptNo,
                'payment_method' => $paymentMethod,
                'payment_date' => $input['payment_date'] ?? date('Y-m-d'),
                'remark' => $input['remark'] ?? '',
                'status' => 'paid',
                'collected_by' => $authUser['id'],
                'created_at' => date('Y-m-d H:i:s')
            ];

            $columns = implode(', ', array_keys($collectionData));
            $placeholders = implode(', ', array_map(fn($k) => ":$k", array_keys($collectionData)));
            $feeModel->query("INSERT INTO fee_collections ($columns) VALUES ($placeholders)", $collectionData);
            $collectionId = (int) $feeModel->query("SELECT LAST_INSERT_ID() as id")->fetch()['id'];

            // Update cash/bank ledger
            $ledgerData = [
                'date' => $collectionData['payment_date'],
                'particular' => "Fee receipt #$receiptNo",
                'reference_id' => $collectionId,
                'reference_type' => 'fee_collection'
            ];

            if ($paymentMethod === 'cash') {
                $ledgerData['debit'] = $amount;
                $ledgerData['credit'] = 0;
                $lCols = implode(', ', array_keys($ledgerData));
                $lPlc = implode(', ', array_map(fn($k) => ":$k", array_keys($ledgerData)));
                $feeModel->query("INSERT INTO cash_ledger ($lCols) VALUES ($lPlc)", $ledgerData);
            } else {
                $ledgerData['debit'] = $amount;
                $ledgerData['credit'] = 0;
                $ledgerData['bank_account_id'] = (int) ($input['bank_account_id'] ?? 0);
                $lCols = implode(', ', array_keys($ledgerData));
                $lPlc = implode(', ', array_map(fn($k) => ":$k", array_keys($ledgerData)));
                $feeModel->query("INSERT INTO bank_ledger ($lCols) VALUES ($lPlc)", $ledgerData);
            }

            $feeModel->commit();
            Audit::log('fees', 'api_collect', $collectionId, $collectionData);

            apiResponse(['success' => true, 'message' => 'Fee collected successfully.', 'data' => ['collection_id' => $collectionId]], 201);
        } catch (Exception $e) {
            $feeModel->rollback();
            apiResponse(['success' => false, 'message' => 'Error collecting fee: ' . $e->getMessage()], 500);
        }
        break;

    default:
        apiResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}
