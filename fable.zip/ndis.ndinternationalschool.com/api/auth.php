<?php
/**
 * ND International School Dinod - API Authentication
 * POST /api/auth - Login and receive JWT token
 */

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/**
 * Simple JWT implementation without external libraries
 */
class JWT
{
    private static string $secret = 'f7a5bb7e3c57713d8c569427ad8df907a6669647e7a2b9577d39c4dc3c70adda';

    public static function encode(array $payload): string
    {
        $header = self::base64UrlEncode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
        $payload['iat'] = time();
        $payload['exp'] = time() + 86400; // 24 hours
        $payloadEncoded = self::base64UrlEncode(json_encode($payload));
        $signature = self::base64UrlEncode(hash_hmac('sha256', "$header.$payloadEncoded", self::$secret, true));
        return "$header.$payloadEncoded.$signature";
    }

    public static function decode(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;

        [$header, $payload, $signature] = $parts;
        $expectedSig = self::base64UrlEncode(hash_hmac('sha256', "$header.$payload", self::$secret, true));

        if (!hash_equals($expectedSig, $signature)) return null;

        $data = json_decode(self::base64UrlDecode($payload), true);
        if (!$data || !isset($data['exp']) || $data['exp'] < time()) return null;

        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $data): string
    {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', 3 - (3 + strlen($data)) % 4));
    }
}

/**
 * Get authenticated user from Bearer token
 */
function getAuthUser(): ?array
{
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!preg_match('/Bearer\s+(.+)/', $auth, $matches)) return null;

    $payload = JWT::decode($matches[1]);
    if (!$payload || !isset($payload['user_id'])) return null;

    $userModel = new User();
    return $userModel->findById($payload['user_id']);
}

/**
 * Send JSON response
 */
function apiResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    apiResponse(['success' => false, 'message' => 'Method not allowed. Use POST to authenticate.'], 405);
}

// Parse JSON body
$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

if (empty($username) || empty($password)) {
    apiResponse(['success' => false, 'message' => 'Username and password are required.'], 400);
}

$userModel = new User();
$user = $userModel->findByUsername($username);

if (!$user || !password_verify($password, $user['password'])) {
    apiResponse(['success' => false, 'message' => 'Invalid credentials.'], 401);
}

if ($user['status'] !== 'active') {
    apiResponse(['success' => false, 'message' => 'Account is not active.'], 403);
}

// Generate token
$token = JWT::encode([
    'user_id' => $user['id'],
    'username' => $user['username'],
    'role' => $user['role_name'] ?? 'Unknown'
]);

// Log the login
Audit::log('auth', 'api_login', $user['id'], ['ip' => $_SERVER['REMOTE_ADDR'] ?? '']);

apiResponse([
    'success' => true,
    'message' => 'Authentication successful.',
    'data' => [
        'token' => $token,
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'full_name' => $user['full_name'] ?? $user['username'],
            'role' => $user['role_name'] ?? 'Unknown',
            'email' => $user['email'] ?? ''
        ]
    ]
]);
