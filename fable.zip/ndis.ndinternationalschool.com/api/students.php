<?php
/**
 * ND International School Dinod - Students API
 * GET /api/students - List students (with pagination, search)
 * GET /api/students?id=X - Get single student
 * POST /api/students - Create student
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Authenticate
$authUser = getAuthUser();
if (!$authUser) {
    apiResponse(['success' => false, 'message' => 'Unauthorized. Provide a valid Bearer token.'], 401);
}

$method = $_SERVER['REQUEST_METHOD'];
$studentModel = new Student();

switch ($method) {
    case 'GET':
        $id = (int) ($_GET['id'] ?? 0);
        if ($id > 0) {
            // Get single student
            $student = $studentModel->findById($id);
            if (!$student) {
                apiResponse(['success' => false, 'message' => 'Student not found.'], 404);
            }
            apiResponse(['success' => true, 'data' => $student]);
        }

        // List students with pagination and search
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $limit = min(100, max(1, (int) ($_GET['limit'] ?? 20)));
        $search = $_GET['search'] ?? '';
        $classId = (int) ($_GET['class_id'] ?? 0);
        $status = $_GET['status'] ?? '';

        $where = '1=1';
        $params = [];

        if ($search) {
            $where .= " AND (s.name LIKE :search OR s.admission_no LIKE :search2 OR s.father_name LIKE :search3)";
            $params['search'] = "%$search%";
            $params['search2'] = "%$search%";
            $params['search3'] = "%$search%";
        }
        if ($classId > 0) {
            $where .= " AND s.class_id = :class_id";
            $params['class_id'] = $classId;
        }
        if ($status) {
            $where .= " AND s.status = :status";
            $params['status'] = $status;
        }

        $sessionModel = new AcademicSession();
        $session = $sessionModel->getActive();
        if ($session) {
            $where .= " AND s.session_id = :session_id";
            $params['session_id'] = $session['id'];
        }

        $total = $studentModel->rawOne("SELECT COUNT(*) as cnt FROM students s WHERE $where", $params)['cnt'] ?? 0;
        $offset = ($page - 1) * $limit;
        $students = $studentModel->raw("SELECT s.*, c.name as class_name, sec.name as section_name FROM students s LEFT JOIN classes c ON s.class_id = c.id LEFT JOIN sections sec ON s.section_id = sec.id WHERE $where ORDER BY s.name LIMIT $limit OFFSET $offset", $params);

        apiResponse([
            'success' => true,
            'data' => $students,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]
        ]);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        if (empty($input['name']) || empty($input['admission_no'])) {
            apiResponse(['success' => false, 'message' => 'Name and admission number are required.'], 400);
        }

        // Check unique admission number
        $existing = $studentModel->findBy('admission_no', $input['admission_no']);
        if ($existing) {
            apiResponse(['success' => false, 'message' => 'Admission number already exists.'], 409);
        }

        $sessionModel2 = new AcademicSession();
        $session2 = $sessionModel2->getActive();
        $input['session_id'] = $session2['id'] ?? null;
        $input['created_at'] = date('Y-m-d H:i:s');

        $id = $studentModel->create($input);
        Audit::log('students', 'api_create', $id, $input);

        apiResponse(['success' => true, 'message' => 'Student created.', 'data' => ['id' => $id]], 201);
        break;

    default:
        apiResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}
