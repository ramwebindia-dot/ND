<?php
/**
 * ND International School Dinod - Front Controller
 * All requests are routed through this file
 */

require_once __DIR__ . '/config.php';

// Initialize the application
$app = new App();
$app->run();
