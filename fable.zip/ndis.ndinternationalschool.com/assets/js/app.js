/**
 * ND International School Dinod - Core JavaScript
 */
document.addEventListener('DOMContentLoaded', function() {

    // ===== DARK MODE =====
    const darkModeToggle = document.getElementById('darkModeToggle');
    const currentTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', currentTheme);
    updateDarkModeIcon(currentTheme);

    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', function() {
            const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
            updateDarkModeIcon(theme);
        });
    }

    function updateDarkModeIcon(theme) {
        const icon = document.querySelector('#darkModeToggle i');
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    // ===== SIDEBAR TOGGLE (Mobile) =====
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        });
    }

    if (overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        });
    }

    // On mobile, tapping a real (leaf) nav link should close the off-canvas sidebar.
    // Group toggles (aria-expanded) only open/close their section, so leave those alone.
    if (sidebar) {
        sidebar.addEventListener('click', function(e) {
            var link = e.target.closest('.nav-link');
            if (!link || link.hasAttribute('aria-expanded')) return;
            if (window.innerWidth <= 991.98) {
                sidebar.classList.remove('show');
                if (overlay) overlay.classList.remove('show');
            }
        });
    }

    // ===== CSRF TOKEN SETUP FOR AJAX =====
    const csrfToken = document.querySelector('meta[name="csrf-token"]');
    if (csrfToken) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': csrfToken.getAttribute('content')
            }
        });
    }

    // ===== AUTO-DISMISS ALERTS =====
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert-auto-dismiss');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // ===== TOOLTIPS =====
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function(tooltipTriggerEl) {
        new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // ===== SIDEBAR SUBMENU =====
    const submenuToggles = document.querySelectorAll('.nav-link[aria-expanded]');
    submenuToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            const isOpen = this.getAttribute('aria-expanded') === 'true';
            
            // Close other submenus
            document.querySelectorAll('.submenu.show').forEach(function(menu) {
                if (menu !== target) {
                    menu.classList.remove('show');
                    const link = document.querySelector('[href="#' + menu.id + '"]');
                    if (link) link.setAttribute('aria-expanded', 'false');
                }
            });

            this.setAttribute('aria-expanded', !isOpen);
            if (target) {
                target.classList.toggle('show');
            }
        });
    });

    // ===== CONFIRM DELETE =====
    document.addEventListener('click', function(e) {
        if (e.target.closest('.btn-delete-confirm')) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
                e.stopImmediatePropagation();
            }
        }
    });

    // ===== NUMBER FORMAT =====
    window.formatNumber = function(num) {
        return new Intl.NumberFormat('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(num);
    };

    // ===== DATE FORMAT =====
    window.formatDate = function(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });
    };

    // ===== FORM VALIDATION CLASS =====
    window.validateForm = function(formId) {
        const form = document.getElementById(formId);
        if (!form) return true;
        let isValid = true;
        
        form.querySelectorAll('[required]').forEach(function(field) {
            if (!field.value.trim()) {
                field.classList.add('is-invalid');
                isValid = false;
            } else {
                field.classList.remove('is-invalid');
            }
        });

        return isValid;
    };

    // ===== SELECT2-STYLE SEARCH FOR SELECT =====
    document.querySelectorAll('.form-select-searchable').forEach(function(select) {
        const wrapper = document.createElement('div');
        wrapper.className = 'position-relative';
        select.parentNode.insertBefore(wrapper, select);
        wrapper.appendChild(select);
    });

    // ===== SESSION TIMEOUT WARNING =====
    let timeoutWarningShown = false;
    setInterval(function() {
        fetch(url('auth/check-session'), { method: 'GET', credentials: 'same-origin' })
            .then(response => {
                if (response.status === 401 && !timeoutWarningShown) {
                    timeoutWarningShown = true;
                    alert('Your session has expired. Please login again.');
                    window.location.href = url('auth/login');
                }
            })
            .catch(() => {});
    }, 60000); // Check every minute
});

// ===== AJAX HELPER =====
function ajaxPost(url, data, callback) {
    const csrfToken = document.querySelector('meta[name="csrf-token"]');
    const headers = {};
    if (csrfToken) {
        headers['X-CSRF-TOKEN'] = csrfToken.getAttribute('content');
    }
    
    fetch(url, {
        method: 'POST',
        headers: headers,
        body: data,
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(result => callback(result))
    .catch(error => {
        console.error('AJAX Error:', error);
        callback({ success: false, message: 'An error occurred. Please try again.' });
    });
}

function ajaxGet(url, callback) {
    fetch(url, {
        method: 'GET',
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(result => callback(result))
    .catch(error => {
        console.error('AJAX Error:', error);
        callback({ success: false, message: 'An error occurred.' });
    });
}
