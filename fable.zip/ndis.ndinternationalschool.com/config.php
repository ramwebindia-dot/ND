<?php
/**
 * ND International School Dinod - Configuration File
 * Update these settings after uploading to cPanel
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'ramwebsi_changes');
define('DB_USER', 'ramwebsi_changes');
define('DB_PASS', 'Ronak1122@#');
define('DB_CHARSET', 'utf8mb4');

// Application Configuration
define('APP_NAME', 'ND International School Dinod');
define('APP_URL', 'https://ndis.ndinternationalschool.com');
define('APP_ROOT', __DIR__);
define('APP_VERSION', '1.0.0');

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour

// File Upload Configuration
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('UPLOAD_PATH', APP_ROOT . '/assets/uploads');
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
define('ALLOWED_DOC_TYPES', ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);
define('ALLOWED_FILE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'video/mp4', 'video/webm']);

// Security Configuration
define('CSRF_TOKEN_NAME', 'csrf_token');
define('HASH_COST', 12);

// Developer
define('DEVELOPER_NAME', 'Ashish');

// Error Reporting (disable display in production)
error_reporting(E_ALL);
ini_set('display_errors', '0'); // OFF in production
ini_set('log_errors', '1');
ini_set('error_log', APP_ROOT . '/error.log');

// Autoloader
spl_autoload_register(function ($class) {
    $paths = [
        APP_ROOT . '/app/core/',
        APP_ROOT . '/app/controllers/',
        APP_ROOT . '/app/models/',
    ];
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Helper Functions
function redirect($url) {
    if (strpos($url, 'http') !== 0) {
        $url = APP_URL . '/' . ltrim($url, '/');
    }
    header("Location: $url");
    exit;
}

function asset($path) {
    return APP_URL . '/assets/' . ltrim($path, '/');
}

function url($path = '') {
    return APP_URL . '/' . ltrim($path, '/');
}

function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

function formatCurrency($amount) {
    $settingsModel = new Settings();
    $currency = $settingsModel->get('currency_symbol') ?? '₹';
    return $currency . number_format((float)$amount, 2);
}

function formatDate($date) {
    if (empty($date) || $date === '0000-00-00') return '';
    return date('d-m-Y', strtotime($date));
}

/** All application settings as a [key => value] map (cached per request). Used by
 *  printable documents — salary slip, hall ticket, report card, ID card, TC. */
function app_settings(): array {
    static $cache = null;
    if ($cache === null) {
        try { $cache = (new Settings())->getAll(); }
        catch (Throwable $e) { $cache = []; }
    }
    return $cache;
}

function formatDateTime($datetime) {
    if (empty($datetime)) return '';
    return date('d-m-Y h:i A', strtotime($datetime));
}

function isActiveSession() {
    $sessionModel = new AcademicSession();
    return $sessionModel->getActive();
}
