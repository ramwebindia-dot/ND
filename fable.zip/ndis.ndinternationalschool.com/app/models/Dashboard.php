<?php
/**
 * Dashboard Model
 */
class Dashboard extends Model
{
    public function getStats(): array
    {
        $sessionId = Session::get('active_session_id');
        if (!$sessionId) {
            $latest = $this->rawOne("SELECT id FROM academic_sessions ORDER BY id DESC LIMIT 1");
            $sessionId = $latest['id'] ?? 0;
        }

        $totalStudents = $this->rawOne(
            "SELECT COUNT(*) as total FROM students WHERE session_id = :sid AND status = 'Active'",
            ['sid' => $sessionId ?? 0]
        )['total'] ?? 0;

        $totalTeachers = $this->rawOne(
            "SELECT COUNT(*) as total FROM teachers WHERE status = 'Active'"
        )['total'] ?? 0;

        $todayAttendance = $this->rawOne(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent
             FROM student_attendance WHERE date = CURDATE() AND session_id = :sid",
            ['sid' => $sessionId ?? 0]
        );

        $feeModel       = new Fee();
        $feeCollections = $feeModel->getTodayCollection($sessionId ?? 0);
        $outstandingFees = $feeModel->getTotalOutstanding($sessionId ?? 0);
        $previousOutstanding = $feeModel->getPreviousSessionsOutstanding($sessionId ?? 0);
        $totalPreviousOutstanding = array_sum(array_column($previousOutstanding, 'outstanding'));

        $cashBalance = $this->rawOne(
            "SELECT COALESCE(balance_after, 0) as balance FROM cash_ledger ORDER BY id DESC LIMIT 1"
        )['balance'] ?? 0;

        $bankBalance = $this->rawOne(
            "SELECT COALESCE(SUM(balance), 0) as total FROM bank_accounts WHERE is_active = 1"
        )['total'] ?? 0;

        $refundTotal = $this->rawOne(
            "SELECT COALESCE(SUM(amount), 0) as total FROM fee_refunds WHERE session_id = :sid AND status = 'Processed'",
            ['sid' => $sessionId ?? 0]
        )['total'] ?? 0;

        return [
            'total_students'           => $totalStudents,
            'total_teachers'           => $totalTeachers,
            'attendance_present'       => $todayAttendance['present'] ?? 0,
            'attendance_total'         => $todayAttendance['total'] ?? 0,
            'fee_collections'          => $feeCollections,
            'outstanding_fees'         => max(0, $outstandingFees),
            'previous_outstanding'     => $previousOutstanding,
            'total_previous_outstanding' => $totalPreviousOutstanding,
            'total_outstanding_all'    => max(0, $outstandingFees) + $totalPreviousOutstanding,
            'cash_balance'             => $cashBalance,
            'bank_balance'             => $bankBalance,
            'refund_total'             => $refundTotal,
        ];
    }

    public function getRecentNotices(int $limit = 5): array
    {
        return $this->raw(
            "SELECT * FROM notices WHERE is_active = 1 ORDER BY created_at DESC LIMIT :limit",
            ['limit' => $limit]
        );
    }

    public function getUpcomingExams(int $limit = 5): array
    {
        $sessionId = Session::get('active_session_id');
        return $this->raw(
            "SELECT e.*, c.name as class_name FROM exams e 
             JOIN classes c ON e.class_id = c.id 
             WHERE e.session_id = :sid AND e.status IN ('Upcoming', 'Ongoing')
             ORDER BY e.start_date ASC LIMIT :limit",
            ['sid' => $sessionId ?? 0, 'limit' => $limit]
        );
    }

    public function getMonthlyFeeChart(int $sessionId): array
    {
        return $this->raw(
            "SELECT DATE_FORMAT(payment_date, '%b') as month, SUM(paid_amount) as total 
             FROM fee_collections WHERE session_id = :sid AND status = 'Paid'
             GROUP BY MONTH(payment_date), DATE_FORMAT(payment_date, '%b') ORDER BY MONTH(payment_date)",
            ['sid' => $sessionId]
        );
    }

    public function getMonthlyAttendanceChart(int $sessionId): array
    {
        return $this->raw(
            "SELECT DATE_FORMAT(date, '%b') as month,
                    SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present,
                    COUNT(*) as total
             FROM student_attendance WHERE session_id = :sid
             GROUP BY MONTH(date), DATE_FORMAT(date, '%b') ORDER BY MONTH(date)",
            ['sid' => $sessionId]
        );
    }
}
