<?php
/**
 * Audit Log Model
 */
class Audit extends Model
{
    public string $table = 'audit_logs';

    public static function log(string $module, string $action, ?int $recordId = null, ?array $newData = null, ?array $oldData = null): void
    {
        try {
            $audit = new self();
            $audit->create([
                'user_id' => Session::get('user_id'),
                'module' => $module,
                'action' => $action,
                'record_id' => $recordId,
                'old_data' => $oldData ? json_encode($oldData) : null,
                'new_data' => $newData ? json_encode($newData) : null,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            ]);
        } catch (Exception $e) {
            error_log("Audit log failed: " . $e->getMessage());
        }
    }

    public function getFiltered(array $filters = [], int $page = 1, int $perPage = 25): array
    {
        $where = '1=1';
        $params = [];

        if (!empty($filters['module'])) {
            $where .= ' AND module = :module';
            $params['module'] = $filters['module'];
        }
        if (!empty($filters['action'])) {
            $where .= ' AND action = :action';
            $params['action'] = $filters['action'];
        }
        if (!empty($filters['user_id'])) {
            $where .= ' AND user_id = :user_id';
            $params['user_id'] = $filters['user_id'];
        }
        if (!empty($filters['date_from'])) {
            $where .= ' AND DATE(a.created_at) >= :date_from';
            $params['date_from'] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where .= ' AND DATE(a.created_at) <= :date_to';
            $params['date_to'] = $filters['date_to'];
        }

        $offset = ($page - 1) * $perPage;
        $countSql = "SELECT COUNT(*) as total FROM audit_logs a WHERE $where";
        $total = (int) $this->rawOne($countSql, $params)['total'];

        $sql = "SELECT a.*, u.full_name as user_name 
                FROM audit_logs a 
                LEFT JOIN users u ON a.user_id = u.id 
                WHERE $where 
                ORDER BY a.created_at DESC 
                LIMIT $perPage OFFSET $offset";
        $data = $this->raw($sql, $params);

        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage),
        ];
    }
}
