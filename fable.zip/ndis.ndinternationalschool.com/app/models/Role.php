<?php
class Role extends Model
{
    public string $table = 'roles';
    public function getRolesWithUserCount(): array
    {
        return $this->raw("SELECT r.*, (SELECT COUNT(*) FROM users WHERE role_id = r.id) as user_count FROM roles r ORDER BY r.id");
    }
    public function updatePermissions(int $roleId, array $permissions): void
    {
        $this->query("DELETE FROM role_permissions WHERE role_id = :rid", ['rid' => $roleId]);
        foreach ($permissions as $perm) {
            $model = new Model(); $model->table = 'role_permissions';
            $model->create(['role_id' => $roleId, 'permission_name' => $perm]);
        }
    }
}