<?php
class Communication extends Model
{
    public string $table = 'notices';
    public function getActiveNotices(string $audience = 'All'): array
    {
        $sql = "SELECT * FROM notices WHERE is_active = 1 AND (target_audience = 'All' OR target_audience = :aud) ORDER BY created_at DESC";
        return $this->raw($sql, ['aud' => $audience]);
    }
    public function getMessages(int $userId, string $type = 'inbox'): array
    {
        if ($type === 'inbox') return $this->raw("SELECT m.*, u.full_name as sender_name FROM messages m JOIN users u ON m.sender_id = u.id WHERE m.receiver_id = :uid ORDER BY m.created_at DESC", ['uid' => $userId]);
        return $this->raw("SELECT m.*, u.full_name as receiver_name FROM messages m JOIN users u ON m.receiver_id = u.id WHERE m.sender_id = :uid ORDER BY m.created_at DESC", ['uid' => $userId]);
    }
    public function sendMessage(int $senderId, int $receiverId, string $subject, string $message): int
    {
        $msgModel = new Model(); $msgModel->table = 'messages';
        return $msgModel->create(['sender_id' => $senderId, 'receiver_id' => $receiverId, 'subject' => $subject, 'message' => $message]);
    }
}