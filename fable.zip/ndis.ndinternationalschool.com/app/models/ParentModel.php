<?php
class ParentModel extends Model
{
    public string $table = 'parents';

    public function findByStudentId(int $studentId): ?array
    {
        $sql = "SELECT p.* FROM parents p JOIN students s ON s.parent_id = p.id WHERE s.id = :sid LIMIT 1";
        return $this->rawOne($sql, ['sid' => $studentId]);
    }

    public function getAllParents(int $page = 1, int $perPage = 20, string $search = ''): array
    {
        $where  = '1=1';
        $params = [];

        if ($search) {
            $where .= " AND (p.father_name LIKE :s OR p.mother_name LIKE :s OR p.father_phone LIKE :s OR p.father_email LIKE :s)";
            $params['s'] = "%$search%";
        }

        $offset = ($page - 1) * $perPage;
        $total  = (int)($this->rawOne("SELECT COUNT(*) as total FROM parents p WHERE $where", $params)['total'] ?? 0);

        $sql = "SELECT p.*,
                       u.email as login_email,
                       u.is_active as login_active,
                       COUNT(s.id) as children_count
                FROM parents p
                LEFT JOIN users u ON p.user_id = u.id
                LEFT JOIN students s ON s.parent_id = p.id
                WHERE $where
                GROUP BY p.id
                ORDER BY p.father_name ASC
                LIMIT $perPage OFFSET $offset";

        return [
            'data'        => $this->raw($sql, $params),
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => ceil($total / $perPage),
        ];
    }

    public function getWithChildren(int $parentId): ?array
    {
        $parent = $this->rawOne(
            "SELECT p.*, u.email as login_email, u.is_active as login_active
             FROM parents p LEFT JOIN users u ON p.user_id = u.id
             WHERE p.id = :id",
            ['id' => $parentId]
        );
        if (!$parent) return null;

        $parent['children'] = $this->raw(
            "SELECT s.*, c.name as class_name, sec.name as section_name
             FROM students s
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             WHERE s.parent_id = :pid ORDER BY s.first_name",
            ['pid' => $parentId]
        );
        return $parent;
    }
}
