<?php
/**
 * Transport Model
 * Handles all transport-related database operations
 */
class Transport extends Model
{
    public string $table = 'transport_routes';

    // ─── Routes ────────────────────────────────────────────────────────────────

    public function getAllRoutes(): array
    {
        try {
            return $this->raw(
                "SELECT r.*, v.vehicle_number AS vehicle_number, v.vehicle_name, v.driver_name, v.driver_phone,
                        COUNT(DISTINCT p.id) as pickup_count,
                        COUNT(DISTINCT sa.id) as student_count
                 FROM transport_routes r
                 LEFT JOIN transport_vehicles v            ON r.vehicle_id = v.id
                 LEFT JOIN transport_pickup_points p       ON p.route_id   = r.id
                 LEFT JOIN student_transport_assignments sa ON sa.route_id = r.id
                 GROUP BY r.id
                 ORDER BY r.name"
            );
        } catch (\Exception $e) {
            // Fallback when new transport tables haven't been created yet
            return $this->raw(
                "SELECT r.*, r.vehicle_number, r.driver_name, r.driver_phone,
                        NULL as vehicle_name, 0 as pickup_count, 0 as student_count
                 FROM transport_routes r
                 ORDER BY r.name"
            );
        }
    }

    public function getRouteById(int $id): ?array
    {
        return $this->rawOne(
            "SELECT r.*, v.vehicle_number, v.vehicle_name, v.driver_name, v.driver_phone
             FROM transport_routes r
             LEFT JOIN transport_vehicles v ON r.vehicle_id = v.id
             WHERE r.id = :id",
            ['id' => $id]
        );
    }

    public function saveRoute(array $data): int|bool
    {
        if (!empty($data['id'])) {
            $id = (int) $data['id'];
            unset($data['id']);
            $this->update($id, $data);
            return $id;
        }
        unset($data['id']);
        return $this->create($data);
    }

    public function deleteRoute(int $id): void
    {
        $this->query("DELETE FROM transport_routes WHERE id = :id", ['id' => $id]);
    }

    // ─── Vehicles ──────────────────────────────────────────────────────────────

    public function getAllVehicles(): array
    {
        return $this->raw(
            "SELECT v.*, r.name as route_name
             FROM transport_vehicles v
             LEFT JOIN transport_routes r ON r.vehicle_id = v.id
             ORDER BY v.vehicle_name"
        );
    }

    public function getVehicleById(int $id): ?array
    {
        $m = new Model();
        $m->table = 'transport_vehicles';
        return $m->findById($id);
    }

    public function getVehicleByNumber(string $number): ?array
    {
        if (empty($number)) return null;
        $m = new Model();
        $m->table = 'transport_vehicles';
        return $m->findBy('vehicle_number', $number);
    }

    public function saveVehicle(array $data): int|bool
    {
        $m = new Model();
        $m->table = 'transport_vehicles';
        if (!empty($data['id'])) {
            $id = (int) $data['id'];
            unset($data['id']);
            $m->update($id, $data);
            return $id;
        }
        unset($data['id']);
        return $m->create($data);
    }

    public function deleteVehicle(int $id): void
    {
        $this->query("DELETE FROM transport_vehicles WHERE id = :id", ['id' => $id]);
    }

    // ─── Pickup Points ─────────────────────────────────────────────────────────

    public function getPickupPoints(?int $routeId = null): array
    {
        $where = $routeId ? "WHERE p.route_id = :rid" : "";
        $params = $routeId ? ['rid' => $routeId] : [];
        return $this->raw(
            "SELECT p.*, r.name as route_name
             FROM transport_pickup_points p
             LEFT JOIN transport_routes r ON p.route_id = r.id
             $where
             ORDER BY r.name, p.stop_order, p.name",
            $params
        );
    }

    public function savePickupPoint(array $data): int|bool
    {
        $m = new Model();
        $m->table = 'transport_pickup_points';
        if (!empty($data['id'])) {
            $id = (int) $data['id'];
            unset($data['id']);
            $m->update($id, $data);
            return $id;
        }
        unset($data['id']);
        return $m->create($data);
    }

    public function deletePickupPoint(int $id): void
    {
        $this->query("DELETE FROM transport_pickup_points WHERE id = :id", ['id' => $id]);
    }

    // ─── Student Assignments ───────────────────────────────────────────────────

    public function getStudentAssignments(int $sessionId, ?int $routeId = null): array
    {
        $where = $routeId ? "AND sa.route_id = :rid" : "";
        $params = ['sid' => $sessionId];
        if ($routeId) $params['rid'] = $routeId;

        return $this->raw(
            "SELECT sa.*, CONCAT(s.first_name, ' ', COALESCE(s.last_name, '')) as student_name, s.admission_number,
                    c.name as class_name, sec.name as section_name,
                    r.name as route_name, p.name as pickup_point_name,
                    r.fare as route_fare
             FROM student_transport_assignments sa
             JOIN students s ON sa.student_id = s.id
             JOIN transport_routes r ON sa.route_id = r.id
             LEFT JOIN transport_pickup_points p ON sa.pickup_point_id = p.id
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             WHERE sa.session_id = :sid $where
             ORDER BY r.name, s.first_name",
            $params
        );
    }

    public function getStudentAssignment(int $studentId, int $sessionId): ?array
    {
        return $this->rawOne(
            "SELECT sa.*, r.name as route_name, r.fare, p.name as pickup_point_name
             FROM student_transport_assignments sa
             JOIN transport_routes r ON sa.route_id = r.id
             LEFT JOIN transport_pickup_points p ON sa.pickup_point_id = p.id
             WHERE sa.student_id = :sid AND sa.session_id = :sess",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
    }

    public function saveStudentAssignment(array $data): int|bool
    {
        $m = new Model();
        $m->table = 'student_transport_assignments';

        // Check if already assigned
        $existing = $this->rawOne(
            "SELECT id FROM student_transport_assignments WHERE student_id = :sid AND session_id = :sess",
            ['sid' => $data['student_id'], 'sess' => $data['session_id']]
        );

        if ($existing) {
            $id = (int) $existing['id'];
            $m->update($id, $data);
            return $id;
        }
        return $m->create($data);
    }

    public function deleteStudentAssignment(int $id): void
    {
        $this->query("DELETE FROM student_transport_assignments WHERE id = :id", ['id' => $id]);
    }

    // ─── Transport Fees ────────────────────────────────────────────────────────

    public function getTransportFees(int $sessionId): array
    {
        $sql = "SELECT tf.*, CONCAT(s.first_name, ' ', COALESCE(s.last_name, '')) as student_name, s.admission_number,
                    r.name as route_name, r.fare as route_fare,
                    c.name as class_name,
                    COALESCE(tf.fee_type, 'Other') as fee_type
             FROM transport_fees tf
             JOIN students s ON tf.student_id = s.id
             JOIN transport_routes r ON tf.route_id = r.id
             LEFT JOIN classes c ON s.class_id = c.id
             WHERE tf.session_id = :sid
             ORDER BY tf.payment_date DESC";
        try {
            return $this->raw($sql, ['sid' => $sessionId]);
        } catch (\Exception $e) {
            // fee_type column not yet added — fall back without it
            if (strpos($e->getMessage(), 'fee_type') !== false) {
                return $this->raw(
                    "SELECT tf.*, CONCAT(s.first_name, ' ', COALESCE(s.last_name, '')) as student_name, s.admission_number,
                            r.name as route_name, r.fare as route_fare,
                            c.name as class_name,
                            'Other' as fee_type
                     FROM transport_fees tf
                     JOIN students s ON tf.student_id = s.id
                     JOIN transport_routes r ON tf.route_id = r.id
                     LEFT JOIN classes c ON s.class_id = c.id
                     WHERE tf.session_id = :sid
                     ORDER BY tf.payment_date DESC",
                    ['sid' => $sessionId]
                );
            }
            throw $e;
        }
    }

    public function collectTransportFee(array $data): int
    {
        $this->beginTransaction();
        try {
            $m = new Model();
            $m->table = 'transport_fees';
            $id = $m->create($data);

            // Update cash or bank ledger so this payment is reflected in
            // Cash & Bank Accounting and the Dashboard balances.
            $accountingModel = new Accounting();
            $paymentMethod = $data['payment_method'] ?? 'Cash';
            $paidAmount    = (float) ($data['paid_amount'] ?? 0);
            $description   = 'Transport Fee Collection' . (!empty($data['receipt_number']) ? ' - Receipt #' . $data['receipt_number'] : '');

            if ($paymentMethod === 'Cash') {
                $accountingModel->addCashCredit($paidAmount, $description, $data['payment_date'], $data['collected_by'] ?? null);
            } else {
                $accountingModel->addBankCredit($data['bank_account_id'] ?? null, $paidAmount, $description, $data['payment_date'], $data['collected_by'] ?? null);
            }

            // Record in the consolidated transactions log. Note: transport_fees
            // uses payment methods Cash/Online/Cheque/DD, while the shared
            // `transactions` table only accepts Cash/Bank Transfer/Cheque/UPI/Card —
            // map to the closest equivalent so the insert doesn't fail.
            $transMethodMap = ['Cash' => 'Cash', 'Online' => 'Bank Transfer', 'Cheque' => 'Cheque', 'DD' => 'Cheque'];
            $transModel = new Model();
            $transModel->table = 'transactions';
            $transModel->create([
                'type' => 'Fee Collection', 'category' => 'Transport Fee', 'reference_id' => $id,
                'reference_type' => 'transport_fee',
                'amount' => $paidAmount, 'payment_method' => $transMethodMap[$paymentMethod] ?? 'Cash',
                'bank_account_id' => $data['bank_account_id'] ?? null,
                'description' => $description . ' (' . $paymentMethod . ')',
                'transaction_date' => $data['payment_date'], 'created_by' => $data['collected_by'] ?? null
            ]);

            $this->commit();
            return $id;
        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    public function getTransportFeeStats(int $sessionId): array
    {
        $row = $this->rawOne(
            "SELECT
                COUNT(DISTINCT sa.student_id) as total_students,
                COALESCE(SUM(r.fare), 0) as total_expected,
                COALESCE((SELECT SUM(tf.amount) FROM transport_fees tf WHERE tf.session_id = :sid2), 0) as total_collected
             FROM student_transport_assignments sa
             JOIN transport_routes r ON sa.route_id = r.id
             WHERE sa.session_id = :sid",
            ['sid' => $sessionId, 'sid2' => $sessionId]
        );
        return $row ?? ['total_students' => 0, 'total_expected' => 0, 'total_collected' => 0];
    }

    // ─── Fee Rates (Dinod / Other / Custom) ───────────────────────────────────

    public function getFeeRates(): array
    {
        return $this->raw(
            "SELECT * FROM transport_fee_rates ORDER BY FIELD(fee_type,'Dinod','Other','Custom')"
        );
    }

    public function getFeeRateByType(string $type): ?array
    {
        return $this->rawOne(
            "SELECT * FROM transport_fee_rates WHERE fee_type = :type",
            ['type' => $type]
        );
    }

    public function saveFeeRate(array $data): int|bool
    {
        $m = new Model();
        $m->table = 'transport_fee_rates';
        if (!empty($data['id'])) {
            $id = (int) $data['id'];
            unset($data['id']);
            $m->update($id, $data);
            return $id;
        }
        unset($data['id']);
        return $m->create($data);
    }

    public function deleteFeeRate(int $id): void
    {
        $this->query("DELETE FROM transport_fee_rates WHERE id = :id", ['id' => $id]);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    public function getRouteWithPickupPoints(int $routeId): array
    {
        $route = $this->getRouteById($routeId);
        $pickupPoints = $this->getPickupPoints($routeId);
        return ['route' => $route, 'pickup_points' => $pickupPoints];
    }

    // ─── Reports ───────────────────────────────────────────────────────────────

    public function getRouteSummaryReport(int $sessionId): array
    {
        return $this->raw(
            "SELECT r.id, r.name as route_name, r.fare,
                    v.vehicle_name, v.vehicle_number, v.capacity,
                    COUNT(DISTINCT p.id) as total_stops,
                    COUNT(DISTINCT sa.id) as total_students,
                    COALESCE(SUM(tf.paid_amount), 0) as total_collected
             FROM transport_routes r
             LEFT JOIN transport_vehicles v ON r.vehicle_id = v.id
             LEFT JOIN transport_pickup_points p ON p.route_id = r.id
             LEFT JOIN student_transport_assignments sa ON sa.route_id = r.id AND sa.session_id = :sid
             LEFT JOIN transport_fees tf ON tf.route_id = r.id AND tf.session_id = :sid2
             WHERE r.is_active = 1
             GROUP BY r.id, r.name, r.fare, v.vehicle_name, v.vehicle_number, v.capacity
             ORDER BY r.name",
            ['sid' => $sessionId, 'sid2' => $sessionId]
        );
    }

    public function getTransportFeeReport(int $sessionId): array
    {
        return $this->raw(
            "SELECT CONCAT(s.first_name, ' ', COALESCE(s.last_name, '')) as student_name, s.admission_number,
                    c.name as class_name, sec.name as section_name,
                    r.name as route_name, r.fare as route_fare,
                    COALESCE(SUM(tf.paid_amount), 0) as paid,
                    COALESCE(SUM(tf.fine), 0) as total_fine,
                    COALESCE(SUM(tf.discount), 0) as total_discount,
                    sa.transport_type
             FROM student_transport_assignments sa
             JOIN students s ON sa.student_id = s.id
             JOIN transport_routes r ON sa.route_id = r.id
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             LEFT JOIN transport_fees tf ON tf.student_id = sa.student_id AND tf.session_id = sa.session_id
             WHERE sa.session_id = :sid
             GROUP BY s.id, s.first_name, s.last_name, s.admission_number, c.name, sec.name, r.name, r.fare, sa.transport_type
             ORDER BY r.name, s.first_name",
            ['sid' => $sessionId]
        );
    }

    public function getUnassignedStudents(int $sessionId): array
    {
        return $this->raw(
            "SELECT s.id, CONCAT(s.first_name, ' ', COALESCE(s.last_name, '')) as student_name, s.admission_number, c.name as class_name, sec.name as section_name
             FROM students s
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             LEFT JOIN student_transport_assignments sa ON sa.student_id = s.id AND sa.session_id = :sid
             WHERE s.status = 'active' AND sa.id IS NULL
             ORDER BY c.name, s.first_name",
            ['sid' => $sessionId]
        );
    }

    public function getVehicleReport(): array
    {
        return $this->raw(
            "SELECT v.*,
                    r.name as assigned_route,
                    COUNT(DISTINCT sa.id) as student_count
             FROM transport_vehicles v
             LEFT JOIN transport_routes r ON r.vehicle_id = v.id
             LEFT JOIN student_transport_assignments sa ON sa.route_id = r.id
             GROUP BY v.id
             ORDER BY v.vehicle_name"
        );
    }
}
