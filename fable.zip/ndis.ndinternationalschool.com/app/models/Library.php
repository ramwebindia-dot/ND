<?php
class Library extends Model
{
    public string $table = 'books';

    public function getBooksWithCategory(): array
    {
        return $this->raw("SELECT b.*, bc.name as category_name FROM books b LEFT JOIN book_categories bc ON b.category_id = bc.id ORDER BY b.title ASC");
    }

    public function issueBook(int $bookId, int $studentId, string $issueDate, string $dueDate, int $issuedBy): int
    {
        $this->beginTransaction();
        try {
            $issueModel = new Model();
            $issueModel->table = 'book_issues';
            $id = $issueModel->create(['book_id' => $bookId, 'student_id' => $studentId, 'issue_date' => $issueDate, 'due_date' => $dueDate, 'status' => 'Issued', 'issued_by' => $issuedBy]);

            $book = $this->findById($bookId);
            if ($book) {
                $this->update($bookId, ['available_quantity' => max(0, (int)$book['available_quantity'] - 1)]);
            }

            $this->commit();
            return $id;
        } catch (Exception $e) { $this->rollBack(); throw $e; }
    }

    public function returnBook(int $issueId, float $fineAmount = 0): bool
    {
        $issueModel = new Model();
        $issueModel->table = 'book_issues';
        $issue = $issueModel->findById($issueId);
        if (!$issue) return false;

        $issueModel->update($issueId, ['return_date' => date('Y-m-d'), 'fine_amount' => $fineAmount, 'status' => 'Returned']);

        $book = $this->findById($issue['book_id']);
        if ($book) {
            $this->update($issue['book_id'], ['available_quantity' => (int)$book['available_quantity'] + 1]);
        }
        return true;
    }

    public function getIssuedBooks(int $page = 1, int $perPage = 20): array
    {
        $offset = ($page - 1) * $perPage;
        $total = (int) $this->rawOne("SELECT COUNT(*) as total FROM book_issues WHERE status = 'Issued'")['total'];
        $data = $this->raw("SELECT bi.*, b.title as book_title, s.first_name, s.last_name, s.admission_number
            FROM book_issues bi JOIN books b ON bi.book_id = b.id JOIN students s ON bi.student_id = s.id
            WHERE bi.status = 'Issued' ORDER BY bi.due_date ASC LIMIT $perPage OFFSET $offset");
        return ['data' => $data, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'total_pages' => ceil($total / $perPage)];
    }

    public function getOverdueBooks(): array
    {
        return $this->raw("SELECT bi.*, b.title as book_title, s.first_name, s.last_name, s.admission_number
            FROM book_issues bi JOIN books b ON bi.book_id = b.id JOIN students s ON bi.student_id = s.id
            WHERE bi.status = 'Issued' AND bi.due_date < CURDATE() ORDER BY bi.due_date ASC");
    }
}