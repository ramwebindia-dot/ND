<?php
class Accounting extends Model
{
    public string $table = 'transactions';

    public function addCashCredit(float $amount, string $description, string $date, ?int $createdBy = null): void
    {
        $currentBalance = $this->getCashBalance();
        $newBalance = $currentBalance + $amount;
        $ledgerModel = new Model();
        $ledgerModel->table = 'cash_ledger';
        $ledgerModel->create([
            'transaction_type' => 'Credit', 'amount' => $amount, 'balance_after' => $newBalance,
            'description' => $description, 'transaction_date' => $date, 'created_by' => $createdBy
        ]);
    }

    public function addCashDebit(float $amount, string $description, string $date, ?int $createdBy = null): void
    {
        $currentBalance = $this->getCashBalance();
        $newBalance = $currentBalance - $amount;
        $ledgerModel = new Model();
        $ledgerModel->table = 'cash_ledger';
        $ledgerModel->create([
            'transaction_type' => 'Debit', 'amount' => $amount, 'balance_after' => $newBalance,
            'description' => $description, 'transaction_date' => $date, 'created_by' => $createdBy
        ]);
    }

    public function addBankCredit(?int $bankAccountId, float $amount, string $description, string $date, ?int $createdBy = null): void
    {
        if (!$bankAccountId) return;
        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $account = $bankModel->findById($bankAccountId);
        if (!$account) return;
        $newBalance = (float)$account['balance'] + $amount;
        $bankModel->update($bankAccountId, ['balance' => $newBalance]);

        $ledgerModel = new Model();
        $ledgerModel->table = 'bank_ledger';
        $ledgerModel->create([
            'bank_account_id' => $bankAccountId, 'transaction_type' => 'Credit', 'amount' => $amount,
            'balance_after' => $newBalance, 'description' => $description,
            'transaction_date' => $date, 'created_by' => $createdBy
        ]);
    }

    public function addBankDebit(?int $bankAccountId, float $amount, string $description, string $date, ?int $createdBy = null): void
    {
        if (!$bankAccountId) return;
        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $account = $bankModel->findById($bankAccountId);
        if (!$account) return;
        $newBalance = (float)$account['balance'] - $amount;
        $bankModel->update($bankAccountId, ['balance' => $newBalance]);

        $ledgerModel = new Model();
        $ledgerModel->table = 'bank_ledger';
        $ledgerModel->create([
            'bank_account_id' => $bankAccountId, 'transaction_type' => 'Debit', 'amount' => $amount,
            'balance_after' => $newBalance, 'description' => $description,
            'transaction_date' => $date, 'created_by' => $createdBy
        ]);
    }

    public function getCashBalance(): float
    {
        $result = $this->rawOne("SELECT COALESCE(balance_after, 0) as balance FROM cash_ledger ORDER BY id DESC LIMIT 1");
        return (float) ($result['balance'] ?? 0);
    }

    public function getBankBalance(int $bankAccountId): float
    {
        $result = $this->rawOne("SELECT balance FROM bank_accounts WHERE id = :id", ['id' => $bankAccountId]);
        return (float) ($result['balance'] ?? 0);
    }

    public function getTotalBankBalance(): float
    {
        $result = $this->rawOne("SELECT COALESCE(SUM(balance), 0) as total FROM bank_accounts WHERE is_active = 1");
        return (float) ($result['total'] ?? 0);
    }

    public function getCashBook(string $dateFrom, string $dateTo): array
    {
        return $this->raw("SELECT * FROM cash_ledger WHERE transaction_date BETWEEN :from AND :to ORDER BY transaction_date, id", ['from' => $dateFrom, 'to' => $dateTo]);
    }

    public function getBankBook(int $bankAccountId, string $dateFrom, string $dateTo): array
    {
        return $this->raw("SELECT * FROM bank_ledger WHERE bank_account_id = :aid AND transaction_date BETWEEN :from AND :to ORDER BY transaction_date, id", ['aid' => $bankAccountId, 'from' => $dateFrom, 'to' => $dateTo]);
    }

    public function getIncomeSummary(string $dateFrom, string $dateTo): array
    {
        return $this->raw("SELECT * FROM income WHERE income_date BETWEEN :from AND :to ORDER BY income_date DESC", ['from' => $dateFrom, 'to' => $dateTo]);
    }

    public function getExpenseSummary(string $dateFrom, string $dateTo): array
    {
        return $this->raw("SELECT * FROM expenses WHERE expense_date BETWEEN :from AND :to ORDER BY expense_date DESC", ['from' => $dateFrom, 'to' => $dateTo]);
    }

    public function getFinancialSummary(string $dateFrom, string $dateTo): array
    {
        $income = (float) ($this->rawOne("SELECT COALESCE(SUM(amount), 0) as total FROM income WHERE income_date BETWEEN :from AND :to", ['from' => $dateFrom, 'to' => $dateTo])['total'] ?? 0);
        $expense = (float) ($this->rawOne("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date BETWEEN :from AND :to", ['from' => $dateFrom, 'to' => $dateTo])['total'] ?? 0);
        $feeCollected = (float) ($this->rawOne("SELECT COALESCE(SUM(paid_amount), 0) as total FROM fee_collections WHERE payment_date BETWEEN :from AND :to AND status = 'Paid'", ['from' => $dateFrom, 'to' => $dateTo])['total'] ?? 0);
        $refunds = (float) ($this->rawOne("SELECT COALESCE(SUM(amount), 0) as total FROM fee_refunds WHERE status = 'Processed' AND created_at BETWEEN :from AND :to", ['from' => $dateFrom . ' 00:00:00', 'to' => $dateTo . ' 23:59:59'])['total'] ?? 0);

        return ['total_income' => $income + $feeCollected, 'total_expenses' => $expense + $refunds, 'net_income' => ($income + $feeCollected) - ($expense + $refunds), 'fee_collected' => $feeCollected, 'refunds' => $refunds, 'other_income' => $income, 'other_expenses' => $expense];
    }
}