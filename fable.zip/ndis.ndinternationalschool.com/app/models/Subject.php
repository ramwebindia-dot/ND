<?php
class Subject extends Model { public string $table = 'subjects'; public function getAllSubjects(): array { return $this->findAll('name', 'ASC'); } }
