<?php
/**
 * Settings Model
 */
class Settings extends Model
{
    public string $table = 'settings';

    public function get(string $key, $default = null)
    {
        $result = $this->findBy('setting_key', $key);
        return $result ? $result['setting_value'] : $default;
    }

    public function set(string $key, $value): void
    {
        $existing = $this->findBy('setting_key', $key);
        if ($existing) {
            $this->update($existing['id'], ['setting_value' => $value]);
        } else {
            $this->create(['setting_key' => $key, 'setting_value' => $value]);
        }
    }

    public function getAll(): array
    {
        $results = $this->findAll();
        $settings = [];
        foreach ($results as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    }

    public function updateSettings(array $data): void
    {
        foreach ($data as $key => $value) {
            $this->set($key, $value);
        }
    }
}
