<?php
/**
 * User Model
 */
class User extends Model
{
    public string $table = 'users';

    public function findByEmail(string $email): ?array
    {
        $sql = "SELECT u.*, r.name as role_name FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.email = :email LIMIT 1";
        return $this->rawOne($sql, ['email' => $email]);
    }

    public function findByUsername(string $username): ?array
    {
        $sql = "SELECT u.*, r.name as role_name FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.username = :username LIMIT 1";
        return $this->rawOne($sql, ['username' => $username]);
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT u.*, r.name as role_name FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.id = :id LIMIT 1";
        return $this->rawOne($sql, ['id' => $id]);
    }

    public function createUser(array $data): int
    {
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        $data['created_at'] = date('Y-m-d H:i:s');
        return $this->create($data);
    }

    public function getAllWithRoles(): array
    {
        $sql = "SELECT u.*, r.name as role_name FROM users u 
                JOIN roles r ON u.role_id = r.id 
                ORDER BY u.created_at DESC";
        return $this->raw($sql);
    }

    public function updateLastLogin(int $id): void
    {
        $this->update($id, ['last_login' => date('Y-m-d H:i:s')]);
    }

    public function getByRole(string $roleName): array
    {
        $sql = "SELECT u.* FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = :role";
        return $this->raw($sql, ['role' => $roleName]);
    }

    // ── Password Reset ──────────────────────────────────────────────

    public function createResetToken(int $userId): string
    {
        // Invalidate old tokens for this user
        $this->query("UPDATE password_reset_tokens SET used = 1 WHERE user_id = :uid", ['uid' => $userId]);

        $token = bin2hex(random_bytes(32)); // 64-char hex
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $this->query(
            "INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (:uid, :token, :expires)",
            ['uid' => $userId, 'token' => $token, 'expires' => $expires]
        );

        return $token;
    }

    public function findValidResetToken(string $token): ?array
    {
        $sql = "SELECT prt.*, u.email, u.full_name
                FROM password_reset_tokens prt
                JOIN users u ON prt.user_id = u.id
                WHERE prt.token = :token
                  AND prt.used = 0
                  AND prt.expires_at > NOW()
                LIMIT 1";
        return $this->rawOne($sql, ['token' => $token]);
    }

    public function markTokenUsed(string $token): void
    {
        $this->query("UPDATE password_reset_tokens SET used = 1 WHERE token = :token", ['token' => $token]);
    }

    public function resetPassword(int $userId, string $newPassword): void
    {
        $hashed = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        $this->update($userId, ['password' => $hashed]);
        // Invalidate all tokens after reset
        $this->query("UPDATE password_reset_tokens SET used = 1 WHERE user_id = :uid", ['uid' => $userId]);
    }

    // ── Brute-Force Protection ──────────────────────────────────────

    public function recordLoginAttempt(string $email, string $ip): void
    {
        $this->query(
            "INSERT INTO login_attempts (email, ip_address) VALUES (:email, :ip)",
            ['email' => $email, 'ip' => $ip]
        );
    }

    public function getRecentAttempts(string $email, string $ip, int $minutes): int
    {
        $sql = "SELECT COUNT(*) as cnt FROM login_attempts
                WHERE (email = :email OR ip_address = :ip)
                  AND attempted_at > DATE_SUB(NOW(), INTERVAL :mins MINUTE)";
        $result = $this->rawOne($sql, ['email' => $email, 'ip' => $ip, 'mins' => $minutes]);
        return (int) ($result['cnt'] ?? 0);
    }

    public function clearLoginAttempts(string $email, string $ip): void
    {
        $this->query(
            "DELETE FROM login_attempts WHERE email = :email OR ip_address = :ip",
            ['email' => $email, 'ip' => $ip]
        );
    }
}
