<?php
/**
 * Fee Model — Ledger-based Fee Management
 * Single source of truth: fee_ledger
 * All balances calculated dynamically — never stored.
 */
class Fee extends Model
{
    public string $table = 'fee_categories';

    // ═══════════════════════════════════════════════════════════════
    // SECTION 1 — FEE HEADS
    // ═══════════════════════════════════════════════════════════════

    public function getHeads(bool $activeOnly = true): array
    {
        $where = $activeOnly ? 'WHERE is_active = 1' : '';
        return $this->raw(
            "SELECT * FROM fee_categories $where ORDER BY sort_order, name"
        );
    }

    public function saveHead(array $d): int
    {
        $id = (int)($d['id'] ?? 0);
        $data = [
            'name'        => trim($d['name']),
            'description' => trim($d['description'] ?? ''),
            'head_type'   => $d['head_type'] ?? 'Custom',
            'sort_order'  => (int)($d['sort_order'] ?? 0),
            'is_mandatory'=> !empty($d['is_mandatory']) ? 1 : 0,
            'is_active'   => 1,
        ];
        if ($id) {
            $m = new Model(); $m->table = 'fee_categories';
            $m->update($id, $data);
            return $id;
        }
        $m = new Model(); $m->table = 'fee_categories';
        return $m->create($data);
    }

    public function deleteHead(int $id): void
    {
        $used = $this->rawOne(
            "SELECT COUNT(*) AS c FROM fee_structures WHERE fee_category_id = :id", ['id' => $id]
        );
        if ((int)($used['c'] ?? 0) > 0) {
            throw new RuntimeException('Fee head is in use by fee structures and cannot be deleted.');
        }
        $m = new Model(); $m->table = 'fee_categories';
        $m->update($id, ['is_active' => 0]);
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 2 — FEE STRUCTURES (Class × Session × Head = Amount)
    // ═══════════════════════════════════════════════════════════════

    public function getStructures(int $sessionId): array
    {
        return $this->raw(
            "SELECT fs.*, c.name AS class_name, fc.name AS head_name, fc.head_type
             FROM fee_structures fs
             JOIN classes c ON fs.class_id = c.id
             JOIN fee_categories fc ON fs.fee_category_id = fc.id
             WHERE fs.session_id = :sid
             ORDER BY c.numeric_value, fc.sort_order, fc.name",
            ['sid' => $sessionId]
        );
    }

    public function getClassStructure(int $classId, int $sessionId): array
    {
        return $this->raw(
            "SELECT fs.*, fc.name AS head_name, fc.head_type, fc.is_mandatory
             FROM fee_structures fs
             JOIN fee_categories fc ON fs.fee_category_id = fc.id
             WHERE fs.class_id = :cid AND fs.session_id = :sid AND fc.is_active = 1
             ORDER BY fc.sort_order, fc.name",
            ['cid' => $classId, 'sid' => $sessionId]
        );
    }

    /** Active transport fee rates (Dinod / Other / Custom) set in the Transport section.
     *  These appear as selectable options on the Collect Fee screen. */
    public function getTransportRates(): array
    {
        return $this->raw(
            "SELECT id, fee_type, label, amount
             FROM transport_fee_rates
             WHERE is_active = 1 ORDER BY amount"
        );
    }

    public function saveStructure(array $d): int
    {
        $id = (int)($d['id'] ?? 0);
        $data = [
            'class_id'        => (int)$d['class_id'],
            'session_id'      => (int)$d['session_id'],
            'fee_category_id' => (int)$d['fee_category_id'],
            'amount'          => (float)$d['amount'],
            'frequency'       => $d['frequency'] ?? 'Monthly',
        ];
        $m = new Model(); $m->table = 'fee_structures';
        if ($id) { $m->update($id, $data); return $id; }
        return $m->create($data);
    }

    public function deleteStructure(int $id): void
    {
        $m = new Model(); $m->table = 'fee_structures';
        $m->delete($id);
    }

    /** Monthly amount for a specific head + class + session. */
    public function getMonthlyAmount(int $classId, int $sessionId, int $categoryId): float
    {
        $row = $this->rawOne(
            "SELECT amount, frequency FROM fee_structures
             WHERE class_id=:cid AND session_id=:sid AND fee_category_id=:cat LIMIT 1",
            ['cid' => $classId, 'sid' => $sessionId, 'cat' => $categoryId]
        );
        if (!$row) return 0.0;
        return (float)$row['amount'];
    }

    /** Get all months in a session. */
    public function getSessionMonths(int $sessionId): array
    {
        $m = new Model(); $m->table = 'academic_sessions';
        $session = $m->findById($sessionId);
        if (!$session) return [];
        $months = [];
        $cur = new DateTime($session['start_date']);
        $end = new DateTime($session['end_date']);
        $cur->modify('first day of this month');
        while ($cur <= $end) {
            $months[] = ['month_year' => $cur->format('Y-m'), 'label' => $cur->format('F Y')];
            $cur->modify('+1 month');
        }
        return $months;
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 3 — DISCOUNTS
    // ═══════════════════════════════════════════════════════════════

    public function getStudentDiscounts(int $studentId, int $sessionId): array
    {
        return $this->raw(
            "SELECT sd.*, fc.name AS head_name, u.full_name AS approved_by_name
             FROM fee_student_discounts sd
             LEFT JOIN fee_categories fc ON sd.fee_category_id = fc.id
             LEFT JOIN users u ON sd.approved_by = u.id
             WHERE sd.student_id = :sid AND sd.session_id = :sess AND sd.is_active = 1
             ORDER BY sd.created_at DESC",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
    }

    public function saveDiscount(array $d): int
    {
        $id = (int)($d['id'] ?? 0);
        $data = [
            'student_id'      => (int)$d['student_id'],
            'session_id'      => (int)$d['session_id'],
            'fee_category_id' => !empty($d['fee_category_id']) ? (int)$d['fee_category_id'] : null,
            'discount_type'   => $d['discount_type'],
            'discount_value'  => (float)$d['discount_value'],
            'reason'          => trim($d['reason'] ?? ''),
            'approved_by'     => (int)($d['approved_by'] ?? 0) ?: null,
            'valid_from'      => $d['valid_from'] ?: null,
            'valid_until'     => $d['valid_until'] ?: null,
            'is_active'       => 1,
        ];
        $m = new Model(); $m->table = 'fee_student_discounts';
        if ($id) { $m->update($id, $data); return $id; }
        return $m->create($data);
    }

    public function deleteDiscount(int $id): void
    {
        $m = new Model(); $m->table = 'fee_student_discounts';
        $m->update($id, ['is_active' => 0]);
    }

    /**
     * Calculate discount for a student on a specific head + month.
     * Returns: absolute discount amount to apply.
     */
    public function calculateDiscount(
        int $studentId, int $sessionId, int $categoryId, float $chargedAmount, string $monthYear = ''
    ): float {
        $today = date('Y-m-d');
        $rows = $this->raw(
            "SELECT * FROM fee_student_discounts
             WHERE student_id = :s AND session_id = :sess AND is_active = 1
               AND (fee_category_id IS NULL OR fee_category_id = :cat)
               AND (valid_from IS NULL OR valid_from <= :today)
               AND (valid_until IS NULL OR valid_until >= :today)
             ORDER BY fee_category_id DESC",
            ['s' => $studentId, 'sess' => $sessionId, 'cat' => $categoryId, 'today' => $today]
        );
        $total = 0.0;
        foreach ($rows as $row) {
            if ($row['discount_type'] === 'Percentage') {
                $total += $chargedAmount * (float)$row['discount_value'] / 100;
            } else {
                $total += (float)$row['discount_value'];
            }
        }
        return min($total, $chargedAmount);
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 4 — LATE FEE
    // ═══════════════════════════════════════════════════════════════

    public function calculateLateFee(
        int $sessionId, int $classId, ?int $categoryId,
        string $monthYear, float $charged, string $paymentDate
    ): float {
        if (!$monthYear || !$paymentDate || $charged <= 0) return 0.0;
        $rule = $this->rawOne(
            "SELECT * FROM fee_late_fee_rules
             WHERE session_id = :sess AND is_active = 1
               AND (class_id IS NULL OR class_id = :cid)
               AND (fee_category_id IS NULL OR fee_category_id = :cat)
             ORDER BY class_id DESC, fee_category_id DESC LIMIT 1",
            ['sess' => $sessionId, 'cid' => $classId, 'cat' => $categoryId ?? 0]
        );
        if (!$rule) return 0.0;

        [$yr, $mo] = explode('-', $monthYear);
        $dueDate = new DateTime(sprintf('%04d-%02d-%02d', $yr, $mo, (int)$rule['due_day']));
        $dueDate->modify('+' . (int)$rule['grace_days'] . ' days');
        $payment = new DateTime($paymentDate);

        if ($payment <= $dueDate) return 0.0;

        if ($rule['late_fee_type'] === 'Percentage') {
            $lf = $charged * (float)$rule['late_fee_amount'] / 100;
            if ((float)$rule['max_late_fee'] > 0) {
                $lf = min($lf, (float)$rule['max_late_fee']);
            }
            return round($lf, 2);
        }
        return (float)$rule['late_fee_amount'];
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 5 — MONTH STATUS (cache table)
    // ═══════════════════════════════════════════════════════════════

    public function getStudentMonthStatus(int $studentId, int $sessionId): array
    {
        $rows = $this->raw(
            "SELECT ms.*, fc.name AS head_name
             FROM fee_month_status ms
             JOIN fee_categories fc ON ms.fee_category_id = fc.id
             WHERE ms.student_id = :sid AND ms.session_id = :sess
             ORDER BY ms.month_year, fc.sort_order",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
        $grouped = [];
        foreach ($rows as $r) {
            $my = $r['month_year'];
            if (!isset($grouped[$my])) {
                $grouped[$my] = [
                    'month_year'    => $my,
                    'label'         => date('F Y', strtotime($my . '-01')),
                    'heads'         => [],
                    'total_charged' => 0,
                    'total_paid'    => 0,
                    'total_discount'=> 0,
                    'total_late_fee'=> 0,
                    'status'        => 'Pending',
                ];
            }
            $grouped[$my]['heads'][] = $r;
            $grouped[$my]['total_charged']  += (float)$r['charged_amount'];
            $grouped[$my]['total_paid']     += (float)$r['paid_amount'];
            $grouped[$my]['total_discount'] += (float)$r['discount_amount'];
            $grouped[$my]['total_late_fee'] += (float)$r['late_fee_amount'];
        }
        foreach ($grouped as &$g) {
            $due  = $g['total_charged'] + $g['total_late_fee'] - $g['total_discount'];
            $paid = $g['total_paid'];
            if ($paid <= 0) {
                $g['status'] = 'Pending';
            } elseif ($paid >= $due) {
                $g['status'] = $paid > $due ? 'Advance' : 'Paid';
            } else {
                $g['status'] = 'Partial';
            }
        }
        return $grouped;
    }

    /**
     * Build the EXPECTED collection grid (Layer 1) for a student, overlaid with
     * what has actually been paid/discounted (Layer 2). This is what the collect
     * screen drives off — it works for students who have never paid, because the
     * expected charges are derived from the class fee structure, not from history.
     *
     * Returns the same shape as getStudentMonthStatus(): keyed by 'YYYY-MM' with
     * 'label', 'heads'[], and month-level totals + status.
     *
     * Discount policy (documented assumption): 'Percentage' standing discounts are
     * applied as a % of each charge; all other discount types are treated as a fixed
     * amount off that head per applicable month, capped at the charge and honoring
     * valid_from/valid_until. Discounts already recorded at payment are not double-counted.
     */
    public function getCollectionGrid(int $studentId, int $sessionId, ?string $paymentDate = null): array
    {
        $paymentDate = $paymentDate ?: date('Y-m-d');
        $stu = $this->rawOne("SELECT class_id FROM students WHERE id = :id", ['id' => $studentId]);
        if (!$stu || !$stu['class_id']) return [];
        $classId = (int)$stu['class_id'];

        $months = $this->getSessionMonths($sessionId);              // [{month_year,label}]
        $heads  = $this->getClassStructure($classId, $sessionId);   // structure rows (amount, frequency, head_name, fee_category_id)
        if (!$months || !$heads) return [];

        // Layer 2: actual paid/discount per (category, month) from active receipts.
        $paidMap = [];
        foreach ($this->raw(
            "SELECT fee_category_id, month_year,
                    SUM(paid_amount) AS paid, SUM(discount_amount) AS discount
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
             WHERE fpi.student_id = :sid AND fpi.session_id = :sess AND fpt.status = 'Active'
               AND fpi.fee_category_id IS NOT NULL AND fpi.month_year IS NOT NULL
             GROUP BY fee_category_id, month_year",
            ['sid' => $studentId, 'sess' => $sessionId]
        ) as $r) {
            $paidMap[$r['fee_category_id'] . '|' . $r['month_year']] = [
                'paid' => (float)$r['paid'], 'discount' => (float)$r['discount'],
            ];
        }

        $discounts = $this->getStudentDiscounts($studentId, $sessionId);

        $grid = [];
        foreach ($months as $idx => $m) {
            $my = $m['month_year'];
            foreach ($heads as $h) {
                if (!$this->frequencyAppliesToMonth($h['frequency'] ?? 'Monthly', $idx)) continue;
                $catId  = (int)$h['fee_category_id'];
                $gross  = (float)$h['amount'];
                $key    = $catId . '|' . $my;
                $recPaid     = $paidMap[$key]['paid']     ?? 0.0;
                $recDiscount = $paidMap[$key]['discount'] ?? 0.0;

                $displayDiscount = $recDiscount;
                $remaining = $gross - $recDiscount - $recPaid;
                if ($remaining > 0.01) {
                    $standing = $this->computeStandingDiscount($discounts, $catId, $my, $gross);
                    $extra = max(0.0, min($standing - $recDiscount, $remaining));
                    $displayDiscount += $extra;
                }

                $lateFee = 0.0;
                if (($gross - $displayDiscount - $recPaid) > 0.01) {
                    $lateFee = $this->calculateLateFee($sessionId, $classId, $catId, $my, $gross, $paymentDate);
                }

                $due    = $gross + $lateFee - $displayDiscount;
                $status = $recPaid <= 0 ? 'Pending'
                        : ($recPaid >= $due - 0.01 ? ($recPaid > $due + 0.01 ? 'Advance' : 'Paid') : 'Partial');

                if (!isset($grid[$my])) {
                    $grid[$my] = [
                        'month_year' => $my, 'label' => $m['label'], 'heads' => [],
                        'total_charged' => 0, 'total_paid' => 0,
                        'total_discount' => 0, 'total_late_fee' => 0, 'status' => 'Pending',
                    ];
                }
                $grid[$my]['heads'][] = [
                    'fee_category_id' => $catId,
                    'head_name'       => $h['head_name'] ?? 'Fee',
                    'charged_amount'  => $gross,
                    'discount_amount' => $displayDiscount,
                    'late_fee_amount' => $lateFee,
                    'paid_amount'     => $recPaid,
                    'status'          => $status,
                ];
                $grid[$my]['total_charged']  += $gross;
                $grid[$my]['total_paid']     += $recPaid;
                $grid[$my]['total_discount'] += $displayDiscount;
                $grid[$my]['total_late_fee'] += $lateFee;
            }
        }

        foreach ($grid as &$g) {
            $due = $g['total_charged'] + $g['total_late_fee'] - $g['total_discount'];
            $g['status'] = $g['total_paid'] <= 0 ? 'Pending'
                : ($g['total_paid'] >= $due - 0.01 ? ($g['total_paid'] > $due + 0.01 ? 'Advance' : 'Paid') : 'Partial');
        }
        unset($g);
        return $grid;
    }

    /** Which months of the session does a given frequency bill in? (idx 0 = first month) */
    private function frequencyAppliesToMonth(string $freq, int $idx): bool
    {
        switch ($freq) {
            case 'Monthly':     return true;
            case 'Quarterly':   return $idx % 3 === 0;
            case 'Half Yearly': return $idx % 6 === 0;
            case 'Yearly':      return $idx === 0;
            case 'Manual':      return false;
            default:            return true;   // unknown -> bill monthly (never under-bill)
        }
    }

    /** Standing discount applicable to one head in one month (see policy note above). */
    private function computeStandingDiscount(array $discounts, int $catId, string $monthYear, float $charged): float
    {
        if ($charged <= 0) return 0.0;
        $monthStart = $monthYear . '-01';
        $monthEnd   = date('Y-m-t', strtotime($monthStart));
        $total = 0.0;
        foreach ($discounts as $d) {
            if (!empty($d['fee_category_id']) && (int)$d['fee_category_id'] !== $catId) continue;
            if (!empty($d['valid_from'])  && $d['valid_from']  > $monthEnd)   continue;
            if (!empty($d['valid_until']) && $d['valid_until'] < $monthStart) continue;
            if (($d['discount_type'] ?? '') === 'Percentage') {
                $total += $charged * (float)$d['discount_value'] / 100;
            } else {
                $total += (float)$d['discount_value'];
            }
        }
        return min($total, $charged);
    }

    public function rebuildMonthStatus(int $studentId, int $sessionId): void
    {
        $items = $this->raw(
            "SELECT fee_category_id, month_year,
                    SUM(charged_amount)  AS charged,
                    SUM(paid_amount)     AS paid,
                    SUM(discount_amount) AS discount,
                    SUM(late_fee_amount) AS late_fee
             FROM fee_payment_items
             WHERE student_id = :sid AND session_id = :sess
               AND fee_category_id IS NOT NULL AND month_year IS NOT NULL
             GROUP BY fee_category_id, month_year",
            ['sid' => $studentId, 'sess' => $sessionId]
        );

        $this->query(
            "DELETE FROM fee_month_status WHERE student_id = :sid AND session_id = :sess",
            ['sid' => $studentId, 'sess' => $sessionId]
        );

        $m = new Model(); $m->table = 'fee_month_status';
        foreach ($items as $r) {
            $due  = (float)$r['charged'] + (float)$r['late_fee'] - (float)$r['discount'];
            $paid = (float)$r['paid'];
            if ($paid <= 0) {
                $status = 'Pending';
            } elseif ($paid >= $due - 0.01) {
                $status = $paid > $due + 0.01 ? 'Advance' : 'Paid';
            } else {
                $status = 'Partial';
            }
            $m->create([
                'student_id'      => $studentId,
                'session_id'      => $sessionId,
                'fee_category_id' => (int)$r['fee_category_id'],
                'month_year'      => $r['month_year'],
                'charged_amount'  => (float)$r['charged'],
                'paid_amount'     => (float)$r['paid'],
                'discount_amount' => (float)$r['discount'],
                'late_fee_amount' => (float)$r['late_fee'],
                'status'          => $status,
            ]);
        }
    }

    public function getPendingMonths(int $studentId, int $sessionId): array
    {
        return $this->raw(
            "SELECT ms.*, fc.name AS head_name, fc.head_type
             FROM fee_month_status ms
             JOIN fee_categories fc ON ms.fee_category_id = fc.id
             WHERE ms.student_id = :sid AND ms.session_id = :sess
               AND ms.status IN ('Pending','Partial')
             ORDER BY ms.month_year, fc.sort_order",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 6 — RECEIPT NUMBER (auto-generate)
    // ═══════════════════════════════════════════════════════════════

    public function generateReceiptNumber(int $sessionId): string
    {
        $this->beginTransaction();
        try {
            $sess = $this->rawOne(
                "SELECT receipt_counter, receipt_prefix, name
                 FROM academic_sessions WHERE id = :id FOR UPDATE",
                ['id' => $sessionId]
            );
            $counter = (int)($sess['receipt_counter'] ?? 0) + 1;
            $prefix  = $sess['receipt_prefix'] ?? 'RCP';
            $year    = substr(str_replace('-', '', $sess['name'] ?? date('Yy')), 0, 4);
            $this->query(
                "UPDATE academic_sessions SET receipt_counter = :c WHERE id = :id",
                ['c' => $counter, 'id' => $sessionId]
            );
            $this->commit();
            return strtoupper($prefix) . '-' . $year . '-' . str_pad($counter, 4, '0', STR_PAD_LEFT);
        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    public function validateReceiptNumber(string $receiptNo, int $sessionId, int $txnId = 0): void
    {
        $row = $this->rawOne(
            "SELECT id FROM fee_payment_transactions
             WHERE receipt_number = :r AND session_id = :s AND status = 'Active'
               AND (:txn = 0 OR id != :txn2)",
            ['r' => $receiptNo, 's' => $sessionId, 'txn' => $txnId, 'txn2' => $txnId]
        );
        if ($row) {
            throw new RuntimeException("Receipt number '$receiptNo' already used in this session.");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 7 — CORE: PROCESS PAYMENT
    // ═══════════════════════════════════════════════════════════════

    /**
     * Process a fee payment (single or family).
     *
     * @param array $txn  Transaction header
     * @param array $items  Line items (one per student × head × month)
     * @return int  Transaction ID (receipt primary key)
     */
    public function processPayment(array $txn, array $items): int
    {
        if (empty($items)) {
            throw new RuntimeException('No fee items provided.');
        }
        $sessionId = (int)$txn['session_id'];
        $this->assertSessionNotLocked($sessionId);

        // Validate receipt number
        $receiptNo = trim($txn['receipt_number'] ?? '');
        if ($receiptNo === '') {
            $receiptNo = $this->generateReceiptNumber($sessionId);
            $txn['receipt_number'] = $receiptNo;
        }
        // NOTE: duplicate receipt numbers are intentionally allowed — when siblings are
        // paid together on a single physical receipt they share the same number
        // (the receipt_number DB index is non-unique). So we do NOT reject duplicates.

        // Total paid
        $totalPaid = 0.0;
        foreach ($items as $item) {
            $totalPaid += (float)($item['paid_amount'] ?? 0);
        }
        if ($totalPaid <= 0) {
            throw new RuntimeException('Total paid amount must be greater than zero.');
        }

        $this->beginTransaction();
        try {
            // 1. Create transaction header
            $txnData = [
                'receipt_number'     => $receiptNo,
                'session_id'         => $sessionId,
                'payment_date'       => $txn['payment_date'],
                'payment_method'     => $txn['payment_method'],
                'total_amount'       => $totalPaid,
                'bank_account_id'    => !empty($txn['bank_account_id']) ? (int)$txn['bank_account_id'] : null,
                'cheque_number'      => $txn['cheque_number'] ?? null,
                'cheque_date'        => !empty($txn['cheque_date']) ? $txn['cheque_date'] : null,
                'upi_transaction_id' => $txn['upi_transaction_id'] ?? null,
                'dd_number'          => $txn['dd_number'] ?? null,
                'collected_by'       => (int)($txn['collected_by'] ?? Session::get('user_id')),
                'remarks'            => trim($txn['remarks'] ?? ''),
                'status'             => 'Active',
            ];
            $txnM = new Model(); $txnM->table = 'fee_payment_transactions';
            $txnId = $txnM->create($txnData);

            // Aggregate by student for fee_collections
            $studentTotals = [];

            // 2. Create line items + ledger entries
            foreach ($items as $item) {
                $studentId  = (int)$item['student_id'];
                $categoryId = !empty($item['fee_category_id']) ? (int)$item['fee_category_id'] : null;
                $monthYear  = trim($item['month_year'] ?? '');
                $charged    = (float)($item['charged_amount'] ?? 0);
                $discount   = (float)($item['discount_amount'] ?? 0);
                $lateFee    = (float)($item['late_fee_amount'] ?? 0);
                $paid       = (float)($item['paid_amount'] ?? 0);
                $advance    = max(0, $paid - ($charged + $lateFee - $discount));

                $itemM = new Model(); $itemM->table = 'fee_payment_items';
                $itemM->create([
                    'transaction_id'    => $txnId,
                    'student_id'        => $studentId,
                    'session_id'        => $sessionId,
                    'fee_category_id'   => $categoryId,
                    'month_year'        => $monthYear ?: null,
                    'charged_amount'    => $charged,
                    'discount_amount'   => $discount,
                    'late_fee_amount'   => $lateFee,
                    'late_fee_days'     => (int)($item['late_fee_days'] ?? 0),
                    'paid_amount'       => $paid,
                    'advance_amount'    => $advance,
                    'is_transport'      => !empty($item['is_transport']) ? 1 : 0,
                    'transport_route_id'=> !empty($item['transport_route_id']) ? (int)$item['transport_route_id'] : null,
                    'transport_fee_type'=> !empty($item['transport_fee_type']) ? $item['transport_fee_type'] : null,
                    'remarks'           => trim($item['remarks'] ?? ''),
                ]);

                // Ledger entries (immutable). Post the Charge (debit) first so the
                // student ledger reads as a true double-entry: Charge(+) then Payment(-),
                // Discount(-), LateFee(+). A fully-settled line nets to ~0.
                if ($charged > 0) {
                    $this->writeLedger($studentId, $sessionId, 'Charge', $categoryId, $monthYear, $charged,
                        'fee_payment_transactions', $txnId,
                        "Charge $receiptNo" . ($monthYear ? " ($monthYear)" : '')
                    );
                    $this->writeLedger($studentId, $sessionId, 'Payment', $categoryId, $monthYear, -$paid,
                        'fee_payment_transactions', $txnId,
                        "Payment via $receiptNo" . ($monthYear ? " ($monthYear)" : '')
                    );
                    if ($discount > 0) {
                        $this->writeLedger($studentId, $sessionId, 'Discount', $categoryId, $monthYear, -$discount,
                            'fee_payment_transactions', $txnId, "Discount on $receiptNo"
                        );
                    }
                    if ($lateFee > 0) {
                        $this->writeLedger($studentId, $sessionId, 'LateFee', $categoryId, $monthYear, $lateFee,
                            'fee_payment_transactions', $txnId, "Late fee $receiptNo"
                        );
                    }
                }

                // Aggregate for fee_collections
                if (!isset($studentTotals[$studentId])) {
                    $studentTotals[$studentId] = ['charged' => 0, 'discount' => 0, 'fine' => 0, 'paid' => 0];
                }
                $studentTotals[$studentId]['charged']  += $charged;
                $studentTotals[$studentId]['discount'] += $discount;
                $studentTotals[$studentId]['fine']     += $lateFee;
                $studentTotals[$studentId]['paid']     += $paid;
            }

            // 3. fee_collections rows (one per student — backward compat)
            $colM = new Model(); $colM->table = 'fee_collections';
            foreach ($studentTotals as $studentId => $totals) {
                $colM->create([
                    'transaction_id'  => $txnId,
                    'student_id'      => $studentId,
                    'session_id'      => $sessionId,
                    'amount'          => $totals['charged'],
                    'discount'        => $totals['discount'],
                    'fine'            => $totals['fine'],
                    'paid_amount'     => $totals['paid'],
                    'payment_method'  => $txn['payment_method'],
                    'receipt_number'  => $receiptNo,
                    'bank_account_id' => $txnData['bank_account_id'],
                    'payment_date'    => $txn['payment_date'],
                    'remarks'         => $txnData['remarks'],
                    'collected_by'    => $txnData['collected_by'],
                    'status'          => 'Paid',
                ]);
                $this->rebuildMonthStatus($studentId, $sessionId);
            }

            // 4. Accounting integration (Cash / Bank Book)
            $accounting = new Accounting();
            $pd = $txn['payment_date'];
            $desc = "Fee Collection - Receipt $receiptNo";
            if ($txn['payment_method'] === 'Cash') {
                $accounting->addCashCredit($totalPaid, $desc, $pd, $txnData['collected_by']);
            } elseif (!empty($txnData['bank_account_id'])) {
                $accounting->addBankCredit($txnData['bank_account_id'], $totalPaid, $desc, $pd, $txnData['collected_by']);
            }

            // 5. Income posting
            $this->query(
                "INSERT INTO transactions (type,category,reference_id,reference_type,amount,
                  payment_method,bank_account_id,description,transaction_date,created_by)
                 VALUES ('Income','Fee Collection',:rid,'fee_payment_transactions',:amt,
                  :pm,:ba,:desc,:pd,:by)",
                [
                    'rid' => $txnId, 'amt' => $totalPaid,
                    'pm'  => $txn['payment_method'],
                    'ba'  => $txnData['bank_account_id'],
                    'desc'=> $desc, 'pd' => $pd,
                    'by'  => $txnData['collected_by'],
                ]
            );

            $this->commit();
            Audit::log('fees', 'payment_collected', $txnId, [
                'receipt' => $receiptNo, 'amount' => $totalPaid,
                'students' => array_keys($studentTotals),
            ]);
            return $txnId;

        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 8 — CANCEL RECEIPT (void, never delete)
    // ═══════════════════════════════════════════════════════════════

    public function cancelReceipt(int $txnId, string $reason, int $cancelledBy): void
    {
        if (!$reason) throw new RuntimeException('Cancellation reason is required.');

        $txnM = new Model(); $txnM->table = 'fee_payment_transactions';
        $txn  = $txnM->findById($txnId);
        if (!$txn) throw new RuntimeException('Receipt not found.');
        if ($txn['status'] === 'Cancelled') throw new RuntimeException('Receipt already cancelled.');

        $this->assertSessionNotLocked((int)$txn['session_id']);

        $items = $this->raw(
            "SELECT * FROM fee_payment_items WHERE transaction_id = :id", ['id' => $txnId]
        );

        $this->beginTransaction();
        try {
            // Mark transaction cancelled
            $txnM->update($txnId, [
                'status'       => 'Cancelled',
                'cancelled_by' => $cancelledBy,
                'cancelled_at' => date('Y-m-d H:i:s'),
                'cancel_reason'=> $reason,
            ]);

            // Mark all collection rows cancelled
            $this->query(
                "UPDATE fee_collections SET status='Cancelled',cancelled_by=:by,
                  cancelled_at=NOW(),cancel_reason=:r WHERE transaction_id=:id",
                ['by' => $cancelledBy, 'r' => $reason, 'id' => $txnId]
            );

            // Ledger reversal entries + rebuild month status
            $affectedStudents = [];
            foreach ($items as $item) {
                $sid = (int)$item['student_id'];
                $paid    = (float)$item['paid_amount'];
                $discount= (float)$item['discount_amount'];
                $lateFee = (float)$item['late_fee_amount'];

                // Reverse: Cancellation entry (positive = debit back)
                $this->writeLedger($sid, (int)$txn['session_id'], 'Cancellation',
                    $item['fee_category_id'] ? (int)$item['fee_category_id'] : null,
                    $item['month_year'] ?? '',
                    $paid + $discount - $lateFee,
                    'fee_payment_transactions', $txnId,
                    "Cancellation of Receipt #{$txn['receipt_number']}: $reason"
                );
                $affectedStudents[$sid] = true;
            }

            foreach (array_keys($affectedStudents) as $sid) {
                $this->rebuildMonthStatus($sid, (int)$txn['session_id']);
            }

            // Reverse accounting
            $accounting = new Accounting();
            $desc = "Cancel Receipt #{$txn['receipt_number']}: $reason";
            if ($txn['payment_method'] === 'Cash') {
                $accounting->addCashDebit((float)$txn['total_amount'], $desc, date('Y-m-d'), $cancelledBy);
            } elseif ($txn['bank_account_id']) {
                $accounting->addBankDebit((int)$txn['bank_account_id'], (float)$txn['total_amount'], $desc, date('Y-m-d'), $cancelledBy);
            }

            $this->commit();
            Audit::log('fees', 'receipt_cancelled', $txnId, ['reason' => $reason]);

        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 9 — LEDGER
    // ═══════════════════════════════════════════════════════════════

    private function writeLedger(
        int $studentId, int $sessionId, string $entryType,
        ?int $categoryId, string $monthYear, float $amount,
        string $refType, int $refId, string $desc
    ): void {
        $this->query(
            "INSERT INTO fee_ledger
             (student_id, session_id, entry_type, fee_category_id, month_year,
              amount, reference_type, reference_id, description, created_by)
             VALUES (:sid,:sess,:type,:cat,:my,:amt,:rt,:rid,:desc,:by)",
            [
                'sid'  => $studentId, 'sess' => $sessionId,
                'type' => $entryType, 'cat'  => $categoryId,
                'my'   => $monthYear ?: null,
                'amt'  => $amount, 'rt' => $refType, 'rid' => $refId,
                'desc' => $desc, 'by' => Session::get('user_id') ?? 0,
            ]
        );
    }

    public function getStudentLedger(int $studentId, int $sessionId): array
    {
        return $this->raw(
            "SELECT fl.*, fc.name AS head_name, u.full_name AS by_name
             FROM fee_ledger fl
             LEFT JOIN fee_categories fc ON fl.fee_category_id = fc.id
             LEFT JOIN users u ON fl.created_by = u.id
             WHERE fl.student_id = :sid AND fl.session_id = :sess
             ORDER BY fl.created_at ASC",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
    }

    /**
     * Dynamic outstanding for a student. Summed from the SAME collection grid the
     * collect screen uses, so the number always matches what the cashier sees —
     * including standing discounts and accrued late fees (deriving from structure ×
     * frequency also avoids the partial-payment double-count of SUM(charged_amount)).
     * Plus unpaid additional charges and processed refunds (money returned = owed again).
     */
    public function getStudentOutstanding(int $studentId, int $sessionId): float
    {
        $out = 0.0;
        foreach ($this->getCollectionGrid($studentId, $sessionId) as $m) {
            foreach ($m['heads'] as $h) {
                $due = (float)$h['charged_amount'] + (float)$h['late_fee_amount'] - (float)$h['discount_amount'];
                $out += max(0, $due - (float)$h['paid_amount']);
            }
        }

        $extraCharges = (float)($this->rawOne(
            "SELECT COALESCE(SUM(amount),0) AS total
             FROM fee_additional_charges
             WHERE student_id = :sid AND session_id = :sess AND is_paid = 0",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0);

        $refunds = (float)($this->rawOne(
            "SELECT COALESCE(SUM(amount),0) AS total
             FROM fee_refunds WHERE student_id = :sid AND session_id = :sess AND status = 'Processed'",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0);

        return max(0, $out + $extraCharges + $refunds);
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 10 — CREDIT BALANCE
    // ═══════════════════════════════════════════════════════════════

    public function getCreditBalance(int $studentId, int $sessionId): float
    {
        $row = $this->rawOne(
            "SELECT COALESCE(credit_amount,0) AS bal FROM fee_credit_balance
             WHERE student_id=:s AND session_id=:sess",
            ['s' => $studentId, 'sess' => $sessionId]
        );
        return (float)($row['bal'] ?? 0);
    }

    public function addCreditBalance(int $studentId, int $sessionId, float $amount, string $reason = ''): void
    {
        $this->query(
            "INSERT INTO fee_credit_balance (student_id, session_id, credit_amount)
             VALUES (:s,:sess,:amt)
             ON DUPLICATE KEY UPDATE credit_amount = credit_amount + :amt2",
            ['s' => $studentId, 'sess' => $sessionId, 'amt' => $amount, 'amt2' => $amount]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 11 — RECEIPTS LIST
    // ═══════════════════════════════════════════════════════════════

    public function getReceiptList(int $sessionId, array $filters = [], int $page = 1, int $perPage = 25): array
    {
        $where  = ['fpt.session_id = :sess'];
        $params = ['sess' => $sessionId];

        if (!empty($filters['receipt_number'])) {
            $where[] = 'fpt.receipt_number LIKE :rn';
            $params['rn'] = '%' . $filters['receipt_number'] . '%';
        }
        if (!empty($filters['payment_method'])) {
            $where[] = 'fpt.payment_method = :pm';
            $params['pm'] = $filters['payment_method'];
        }
        if (!empty($filters['status'])) {
            $where[] = 'fpt.status = :st';
            $params['st'] = $filters['status'];
        }
        if (!empty($filters['date_from'])) {
            $where[] = 'fpt.payment_date >= :df';
            $params['df'] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where[] = 'fpt.payment_date <= :dt';
            $params['dt'] = $filters['date_to'];
        }
        if (!empty($filters['class_id'])) {
            $where[] = 'EXISTS (SELECT 1 FROM fee_payment_items fpi2
                JOIN students st2 ON fpi2.student_id=st2.id
                WHERE fpi2.transaction_id=fpt.id AND st2.class_id=:cid)';
            $params['cid'] = (int)$filters['class_id'];
        }

        $whereStr = implode(' AND ', $where);
        $total = (int)($this->rawOne(
            "SELECT COUNT(DISTINCT fpt.id) AS cnt FROM fee_payment_transactions fpt WHERE $whereStr", $params
        )['cnt'] ?? 0);

        $offset = ($page - 1) * $perPage;
        $params['limit']  = $perPage;
        $params['offset'] = $offset;

        $rows = $this->raw(
            "SELECT fpt.*,
                    GROUP_CONCAT(DISTINCT CONCAT(s.first_name,' ',COALESCE(s.last_name,''))
                                 ORDER BY s.first_name SEPARATOR ', ') AS student_names,
                    GROUP_CONCAT(DISTINCT c.name ORDER BY c.name SEPARATOR ', ') AS class_names,
                    u.full_name AS collected_by_name
             FROM fee_payment_transactions fpt
             LEFT JOIN fee_payment_items fpi ON fpi.transaction_id = fpt.id
             LEFT JOIN students s ON fpi.student_id = s.id
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN users u ON fpt.collected_by = u.id
             WHERE $whereStr
             GROUP BY fpt.id
             ORDER BY fpt.payment_date DESC, fpt.id DESC
             LIMIT :limit OFFSET :offset",
            $params
        );

        return [
            'data'        => $rows,
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => max(1, ceil($total / $perPage)),
        ];
    }

    public function getReceiptDetails(int $txnId): ?array
    {
        $txn = $this->rawOne(
            "SELECT fpt.*, u.full_name AS collected_by_name
             FROM fee_payment_transactions fpt
             LEFT JOIN users u ON fpt.collected_by = u.id
             WHERE fpt.id = :id",
            ['id' => $txnId]
        );
        if (!$txn) return null;

        $items = $this->raw(
            "SELECT fpi.*,
                    CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS student_name,
                    s.admission_number, c.name AS class_name, sec.name AS section_name,
                    fc.name AS head_name
             FROM fee_payment_items fpi
             JOIN students s ON fpi.student_id = s.id
             JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             LEFT JOIN fee_categories fc ON fpi.fee_category_id = fc.id
             WHERE fpi.transaction_id = :id
             ORDER BY s.first_name, fc.sort_order",
            ['id' => $txnId]
        );

        // Group items by student
        $byStudent = [];
        foreach ($items as $item) {
            $sid = $item['student_id'];
            if (!isset($byStudent[$sid])) {
                $byStudent[$sid] = [
                    'student_id'       => $sid,
                    'student_name'     => $item['student_name'],
                    'admission_number' => $item['admission_number'],
                    'class_name'       => $item['class_name'],
                    'section_name'     => $item['section_name'],
                    'items'            => [],
                    'total_charged'    => 0,
                    'total_discount'   => 0,
                    'total_late_fee'   => 0,
                    'total_paid'       => 0,
                ];
            }
            $byStudent[$sid]['items'][]          = $item;
            $byStudent[$sid]['total_charged']    += (float)$item['charged_amount'];
            $byStudent[$sid]['total_discount']   += (float)$item['discount_amount'];
            $byStudent[$sid]['total_late_fee']   += (float)$item['late_fee_amount'];
            $byStudent[$sid]['total_paid']       += (float)$item['paid_amount'];
        }

        $txn['students'] = array_values($byStudent);
        return $txn;
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 12 — FAMILY / SIBLINGS
    // ═══════════════════════════════════════════════════════════════

    public function getFamilyStudents(int $parentId, int $sessionId): array
    {
        return $this->raw(
            "SELECT s.*, c.name AS class_name, sec.name AS section_name
             FROM students s
             JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             WHERE s.parent_id = :pid AND s.session_id = :sess AND s.status = 'Active'
             ORDER BY s.first_name",
            ['pid' => $parentId, 'sess' => $sessionId]
        );
    }

    public function getSiblings(int $studentId, int $sessionId): array
    {
        $s = $this->rawOne("SELECT parent_id FROM students WHERE id=:id", ['id' => $studentId]);
        if (!$s || !$s['parent_id']) return [];
        return $this->raw(
            "SELECT s.*, c.name AS class_name, sec.name AS section_name
             FROM students s
             JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             WHERE s.parent_id = :pid AND s.session_id = :sess
               AND s.status = 'Active' AND s.id != :sid
             ORDER BY s.first_name",
            ['pid' => $s['parent_id'], 'sess' => $sessionId, 'sid' => $studentId]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 13 — SESSION LOCKING
    // ═══════════════════════════════════════════════════════════════

    public function isSessionLocked(int $sessionId): bool
    {
        $row = $this->rawOne(
            "SELECT is_fee_locked FROM academic_sessions WHERE id=:id", ['id' => $sessionId]
        );
        return (bool)($row['is_fee_locked'] ?? false);
    }

    public function assertSessionNotLocked(int $sessionId): void
    {
        if ($this->isSessionLocked($sessionId)) {
            throw new RuntimeException('Fee session is locked. Contact Super Admin to unlock.');
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 14 — ADDITIONAL CHARGES
    // ═══════════════════════════════════════════════════════════════

    public function getAdditionalCharges(int $studentId, int $sessionId): array
    {
        return $this->raw(
            "SELECT ac.*, u.full_name AS created_by_name
             FROM fee_additional_charges ac
             LEFT JOIN users u ON ac.created_by = u.id
             WHERE ac.student_id = :sid AND ac.session_id = :sess
             ORDER BY ac.charge_date DESC",
            ['sid' => $studentId, 'sess' => $sessionId]
        );
    }

    public function markAdditionalChargePaid(int $id): void
    {
        $m = new Model(); $m->table = 'fee_additional_charges';
        $m->update($id, ['is_paid' => 1]);
    }

    public function saveAdditionalCharge(array $d): int
    {
        $m = new Model(); $m->table = 'fee_additional_charges';
        return $m->create([
            'student_id'  => (int)$d['student_id'],
            'session_id'  => (int)$d['session_id'],
            'charge_type' => $d['charge_type'],
            'head_label'  => $d['head_label'] ?? $d['charge_type'],
            'amount'      => (float)$d['amount'],
            'description' => trim($d['description'] ?? ''),
            'charge_date' => $d['charge_date'] ?? date('Y-m-d'),
            'is_paid'     => 0,
            'created_by'  => (int)($d['created_by'] ?? Session::get('user_id')),
        ]);
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 15 — REPORTS
    // ═══════════════════════════════════════════════════════════════

    public function getDashboardSummary(int $sessionId): array
    {
        $today = date('Y-m-d');
        $month = date('Y-m');

        $todayTotal = $this->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS total
             FROM fee_payment_transactions
             WHERE session_id=:sess AND payment_date=:today AND status='Active'",
            ['sess' => $sessionId, 'today' => $today]
        );
        $monthTotal = $this->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS total
             FROM fee_payment_transactions
             WHERE session_id=:sess AND DATE_FORMAT(payment_date,'%Y-%m')=:mo AND status='Active'",
            ['sess' => $sessionId, 'mo' => $month]
        );
        $sessionTotal = $this->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS total
             FROM fee_payment_transactions
             WHERE session_id=:sess AND status='Active'",
            ['sess' => $sessionId]
        );
        $outstanding = $this->rawOne(
            "SELECT COALESCE(SUM(fpi.charged_amount+fpi.late_fee_amount-fpi.discount_amount-fpi.paid_amount),0) AS total
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id=fpt.id
             WHERE fpi.session_id=:sess AND fpt.status='Active'",
            ['sess' => $sessionId]
        );
        $byMethod = $this->raw(
            "SELECT payment_method, COALESCE(SUM(total_amount),0) AS total, COUNT(*) AS cnt
             FROM fee_payment_transactions
             WHERE session_id=:sess AND payment_date=:today AND status='Active'
             GROUP BY payment_method",
            ['sess' => $sessionId, 'today' => $today]
        );

        return [
            'today'       => (float)($todayTotal['total'] ?? 0),
            'month'       => (float)($monthTotal['total'] ?? 0),
            'session'     => (float)($sessionTotal['total'] ?? 0),
            'outstanding' => max(0, (float)($outstanding['total'] ?? 0)),
            'by_method'   => $byMethod,
        ];
    }

    public function getOutstandingReport(int $sessionId, ?int $classId = null): array
    {
        $where  = ['s.session_id = :sess', 's.status = "Active"'];
        $params = ['sess' => $sessionId];
        if ($classId) { $where[] = 's.class_id = :cid'; $params['cid'] = $classId; }
        $w = implode(' AND ', $where);

        return $this->raw(
            "SELECT s.id, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS student_name,
                    s.admission_number, c.name AS class_name, sec.name AS section_name,
                    COALESCE(SUM(fpi.charged_amount+fpi.late_fee_amount-fpi.discount_amount),0) AS total_due,
                    COALESCE(SUM(fpi.paid_amount),0) AS total_paid,
                    GREATEST(0, COALESCE(SUM(fpi.charged_amount+fpi.late_fee_amount-fpi.discount_amount),0)
                               - COALESCE(SUM(fpi.paid_amount),0)) AS outstanding
             FROM students s
             JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             LEFT JOIN fee_payment_items fpi ON fpi.student_id=s.id AND fpi.session_id=:sess2
             LEFT JOIN fee_payment_transactions fpt ON fpi.transaction_id=fpt.id AND fpt.status='Active'
             WHERE $w
             GROUP BY s.id
             HAVING outstanding > 0
             ORDER BY c.numeric_value, s.first_name",
            array_merge($params, ['sess2' => $sessionId])
        );
    }

    public function getDailyCollection(string $date, int $sessionId): array
    {
        $rows = $this->raw(
            "SELECT fpt.*, u.full_name AS collected_by_name,
                    GROUP_CONCAT(DISTINCT CONCAT(s.first_name,' ',COALESCE(s.last_name,''))
                                 SEPARATOR ', ') AS student_names
             FROM fee_payment_transactions fpt
             LEFT JOIN fee_payment_items fpi ON fpi.transaction_id=fpt.id
             LEFT JOIN students s ON fpi.student_id=s.id
             LEFT JOIN users u ON fpt.collected_by=u.id
             WHERE fpt.session_id=:sess AND fpt.payment_date=:date AND fpt.status='Active'
             GROUP BY fpt.id
             ORDER BY fpt.id",
            ['sess' => $sessionId, 'date' => $date]
        );
        $summary = $this->raw(
            "SELECT payment_method, COALESCE(SUM(total_amount),0) AS total, COUNT(*) AS cnt
             FROM fee_payment_transactions
             WHERE session_id=:sess AND payment_date=:date AND status='Active'
             GROUP BY payment_method",
            ['sess' => $sessionId, 'date' => $date]
        );
        return ['receipts' => $rows, 'summary' => $summary];
    }

    public function getMonthlyReport(string $monthYear, int $sessionId, ?int $classId = null): array
    {
        $where  = ['fpi.session_id = :sess', 'fpi.month_year = :my', 'fpt.status = "Active"'];
        $params = ['sess' => $sessionId, 'my' => $monthYear];
        if ($classId) { $where[] = 's.class_id = :cid'; $params['cid'] = $classId; }
        $w = implode(' AND ', $where);

        return $this->raw(
            "SELECT s.id, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS student_name,
                    s.admission_number, c.name AS class_name, fc.name AS head_name,
                    SUM(fpi.charged_amount)  AS charged,
                    SUM(fpi.paid_amount)     AS paid,
                    SUM(fpi.discount_amount) AS discount,
                    SUM(fpi.late_fee_amount) AS late_fee,
                    ms.status
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id=fpt.id
             JOIN students s ON fpi.student_id=s.id
             JOIN classes c ON s.class_id=c.id
             LEFT JOIN fee_categories fc ON fpi.fee_category_id=fc.id
             LEFT JOIN fee_month_status ms ON ms.student_id=fpi.student_id
               AND ms.session_id=fpi.session_id AND ms.month_year=fpi.month_year
               AND ms.fee_category_id=fpi.fee_category_id
             WHERE $w
             GROUP BY s.id, fpi.fee_category_id
             ORDER BY c.numeric_value, s.first_name, fc.sort_order",
            $params
        );
    }

    public function getDiscountReport(int $sessionId): array
    {
        return $this->raw(
            "SELECT sd.*, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS student_name,
                    s.admission_number, c.name AS class_name,
                    fc.name AS head_name, u.full_name AS approved_by_name
             FROM fee_student_discounts sd
             JOIN students s ON sd.student_id=s.id
             JOIN classes c ON s.class_id=c.id
             LEFT JOIN fee_categories fc ON sd.fee_category_id=fc.id
             LEFT JOIN users u ON sd.approved_by=u.id
             WHERE sd.session_id=:sess AND sd.is_active=1
             ORDER BY c.numeric_value, s.first_name",
            ['sess' => $sessionId]
        );
    }

    public function getRefundReport(int $sessionId): array
    {
        return $this->raw(
            "SELECT fr.*, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS student_name,
                    s.admission_number, c.name AS class_name, u.full_name AS approved_by_name
             FROM fee_refunds fr
             JOIN students s ON fr.student_id=s.id
             JOIN classes c ON s.class_id=c.id
             LEFT JOIN users u ON fr.approved_by=u.id
             WHERE fr.session_id=:sess
             ORDER BY fr.created_at DESC",
            ['sess' => $sessionId]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // DASHBOARD HELPERS — called by Dashboard model
    // ═══════════════════════════════════════════════════════════════

    public function getTodayCollection(int $sessionId): array
    {
        $row = $this->rawOne(
            "SELECT
                COALESCE(SUM(fpi.paid_amount), 0)                                   AS total,
                COALESCE(SUM(CASE WHEN fpt.payment_method='Cash'         THEN fpi.paid_amount ELSE 0 END), 0) AS cash,
                COALESCE(SUM(CASE WHEN fpt.payment_method!='Cash'        THEN fpi.paid_amount ELSE 0 END), 0) AS bank,
                COUNT(DISTINCT fpt.id)                                               AS receipts
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
             WHERE fpt.session_id = :sid
               AND fpt.payment_date = CURDATE()
               AND fpt.status = 'Active'",
            ['sid' => $sessionId]
        );
        return $row ?: ['total' => 0, 'cash' => 0, 'bank' => 0, 'receipts' => 0];
    }

    /**
     * Session-wide expected outstanding (gross), on the same basis as the per-student
     * collection grid: expected charges = Σ_class Σ_head amount × frequency-occurrences ×
     * active students in that class, minus what has actually been settled (paid + recorded
     * discount). Note: this is GROSS of any standing concessions not yet applied at payment.
     */
    public function getTotalOutstanding(int $sessionId): float
    {
        $numMonths = count($this->getSessionMonths($sessionId));
        if ($numMonths === 0) return 0.0;

        $expected = 0.0;
        foreach ($this->raw(
            "SELECT fs.amount, fs.frequency, COUNT(st.id) AS students
             FROM fee_structures fs
             JOIN students st ON st.class_id = fs.class_id
                              AND st.session_id = fs.session_id
                              AND st.status = 'Active'
             WHERE fs.session_id = :sid
             GROUP BY fs.id, fs.amount, fs.frequency",
            ['sid' => $sessionId]
        ) as $r) {
            $occ = $this->frequencyOccurrences($r['frequency'], $numMonths);
            $expected += (float)$r['amount'] * $occ * (int)$r['students'];
        }

        $settled = (float)($this->rawOne(
            "SELECT COALESCE(SUM(fpi.paid_amount + fpi.discount_amount), 0) AS total
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
             WHERE fpi.session_id = :sid AND fpt.status = 'Active'",
            ['sid' => $sessionId]
        )['total'] ?? 0);

        return max(0, $expected - $settled);
    }

    /** How many times a frequency bills across a session of N months. */
    private function frequencyOccurrences(string $freq, int $numMonths): int
    {
        switch ($freq) {
            case 'Monthly':     return $numMonths;
            case 'Quarterly':   return (int)ceil($numMonths / 3);
            case 'Half Yearly': return (int)ceil($numMonths / 6);
            case 'Yearly':      return 1;
            case 'Manual':      return 0;
            default:            return $numMonths;
        }
    }

    public function getPreviousSessionsOutstanding(int $currentSessionId): array
    {
        $sessions = $this->raw(
            "SELECT id, name FROM academic_sessions WHERE id != :sid AND is_archived = 0 ORDER BY id DESC LIMIT 5",
            ['sid' => $currentSessionId]
        );

        $result = [];
        foreach ($sessions as $sess) {
            $outstanding = $this->getTotalOutstanding((int)$sess['id']);
            if ($outstanding > 0) {
                $result[] = [
                    'session_id'  => $sess['id'],
                    'session_name'=> $sess['name'],
                    'outstanding' => $outstanding,
                ];
            }
        }
        return $result;
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 14 — LATE FEE RULES (config CRUD)
    // ═══════════════════════════════════════════════════════════════

    public function getLateFeeRules(int $sessionId): array
    {
        return $this->raw(
            "SELECT r.*, c.name AS class_name, fc.name AS category_name
             FROM fee_late_fee_rules r
             LEFT JOIN classes c ON r.class_id = c.id
             LEFT JOIN fee_categories fc ON r.fee_category_id = fc.id
             WHERE r.session_id = :sess OR r.session_id IS NULL
             ORDER BY r.is_active DESC, c.numeric_value, fc.sort_order",
            ['sess' => $sessionId]
        );
    }

    public function saveLateFeeRule(array $d, int $sessionId): int
    {
        $maxRaw = $d['max_late_fee'] ?? '';
        $row = [
            'session_id'      => $sessionId,
            'class_id'        => !empty($d['class_id']) ? (int)$d['class_id'] : null,
            'fee_category_id' => !empty($d['fee_category_id']) ? (int)$d['fee_category_id'] : null,
            'due_day'         => max(1, min(31, (int)($d['due_day'] ?? 10))),
            'grace_days'      => max(0, (int)($d['grace_days'] ?? 0)),
            'late_fee_type'   => (($d['late_fee_type'] ?? 'Fixed') === 'Percentage') ? 'Percentage' : 'Fixed',
            'late_fee_amount' => (float)($d['late_fee_amount'] ?? 0),
            'max_late_fee'    => ($maxRaw === '' || $maxRaw === null) ? null : (float)$maxRaw,
            'is_active'       => (int)($d['is_active'] ?? 1) ? 1 : 0,
        ];
        $m = new Model(); $m->table = 'fee_late_fee_rules';
        $id = (int)($d['id'] ?? 0);
        if ($id) { $m->update($id, $row); return $id; }
        return (int)$m->create($row);
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 15 — CASH CLOSING
    // ═══════════════════════════════════════════════════════════════

    /** Auto-computed cash figures for a given date. */
    public function getCashClosingAuto(string $date, int $sessionId): array
    {
        $collected = (float)($this->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS t
             FROM fee_payment_transactions
             WHERE session_id = :sess AND payment_date = :d
               AND status = 'Active' AND payment_method = 'Cash'",
            ['sess' => $sessionId, 'd' => $date]
        )['t'] ?? 0);
        $refunded = (float)($this->rawOne(
            "SELECT COALESCE(SUM(amount),0) AS t
             FROM fee_refunds
             WHERE session_id = :sess AND status = 'Processed'
               AND refund_method = 'Cash' AND DATE(created_at) = :d",
            ['sess' => $sessionId, 'd' => $date]
        )['t'] ?? 0);
        return ['cash_collected' => $collected, 'cash_refunded' => $refunded];
    }

    public function getCashClosings(int $sessionId, int $limit = 30): array
    {
        return $this->raw(
            "SELECT cc.*, u.full_name AS cashier_name
             FROM fee_cash_closing cc
             LEFT JOIN users u ON cc.cashier_id = u.id
             WHERE cc.session_id = :sess
             ORDER BY cc.closing_date DESC, cc.id DESC
             LIMIT {$limit}",
            ['sess' => $sessionId]
        );
    }

    public function saveCashClosing(array $d, int $sessionId): void
    {
        $opening    = (float)($d['opening_cash'] ?? 0);
        $collected  = (float)($d['cash_collected'] ?? 0);
        $refunded   = (float)($d['cash_refunded'] ?? 0);
        $adjust     = (float)($d['cash_adjustments'] ?? 0);
        $closing    = (float)($d['closing_cash'] ?? 0);
        $expected   = $opening + $collected - $refunded + $adjust;
        $difference = $closing - $expected;

        $this->query(
            "INSERT INTO fee_cash_closing
                (closing_date, session_id, cashier_id, opening_cash, cash_collected,
                 cash_refunded, cash_adjustments, closing_cash, difference, notes, status)
             VALUES
                (:cd, :sess, :cashier, :opening, :collected, :refunded, :adjust, :closing, :diff, :notes, 'Submitted')
             ON DUPLICATE KEY UPDATE
                opening_cash=:opening2, cash_collected=:collected2, cash_refunded=:refunded2,
                cash_adjustments=:adjust2, closing_cash=:closing2, difference=:diff2,
                notes=:notes2, status='Submitted'",
            [
                'cd' => $d['closing_date'], 'sess' => $sessionId, 'cashier' => (int)$d['cashier_id'],
                'opening' => $opening, 'collected' => $collected, 'refunded' => $refunded,
                'adjust' => $adjust, 'closing' => $closing, 'diff' => $difference,
                'notes' => $d['notes'] ?? '',
                'opening2' => $opening, 'collected2' => $collected, 'refunded2' => $refunded,
                'adjust2' => $adjust, 'closing2' => $closing, 'diff2' => $difference,
                'notes2' => $d['notes'] ?? '',
            ]
        );
    }

    public function approveCashClosing(int $id, int $approverId): void
    {
        $this->query(
            "UPDATE fee_cash_closing
             SET status='Approved', approved_by=:by, approved_at=NOW()
             WHERE id=:id AND status='Submitted'",
            ['by' => $approverId, 'id' => $id]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 16 — BANK RECONCILIATION
    // ═══════════════════════════════════════════════════════════════

    public function getCollectionsByMethod(string $date, int $sessionId): array
    {
        return $this->raw(
            "SELECT payment_method AS method, COUNT(*) AS count, COALESCE(SUM(total_amount),0) AS total
             FROM fee_payment_transactions
             WHERE session_id = :sess AND payment_date = :d AND status = 'Active'
             GROUP BY payment_method
             ORDER BY total DESC",
            ['sess' => $sessionId, 'd' => $date]
        );
    }

    // ── Report wrappers used by ReportsController ─────────────────────
    /** Daily collection grouped by payment method (Reports > Daily Collection). */
    public function getDailySummaryByMethod(string $date, int $sessionId): array
    {
        return $this->getCollectionsByMethod($date, $sessionId);
    }

    /** Monthly collection detail for a given year+month. */
    public function getMonthlyCollection(int $year, int $month, int $sessionId): array
    {
        return $this->getMonthlyReport(sprintf('%04d-%02d', $year, $month), $sessionId);
    }

    /**
     * Outstanding per active student, using the corrected structure-based figure
     * (matches the collect screen / getStudentOutstanding, incl. discounts).
     */
    public function getOutstandingDetails(int $sessionId, ?int $classId = null): array
    {
        $numMonths = count($this->getSessionMonths($sessionId));
        $where  = ['s.session_id = :sess', "s.status = 'Active'"];
        $params = ['sess' => $sessionId];
        if ($classId) { $where[] = 's.class_id = :cid'; $params['cid'] = $classId; }
        $students = $this->raw(
            "SELECT s.id, s.admission_number, s.first_name, s.last_name, s.class_id, c.name AS class_name
             FROM students s JOIN classes c ON s.class_id = c.id
             WHERE " . implode(' AND ', $where) . "
             ORDER BY c.numeric_value, s.first_name",
            $params
        );
        $expByClass = [];
        $rows = [];
        foreach ($students as $st) {
            $cid = (int)$st['class_id'];
            if (!isset($expByClass[$cid])) {
                $exp = 0.0;
                foreach ($this->getClassStructure($cid, $sessionId) as $h) {
                    $exp += (float)$h['amount'] * $this->frequencyOccurrences($h['frequency'] ?? 'Monthly', $numMonths);
                }
                $expByClass[$cid] = $exp;
            }
            $outstanding = $this->getStudentOutstanding((int)$st['id'], $sessionId);
            if ($outstanding <= 0.009) continue;
            $agg = $this->rawOne(
                "SELECT COALESCE(SUM(fpi.paid_amount),0) AS paid, COALESCE(SUM(fpi.discount_amount),0) AS disc
                 FROM fee_payment_items fpi
                 JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
                 WHERE fpi.student_id = :sid AND fpi.session_id = :sess AND fpt.status = 'Active'",
                ['sid' => $st['id'], 'sess' => $sessionId]
            );
            $st['student_id']     = $st['id'];
            $st['total_charged']  = $expByClass[$cid];
            $st['total_paid']     = (float)($agg['paid'] ?? 0);
            $st['total_discount'] = (float)($agg['disc'] ?? 0);
            $st['outstanding']    = $outstanding;
            $rows[] = $st;
        }
        return $rows;
    }

    public function getPendingCheques(int $sessionId): array
    {
        return $this->raw(
            "SELECT receipt_number, cheque_number, cheque_date, total_amount
             FROM fee_payment_transactions
             WHERE session_id = :sess AND status = 'Active'
               AND payment_method = 'Cheque' AND cheque_date IS NOT NULL AND cheque_date > CURDATE()
             ORDER BY cheque_date ASC",
            ['sess' => $sessionId]
        );
    }

    // ═══════════════════════════════════════════════════════════════
    // SECTION 17 — RECONCILIATION (items vs headers)
    // ═══════════════════════════════════════════════════════════════

    public function runReconciliation(int $sessionId, ?int $userId): array
    {
        $items = $this->rawOne(
            "SELECT COALESCE(SUM(fpi.charged_amount),0)  AS total_charged,
                    COALESCE(SUM(fpi.paid_amount),0)     AS total_paid,
                    COALESCE(SUM(fpi.discount_amount),0) AS total_discount,
                    COALESCE(SUM(fpi.late_fee_amount),0) AS total_late_fee
             FROM fee_payment_items fpi
             JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
             WHERE fpt.session_id = :sess AND fpt.status = 'Active'",
            ['sess' => $sessionId]
        ) ?: [];
        $headers = (float)($this->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS t
             FROM fee_payment_transactions
             WHERE session_id = :sess AND status = 'Active'",
            ['sess' => $sessionId]
        )['t'] ?? 0);
        $refund = (float)($this->rawOne(
            "SELECT COALESCE(SUM(amount),0) AS t
             FROM fee_refunds WHERE session_id = :sess AND status = 'Processed'",
            ['sess' => $sessionId]
        )['t'] ?? 0);

        $totalCharged  = (float)($items['total_charged'] ?? 0);
        $totalPaid     = (float)($items['total_paid'] ?? 0);
        $totalDiscount = (float)($items['total_discount'] ?? 0);
        $totalLate     = (float)($items['total_late_fee'] ?? 0);
        $calcOutstanding = max(0, $totalCharged + $totalLate - $totalDiscount - $totalPaid);
        $mismatch  = round(abs($totalPaid - $headers), 2);
        $status    = $mismatch < 0.01 ? 'OK' : 'Mismatch';

        $result = [
            'total_charged'      => $totalCharged,
            'total_paid'         => $totalPaid,
            'total_discount'     => $totalDiscount,
            'total_late_fee'     => $totalLate,
            'total_refund'       => $refund,
            'calc_outstanding'   => $calcOutstanding,
            'ledger_outstanding' => $headers,
            'mismatch'           => $mismatch,
            'status'             => $status,
        ];

        $this->query(
            "INSERT INTO fee_reconciliation_log
                (session_id, run_date, run_by, total_charged, total_paid, total_discount,
                 total_late_fee, total_refund, calc_outstanding, ledger_outstanding, mismatch, status)
             VALUES
                (:sess, CURDATE(), :by, :tc, :tp, :td, :tl, :tr, :co, :lo, :mm, :st)",
            [
                'sess' => $sessionId, 'by' => $userId, 'tc' => $totalCharged, 'tp' => $totalPaid,
                'td' => $totalDiscount, 'tl' => $totalLate, 'tr' => $refund, 'co' => $calcOutstanding,
                'lo' => $headers, 'mm' => $mismatch, 'st' => $status,
            ]
        );
        return $result;
    }

    public function getReconciliationHistory(int $sessionId, int $limit = 30): array
    {
        return $this->raw(
            "SELECT rl.*, u.full_name AS run_by_name
             FROM fee_reconciliation_log rl
             LEFT JOIN users u ON rl.run_by = u.id
             WHERE rl.session_id = :sess
             ORDER BY rl.id DESC
             LIMIT {$limit}",
            ['sess' => $sessionId]
        );
    }
}
