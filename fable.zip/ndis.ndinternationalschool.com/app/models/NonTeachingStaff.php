<?php
class NonTeachingStaff extends Model
{
    public string $table = 'non_teaching_staff';

    public function getAllWithDept(int $page = 1, int $perPage = 20, string $search = '', string $status = ''): array
    {
        $offset = ($page - 1) * $perPage;
        $where  = '1=1';
        $params = [];

        if ($search) {
            $where .= " AND (s.first_name LIKE :s OR s.last_name LIKE :s OR s.employee_id LIKE :s OR s.phone LIKE :s OR s.designation LIKE :s)";
            $params['s'] = "%$search%";
        }
        if ($status) {
            $where .= " AND s.status = :status";
            $params['status'] = $status;
        }

        $total = (int)($this->rawOne("SELECT COUNT(*) as total FROM non_teaching_staff s WHERE $where", $params)['total'] ?? 0);

        $sql = "SELECT s.*, d.name AS department_name
                FROM non_teaching_staff s
                LEFT JOIN departments d ON s.department_id = d.id
                WHERE $where
                ORDER BY s.first_name ASC
                LIMIT $perPage OFFSET $offset";

        return [
            'data'        => $this->raw($sql, $params),
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }

    public function getActiveStaff(): array
    {
        return $this->findAllBy('status', 'Active', 'first_name ASC');
    }

    /** Active staff whose designation is Driver — used by the Transport driver dropdowns. */
    public function getDrivers(): array
    {
        return $this->raw(
            "SELECT id, TRIM(CONCAT(first_name, ' ', COALESCE(last_name, ''))) AS name, phone
             FROM non_teaching_staff
             WHERE status = 'Active' AND designation LIKE '%Driver%'
             ORDER BY first_name ASC"
        );
    }

    /** Add a driver into the staff list from Transport (if a driver with that phone
     *  isn't already there). Returns the staff id. This keeps drivers in sync both ways. */
    public function ensureDriver(string $name, ?string $phone): int
    {
        $name = trim($name);
        if ($name === '') return 0;
        if (!empty($phone)) {
            $ex = $this->rawOne(
                "SELECT id FROM non_teaching_staff WHERE phone = :p AND designation LIKE '%Driver%' LIMIT 1",
                ['p' => $phone]
            );
            if ($ex) return (int)$ex['id'];
        }
        $parts = explode(' ', $name, 2);
        $m = new Model(); $m->table = 'non_teaching_staff';
        return (int)$m->create([
            'employee_id' => 'DRV' . date('ymdHis') . rand(10, 99),
            'first_name'  => $parts[0],
            'last_name'   => $parts[1] ?? null,
            'phone'       => $phone ?: null,
            'designation' => 'Driver',
            'status'      => 'Active',
        ]);
    }
}
