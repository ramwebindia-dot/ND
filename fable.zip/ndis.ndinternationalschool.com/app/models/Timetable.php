<?php
class Timetable extends Model
{
    public string $table = 'timetables';

    public function getClassTimetable(int $classId, ?int $sectionId, int $sessionId): array
    {
        $sql = "SELECT t.*, s.name as subject_name, s.code as subject_code, 
                CONCAT(te.first_name, ' ', te.last_name) as teacher_name
                FROM timetables t
                JOIN subjects s ON t.subject_id = s.id
                JOIN teachers te ON t.teacher_id = te.id
                WHERE t.class_id = :cid AND t.section_id <=> :sid AND t.session_id = :sess
                ORDER BY t.day_of_week, t.period_number";
        return $this->raw($sql, ['cid' => $classId, 'sid' => $sectionId, 'sess' => $sessionId]);
    }

    public function checkConflict(int $teacherId, int $dayOfWeek, string $startTime, string $endTime, int $sessionId, ?int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) as total FROM timetables 
                WHERE teacher_id = :tid AND day_of_week = :dow AND session_id = :sid
                AND ((start_time < :end AND end_time > :start))";
        $params = ['tid' => $teacherId, 'dow' => $dayOfWeek, 'sid' => $sessionId, 'start' => $startTime, 'end' => $endTime];
        if ($excludeId) {
            $sql .= " AND id != :exclude";
            $params['exclude'] = $excludeId;
        }
        return ($this->rawOne($sql, $params)['total'] ?? 0) > 0;
    }
}
