<?php
class Notification extends Model
{
    public string $table = 'notifications';
    public function getUnread(int $userId): array
    {
        return $this->raw("SELECT * FROM notifications WHERE user_id = :uid AND is_read = 0 ORDER BY created_at DESC", ['uid' => $userId]);
    }
    public function getUnreadCount(int $userId): int
    {
        return (int) ($this->rawOne("SELECT COUNT(*) as total FROM notifications WHERE user_id = :uid AND is_read = 0", ['uid' => $userId])['total'] ?? 0);
    }
    public static function add(int $userId, string $title, string $message, string $type = 'General', ?string $link = null): void
    {
        $model = new Model(); $model->table = 'notifications';
        $model->create(['user_id' => $userId, 'title' => $title, 'message' => $message, 'type' => $type, 'link' => $link]);
    }
    public function markRead(int $id): void { $this->update($id, ['is_read' => 1]); }
    public function markAllRead(int $userId): void { $this->query("UPDATE notifications SET is_read = 1 WHERE user_id = :uid", ['uid' => $userId]); }
}