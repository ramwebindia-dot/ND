<?php
class Material extends Model
{
    public string $table = 'learning_materials';
    public function getMaterials(int $sessionId, ?int $classId = null, ?int $subjectId = null): array
    {
        $where = "lm.session_id = :sid";
        $params = ['sid' => $sessionId];
        if ($classId) { $where .= " AND lm.class_id = :cid"; $params['cid'] = $classId; }
        if ($subjectId) { $where .= " AND lm.subject_id = :subid"; $params['subid'] = $subjectId; }
        return $this->raw("SELECT lm.*, c.name as class_name, s.name as subject_name FROM learning_materials lm LEFT JOIN classes c ON lm.class_id = c.id LEFT JOIN subjects s ON lm.subject_id = s.id WHERE $where ORDER BY lm.created_at DESC", $params);
    }
}