<?php
class ClassModel extends Model
{
    public string $table = 'classes';

    public function getClassesWithDetails(int $sessionId): array
    {
        $sql = "SELECT c.*, t.first_name as teacher_name, t.last_name as teacher_last_name,
                (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.session_id = :sid AND s.status = 'Active') as student_count
                FROM classes c LEFT JOIN teachers t ON c.class_teacher_id = t.id
                WHERE c.session_id = :sid2 ORDER BY c.numeric_value ASC";
        return $this->raw($sql, ['sid' => $sessionId, 'sid2' => $sessionId]);
    }

    public function getBySession(int $sessionId): array
    {
        return $this->findAllBy('session_id', $sessionId, 'numeric_value ASC');
    }
}
