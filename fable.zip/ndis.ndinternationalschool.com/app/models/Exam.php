<?php
class Exam extends Model
{
    public string $table = 'exams';

    public function getExamsWithClass(int $sessionId): array
    {
        return $this->raw(
            "SELECT e.*, c.name AS class_name, sec.name AS section_name,
                    COUNT(es.id) AS schedule_count
             FROM exams e
             JOIN classes c ON e.class_id = c.id
             LEFT JOIN sections sec ON e.section_id = sec.id
             LEFT JOIN exam_schedules es ON es.exam_id = e.id
             WHERE e.session_id = :sid
             GROUP BY e.id
             ORDER BY e.start_date DESC",
            ['sid' => $sessionId]
        );
    }

    public function getExamWithSchedule(int $examId): ?array
    {
        $exam = $this->findById($examId);
        if (!$exam) return null;
        $exam['schedules'] = $this->raw(
            "SELECT es.*, s.name AS subject_name
             FROM exam_schedules es
             JOIN subjects s ON es.subject_id = s.id
             WHERE es.exam_id = :eid
             ORDER BY es.exam_date, s.name",
            ['eid' => $examId]
        );
        return $exam;
    }

    /**
     * Get result summary for a class: total marks, obtained, percentage, rank.
     */
    public function getClassResults(int $examId, int $classId): array
    {
        $rows = $this->raw(
            "SELECT s.id AS student_id,
                    s.first_name, s.last_name, s.roll_number, s.admission_number,
                    SUM(es.total_marks)    AS max_marks,
                    SUM(es.passing_marks)  AS total_pass_marks,
                    SUM(m.marks_obtained)  AS obtained,
                    ROUND(SUM(m.marks_obtained)/SUM(es.total_marks)*100, 2) AS percentage
             FROM students s
             JOIN marks m ON m.student_id = s.id AND m.exam_id = :eid
             JOIN exam_schedules es ON es.subject_id = m.subject_id AND es.exam_id = :eid2
             WHERE s.class_id = :cid AND s.status = 'Active'
             GROUP BY s.id
             ORDER BY obtained DESC",
            ['eid' => $examId, 'eid2' => $examId, 'cid' => $classId]
        );

        // Assign rank
        foreach ($rows as $i => &$r) {
            $r['rank'] = $i + 1;
            $r['result'] = ($r['obtained'] >= $r['total_pass_marks']) ? 'Pass' : 'Fail';
        }
        return $rows;
    }

    /**
     * Get student marks with per-subject pass/fail info.
     */
    public function getStudentResult(int $examId, int $studentId): array
    {
        return $this->raw(
            "SELECT m.*, s.name AS subject_name,
                    es.total_marks, es.passing_marks, es.exam_date,
                    ROUND(m.marks_obtained / es.total_marks * 100, 1) AS subject_pct
             FROM marks m
             JOIN subjects s ON m.subject_id = s.id
             JOIN exam_schedules es ON es.exam_id = m.exam_id AND es.subject_id = m.subject_id
             WHERE m.exam_id = :eid AND m.student_id = :sid
             ORDER BY es.exam_date, s.name",
            ['eid' => $examId, 'sid' => $studentId]
        );
    }

    /**
     * Get rank of a student in their class for an exam.
     */
    public function getStudentRank(int $examId, int $studentId, int $classId): int
    {
        $results = $this->getClassResults($examId, $classId);
        foreach ($results as $r) {
            if ((int)$r['student_id'] === $studentId) return (int)$r['rank'];
        }
        return 0;
    }
}
