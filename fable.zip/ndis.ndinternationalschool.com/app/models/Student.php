<?php
class Student extends Model
{
    public string $table = 'students';

    public function getStudentsWithDetails(int $sessionId, int $page = 1, int $perPage = 20, string $search = '', ?int $classId = null, ?int $sectionId = null): array
    {
        $where = "s.session_id = :sid AND s.status = 'Active'";
        $params = ['sid' => $sessionId];

        if ($search) {
            $where .= " AND (s.first_name LIKE :search OR s.last_name LIKE :search2 OR s.admission_number LIKE :search3)";
            $params['search'] = "%$search%";
            $params['search2'] = "%$search%";
            $params['search3'] = "%$search%";
        }

        if ($classId) {
            $where .= " AND s.class_id = :class_id";
            $params['class_id'] = $classId;
        }

        if ($sectionId) {
            $where .= " AND s.section_id = :section_id";
            $params['section_id'] = $sectionId;
        }

        $offset = ($page - 1) * $perPage;
        $countSql = "SELECT COUNT(*) as total FROM students s WHERE $where";
        $total = (int) $this->rawOne($countSql, $params)['total'];

        $sql = "SELECT s.*, c.name as class_name, sec.name as section_name, p.father_name, p.mother_name
                FROM students s
                LEFT JOIN classes c ON s.class_id = c.id
                LEFT JOIN sections sec ON s.section_id = sec.id
                LEFT JOIN parents p ON s.parent_id = p.id
                WHERE $where
                ORDER BY s.first_name ASC
                LIMIT $perPage OFFSET $offset";

        return [
            'data' => $this->raw($sql, $params),
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage),
        ];
    }

    public function getStudentWithDetails(int $id): ?array
    {
        $sql = "SELECT s.*, c.name as class_name, sec.name as section_name, p.*,
                sess.name as session_name
                FROM students s
                LEFT JOIN classes c ON s.class_id = c.id
                LEFT JOIN sections sec ON s.section_id = sec.id
                LEFT JOIN parents p ON s.parent_id = p.id
                LEFT JOIN academic_sessions sess ON s.session_id = sess.id
                WHERE s.id = :id LIMIT 1";
        return $this->rawOne($sql, ['id' => $id]);
    }

    public function getByAdmissionNumber(string $admissionNumber): ?array
    {
        return $this->findBy('admission_number', $admissionNumber);
    }

    public function createStudent(array $data, ?array $parentData = null): int
    {
        $this->beginTransaction();
        try {
            // Create parent if provided
            if ($parentData && !empty($parentData['father_name'])) {
                $parentModel = new ParentModel();
                $parentId = $parentModel->create($parentData);
                $data['parent_id'] = $parentId;
            }

            $studentId = $this->create($data);
            $this->commit();
            return $studentId;
        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    public function getStudentFeeLedger(int $studentId, int $sessionId): array
    {
        $sql = "SELECT 'charge' as type, fs.amount, fc.receipt_number as reference, fc.payment_date as date, 
                fc.paid_amount, fc.discount, fc.fine, fc.payment_method, fc.status,
                fcat.name as category_name
                FROM fee_collections fc
                JOIN fee_categories fcat ON fc.fee_category_id = fcat.id
                LEFT JOIN fee_structures fs ON fc.fee_installment_id IS NULL AND fs.class_id = (SELECT class_id FROM students WHERE id = :sid1) AND fs.fee_category_id = fc.fee_category_id
                WHERE fc.student_id = :sid2 AND fc.session_id = :sess1 AND fc.status != 'Cancelled'
                UNION ALL
                SELECT 'discount' as type, fd.amount, 'Discount' as reference, NOW() as date,
                0 as paid_amount, fd.amount as discount, 0 as fine, '' as payment_method, 'Applied' as status,
                fd.discount_type as category_name
                FROM fee_discounts fd
                WHERE fd.student_id = :sid3 AND fd.session_id = :sess2
                UNION ALL
                SELECT 'refund' as type, fr.amount, fr.refund_voucher_number as reference, fr.created_at as date,
                0 as paid_amount, 0 as discount, 0 as fine, fr.refund_method as payment_method, fr.status,
                'Refund' as category_name
                FROM fee_refunds fr
                WHERE fr.student_id = :sid4 AND fr.session_id = :sess3 AND fr.status != 'Cancelled'
                ORDER BY date ASC";

        $rows = $this->raw($sql, [
            'sid1' => $studentId, 'sid2' => $studentId, 'sid3' => $studentId, 'sid4' => $studentId,
            'sess1' => $sessionId, 'sess2' => $sessionId, 'sess3' => $sessionId
        ]);

        // The raw rows carry different meanings per `type` (charge/discount/refund)
        // but the ledger views (student profile, parent portal, student portal) all
        // expect plain `description`, `debit`, `credit` and a running `balance`
        // column. Compute those here once so every consumer gets consistent data.
        $balance = 0.0;
        foreach ($rows as &$row) {
            $type = $row['type'] ?? '';
            if ($type === 'charge') {
                // fs.amount is only populated for manual (non-installment) fee
                // structures because of the join condition above; fall back to
                // paid + discount as the best estimate of what was charged.
                $charged = $row['amount'] !== null
                    ? (float) $row['amount']
                    : ((float) $row['paid_amount'] + (float) $row['discount']);
                $row['debit']  = $charged;
                $row['credit'] = (float) $row['paid_amount'];
                $row['description'] = trim('Fee Paid - ' . ($row['category_name'] ?: 'Fee')
                    . (!empty($row['reference']) ? ' (Receipt #' . $row['reference'] . ')' : ''));
            } elseif ($type === 'discount') {
                $row['debit']  = 0.0;
                $row['credit'] = (float) $row['amount'];
                $row['description'] = 'Discount' . (!empty($row['category_name']) ? ' - ' . $row['category_name'] : '');
            } elseif ($type === 'refund') {
                $row['debit']  = (float) $row['amount'];
                $row['credit'] = 0.0;
                $row['description'] = 'Refund' . (!empty($row['reference']) ? ' (Voucher #' . $row['reference'] . ')' : '');
            } else {
                $row['debit']  = 0.0;
                $row['credit'] = 0.0;
                $row['description'] = $row['category_name'] ?? '-';
            }
            $balance += $row['credit'] - $row['debit'];
            $row['balance'] = $balance;
        }
        unset($row);

        return $rows;
    }

    public function getOutstandingBalance(int $studentId, int $sessionId): float
    {
        $totalCharges = $this->rawOne(
            "SELECT COALESCE(SUM(fs.amount), 0) as total FROM fee_structures fs
             JOIN students s ON s.class_id = fs.class_id
             WHERE s.id = :sid AND fs.session_id = :sess",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        // Custom / one-off fee lines billed at the Collect Fee screen for a
        // category that has no Fee Structure row for this student's class.
        // Without this, billing a custom amount never registers as 'owed',
        // so outstanding could never reflect it (it would stay 0 forever).
        $totalCustomCharges = $this->rawOne(
            "SELECT COALESCE(SUM(fc.amount), 0) as total FROM fee_collections fc
             WHERE fc.student_id = :sid AND fc.session_id = :sess
               AND fc.status != 'Cancelled'
               AND fc.fee_category_id IS NOT NULL
               AND NOT EXISTS (
                   SELECT 1 FROM fee_structures fs2
                   JOIN students s3 ON s3.class_id = fs2.class_id
                   WHERE s3.id = fc.student_id
                     AND fs2.session_id = fc.session_id
                     AND fs2.fee_category_id = fc.fee_category_id
               )",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        $totalPaid = $this->rawOne(
            "SELECT COALESCE(SUM(paid_amount), 0) as total FROM fee_collections 
             WHERE student_id = :sid AND session_id = :sess AND status != 'Cancelled'",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        // Discount applied AT collection time (stored on fee_collections.discount).
        // Without this, a discount given while collecting a fee never reduces
        // the outstanding balance shown here, even though it does reduce the
        // Fee Management > Outstanding tab and Dashboard totals (Fee model),
        // causing this page to disagree with those screens.
        $totalCollectionDiscount = $this->rawOne(
            "SELECT COALESCE(SUM(discount), 0) as total FROM fee_collections
             WHERE student_id = :sid AND session_id = :sess AND status != 'Cancelled'",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        // Standalone discounts/waivers granted separately (not at collection time)
        $totalDiscount = $this->rawOne(
            "SELECT COALESCE(SUM(amount), 0) as total FROM fee_discounts 
             WHERE student_id = :sid AND session_id = :sess",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        $totalRefund = $this->rawOne(
            "SELECT COALESCE(SUM(amount), 0) as total FROM fee_refunds 
             WHERE student_id = :sid AND session_id = :sess AND status = 'Processed'",
            ['sid' => $studentId, 'sess' => $sessionId]
        )['total'] ?? 0;

        return max(0, ($totalCharges + $totalCustomCharges) - $totalPaid - $totalCollectionDiscount - $totalDiscount - $totalRefund);
    }
}
