<?php
class Attendance extends Model
{
    public string $table = 'student_attendance';

    public function markBulk(array $records, int $sessionId, int $classId, ?int $sectionId, string $date, int $markedBy): int
    {
        $count = 0;
        foreach ($records as $studentId => $status) {
            $sql = "INSERT INTO student_attendance (student_id, class_id, section_id, session_id, date, status, marked_by, created_at)
                    VALUES (:student_id, :class_id, :section_id, :session_id, :date, :status, :marked_by, NOW())
                    ON DUPLICATE KEY UPDATE status = :status2, marked_by = :marked_by2";
            $this->query($sql, [
                'student_id' => $studentId, 'class_id' => $classId, 'section_id' => $sectionId,
                'session_id' => $sessionId, 'date' => $date, 'status' => $status, 'marked_by' => $markedBy,
                'status2' => $status, 'marked_by2' => $markedBy
            ]);
            $count++;
        }
        return $count;
    }

    public function getClassAttendance(int $classId, string $date, int $sessionId): array
    {
        $sql = "SELECT sa.*, s.first_name, s.last_name, s.roll_number FROM student_attendance sa
                JOIN students s ON sa.student_id = s.id
                WHERE sa.class_id = :cid AND sa.date = :date AND sa.session_id = :sid
                ORDER BY s.roll_number ASC";
        return $this->raw($sql, ['cid' => $classId, 'date' => $date, 'sid' => $sessionId]);
    }

    public function getAttendanceReport(?int $classId, int $sessionId, string $fromDate, string $toDate): array
    {
        $params = ['sid' => $sessionId, 'sid2' => $sessionId, 'from' => $fromDate, 'to' => $toDate];
        $classFilter = '';
        if (!empty($classId)) {
            $classFilter = 'AND s.class_id = :cid';
            $params['cid'] = $classId;
        }
        $sql = "SELECT s.id, s.first_name, s.last_name, s.roll_number, c.name as class_name,
                COUNT(sa.id) as total,
                SUM(CASE WHEN sa.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN sa.status = 'Absent' THEN 1 ELSE 0 END) as absent,
                SUM(CASE WHEN sa.status = 'Late' THEN 1 ELSE 0 END) as late
                FROM students s
                LEFT JOIN classes c ON s.class_id = c.id
                LEFT JOIN student_attendance sa ON s.id = sa.student_id
                    AND sa.date BETWEEN :from AND :to AND sa.session_id = :sid
                WHERE s.session_id = :sid2 AND s.status = 'Active' $classFilter
                GROUP BY s.id, s.first_name, s.last_name, s.roll_number, c.name ORDER BY c.name ASC, s.roll_number ASC";
        return $this->raw($sql, $params);
    }

    public function getTeacherAttendanceReport(string $fromDate, string $toDate): array
    {
        $sql = "SELECT t.id, t.first_name, t.last_name, t.employee_id,
                COUNT(ta.id) as total,
                SUM(CASE WHEN ta.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN ta.status = 'Absent' THEN 1 ELSE 0 END) as absent,
                SUM(CASE WHEN ta.status = 'Late' THEN 1 ELSE 0 END) as late,
                SUM(CASE WHEN ta.status = 'Half Day' THEN 1 ELSE 0 END) as half_day
                FROM teachers t
                LEFT JOIN teacher_attendance ta ON t.id = ta.teacher_id AND ta.date BETWEEN :from AND :to
                WHERE t.status = 'Active'
                GROUP BY t.id ORDER BY t.first_name ASC";
        return $this->raw($sql, ['from' => $fromDate, 'to' => $toDate]);
    }

    public function getTeacherAttendanceByDate(string $date): array
    {
        $sql = "SELECT teacher_id, status FROM teacher_attendance WHERE date = :date";
        $rows = $this->raw($sql, ['date' => $date]);
        $result = [];
        foreach ($rows as $row) {
            $result[$row['teacher_id']] = $row['status'];
        }
        return $result;
    }

    public function markTeacherAttendance(array $records, string $date, int $markedBy): int
    {
        $count = 0;
        foreach ($records as $teacherId => $status) {
            $sql = "INSERT INTO teacher_attendance (teacher_id, date, status, marked_by, created_at)
                    VALUES (:teacher_id, :date, :status, :marked_by, NOW())
                    ON DUPLICATE KEY UPDATE status = :status2, marked_by = :marked_by2";
            $this->query($sql, ['teacher_id' => $teacherId, 'date' => $date, 'status' => $status, 'marked_by' => $markedBy, 'status2' => $status, 'marked_by2' => $markedBy]);
            $count++;
        }
        return $count;
    }
}
