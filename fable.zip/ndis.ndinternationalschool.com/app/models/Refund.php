<?php
class Refund extends Model
{
    public string $table = 'fee_refunds';

    public function processRefund(array $data): int
    {
        $this->beginTransaction();
        try {
            $refundModel = new Model();
            $refundModel->table = 'fee_refunds';
            $id = $refundModel->create($data);

            if ($data['status'] === 'Processed') {
                $accountingModel = new Accounting();
                if ($data['refund_method'] === 'Cash') {
                    $accountingModel->addCashDebit($data['amount'], 'Refund - Voucher #' . $data['refund_voucher_number'], date('Y-m-d'), $data['approved_by']);
                } else {
                    $accountingModel->addBankDebit($data['bank_account_id'], $data['amount'], 'Refund - Voucher #' . $data['refund_voucher_number'], date('Y-m-d'), $data['approved_by']);
                }

                $transModel = new Model();
                $transModel->table = 'transactions';
                $transModel->create([
                    'type' => 'Refund', 'category' => 'Fee Refund', 'reference_id' => $id,
                    'amount' => $data['amount'], 'payment_method' => $data['refund_method'],
                    'bank_account_id' => $data['bank_account_id'] ?? null,
                    'description' => 'Fee refund - ' . $data['refund_voucher_number'],
                    'transaction_date' => date('Y-m-d'), 'created_by' => $data['approved_by']
                ]);
            }

            $this->commit();
            return $id;
        } catch (Exception $e) {
            $this->rollBack();
            throw $e;
        }
    }

    public function getRefunds(int $sessionId, int $page = 1, int $perPage = 20): array
    {
        $offset = ($page - 1) * $perPage;
        $total = (int) $this->rawOne("SELECT COUNT(*) as total FROM fee_refunds WHERE session_id = :sid", ['sid' => $sessionId])['total'];
        $data = $this->raw("SELECT fr.*, s.first_name, s.last_name, s.admission_number, fc.receipt_number
            FROM fee_refunds fr
            JOIN students s ON fr.student_id = s.id
            LEFT JOIN fee_collections fc ON fr.fee_collection_id = fc.id
            WHERE fr.session_id = :sid ORDER BY fr.created_at DESC LIMIT $perPage OFFSET $offset", ['sid' => $sessionId]);
        return ['data' => $data, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'total_pages' => ceil($total / $perPage)];
    }
}