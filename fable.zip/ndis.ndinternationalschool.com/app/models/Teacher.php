<?php
class Teacher extends Model
{
    public string $table = 'teachers';

    public function getTeachersWithDept(int $page = 1, int $perPage = 20, string $search = '', ?int $deptId = null): array
    {
        $offset = ($page - 1) * $perPage;
        $where  = '1=1';
        $params = [];

        if ($search) {
            $where .= " AND (t.first_name LIKE :s OR t.last_name LIKE :s OR t.employee_id LIKE :s OR t.phone LIKE :s OR t.email LIKE :s)";
            $params['s'] = "%$search%";
        }
        if ($deptId) {
            $where .= " AND t.department_id = :dept";
            $params['dept'] = $deptId;
        }

        $total = (int)($this->rawOne("SELECT COUNT(*) as total FROM teachers t WHERE $where", $params)['total'] ?? 0);

        $sql = "SELECT t.*, d.name as department_name, u.email as login_email, u.is_active as login_active
                FROM teachers t
                LEFT JOIN departments d ON t.department_id = d.id
                LEFT JOIN users u ON t.user_id = u.id
                WHERE $where
                ORDER BY t.first_name ASC
                LIMIT $perPage OFFSET $offset";

        return [
            'data'        => $this->raw($sql, $params),
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'total_pages' => ceil($total / $perPage),
        ];
    }

    public function getByEmployeeId(string $empId): ?array
    {
        return $this->findBy('employee_id', $empId);
    }

    public function getActiveTeachers(): array
    {
        return $this->findAllBy('status', 'Active', 'first_name ASC');
    }
}
