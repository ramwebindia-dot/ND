<?php
class Mark extends Model
{
    public string $table = 'marks';

    /**
     * Save marks bulk — uses per-subject total_marks from exam_schedules.
     */
    public function saveBulk(int $examId, array $marksData): int
    {
        // Load schedule for total_marks & passing_marks
        $schedules = $this->raw(
            "SELECT subject_id, total_marks, passing_marks FROM exam_schedules WHERE exam_id = :eid",
            ['eid' => $examId]
        );
        $scheduleMap = [];
        foreach ($schedules as $s) {
            $scheduleMap[(int)$s['subject_id']] = $s;
        }

        $count = 0;
        foreach ($marksData as $studentId => $subjects) {
            foreach ($subjects as $subjectId => $marksObtained) {
                $marksObtained = (float)$marksObtained;
                $subjectId     = (int)$subjectId;
                $totalMarks    = (float)($scheduleMap[$subjectId]['total_marks']   ?? 100);
                $passingMarks  = (float)($scheduleMap[$subjectId]['passing_marks'] ?? 33);

                // Clamp to max
                $marksObtained = min($marksObtained, $totalMarks);

                $gradeInfo = Helper::calculateGrade($marksObtained, $totalMarks);

                $sql = "INSERT INTO marks
                            (exam_id, student_id, subject_id, marks_obtained, total_marks, passing_marks, grade, grade_point, created_at)
                        VALUES
                            (:exam_id, :student_id, :subject_id, :marks, :total, :pass, :grade, :gp, NOW())
                        ON DUPLICATE KEY UPDATE
                            marks_obtained = :marks2,
                            total_marks    = :total2,
                            passing_marks  = :pass2,
                            grade          = :grade2,
                            grade_point    = :gp2";

                $this->query($sql, [
                    'exam_id'    => $examId,
                    'student_id' => (int)$studentId,
                    'subject_id' => $subjectId,
                    'marks'      => $marksObtained,
                    'total'      => $totalMarks,
                    'pass'       => $passingMarks,
                    'grade'      => $gradeInfo['grade'],
                    'gp'         => $gradeInfo['point'],
                    'marks2'     => $marksObtained,
                    'total2'     => $totalMarks,
                    'pass2'      => $passingMarks,
                    'grade2'     => $gradeInfo['grade'],
                    'gp2'        => $gradeInfo['point'],
                ]);
                $count++;
            }
        }
        return $count;
    }

    public function getStudentMarks(int $examId, int $studentId): array
    {
        return $this->raw(
            "SELECT m.*, s.name AS subject_name,
                    es.total_marks, es.passing_marks, es.exam_date
             FROM marks m
             JOIN subjects s ON m.subject_id = s.id
             LEFT JOIN exam_schedules es ON es.exam_id = m.exam_id AND es.subject_id = m.subject_id
             WHERE m.exam_id = :eid AND m.student_id = :sid
             ORDER BY es.exam_date, s.name",
            ['eid' => $examId, 'sid' => $studentId]
        );
    }

    public function getClassResults(int $examId, int $classId): array
    {
        return $this->raw(
            "SELECT m.*, s.first_name, s.last_name, s.roll_number,
                    sub.name AS subject_name,
                    es.total_marks, es.passing_marks
             FROM marks m
             JOIN students s ON m.student_id = s.id
             JOIN subjects sub ON m.subject_id = sub.id
             LEFT JOIN exam_schedules es ON es.exam_id = m.exam_id AND es.subject_id = m.subject_id
             WHERE m.exam_id = :eid AND s.class_id = :cid
             ORDER BY s.roll_number, sub.name",
            ['eid' => $examId, 'cid' => $classId]
        );
    }
}
