<?php
/**
 * Academic Session Model
 */
class AcademicSession extends Model
{
    public string $table = 'academic_sessions';

    public function getActive(): ?array
    {
        return $this->findBy('is_active', 1);
    }

    public function activate(int $id): bool
    {
        // Deactivate all sessions first
        $this->query("UPDATE academic_sessions SET is_active = 0");
        // Activate the selected session
        return $this->update($id, ['is_active' => 1, 'is_archived' => 0]);
    }

    public function archive(int $id): bool
    {
        return $this->update($id, ['is_archived' => 1, 'is_active' => 0]);
    }

    public function getActiveSessionId(): ?int
    {
        $session = $this->getActive();
        return $session ? (int) $session['id'] : null;
    }

    public function getActiveSessions(): array
    {
        return $this->findAllBy('is_archived', 0, 'name DESC');
    }

    public function getArchivedSessions(): array
    {
        return $this->findAllBy('is_archived', 1, 'name DESC');
    }

    public function promoteStudents(int $fromSessionId, int $toSessionId, array $studentIds): int
    {
        $count = 0;
        $studentModel = new Student();
        foreach ($studentIds as $studentId) {
            $student = $studentModel->findById((int) $studentId);
            if ($student) {
                $nextClassId = $this->getNextClass($student['class_id'], $toSessionId);
                if ($nextClassId) {
                    $studentModel->update((int) $studentId, [
                        'session_id' => $toSessionId,
                        'class_id' => $nextClassId,
                        'section_id' => null,
                        'roll_number' => null,
                        'status' => 'Active',
                    ]);
                    $count++;
                }
            }
        }
        return $count;
    }

    protected function getNextClass(?int $currentClassId, int $toSessionId): ?int
    {
        if (!$currentClassId) return null;
        $classModel = new ClassModel();
        $currentClass = $classModel->findById($currentClassId);
        if (!$currentClass) return null;

        $nextNumeric = ($currentClass['numeric_value'] ?? 0) + 1;
        $sql = "SELECT id FROM classes WHERE numeric_value = :nv AND session_id = :sid LIMIT 1";
        $nextClass = $this->rawOne($sql, ['nv' => $nextNumeric, 'sid' => $toSessionId]);
        return $nextClass ? (int) $nextClass['id'] : null;
    }
}
