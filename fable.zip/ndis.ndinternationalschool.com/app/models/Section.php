<?php
class Section extends Model
{
    public string $table = 'sections';

    public function getByClass(int $classId): array
    {
        return $this->raw(
            "SELECT s.*, CONCAT(t.first_name, ' ', COALESCE(t.last_name, '')) AS class_teacher_name
             FROM sections s
             LEFT JOIN teachers t ON s.class_teacher_id = t.id
             WHERE s.class_id = :cid
             ORDER BY s.name ASC",
            ['cid' => $classId]
        );
    }
}
