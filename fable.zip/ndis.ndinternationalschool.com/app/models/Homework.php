<?php
class Homework extends Model
{
    public string $table = 'homework';

    public function getHomeworkWithDetails(int $sessionId, int $page = 1, int $perPage = 20): array
    {
        $offset = ($page - 1) * $perPage;
        $total = (int) $this->rawOne("SELECT COUNT(*) as total FROM homework WHERE session_id = :sid", ['sid' => $sessionId])['total'];
        $data = $this->raw("SELECT h.*, c.name as class_name, sec.name as section_name,
                CONCAT(t.first_name, ' ', COALESCE(t.last_name,'')) as teacher_name
            FROM homework h
            JOIN classes c ON h.class_id = c.id
            LEFT JOIN sections sec ON h.section_id = sec.id
            LEFT JOIN teachers t ON h.teacher_id = t.id
            WHERE h.session_id = :sid ORDER BY h.deadline DESC LIMIT $perPage OFFSET $offset", ['sid' => $sessionId]);
        return ['data' => $data, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'total_pages' => ceil($total / $perPage)];
    }

    public function submitHomework(int $homeworkId, int $studentId, ?string $filePath = null, ?string $remarks = null): int
    {
        $subModel = new Model();
        $subModel->table = 'homework_submissions';
        $sql = "INSERT INTO homework_submissions (homework_id, student_id, file_path, remarks, status, submitted_at)
                VALUES (:hid, :sid, :file, :remarks, 'Submitted', NOW())
                ON DUPLICATE KEY UPDATE file_path = :file2, remarks = :remarks2, status = 'Submitted', submitted_at = NOW()";
        $this->query($sql, ['hid' => $homeworkId, 'sid' => $studentId, 'file' => $filePath, 'remarks' => $remarks, 'file2' => $filePath, 'remarks2' => $remarks]);
        return $this->lastInsertId();
    }
}