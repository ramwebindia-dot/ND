<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-plus me-2"></i>Create User</h4>
    <a href="<?php echo url('users'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:620px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('users/create'); ?>">
            <?php echo CSRF::field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" class="form-control"
                           value="<?php echo e($_POST['full_name'] ?? ''); ?>" required autofocus>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Role <span class="text-danger">*</span></label>
                    <select name="role_id" class="form-select" required>
                        <option value="">-- Select Role --</option>
                        <?php foreach ($roles as $r): ?>
                        <option value="<?php echo $r['id']; ?>" <?php echo (int)($_POST['role_id'] ?? 0) === (int)$r['id'] ? 'selected' : ''; ?>>
                            <?php echo e($r['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control"
                           value="<?php echo e($_POST['email'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username <span class="text-muted small">(optional)</span></label>
                    <input type="text" name="username" class="form-control"
                           value="<?php echo e($_POST['username'] ?? ''); ?>"
                           placeholder="Leave blank to use email">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" name="password" id="pwdField" class="form-control" required minlength="6">
                        <button type="button" class="btn btn-outline-secondary" onclick="togglePwd()">
                            <i class="fas fa-eye" id="pwdEye"></i>
                        </button>
                    </div>
                    <div class="form-text">Minimum 6 characters</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control"
                           value="<?php echo e($_POST['phone'] ?? ''); ?>" maxlength="20">
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Create User</button>
                <a href="<?php echo url('users'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function togglePwd() {
    const f = document.getElementById('pwdField');
    const e = document.getElementById('pwdEye');
    f.type = f.type === 'password' ? 'text' : 'password';
    e.className = f.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
