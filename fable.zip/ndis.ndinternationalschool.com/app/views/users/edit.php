<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-edit me-2"></i>Edit User</h4>
    <a href="<?php echo url('users'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row g-3">

<!-- Edit Form -->
<div class="col-md-7">
<div class="card">
    <div class="card-header fw-bold">Account Details</div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('users/edit?id=' . $user['id']); ?>">
            <?php echo CSRF::field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" class="form-control"
                           value="<?php echo e($user['full_name']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Role <span class="text-danger">*</span></label>
                    <select name="role_id" class="form-select" required>
                        <?php foreach ($roles as $r): ?>
                        <option value="<?php echo $r['id']; ?>" <?php echo $user['role_id'] == $r['id'] ? 'selected' : ''; ?>>
                            <?php echo e($r['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control" value="<?php echo e($user['email']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?php echo e($user['username'] ?? ''); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e($user['phone'] ?? ''); ?>">
                </div>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
            </div>
        </form>
    </div>
</div>
</div>

<!-- Sidebar: Password reset + Info -->
<div class="col-md-5">
    <div class="card mb-3">
        <div class="card-header fw-bold">Reset Password</div>
        <div class="card-body">
            <form method="POST" action="<?php echo url('users/reset-password'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <div class="input-group">
                        <input type="password" name="new_password" id="resetPwd" class="form-control" minlength="6" required>
                        <button type="button" class="btn btn-outline-secondary" onclick="togglePwd()">
                            <i class="fas fa-eye" id="resetEye"></i>
                        </button>
                    </div>
                    <div class="form-text">Minimum 6 characters</div>
                </div>
                <button type="submit" class="btn btn-warning btn-sm"
                        onclick="return confirm('Reset password for this user?')">
                    <i class="fas fa-key me-1"></i>Reset Password
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header fw-bold">Account Info</div>
        <div class="card-body">
            <table class="table table-sm table-borderless mb-0">
                <tr><td class="text-muted">Status</td>
                    <td><span class="badge bg-<?php echo $user['is_active'] ? 'success' : 'secondary'; ?>">
                        <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                    </span></td>
                </tr>
                <tr><td class="text-muted">Last Login</td>
                    <td><?php echo $user['last_login'] ? date('d M Y H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                </tr>
                <tr><td class="text-muted">Created</td>
                    <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                </tr>
            </table>

            <div class="mt-3 d-flex gap-2">
                <!-- Toggle Active -->
                <form method="POST" action="<?php echo url('users/toggle-active'); ?>">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                    <button type="submit" class="btn btn-sm btn-outline-<?php echo $user['is_active'] ? 'warning' : 'success'; ?>"
                            onclick="return confirm('<?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?> this user?')">
                        <i class="fas fa-<?php echo $user['is_active'] ? 'ban' : 'check'; ?> me-1"></i>
                        <?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>
                    </button>
                </form>

                <?php if (Session::get('role_name') === 'Super Admin' && (int)$user['id'] !== (int)Session::get('user_id')): ?>
                <form method="POST" action="<?php echo url('users/delete'); ?>"
                      onsubmit="return confirm('Permanently delete this user?')">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger">
                        <i class="fas fa-trash me-1"></i>Delete
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</div><!-- /row -->

<script>
function togglePwd() {
    const f = document.getElementById('resetPwd');
    const e = document.getElementById('resetEye');
    f.type = f.type === 'password' ? 'text' : 'password';
    e.className = f.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
