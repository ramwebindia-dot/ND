<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-users-cog me-2"></i>User Management</h4>
    <?php if (in_array(Session::get('role_name'), ['Super Admin','School Admin'])): ?>
    <a href="<?php echo url('users/create'); ?>" class="btn btn-primary btn-sm">
        <i class="fas fa-plus me-1"></i>New User
    </a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('users'); ?>" class="row g-2 align-items-end">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control form-control-sm"
                       placeholder="Search name, email or username..."
                       value="<?php echo e($search ?? ''); ?>">
            </div>
            <div class="col-md-3">
                <select name="role_id" class="form-select form-select-sm">
                    <option value="">All Roles</option>
                    <?php foreach ($roles as $r): ?>
                    <option value="<?php echo $r['id']; ?>" <?php echo $roleId == $r['id'] ? 'selected' : ''; ?>>
                        <?php echo e($r['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-search me-1"></i>Filter</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo url('users'); ?>" class="btn btn-outline-secondary btn-sm w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email / Username</th>
                        <th>Role</th>
                        <th>Phone</th>
                        <th>Last Login</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($users)): ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">No users found.</td></tr>
                <?php else: ?>
                    <?php foreach ($users as $i => $u): ?>
                    <tr>
                        <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                        <td>
                            <div class="fw-medium"><?php echo e($u['full_name']); ?></div>
                        </td>
                        <td>
                            <div class="small"><?php echo e($u['email']); ?></div>
                            <?php if ($u['username']): ?><div class="text-muted small">@<?php echo e($u['username']); ?></div><?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-<?php
                                echo match($u['role_name'] ?? '') {
                                    'Super Admin'  => 'danger',
                                    'School Admin' => 'warning text-dark',
                                    'Teacher'      => 'info',
                                    'Accountant'   => 'success',
                                    'Principal'    => 'primary',
                                    default        => 'secondary',
                                };
                            ?>"><?php echo e($u['role_name']); ?></span>
                        </td>
                        <td class="small"><?php echo e($u['phone'] ?? '—'); ?></td>
                        <td class="small text-muted">
                            <?php echo $u['last_login'] ? date('d M Y H:i', strtotime($u['last_login'])) : 'Never'; ?>
                        </td>
                        <td>
                            <?php if ($u['is_active']): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="<?php echo url('users/edit?id=' . $u['id']); ?>"
                                   class="btn btn-sm btn-outline-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <!-- Toggle Active -->
                                <form method="POST" action="<?php echo url('users/toggle-active'); ?>" class="d-inline">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-<?php echo $u['is_active'] ? 'secondary' : 'success'; ?>"
                                            title="<?php echo $u['is_active'] ? 'Deactivate' : 'Activate'; ?>">
                                        <i class="fas fa-<?php echo $u['is_active'] ? 'ban' : 'check'; ?>"></i>
                                    </button>
                                </form>

                                <!-- Delete (Super Admin only) -->
                                <?php if (Session::get('role_name') === 'Super Admin'): ?>
                                <form method="POST" action="<?php echo url('users/delete'); ?>" class="d-inline"
                                      onsubmit="return confirm('Delete user <?php echo e(addslashes($u['full_name'])); ?>? This cannot be undone.')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($pagination['total_pages'] > 1): ?>
        <div class="px-3 py-2 border-top">
            <nav>
                <ul class="pagination pagination-sm justify-content-center mb-0">
                    <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                    <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo url('users?page=' . $p . ($search ? '&search='.urlencode($search) : '') . ($roleId ? '&role_id='.$roleId : '')); ?>">
                            <?php echo $p; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>

        <div class="px-3 py-2 text-muted small border-top">
            Showing <?php echo count($users); ?> of <?php echo $pagination['total']; ?> users
        </div>
    </div>
</div>
