<div class="page-header">
    <h4><i class="fas fa-bus"></i> Vehicles</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#vehicleModal">
        <i class="fas fa-plus me-1"></i>Add Vehicle
    </button>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Vehicle Name</th>
                        <th>Reg. Number</th>
                        <th>Type</th>
                        <th>Capacity</th>
                        <th>Driver</th>
                        <th>Phone</th>
                        <th>Assigned Route</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($vehicles)): ?>
                        <tr><td colspan="10" class="text-center text-muted py-4">No vehicles added yet. <button class="btn btn-link p-0" data-bs-toggle="modal" data-bs-target="#vehicleModal">Add one now</button></td></tr>
                    <?php else: ?>
                        <?php foreach ($vehicles as $i => $v): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($v['vehicle_name']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo e($v['vehicle_number']); ?></span></td>
                            <td><?php echo e($v['vehicle_type']); ?></td>
                            <td><?php echo e($v['capacity']); ?> seats</td>
                            <td><?php echo e($v['driver_name'] ?? '-'); ?></td>
                            <td><?php echo e($v['driver_phone'] ?? '-'); ?></td>
                            <td><?php echo e($v['route_name'] ?? '<span class="text-muted">-</span>'); ?></td>
                            <td>
                                <?php if ($v['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-xs btn-outline-primary-custom"
                                        onclick="editVehicle(<?php echo htmlspecialchars(json_encode($v), ENT_QUOTES); ?>)"
                                        title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="<?php echo url('transport/delete-vehicle?id=' . $v['id']); ?>"
                                   class="btn btn-xs btn-outline-danger"
                                   onclick="return confirm('Delete this vehicle?')"
                                   title="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="vehicleModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="vehicleModalTitle"><i class="fas fa-bus me-2"></i>Add Vehicle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo url('transport/save-vehicle'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="vehicleId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Vehicle Name <span class="text-danger">*</span></label>
                            <input type="text" name="vehicle_name" id="vehicleName" class="form-control" placeholder="e.g. School Bus 1" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Registration Number <span class="text-danger">*</span></label>
                            <input type="text" name="vehicle_number" id="vehicleNumber" class="form-control" placeholder="e.g. HR-18-A-1234" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Vehicle Type</label>
                            <select name="vehicle_type" id="vehicleType" class="form-select">
                                <option value="Bus">Bus</option>
                                <option value="Mini Bus">Mini Bus</option>
                                <option value="Van">Van</option>
                                <option value="Auto">Auto</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Capacity (Seats)</label>
                            <input type="number" name="capacity" id="vehicleCapacity" class="form-control" value="40" min="1">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select name="is_active" id="vehicleActive" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <?php if (!empty($drivers)): ?>
                        <div class="col-md-12">
                            <label class="form-label"><i class="fas fa-users-cog me-1 text-muted"></i>Select from Staff <small class="text-muted">(auto-fills name & phone)</small></label>
                            <select id="driverStaffSelect" class="form-select" onchange="fillDriverFromStaff(this)">
                                <option value="">— Type manually OR select from staff —</option>
                                <?php foreach ($drivers as $d): ?>
                                <option value="<?php echo $d['id']; ?>"
                                        data-name="<?php echo e(trim($d['name'])); ?>"
                                        data-phone="<?php echo e($d['phone'] ?? ''); ?>">
                                    <?php echo e(trim($d['name'])); ?><?php echo !empty($d['phone']) ? ' · ' . e($d['phone']) : ''; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-4">
                            <label class="form-label">Driver Name</label>
                            <input type="text" name="driver_name" id="vehicleDriver" class="form-control" placeholder="Driver name">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Driver Phone</label>
                            <input type="text" name="driver_phone" id="vehicleDriverPhone" class="form-control" placeholder="9876500000">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Driver License No.</label>
                            <input type="text" name="driver_license" id="vehicleLicense" class="form-control" placeholder="License number">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="add_driver_to_staff" value="1" id="vehicleAddDriver">
                                <label class="form-check-label" for="vehicleAddDriver">Is driver ko Staff (Non-Teaching) list mein bhi add karo</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Insurance Expiry</label>
                            <input type="date" name="insurance_expiry" id="vehicleInsurance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fitness Certificate Expiry</label>
                            <input type="date" name="fitness_expiry" id="vehicleFitness" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" id="vehicleNotes" class="form-control" rows="2" placeholder="Any additional notes..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Vehicle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function fillDriverFromStaff(sel) {
    const opt = sel.options[sel.selectedIndex];
    if (!opt.value) return;
    document.getElementById('vehicleDriver').value      = opt.dataset.name  || '';
    document.getElementById('vehicleDriverPhone').value = opt.dataset.phone || '';
}

function editVehicle(v) {
    document.getElementById('vehicleModalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Vehicle';
    document.getElementById('vehicleId').value           = v.id;
    document.getElementById('vehicleName').value         = v.vehicle_name;
    document.getElementById('vehicleNumber').value       = v.vehicle_number;
    document.getElementById('vehicleType').value         = v.vehicle_type;
    document.getElementById('vehicleCapacity').value     = v.capacity;
    document.getElementById('vehicleActive').value       = v.is_active;
    document.getElementById('vehicleDriver').value       = v.driver_name  || '';
    document.getElementById('vehicleDriverPhone').value  = v.driver_phone || '';
    document.getElementById('vehicleLicense').value      = v.driver_license || '';
    document.getElementById('vehicleInsurance').value    = v.insurance_expiry || '';
    document.getElementById('vehicleFitness').value      = v.fitness_expiry   || '';
    document.getElementById('vehicleNotes').value        = v.notes || '';
    // Reset staff dropdown on edit open
    const sel = document.getElementById('driverStaffSelect');
    if (sel) sel.value = '';
    new bootstrap.Modal(document.getElementById('vehicleModal')).show();
}
</script>
