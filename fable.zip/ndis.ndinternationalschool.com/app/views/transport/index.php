<div class="page-header">
    <h4><i class="fas fa-bus"></i> Transport Management</h4>
    <div>
        <a href="<?php echo url('transport/routes'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-route me-1"></i>Manage Routes</a>
        <a href="<?php echo url('transport/vehicles'); ?>" class="btn btn-primary-custom"><i class="fas fa-bus me-1"></i>Manage Vehicles</a>
    </div>
</div>

<!-- Stats -->
<?php
$totalRoutes   = count($routes ?? []);
$totalVehicles = count($vehicles ?? []);
$totalStudents = $stats['total_students'] ?? 0;
$outstanding   = max(0, ($stats['total_expected'] ?? 0) - ($stats['total_collected'] ?? 0));
?>
<div class="row mb-4">
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--primary);">
            <div class="stat-icon bg-primary-custom"><i class="fas fa-route"></i></div>
            <div class="stat-value"><?php echo $totalRoutes; ?></div>
            <div class="stat-label">Total Routes</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--info);">
            <div class="stat-icon" style="background:var(--info);"><i class="fas fa-bus text-white"></i></div>
            <div class="stat-value"><?php echo $totalVehicles; ?></div>
            <div class="stat-label">Vehicles</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--success);">
            <div class="stat-icon bg-success-custom"><i class="fas fa-user-graduate"></i></div>
            <div class="stat-value"><?php echo $totalStudents; ?></div>
            <div class="stat-label">Students Using Transport</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--warning);">
            <div class="stat-icon" style="background:var(--warning);"><i class="fas fa-rupee-sign text-white"></i></div>
            <div class="stat-value"><?php echo formatCurrency($stats['total_collected'] ?? 0); ?></div>
            <div class="stat-label">Fees Collected</div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Routes Overview -->
    <div class="col-md-7 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-route me-2 text-primary"></i>Routes Overview</h6>
                <a href="<?php echo url('transport/routes'); ?>" class="btn btn-sm btn-outline-primary-custom">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Route</th>
                                <th>Vehicle</th>
                                <th>Stops</th>
                                <th>Students</th>
                                <th>Fare</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($routes)): ?>
                                <tr><td colspan="6" class="text-center text-muted py-4">No routes configured. <a href="<?php echo url('transport/routes'); ?>">Add a route</a></td></tr>
                            <?php else: ?>
                                <?php foreach ($routes as $route): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($route['name']); ?></strong>
                                        <?php if ($route['is_active']): ?>
                                            <span class="badge bg-success ms-1">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary ms-1">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($route['vehicle_number'] ?? '-'); ?></td>
                                    <td><span class="badge bg-info text-dark"><?php echo $route['pickup_count'] ?? 0; ?></span></td>
                                    <td><span class="badge bg-primary"><?php echo $route['student_count'] ?? 0; ?></span></td>
                                    <td><?php echo formatCurrency($route['fare'] ?? 0); ?></td>
                                    <td>
                                        <a href="<?php echo url('transport/route-details?id=' . $route['id']); ?>" class="btn btn-xs btn-outline-primary-custom" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Vehicles Overview -->
    <div class="col-md-5 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="mb-0"><i class="fas fa-bus me-2 text-info"></i>Vehicles</h6>
                <a href="<?php echo url('transport/vehicles'); ?>" class="btn btn-sm btn-outline-primary-custom">Manage</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Vehicle</th>
                                <th>Driver</th>
                                <th>Route</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($vehicles)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-4">No vehicles added yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($vehicles as $v): ?>
                                <tr>
                                    <td>
                                        <i class="fas fa-bus text-info me-1"></i>
                                        <strong><?php echo e($v['vehicle_number']); ?></strong>
                                        <small class="text-muted d-block"><?php echo e($v['vehicle_name']); ?></small>
                                    </td>
                                    <td>
                                        <?php echo e($v['driver_name'] ?? '-'); ?>
                                        <?php if (!empty($v['driver_phone'])): ?>
                                            <small class="text-muted d-block"><?php echo e($v['driver_phone']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($v['route_name'] ?? '<span class="text-muted">Unassigned</span>'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Links -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h6 class="mb-3"><i class="fas fa-th me-2"></i>Quick Access</h6>
                <div class="row g-3">
                    <div class="col-6 col-md-2">
                        <a href="<?php echo url('transport/pickup-points'); ?>" class="text-decoration-none">
                            <div class="text-center p-3 rounded" style="background:var(--hover-bg); border:1px solid var(--border-color);">
                                <i class="fas fa-map-marker-alt fa-2x text-danger mb-2 d-block"></i>
                                <small class="fw-semibold">Pickup Points</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-md-2">
                        <a href="<?php echo url('transport/student-transport'); ?>" class="text-decoration-none">
                            <div class="text-center p-3 rounded" style="background:var(--hover-bg); border:1px solid var(--border-color);">
                                <i class="fas fa-user-graduate fa-2x text-success mb-2 d-block"></i>
                                <small class="fw-semibold">Student Transport</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-md-2">
                        <a href="<?php echo url('transport/fees'); ?>" class="text-decoration-none">
                            <div class="text-center p-3 rounded" style="background:var(--hover-bg); border:1px solid var(--border-color);">
                                <i class="fas fa-rupee-sign fa-2x text-warning mb-2 d-block"></i>
                                <small class="fw-semibold">Transport Fees</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-md-2">
                        <a href="<?php echo url('transport/routes'); ?>" class="text-decoration-none">
                            <div class="text-center p-3 rounded" style="background:var(--hover-bg); border:1px solid var(--border-color);">
                                <i class="fas fa-route fa-2x text-primary mb-2 d-block"></i>
                                <small class="fw-semibold">Routes</small>
                            </div>
                        </a>
                    </div>
                    <div class="col-6 col-md-2">
                        <a href="<?php echo url('transport/vehicles'); ?>" class="text-decoration-none">
                            <div class="text-center p-3 rounded" style="background:var(--hover-bg); border:1px solid var(--border-color);">
                                <i class="fas fa-bus fa-2x text-info mb-2 d-block"></i>
                                <small class="fw-semibold">Vehicles</small>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
