<div class="page-header">
    <h4><i class="fas fa-rupee-sign"></i> Transport Fees</h4>
    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#feeRatesModal">
        <i class="fas fa-cog me-1"></i>Fee Rate Settings
    </button>
</div>

<!-- ═══════════════════════════════════════════════════════════
     FEE RATE SETTINGS MODAL (Dinod / Other / Custom)
═══════════════════════════════════════════════════════════ -->
<div class="modal fade" id="feeRatesModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-cog me-2"></i>Transport Fee Rate Settings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted small mb-3">Set the standard monthly fee amount for each transport fee type. These amounts will auto-fill when collecting a fee.</p>
                <div class="row g-3">
                    <?php
                    $feeTypeConfig = [
                        'Dinod'  => ['icon' => 'fas fa-map-marker-alt', 'color' => 'warning', 'desc' => 'Village route fee for Dinod area students'],
                        'Other'  => ['icon' => 'fas fa-bus',            'color' => 'secondary','desc' => 'Standard fee for all other routes'],
                        'Custom' => ['icon' => 'fas fa-edit',           'color' => 'info',    'desc' => 'Default suggestion for manually entered custom fees'],
                    ];
                    foreach ($feeTypeConfig as $ft => $cfg):
                        $existing = $feeRateMap[$ft] ?? null;
                    ?>
                    <div class="col-md-4">
                        <div class="card h-100 border-<?php echo $cfg['color']; ?>">
                            <div class="card-header bg-<?php echo $cfg['color']; ?> bg-opacity-10 d-flex justify-content-between align-items-center py-2">
                                <span class="fw-semibold"><i class="<?php echo $cfg['icon']; ?> me-1"></i><?php echo $ft; ?></span>
                                <?php if ($existing): ?>
                                    <a href="<?php echo url('transport/delete-fee-rate?id=' . $existing['id']); ?>"
                                       class="text-danger small"
                                       onclick="return confirm('Reset <?php echo $ft; ?> fee rate? This removes the saved amount.');"
                                       title="Delete / Reset">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-3">
                                <p class="text-muted small mb-3"><?php echo $cfg['desc']; ?></p>
                                <form method="POST" action="<?php echo url('transport/save-fee-rate'); ?>">
                                    <?php echo CSRF::field(); ?>
                                    <?php if ($existing): ?>
                                        <input type="hidden" name="id" value="<?php echo $existing['id']; ?>">
                                    <?php endif; ?>
                                    <input type="hidden" name="fee_type" value="<?php echo $ft; ?>">
                                    <div class="mb-2">
                                        <label class="form-label form-label-sm">Label</label>
                                        <input type="text" name="label" class="form-control form-control-sm"
                                               value="<?php echo e($existing['label'] ?? $ft . ' Fee'); ?>"
                                               placeholder="e.g. Dinod Village Route">
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label form-label-sm">Amount (₹) <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">₹</span>
                                            <input type="number" name="amount" class="form-control"
                                                   value="<?php echo $existing['amount'] ?? '0.00'; ?>"
                                                   min="0" step="0.01" required placeholder="0.00">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label form-label-sm">Description</label>
                                        <input type="text" name="description" class="form-control form-control-sm"
                                               value="<?php echo e($existing['description'] ?? ''); ?>"
                                               placeholder="Optional note">
                                    </div>
                                    <button type="submit" class="btn btn-<?php echo $cfg['color']; ?> btn-sm w-100">
                                        <i class="fas fa-save me-1"></i><?php echo $existing ? 'Update' : 'Set'; ?> <?php echo $ft; ?> Rate
                                    </button>
                                </form>
                            </div>
                            <?php if ($existing): ?>
                            <div class="card-footer py-1 text-center">
                                <small class="text-muted">Current: <strong class="text-<?php echo $cfg['color']; ?>">₹<?php echo number_format($existing['amount'], 2); ?>/mo</strong></small>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Current Rate Summary Bar -->
<?php if (!empty($feeRates)): ?>
<div class="alert alert-light border mb-3 py-2">
    <div class="d-flex flex-wrap gap-3 align-items-center">
        <small class="text-muted fw-semibold"><i class="fas fa-tags me-1"></i>Current Fee Rates:</small>
        <?php foreach (['Dinod'=>'warning','Other'=>'secondary','Custom'=>'info'] as $ft => $col): ?>
            <?php if (isset($feeRateMap[$ft])): ?>
            <span class="badge bg-<?php echo $col; ?> text-dark fs-6 fw-normal px-3 py-2">
                <i class="<?php echo $ft==='Dinod'?'fas fa-map-marker-alt':($ft==='Other'?'fas fa-bus':'fas fa-edit'); ?> me-1"></i>
                <?php echo $ft; ?>: ₹<?php echo number_format($feeRateMap[$ft]['amount'], 2); ?>/mo
            </span>
            <?php endif; ?>
        <?php endforeach; ?>
        <button class="btn btn-outline-secondary btn-sm ms-auto" data-bs-toggle="modal" data-bs-target="#feeRatesModal">
            <i class="fas fa-pencil-alt me-1"></i>Edit Rates
        </button>
    </div>
</div>
<?php endif; ?>


<!-- Stats -->
<?php
$expected  = $stats['total_expected']  ?? 0;
$collected = $stats['total_collected'] ?? 0;
$pending   = max(0, $expected - $collected);
$pct       = $expected > 0 ? round($collected / $expected * 100) : 0;
?>
<div class="row mb-4">
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--info);">
            <div class="stat-icon" style="background:var(--info);"><i class="fas fa-user-graduate text-white"></i></div>
            <div class="stat-value"><?php echo $stats['total_students'] ?? 0; ?></div>
            <div class="stat-label">Students Using Transport</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--primary);">
            <div class="stat-icon bg-primary-custom"><i class="fas fa-rupee-sign"></i></div>
            <div class="stat-value"><?php echo formatCurrency($expected); ?></div>
            <div class="stat-label">Total Expected</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--success);">
            <div class="stat-icon bg-success-custom"><i class="fas fa-check-circle"></i></div>
            <div class="stat-value text-success"><?php echo formatCurrency($collected); ?></div>
            <div class="stat-label">Collected</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--danger);">
            <div class="stat-icon bg-danger-custom"><i class="fas fa-exclamation-circle"></i></div>
            <div class="stat-value text-danger"><?php echo formatCurrency($pending); ?></div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
</div>

<?php if ($expected > 0): ?>
<div class="card mb-3">
    <div class="card-body py-2">
        <div class="d-flex justify-content-between mb-1">
            <small class="text-muted">Collection Progress</small>
            <small class="fw-bold"><?php echo $pct; ?>%</small>
        </div>
        <div class="progress" style="height:10px; border-radius:5px;">
            <div class="progress-bar bg-success" style="width:<?php echo $pct; ?>%;"></div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Fee Records -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Route</th>
                        <th>Fee Type</th>
                        <th>Month</th>
                        <th>Amount</th>
                        <th>Fine</th>
                        <th>Discount</th>
                        <th>Paid</th>
                        <th>Method</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($fees)): ?>
                        <tr><td colspan="11" class="text-center text-muted py-4">No transport fee records yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($fees as $i => $f): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td>
                                <strong><?php echo e($f['student_name']); ?></strong>
                                <small class="text-muted d-block"><?php echo e($f['admission_number']); ?></small>
                            </td>
                            <td><?php echo e($f['route_name']); ?></td>
                            <td>
                                <?php
                                $ft = $f['fee_type'] ?? 'Other';
                                $ftClass = $ft === 'Dinod' ? 'bg-warning text-dark' : ($ft === 'Custom' ? 'bg-info text-dark' : 'bg-secondary');
                                ?>
                                <span class="badge <?php echo $ftClass; ?>"><?php echo e($ft); ?></span>
                            </td>
                            <td><?php echo e($f['month'] ?? '-'); ?></td>
                            <td><?php echo formatCurrency($f['amount']); ?></td>
                            <td><?php echo $f['fine'] > 0 ? '<span class="text-danger">' . formatCurrency($f['fine']) . '</span>' : '-'; ?></td>
                            <td><?php echo $f['discount'] > 0 ? '<span class="text-success">' . formatCurrency($f['discount']) . '</span>' : '-'; ?></td>
                            <td><strong class="text-success"><?php echo formatCurrency($f['paid_amount']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo e($f['payment_method']); ?></span></td>
                            <td><?php echo date('d M Y', strtotime($f['payment_date'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


