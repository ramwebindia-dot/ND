<div class="page-header">
    <h4><i class="fas fa-chart-bar"></i> Transport Reports</h4>
    <button class="btn btn-outline-secondary btn-sm" onclick="window.print()">
        <i class="fas fa-print me-1"></i>Print
    </button>
</div>

<?php
$expected  = $stats['total_expected']  ?? 0;
$collected = $stats['total_collected'] ?? 0;
$pending   = max(0, $expected - $collected);
?>

<!-- Summary Stats -->
<div class="row mb-4">
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--primary);">
            <div class="stat-icon bg-primary-custom"><i class="fas fa-route text-white"></i></div>
            <div class="stat-value"><?php echo count($routes); ?></div>
            <div class="stat-label">Total Routes</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--info);">
            <div class="stat-icon" style="background:var(--info);"><i class="fas fa-user-graduate text-white"></i></div>
            <div class="stat-value"><?php echo $stats['total_students'] ?? 0; ?></div>
            <div class="stat-label">Students Using Transport</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--success);">
            <div class="stat-icon bg-success-custom"><i class="fas fa-rupee-sign text-white"></i></div>
            <div class="stat-value text-success"><?php echo formatCurrency($collected); ?></div>
            <div class="stat-label">Fees Collected</div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card" style="border-left-color:var(--danger);">
            <div class="stat-icon bg-danger-custom"><i class="fas fa-exclamation-circle text-white"></i></div>
            <div class="stat-value text-danger"><?php echo formatCurrency($pending); ?></div>
            <div class="stat-label">Pending Collection</div>
        </div>
    </div>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3" id="reportTabs">
    <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="tab" href="#routeSummary">
            <i class="fas fa-route me-1"></i>Route Summary
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#feeReport">
            <i class="fas fa-rupee-sign me-1"></i>Fee Collection
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#vehicleReport">
            <i class="fas fa-bus me-1"></i>Vehicles
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#unassigned">
            <i class="fas fa-user-times me-1"></i>Unassigned Students
            <?php if (!empty($unassigned)): ?>
                <span class="badge bg-warning text-dark ms-1"><?php echo count($unassigned); ?></span>
            <?php endif; ?>
        </a>
    </li>
</ul>

<div class="tab-content">

    <!-- ── Route Summary ───────────────────────────────────────────────── -->
    <div class="tab-pane fade show active" id="routeSummary">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Route</th>
                                <th>Vehicle</th>
                                <th class="text-center">Capacity</th>
                                <th class="text-center">Students</th>
                                <th class="text-center">Stops</th>
                                <th class="text-end">Route Fare</th>
                                <th class="text-end">Collected</th>
                                <th class="text-center">Fill %</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($routeSummary)): ?>
                                <tr><td colspan="8" class="text-center text-muted py-4">No routes found.</td></tr>
                            <?php else: foreach ($routeSummary as $row): ?>
                                <?php
                                    $cap   = max(1, (int)($row['capacity'] ?? 1));
                                    $stu   = (int)($row['total_students'] ?? 0);
                                    $pct   = min(100, round($stu / $cap * 100));
                                    $color = $pct >= 90 ? 'danger' : ($pct >= 70 ? 'warning' : 'success');
                                ?>
                                <tr>
                                    <td><strong><?php echo e($row['route_name']); ?></strong></td>
                                    <td>
                                        <?php if (!empty($row['vehicle_name'])): ?>
                                            <i class="fas fa-bus text-muted me-1"></i><?php echo e($row['vehicle_name']); ?>
                                            <br><small class="text-muted"><?php echo e($row['vehicle_number']); ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?php echo (int)($row['capacity'] ?? 0); ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-primary"><?php echo $stu; ?></span>
                                    </td>
                                    <td class="text-center"><?php echo (int)($row['total_stops'] ?? 0); ?></td>
                                    <td class="text-end"><?php echo formatCurrency($row['fare'] ?? 0); ?></td>
                                    <td class="text-end text-success fw-bold"><?php echo formatCurrency($row['total_collected'] ?? 0); ?></td>
                                    <td class="text-center">
                                        <div class="progress" style="height:8px; min-width:60px;">
                                            <div class="progress-bar bg-<?php echo $color; ?>" style="width:<?php echo $pct; ?>%;"></div>
                                        </div>
                                        <small class="text-muted"><?php echo $pct; ?>%</small>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ── Fee Collection Report ───────────────────────────────────────── -->
    <div class="tab-pane fade" id="feeReport">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center py-2">
                <span class="fw-bold">Fee Collection by Student</span>
                <input type="text" id="feeSearch" class="form-control form-control-sm w-auto" placeholder="Search student / route...">
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0" id="feeTable">
                        <thead class="table-light">
                            <tr>
                                <th>Student</th>
                                <th>Class</th>
                                <th>Route</th>
                                <th>Type</th>
                                <th class="text-end">Route Fare</th>
                                <th class="text-end">Paid</th>
                                <th class="text-end">Balance</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($feeReport)): ?>
                                <tr><td colspan="8" class="text-center text-muted py-4">No student transport assignments found.</td></tr>
                            <?php else: foreach ($feeReport as $row): ?>
                                <?php
                                    $fare    = (float)($row['route_fare'] ?? 0);
                                    $paid    = (float)($row['paid'] ?? 0);
                                    $balance = max(0, $fare - $paid);
                                    $status  = $balance <= 0 ? ['Paid', 'success'] : ($paid > 0 ? ['Partial', 'warning'] : ['Pending', 'danger']);
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($row['student_name']); ?></strong>
                                        <br><small class="text-muted"><?php echo e($row['admission_number']); ?></small>
                                    </td>
                                    <td><?php echo e($row['class_name'] ?? ''); ?> <?php echo e($row['section_name'] ?? ''); ?></td>
                                    <td><?php echo e($row['route_name']); ?></td>
                                    <td><small><?php echo e($row['transport_type'] ?? 'Both'); ?></small></td>
                                    <td class="text-end"><?php echo formatCurrency($fare); ?></td>
                                    <td class="text-end text-success"><?php echo formatCurrency($paid); ?></td>
                                    <td class="text-end <?php echo $balance > 0 ? 'text-danger' : ''; ?>">
                                        <?php echo formatCurrency($balance); ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-<?php echo $status[1]; ?>"><?php echo $status[0]; ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ── Vehicle Report ─────────────────────────────────────────────── -->
    <div class="tab-pane fade" id="vehicleReport">
        <div class="row">
            <?php if (empty($vehicleReport)): ?>
                <div class="col-12 text-center text-muted py-4">No vehicles found.</div>
            <?php else: foreach ($vehicleReport as $v): ?>
                <?php
                    $cap     = max(1, (int)($v['capacity'] ?? 1));
                    $stu     = (int)($v['student_count'] ?? 0);
                    $pct     = min(100, round($stu / $cap * 100));
                    $color   = $pct >= 90 ? 'danger' : ($pct >= 60 ? 'warning' : 'success');
                    $expIns  = $v['insurance_expiry'] ?? null;
                    $expFit  = $v['fitness_expiry']   ?? null;
                    $insWarn = $expIns && strtotime($expIns) < strtotime('+30 days');
                    $fitWarn = $expFit && strtotime($expFit) < strtotime('+30 days');
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h6 class="mb-0"><?php echo e($v['vehicle_name']); ?></h6>
                                    <small class="text-muted"><?php echo e($v['vehicle_number']); ?> &bull; <?php echo e($v['vehicle_type']); ?></small>
                                </div>
                                <span class="badge <?php echo $v['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo $v['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </div>

                            <div class="mb-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <small class="text-muted">Occupancy</small>
                                    <small><?php echo $stu; ?> / <?php echo $cap; ?></small>
                                </div>
                                <div class="progress" style="height:6px;">
                                    <div class="progress-bar bg-<?php echo $color; ?>" style="width:<?php echo $pct; ?>%;"></div>
                                </div>
                            </div>

                            <?php if (!empty($v['driver_name'])): ?>
                            <div class="mb-1 small">
                                <i class="fas fa-user-tie text-muted me-1"></i><?php echo e($v['driver_name']); ?>
                                <?php if (!empty($v['driver_phone'])): ?>
                                    &bull; <a href="tel:<?php echo e($v['driver_phone']); ?>"><?php echo e($v['driver_phone']); ?></a>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($v['assigned_route'])): ?>
                            <div class="small text-muted"><i class="fas fa-route me-1"></i><?php echo e($v['assigned_route']); ?></div>
                            <?php endif; ?>

                            <?php if ($insWarn || $fitWarn): ?>
                            <div class="mt-2">
                                <?php if ($insWarn): ?>
                                    <span class="badge bg-warning text-dark me-1"><i class="fas fa-exclamation-triangle me-1"></i>Insurance expires <?php echo formatDate($expIns); ?></span>
                                <?php endif; ?>
                                <?php if ($fitWarn): ?>
                                    <span class="badge bg-warning text-dark"><i class="fas fa-exclamation-triangle me-1"></i>Fitness expires <?php echo formatDate($expFit); ?></span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>

    <!-- ── Unassigned Students ────────────────────────────────────────── -->
    <div class="tab-pane fade" id="unassigned">
        <div class="card">
            <div class="card-header py-2">
                <span class="fw-bold">Students Not Assigned to Any Transport Route</span>
                <span class="badge bg-secondary ms-2"><?php echo count($unassigned); ?></span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Admission No.</th>
                                <th>Class</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($unassigned)): ?>
                                <tr><td colspan="5" class="text-center text-muted py-4">
                                    <i class="fas fa-check-circle text-success me-1"></i>All active students have transport assigned.
                                </td></tr>
                            <?php else: $n = 0; foreach ($unassigned as $s): $n++; ?>
                                <tr>
                                    <td><?php echo $n; ?></td>
                                    <td><?php echo e($s['student_name']); ?></td>
                                    <td><?php echo e($s['admission_number']); ?></td>
                                    <td><?php echo e($s['class_name'] ?? ''); ?> <?php echo e($s['section_name'] ?? ''); ?></td>
                                    <td>
                                        <a href="<?php echo url('transport/student-transport'); ?>" class="btn btn-xs btn-outline-primary-custom">
                                            <i class="fas fa-plus me-1"></i>Assign
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div><!-- .tab-content -->

<script>
// Live search for fee table
document.getElementById('feeSearch')?.addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#feeTable tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
});
</script>
