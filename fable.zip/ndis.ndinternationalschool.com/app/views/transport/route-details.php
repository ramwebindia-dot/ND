<?php if (!$route): ?>
    <div class="alert alert-danger">Route not found.</div>
<?php else: ?>

<div class="page-header">
    <h4>
        <a href="<?php echo url('transport/routes'); ?>" class="text-muted me-2"><i class="fas fa-arrow-left"></i></a>
        <i class="fas fa-route me-2"></i><?php echo e($route['name']); ?>
    </h4>
    <div>
        <a href="<?php echo url('transport/pickup-points?route_id=' . $route['id']); ?>" class="btn btn-outline-primary-custom">
            <i class="fas fa-map-marker-alt me-1"></i>Manage Stops
        </a>
        <a href="<?php echo url('transport/student-transport?route_id=' . $route['id']); ?>" class="btn btn-primary-custom">
            <i class="fas fa-user-graduate me-1"></i>Manage Students
        </a>
    </div>
</div>

<!-- Route Info -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Route Information</h6></div>
            <div class="card-body">
                <table class="table table-borderless mb-0">
                    <tr>
                        <td class="text-muted" width="40%">Route Name</td>
                        <td><strong><?php echo e($route['name']); ?></strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Description</td>
                        <td><?php echo e($route['description'] ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Monthly Fare</td>
                        <td><strong class="text-success"><?php echo formatCurrency($route['fare']); ?></strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Status</td>
                        <td>
                            <?php if ($route['is_active']): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h6 class="mb-0"><i class="fas fa-bus me-2"></i>Vehicle Details</h6></div>
            <div class="card-body">
                <?php if (!empty($route['vehicle_number'])): ?>
                <table class="table table-borderless mb-0">
                    <tr>
                        <td class="text-muted" width="40%">Vehicle No.</td>
                        <td><strong><?php echo e($route['vehicle_number']); ?></strong></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Driver</td>
                        <td><?php echo e($route['driver_name'] ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Driver Phone</td>
                        <td>
                            <?php if (!empty($route['driver_phone'])): ?>
                                <a href="tel:<?php echo e($route['driver_phone']); ?>"><?php echo e($route['driver_phone']); ?></a>
                            <?php else: ?>-<?php endif; ?>
                        </td>
                    </tr>
                </table>
                <?php else: ?>
                    <div class="text-center py-3 text-muted">
                        <i class="fas fa-exclamation-triangle text-warning d-block fa-2x mb-2"></i>
                        No vehicle assigned to this route.
                        <br><a href="<?php echo url('transport/routes'); ?>">Assign a vehicle</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Route Map -->
<?php if (!empty($pickupPoints)): ?>
<div class="card mb-4">
    <div class="card-header fw-bold"><i class="fas fa-map me-2"></i>Route Map</div>
    <div class="card-body p-0">
        <div id="routeMap" style="height:320px; width:100%;"></div>
    </div>
</div>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function() {
    var map = L.map('routeMap').setView([28.6139, 77.2090], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var stops = <?php echo json_encode(array_map(function($p) {
        return ['name' => $p['name'], 'lat' => $p['latitude'] ?? null, 'lng' => $p['longitude'] ?? null, 'time' => $p['pickup_time'] ?? ''];
    }, $pickupPoints)); ?>;

    var latLngs = [];
    stops.forEach(function(s) {
        if (s.lat && s.lng) {
            var m = L.marker([s.lat, s.lng]).addTo(map);
            m.bindPopup('<b>' + s.name + '</b>' + (s.time ? '<br>Pickup: ' + s.time : ''));
            latLngs.push([s.lat, s.lng]);
        }
    });
    if (latLngs.length > 1) {
        L.polyline(latLngs, {color: '#4e73df', weight: 3}).addTo(map);
        map.fitBounds(latLngs);
    } else if (!latLngs.length) {
        document.getElementById('routeMap').innerHTML =
            '<div class="text-center py-5 text-muted"><i class="fas fa-map-marker-slash fa-2x mb-2 d-block"></i>No GPS coordinates set for stops.<br><small>Edit pickup points to add latitude/longitude.</small></div>';
    }
})();
</script>
<?php endif; ?>

<!-- Pickup & Drop Points -->
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0"><i class="fas fa-map-marker-alt me-2 text-danger"></i>Route-wise Pickup & Drop Points</h6>
        <span class="badge bg-secondary"><?php echo count($pickupPoints); ?> stops</span>
    </div>
    <div class="card-body">
        <?php if (empty($pickupPoints)): ?>
            <div class="text-center py-3 text-muted">
                No stops configured for this route.
                <a href="<?php echo url('transport/pickup-points?route_id=' . $route['id']); ?>">Add stops</a>
            </div>
        <?php else: ?>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <div class="text-center">
                    <div class="p-2 px-3 rounded" style="background:var(--primary-light, #e8f0fe); border:2px solid var(--primary);">
                        <i class="fas fa-school text-primary d-block mb-1"></i>
                        <small class="fw-bold">School</small>
                    </div>
                </div>
                <?php foreach ($pickupPoints as $p): ?>
                <i class="fas fa-long-arrow-alt-right text-muted"></i>
                <div class="text-center">
                    <div class="p-2 px-3 rounded border" style="min-width:100px;">
                        <i class="fas fa-map-marker-alt text-danger d-block mb-1"></i>
                        <small class="fw-bold"><?php echo e($p['name']); ?></small>
                        <?php if (!empty($p['pickup_time'])): ?>
                            <small class="text-success d-block"><i class="fas fa-arrow-up"></i> <?php echo date('h:i A', strtotime($p['pickup_time'])); ?></small>
                        <?php endif; ?>
                        <?php if (!empty($p['drop_time'])): ?>
                            <small class="text-warning d-block"><i class="fas fa-arrow-down"></i> <?php echo date('h:i A', strtotime($p['drop_time'])); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Students on this route -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0"><i class="fas fa-user-graduate me-2 text-success"></i>Students on this Route</h6>
        <span class="badge bg-primary"><?php echo count($students); ?> students</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Admission No.</th>
                        <th>Class / Section</th>
                        <th>Pickup Point</th>
                        <th>Transport Type</th>
                        <th>Fare</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">No students assigned to this route.</td></tr>
                    <?php else: ?>
                        <?php foreach ($students as $i => $s): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($s['student_name']); ?></strong></td>
                            <td><?php echo e($s['admission_number']); ?></td>
                            <td><?php echo e($s['class_name'] ?? '-'); ?> <?php echo !empty($s['section_name']) ? '- ' . e($s['section_name']) : ''; ?></td>
                            <td>
                                <?php if (!empty($s['pickup_point_name'])): ?>
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i><?php echo e($s['pickup_point_name']); ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-info text-dark"><?php echo e($s['transport_type'] ?? 'Both'); ?></span></td>
                            <td><?php echo formatCurrency($s['custom_fare'] ?? $s['route_fare'] ?? 0); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php endif; ?>
