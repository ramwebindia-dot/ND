<div class="page-header">
    <h4><i class="fas fa-map-marker-alt"></i> Pickup Points</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#pickupModal">
        <i class="fas fa-plus me-1"></i>Add Pickup Point
    </button>
</div>

<!-- Filter -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('transport/pickup-points'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1">Filter by Route</label>
                <select name="route_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Routes</option>
                    <?php foreach ($routes as $r): ?>
                        <option value="<?php echo $r['id']; ?>" <?php echo $filterRoute == $r['id'] ? 'selected' : ''; ?>>
                            <?php echo e($r['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($filterRoute): ?>
            <div class="col-md-2">
                <a href="<?php echo url('transport/pickup-points'); ?>" class="btn btn-sm btn-outline-secondary">Clear Filter</a>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Stop Name</th>
                        <th>Route</th>
                        <th>Order</th>
                        <th>Pick-up Time</th>
                        <th>Drop Time</th>
                        <th>Address / Landmark</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pickupPoints)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No pickup points found. <button class="btn btn-link p-0" data-bs-toggle="modal" data-bs-target="#pickupModal">Add one</button></td></tr>
                    <?php else: ?>
                        <?php foreach ($pickupPoints as $i => $p): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td>
                                <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                <strong><?php echo e($p['name']); ?></strong>
                            </td>
                            <td><span class="badge bg-primary"><?php echo e($p['route_name']); ?></span></td>
                            <td><span class="badge bg-secondary">Stop <?php echo $p['stop_order']; ?></span></td>
                            <td>
                                <?php if (!empty($p['pickup_time'])): ?>
                                    <i class="fas fa-arrow-up text-success me-1"></i><?php echo date('h:i A', strtotime($p['pickup_time'])); ?>
                                <?php else: ?><span class="text-muted">-</span><?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($p['drop_time'])): ?>
                                    <i class="fas fa-arrow-down text-warning me-1"></i><?php echo date('h:i A', strtotime($p['drop_time'])); ?>
                                <?php else: ?><span class="text-muted">-</span><?php endif; ?>
                            </td>
                            <td><?php echo e($p['address'] ?? $p['landmark'] ?? '-'); ?></td>
                            <td>
                                <button class="btn btn-xs btn-outline-primary-custom"
                                        onclick="editPickup(<?php echo htmlspecialchars(json_encode($p), ENT_QUOTES); ?>)"
                                        title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="<?php echo url('transport/delete-pickup-point?id=' . $p['id']); ?>"
                                   class="btn btn-xs btn-outline-danger"
                                   onclick="return confirm('Delete this pickup point?')"
                                   title="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="pickupModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pickupModalTitle"><i class="fas fa-map-marker-alt me-2"></i>Add Pickup Point</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo url('transport/save-pickup-point'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="pickupId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Stop Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="pickupName" class="form-control" placeholder="e.g. Bus Stand" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Stop Order</label>
                            <input type="number" name="stop_order" id="pickupOrder" class="form-control" value="1" min="1">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Route <span class="text-danger">*</span></label>
                            <select name="route_id" id="pickupRoute" class="form-select" required>
                                <option value="">Select Route</option>
                                <?php foreach ($routes as $r): ?>
                                    <option value="<?php echo $r['id']; ?>" <?php echo $filterRoute == $r['id'] ? 'selected' : ''; ?>>
                                        <?php echo e($r['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Morning Pick-up Time</label>
                            <input type="time" name="pickup_time" id="pickupTime" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Afternoon Drop Time</label>
                            <input type="time" name="drop_time" id="pickupDropTime" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Address</label>
                            <input type="text" name="address" id="pickupAddress" class="form-control" placeholder="Full address">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Landmark</label>
                            <input type="text" name="landmark" id="pickupLandmark" class="form-control" placeholder="Nearby landmark">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editPickup(p) {
    document.getElementById('pickupModalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Pickup Point';
    document.getElementById('pickupId').value       = p.id;
    document.getElementById('pickupName').value     = p.name;
    document.getElementById('pickupOrder').value    = p.stop_order;
    document.getElementById('pickupRoute').value    = p.route_id;
    document.getElementById('pickupTime').value     = p.pickup_time || '';
    document.getElementById('pickupDropTime').value = p.drop_time  || '';
    document.getElementById('pickupAddress').value  = p.address    || '';
    document.getElementById('pickupLandmark').value = p.landmark   || '';
    new bootstrap.Modal(document.getElementById('pickupModal')).show();
}
</script>
