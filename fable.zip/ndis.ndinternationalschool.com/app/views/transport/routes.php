<div class="page-header">
    <h4><i class="fas fa-route"></i> Vehicle Routes</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#routeModal">
        <i class="fas fa-plus me-1"></i>Add Route
    </button>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Route Name</th>
                        <th>Assigned Vehicle</th>
                        <th>Fare</th>
                        <th>Stops</th>
                        <th>Students</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($routes)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No routes yet. <button class="btn btn-link p-0" data-bs-toggle="modal" data-bs-target="#routeModal">Add one</button></td></tr>
                    <?php else: ?>
                        <?php foreach ($routes as $i => $r): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td>
                                <strong><?php echo e($r['name']); ?></strong>
                                <?php if (!empty($r['description'])): ?>
                                    <small class="text-muted d-block"><?php echo e($r['description']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($r['vehicle_number'])): ?>
                                    <i class="fas fa-bus text-info me-1"></i>
                                    <?php echo e($r['vehicle_number']); ?>
                                    <small class="text-muted d-block"><?php echo e($r['driver_name'] ?? ''); ?></small>
                                <?php else: ?>
                                    <span class="text-warning"><i class="fas fa-exclamation-triangle me-1"></i>Not Assigned</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo formatCurrency($r['fare'] ?? 0); ?>/month</td>
                            <td><span class="badge bg-info text-dark"><?php echo $r['pickup_count'] ?? 0; ?> stops</span></td>
                            <td><span class="badge bg-primary"><?php echo $r['student_count'] ?? 0; ?> students</span></td>
                            <td>
                                <?php if ($r['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo url('transport/route-details?id=' . $r['id']); ?>" class="btn btn-xs btn-outline-success" title="View Stops & Students">
                                    <i class="fas fa-map-marked-alt"></i>
                                </a>
                                <button class="btn btn-xs btn-outline-primary-custom"
                                        onclick="editRoute(<?php echo htmlspecialchars(json_encode($r), ENT_QUOTES); ?>)"
                                        title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="<?php echo url('transport/delete-route?id=' . $r['id']); ?>"
                                   class="btn btn-xs btn-outline-danger"
                                   onclick="return confirm('Delete this route?')"
                                   title="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Route Modal -->
<div class="modal fade" id="routeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="routeModalTitle"><i class="fas fa-route me-2"></i>Add Route</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo url('transport/save-route'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="routeId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Route Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="routeName" class="form-control" placeholder="e.g. Route A - Bhiwani City" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" id="routeDesc" class="form-control" placeholder="Short description of the route">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Assign Vehicle</label>
                            <select name="vehicle_id" id="routeVehicle" class="form-select">
                                <option value="">-- Not Assigned --</option>
                                <?php foreach ($vehicles as $v): ?>
                                    <?php if ($v['is_active']): ?>
                                    <option value="<?php echo $v['id']; ?>">
                                        <?php echo e($v['vehicle_number']); ?> – <?php echo e($v['vehicle_name']); ?>
                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Monthly Fare (₹) <span class="text-danger">*</span></label>
                            <input type="number" name="fare" id="routeFare" class="form-control" placeholder="800" min="0" step="0.01" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select name="is_active" id="routeActive" class="form-select">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <?php if (!empty($drivers)): ?>
                        <div class="col-md-12">
                            <label class="form-label"><i class="fas fa-users-cog me-1 text-muted"></i>Select Driver from Staff <small class="text-muted">(auto-fills name & phone)</small></label>
                            <select id="routeDriverStaff" class="form-select" onchange="fillRouteDriver(this)">
                                <option value="">— Type manually OR select from staff —</option>
                                <?php foreach ($drivers as $d): ?>
                                <option value="<?php echo $d['id']; ?>"
                                        data-name="<?php echo e(trim($d['name'])); ?>"
                                        data-phone="<?php echo e($d['phone'] ?? ''); ?>">
                                    <?php echo e(trim($d['name'])); ?><?php echo !empty($d['phone']) ? ' · ' . e($d['phone']) : ''; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-6">
                            <label class="form-label">Driver Name</label>
                            <input type="text" name="driver_name" id="routeDriver" class="form-control" placeholder="Driver name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Driver Phone</label>
                            <input type="text" name="driver_phone" id="routeDriverPhone" class="form-control" placeholder="9876500000">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="add_driver_to_staff" value="1" id="routeAddDriver">
                                <label class="form-check-label" for="routeAddDriver">Is driver ko Staff (Non-Teaching) list mein bhi add karo</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Route</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function fillRouteDriver(sel) {
    const opt = sel.options[sel.selectedIndex];
    if (!opt.value) return;
    document.getElementById('routeDriver').value      = opt.dataset.name  || '';
    document.getElementById('routeDriverPhone').value = opt.dataset.phone || '';
}

function editRoute(r) {
    document.getElementById('routeModalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Route';
    document.getElementById('routeId').value       = r.id;
    document.getElementById('routeName').value     = r.name;
    document.getElementById('routeDesc').value     = r.description || '';
    document.getElementById('routeVehicle').value  = r.vehicle_id  || '';
    document.getElementById('routeFare').value     = r.fare;
    document.getElementById('routeActive').value   = r.is_active;
    document.getElementById('routeDriver').value      = r.driver_name  || '';
    document.getElementById('routeDriverPhone').value = r.driver_phone || '';
    new bootstrap.Modal(document.getElementById('routeModal')).show();
}
</script>
