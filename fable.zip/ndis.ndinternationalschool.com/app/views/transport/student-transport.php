<div class="page-header">
    <h4><i class="fas fa-user-graduate"></i> Student Transport</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#assignModal">
        <i class="fas fa-plus me-1"></i>Assign Student
    </button>
</div>

<!-- Filter -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('transport/student-transport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1">Filter by Route</label>
                <select name="route_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">All Routes</option>
                    <?php foreach ($routes as $r): ?>
                        <option value="<?php echo $r['id']; ?>" <?php echo $filterRoute == $r['id'] ? 'selected' : ''; ?>>
                            <?php echo e($r['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($filterRoute): ?>
            <div class="col-auto">
                <a href="<?php echo url('transport/student-transport'); ?>" class="btn btn-sm btn-outline-secondary">Clear</a>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Admission No.</th>
                        <th>Class</th>
                        <th>Route</th>
                        <th>Pickup Point</th>
                        <th>Type</th>
                        <th>Fare</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($assignments)): ?>
                        <tr><td colspan="9" class="text-center text-muted py-4">No students assigned to transport yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($assignments as $i => $a): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td>
                                <a href="<?php echo url('students/profile?id=' . $a['student_id']); ?>">
                                    <strong><?php echo e($a['student_name']); ?></strong>
                                </a>
                            </td>
                            <td><?php echo e($a['admission_number']); ?></td>
                            <td><?php echo e($a['class_name'] ?? '-'); ?></td>
                            <td>
                                <a href="<?php echo url('transport/route-details?id=' . $a['route_id']); ?>">
                                    <?php echo e($a['route_name']); ?>
                                </a>
                            </td>
                            <td>
                                <?php if (!empty($a['pickup_point_name'])): ?>
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i><?php echo e($a['pickup_point_name']); ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-info text-dark"><?php echo e($a['transport_type'] ?? 'Both'); ?></span></td>
                            <td><?php echo formatCurrency($a['custom_fare'] ?? $a['route_fare'] ?? 0); ?>/mo</td>
                            <td>
                                <button class="btn btn-xs btn-outline-primary-custom"
                                        onclick="editAssignment(<?php echo htmlspecialchars(json_encode($a), ENT_QUOTES); ?>)"
                                        title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="<?php echo url('transport/delete-student-assignment?id=' . $a['id']); ?>"
                                   class="btn btn-xs btn-outline-danger"
                                   onclick="return confirm('Remove this student from transport?')"
                                   title="Remove">
                                    <i class="fas fa-times"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Assign Modal -->
<div class="modal fade" id="assignModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignModalTitle"><i class="fas fa-user-graduate me-2"></i>Assign Student to Transport</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo url('transport/save-student-assignment'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="assignId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Student <span class="text-danger">*</span></label>
                            <select name="student_id" id="assignStudent" class="form-select" required>
                                <option value="">Select Student</option>
                                <?php foreach ($students as $s): ?>
                                    <option value="<?php echo $s['id']; ?>">
                                        <?php echo e($s['name'] ?? trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))); ?> (<?php echo e($s['admission_number']); ?>) – <?php echo e($s['class_name'] ?? ''); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Route <span class="text-danger">*</span></label>
                            <select name="route_id" id="assignRoute" class="form-select" required onchange="loadPickupPoints(this.value)">
                                <option value="">Select Route</option>
                                <?php foreach ($routes as $r): ?>
                                    <option value="<?php echo $r['id']; ?>" data-fare="<?php echo $r['fare']; ?>">
                                        <?php echo e($r['name']); ?> (<?php echo formatCurrency($r['fare']); ?>/mo)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Pickup Point</label>
                            <select name="pickup_point_id" id="assignPickup" class="form-select">
                                <option value="">Select a route first</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Transport Type</label>
                            <select name="transport_type" id="assignType" class="form-select">
                                <option value="Both">Both (Pick & Drop)</option>
                                <option value="Pick Up Only">Pick Up Only</option>
                                <option value="Drop Only">Drop Only</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Custom Fare (₹) <small class="text-muted">leave blank for route default</small></label>
                            <input type="number" name="custom_fare" id="assignFare" class="form-control" placeholder="Auto from route" min="0" step="0.01">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Remarks</label>
                            <input type="text" name="remarks" id="assignRemarks" class="form-control" placeholder="Optional notes">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Assignment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function loadPickupPoints(routeId) {
    const sel = document.getElementById('assignPickup');
    if (!routeId) { sel.innerHTML = '<option value="">Select a route first</option>'; return; }
    sel.innerHTML = '<option value="">Loading...</option>';
    fetch('<?php echo url('transport/get-route-pickup-points'); ?>?route_id=' + routeId)
        .then(r => r.json())
        .then(data => {
            sel.innerHTML = '<option value="">-- No specific point --</option>';
            (data.points || []).forEach(p => {
                sel.innerHTML += `<option value="${p.id}">${p.name} (Stop ${p.stop_order})</option>`;
            });
        })
        .catch(() => { sel.innerHTML = '<option value="">Error loading points</option>'; });
}

function editAssignment(a) {
    document.getElementById('assignModalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Assignment';
    document.getElementById('assignId').value       = a.id;
    document.getElementById('assignStudent').value  = a.student_id;
    document.getElementById('assignRoute').value    = a.route_id;
    document.getElementById('assignType').value     = a.transport_type || 'Both';
    document.getElementById('assignFare').value     = a.custom_fare || '';
    document.getElementById('assignRemarks').value  = a.remarks || '';
    loadPickupPoints(a.route_id).then ? '' : loadPickupPoints(a.route_id);
    // Set pickup after load
    setTimeout(() => { document.getElementById('assignPickup').value = a.pickup_point_id || ''; }, 600);
    new bootstrap.Modal(document.getElementById('assignModal')).show();
}
</script>
