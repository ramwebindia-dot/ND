<div class="mb-4">
    <h5 class="fw-bold mb-1">Welcome Back!</h5>
    <p class="text-muted mb-0" style="font-size: 13px;">Sign in to your account</p>
</div>

<?php if (!empty($flash['error'])): ?>
<div class="alert alert-danger d-flex align-items-center py-2 mb-3">
    <i class="fas fa-exclamation-circle me-2"></i><span><?php echo e($flash['error']); ?></span>
</div>
<?php endif; ?>
<?php if (!empty($flash['warning'])): ?>
<div class="alert alert-warning d-flex align-items-center py-2 mb-3">
    <i class="fas fa-exclamation-triangle me-2"></i><span><?php echo e($flash['warning']); ?></span>
</div>
<?php endif; ?>
<?php if (!empty($flash['success'])): ?>
<div class="alert alert-success d-flex align-items-center py-2 mb-3">
    <i class="fas fa-check-circle me-2"></i><span><?php echo e($flash['success']); ?></span>
</div>
<?php endif; ?>

<form method="POST" action="<?php echo url('auth/login'); ?>" id="loginForm">
    <?php echo CSRF::field(); ?>
    
    <div class="form-group mb-3">
        <label class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" name="email" class="form-control" placeholder="Enter your email" 
                   value="<?php echo e($email ?? ''); ?>" required autofocus>
        </div>
    </div>

    <div class="form-group mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" name="password" class="form-control" placeholder="Enter your password" required
                   id="loginPassword">
            <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('loginPassword', this)">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember">
            <label class="form-check-label" for="remember" style="font-size: 13px;">Remember me</label>
        </div>
        <a href="<?php echo url('auth/forgot-password'); ?>" style="font-size: 13px;">Forgot Password?</a>
    </div>

    <button type="submit" class="btn btn-login">
        <i class="fas fa-sign-in-alt me-2"></i>Sign In
    </button>
</form>

<script>
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}
</script>
