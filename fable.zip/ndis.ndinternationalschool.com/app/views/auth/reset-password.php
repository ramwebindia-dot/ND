<div class="mb-4">
    <h5 class="fw-bold mb-1">Reset Your Password</h5>
    <p class="text-muted mb-0" style="font-size: 13px;">
        Setting new password for <strong><?php echo e($email); ?></strong>
    </p>
</div>

<form method="POST" action="<?php echo url('auth/reset-password'); ?>?token=<?php echo urlencode($token); ?>">
    <?php echo CSRF::field(); ?>

    <div class="form-group mb-3">
        <label class="form-label">New Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" name="new_password" class="form-control" placeholder="Minimum 6 characters" required minlength="6" id="newPass">
            <button class="btn btn-outline-secondary" type="button" onclick="togglePass('newPass', this)">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>

    <div class="form-group mb-3">
        <label class="form-label">Confirm New Password</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter new password" required minlength="6" id="confirmPass">
            <button class="btn btn-outline-secondary" type="button" onclick="togglePass('confirmPass', this)">
                <i class="fas fa-eye"></i>
            </button>
        </div>
    </div>

    <div id="passMatchMsg" class="text-danger mb-2" style="font-size:13px; display:none;">
        Passwords do not match.
    </div>

    <button type="submit" class="btn btn-login" id="submitBtn">
        <i class="fas fa-check-circle me-2"></i>Set New Password
    </button>

    <div class="text-center mt-3">
        <a href="<?php echo url('auth/login'); ?>" style="font-size: 13px;">
            <i class="fas fa-arrow-left me-1"></i>Back to Login
        </a>
    </div>
</form>

<script>
function togglePass(id, btn) {
    var inp = document.getElementById(id);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    btn.querySelector('i').classList.toggle('fa-eye');
    btn.querySelector('i').classList.toggle('fa-eye-slash');
}

document.getElementById('confirmPass').addEventListener('input', function() {
    var match = this.value === document.getElementById('newPass').value;
    document.getElementById('passMatchMsg').style.display = match ? 'none' : 'block';
    document.getElementById('submitBtn').disabled = !match;
});
</script>
