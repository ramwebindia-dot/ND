<div class="mb-4">
    <h5 class="fw-bold mb-1">Forgot Password?</h5>
    <p class="text-muted mb-0" style="font-size: 13px;">Enter your registered email to receive a reset link.</p>
</div>

<form method="POST" action="<?php echo url('auth/forgot-password'); ?>">
    <?php echo CSRF::field(); ?>

    <div class="form-group mb-3">
        <label class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" name="email" class="form-control"
                   placeholder="Enter your registered email"
                   value="<?php echo e($_POST['email'] ?? ''); ?>" required>
        </div>
    </div>

    <button type="submit" class="btn btn-login">
        <i class="fas fa-paper-plane me-2"></i>Send Reset Link
    </button>

    <div class="text-center mt-3">
        <a href="<?php echo url('auth/login'); ?>" style="font-size: 13px;">
            <i class="fas fa-arrow-left me-1"></i>Back to Login
        </a>
    </div>
</form>

<div class="mt-3 p-3 rounded" style="background:#e8f4fd; font-size:13px; color:#1565C0; border:1px solid #bee3f8;">
    <i class="fas fa-info-circle me-1"></i>
    The reset link will be valid for <strong>1 hour</strong>.
    If you don't receive an email, check your spam folder or contact the administrator.
</div>
