<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-database me-2"></i>Database Backup</h4>
    <form method="POST" action="<?php echo url('backup/create'); ?>" class="d-inline">
        <?php echo CSRF::field(); ?>
        <button type="submit" class="btn btn-primary-custom" onclick="return confirm('Create a new database backup now?')">
            <i class="fas fa-plus me-1"></i>Create Backup
        </button>
    </form>
</div>

<div class="alert alert-info d-flex align-items-start gap-2">
    <i class="fas fa-info-circle mt-1"></i>
    <div>
        Backups are stored securely outside the public web directory.
        <strong>Restore will overwrite all current data</strong> — download a fresh backup before restoring.
    </div>
</div>

<div class="card">
    <div class="card-header"><i class="fas fa-archive me-2"></i>Backup Files</div>
    <div class="card-body">
        <?php if (!empty($backups)): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>File Name</th>
                        <th>Size</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($backups as $i => $backup): ?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><i class="fas fa-file-alt text-muted me-1"></i><?php echo e($backup['name']); ?></td>
                        <td><?php echo number_format($backup['size'] / 1024, 2); ?> KB</td>
                        <td><?php echo formatDateTime($backup['date']); ?></td>
                        <td>
                            <!-- Download (GET is fine for downloads) -->
                            <a href="<?php echo url('backup/download?file=' . urlencode($backup['name'])); ?>"
                               class="btn btn-sm btn-info" title="Download">
                                <i class="fas fa-download"></i>
                            </a>

                            <!-- Restore → goes to confirmation page (GET) -->
                            <a href="<?php echo url('backup/restore?file=' . urlencode($backup['name'])); ?>"
                               class="btn btn-sm btn-warning" title="Restore">
                                <i class="fas fa-undo"></i>
                            </a>

                            <!-- Delete → POST with CSRF -->
                            <form method="POST" action="<?php echo url('backup/delete'); ?>" class="d-inline"
                                  onsubmit="return confirm('Permanently delete this backup file?')">
                                <?php echo CSRF::field(); ?>
                                <input type="hidden" name="file" value="<?php echo e($backup['name']); ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-database fa-3x text-muted mb-3 d-block"></i>
            <p class="text-muted">No backups found. Click "Create Backup" to generate your first backup.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
