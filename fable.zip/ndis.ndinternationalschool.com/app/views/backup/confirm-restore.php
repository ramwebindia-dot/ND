<div class="page-header">
    <h4><i class="fas fa-exclamation-triangle text-danger me-2"></i>Confirm Database Restore</h4>
</div>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border-danger">
            <div class="card-header bg-danger text-white fw-bold">
                <i class="fas fa-database me-2"></i>⚠️ Warning: This action cannot be undone!
            </div>
            <div class="card-body">
                <p class="text-muted mb-3">You are about to restore the database from the following backup. <strong>All current data will be overwritten.</strong></p>

                <table class="table table-sm table-bordered">
                    <tr>
                        <th width="120">File</th>
                        <td><?php echo e($info['name']); ?></td>
                    </tr>
                    <tr>
                        <th>Date</th>
                        <td><?php echo e($info['date']); ?></td>
                    </tr>
                    <tr>
                        <th>Size</th>
                        <td><?php echo round($info['size'] / 1024, 1); ?> KB</td>
                    </tr>
                </table>

                <div class="alert alert-danger">
                    <strong>This will:</strong>
                    <ul class="mb-0 mt-1">
                        <li>Drop all existing tables</li>
                        <li>Re-create them from the backup file</li>
                        <li>Permanently delete data added after this backup</li>
                    </ul>
                </div>

                <div class="d-flex gap-2 mt-3">
                    <form method="POST" action="<?php echo url('backup/restore'); ?>">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="file" value="<?php echo e($info['name']); ?>">
                        <button type="submit" class="btn btn-danger"
                                onclick="return confirm('Are you absolutely sure? This will overwrite ALL current data!')">
                            <i class="fas fa-undo me-2"></i>Yes, Restore Now
                        </button>
                    </form>
                    <a href="<?php echo url('backup'); ?>" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
