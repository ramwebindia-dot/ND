<?php
// Variables: $student, $marks, $rank, $exams, $examId, $settings, $totalMax, $totalObt, $pct, $allPass
$schoolName = $settings['app_name'] ?? APP_NAME;
$address    = $settings['address'] ?? '';
$examName   = '';
foreach ($exams as $e) { if ((int)$e['id'] === $examId) { $examName = $e['name']; break; } }
?>
<div style="border:2px solid #000; padding:20px; max-width:700px; font-family:Arial,sans-serif; font-size:12px;">
    <div style="text-align:center; border-bottom:2px solid #000; padding-bottom:10px; margin-bottom:12px;">
        <div style="font-size:18px; font-weight:bold;"><?php echo htmlspecialchars($schoolName); ?></div>
        <?php if ($address): ?><div style="font-size:11px;"><?php echo htmlspecialchars($address); ?></div><?php endif; ?>
        <div style="font-size:15px; font-weight:bold; margin-top:6px;">REPORT CARD</div>
        <div><?php echo htmlspecialchars($examName); ?></div>
    </div>

    <table style="width:100%; margin-bottom:12px; border-collapse:collapse;">
        <tr>
            <td style="padding:3px 0; color:#555; width:25%;">Student Name</td>
            <td style="font-weight:bold; padding:3px 8px;"><?php echo htmlspecialchars(trim(($student['first_name']??'').' '.($student['last_name']??''))); ?></td>
            <td style="padding:3px 0; color:#555; width:20%;">Adm. No.</td>
            <td style="padding:3px 8px;"><?php echo htmlspecialchars($student['admission_number']??'—'); ?></td>
        </tr>
        <tr>
            <td style="padding:3px 0; color:#555;">Class/Section</td>
            <td style="padding:3px 8px;"><?php echo htmlspecialchars(($student['class_name']??'—').(isset($student['section_name'])?' / '.$student['section_name']:'')); ?></td>
            <td style="padding:3px 0; color:#555;">Roll Number</td>
            <td style="padding:3px 8px;"><?php echo htmlspecialchars($student['roll_number']??'—'); ?></td>
        </tr>
        <tr>
            <td style="padding:3px 0; color:#555;">Father Name</td>
            <td style="padding:3px 8px;"><?php echo htmlspecialchars($student['father_name']??'—'); ?></td>
            <td style="padding:3px 0; color:#555;">Class Rank</td>
            <td style="padding:3px 8px; font-weight:bold;"><?php echo $rank ? "#$rank" : '—'; ?></td>
        </tr>
    </table>

    <table style="border-collapse:collapse; width:100%; margin-bottom:12px;">
        <thead>
            <tr style="background:#333; color:#fff;">
                <th style="border:1px solid #999; padding:5px 8px;">#</th>
                <th style="border:1px solid #999; padding:5px 8px;">Subject</th>
                <th style="border:1px solid #999; padding:5px 8px; text-align:center;">Max</th>
                <th style="border:1px solid #999; padding:5px 8px; text-align:center;">Obtained</th>
                <th style="border:1px solid #999; padding:5px 8px; text-align:center;">%</th>
                <th style="border:1px solid #999; padding:5px 8px; text-align:center;">Grade</th>
                <th style="border:1px solid #999; padding:5px 8px; text-align:center;">Result</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($marks as $i => $m):
            $subPass = (float)$m['marks_obtained'] >= (float)($m['passing_marks'] ?? 33);
            $subPct  = $m['total_marks'] > 0 ? round($m['marks_obtained'] / $m['total_marks'] * 100, 1) : 0;
        ?>
        <tr style="<?php echo !$subPass ? 'background:#fff0f0;' : ''; ?>">
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo $i+1; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo htmlspecialchars($m['subject_name']); ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center;"><?php echo (int)$m['total_marks']; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center; font-weight:bold;"><?php echo (float)$m['marks_obtained']; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center;"><?php echo $subPct; ?>%</td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center;"><?php echo htmlspecialchars($m['grade']??'—'); ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center; color:<?php echo $subPass?'#155724':'#721c24'; ?>; font-weight:bold;">
                <?php echo $subPass ? 'Pass' : 'Fail'; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <tr style="background:#f0f0f0; font-weight:bold;">
            <td colspan="2" style="border:1px solid #ccc; padding:5px 8px; text-align:right;">TOTAL</td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:center;"><?php echo $totalMax; ?></td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:center;"><?php echo $totalObt; ?></td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:center;"><?php echo $pct; ?>%</td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:center;"></td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:center; color:<?php echo $allPass?'#155724':'#721c24'; ?>; font-size:14px;">
                <?php echo $allPass ? 'PASS' : 'FAIL'; ?>
            </td>
        </tr>
        </tbody>
    </table>

    <table style="width:100%; margin-top:30px; border-collapse:collapse;">
        <tr>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:11px;">Class Teacher</div>
            </td>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:11px;">Principal</div>
            </td>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:11px;">Parent Signature</div>
            </td>
        </tr>
    </table>
</div>
