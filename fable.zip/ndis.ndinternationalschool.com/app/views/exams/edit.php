<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-edit me-2"></i>Edit Exam</h4>
    <a href="<?php echo url('exams'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('exams/edit?id=' . $exam['id']); ?>">
    <?php echo CSRF::field(); ?>

    <div class="card mb-3">
        <div class="card-header fw-bold">Exam Details</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Exam Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($exam['name']); ?>" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Type</label>
                    <select name="exam_type" class="form-select">
                        <?php foreach (['Unit Test','Mid Term','Final','Other'] as $t): ?>
                        <option <?php echo ($exam['exam_type'] ?? '') === $t ? 'selected' : ''; ?>><?php echo $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php foreach (['Upcoming','Ongoing','Completed'] as $st): ?>
                        <option <?php echo ($exam['status'] ?? '') === $st ? 'selected' : ''; ?>><?php echo $st; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Class</label>
                    <select name="class_id" id="classSelect" class="form-select" required>
                        <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $exam['class_id'] == $c['id'] ? 'selected' : ''; ?>>
                            <?php echo e($c['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Section</label>
                    <select name="section_id" id="sectionSelect" class="form-select">
                        <option value="">All Sections</option>
                        <?php foreach ($sections as $sec): ?>
                        <option value="<?php echo $sec['id']; ?>" <?php echo ($exam['section_id'] ?? '') == $sec['id'] ? 'selected' : ''; ?>>
                            <?php echo e($sec['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="form-control" value="<?php echo e($exam['start_date']); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" class="form-control" value="<?php echo e($exam['end_date']); ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2"><?php echo e($exam['description'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>
    </div>

    <!-- Subject Schedule -->
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center fw-bold">
            <span>Subject Schedule</span>
            <button type="button" class="btn btn-success btn-sm" onclick="addRow()">
                <i class="fas fa-plus me-1"></i>Add Subject
            </button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Subject</th>
                            <th>Exam Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Marks</th>
                            <th>Pass Marks</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="schedBody">
                    <?php foreach ($exam['schedules'] as $sched): ?>
                    <tr>
                        <td>
                            <select name="subjects[]" class="form-select form-select-sm" required>
                                <option value="">-- Subject --</option>
                                <?php foreach ($subjects as $sub): ?>
                                <option value="<?php echo $sub['id']; ?>" <?php echo $sched['subject_id'] == $sub['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($sub['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td><input type="date" name="exam_dates[]" class="form-control form-control-sm" value="<?php echo e($sched['exam_date']); ?>" required></td>
                        <td><input type="time" name="start_times[]" class="form-control form-control-sm" value="<?php echo e($sched['start_time'] ?? '09:00'); ?>"></td>
                        <td><input type="time" name="end_times[]" class="form-control form-control-sm" value="<?php echo e($sched['end_time'] ?? '12:00'); ?>"></td>
                        <td><input type="number" name="total_marks[]" class="form-control form-control-sm" value="<?php echo (int)$sched['total_marks']; ?>" min="1" required style="width:75px;"></td>
                        <td><input type="number" name="pass_marks[]" class="form-control form-control-sm" value="<?php echo (int)$sched['passing_marks']; ?>" min="0" style="width:75px;"></td>
                        <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove()"><i class="fas fa-times"></i></button></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
    <a href="<?php echo url('exams'); ?>" class="btn btn-secondary ms-2">Cancel</a>
</form>

<script>
const subjectOpts = [<?php foreach ($subjects as $sub): ?>
    {id: <?php echo $sub['id']; ?>, name: "<?php echo addslashes(e($sub['name'])); ?>"},
<?php endforeach; ?>];

function buildSubjectSelect(selectedId = '') {
    let opts = '<option value="">-- Subject --</option>';
    subjectOpts.forEach(s => opts += `<option value="${s.id}" ${s.id == selectedId ? 'selected' : ''}>${s.name}</option>`);
    return opts;
}

function addRow() {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><select name="subjects[]" class="form-select form-select-sm" required>${buildSubjectSelect()}</select></td>
        <td><input type="date" name="exam_dates[]" class="form-control form-control-sm" required></td>
        <td><input type="time" name="start_times[]" class="form-control form-control-sm" value="09:00"></td>
        <td><input type="time" name="end_times[]" class="form-control form-control-sm" value="12:00"></td>
        <td><input type="number" name="total_marks[]" class="form-control form-control-sm" value="100" min="1" required style="width:75px;"></td>
        <td><input type="number" name="pass_marks[]" class="form-control form-control-sm" value="33" min="0" style="width:75px;"></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove()"><i class="fas fa-times"></i></button></td>
    `;
    document.getElementById('schedBody').appendChild(tr);
}

document.getElementById('classSelect').addEventListener('change', function() {
    const sel = document.getElementById('sectionSelect');
    const classId = this.value;
    if (!classId) { sel.innerHTML = '<option value="">All Sections</option>'; return; }
    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + classId)
        .then(r => r.json())
        .then(data => {
            sel.innerHTML = '<option value="">All Sections</option>';
            data.forEach(s => sel.innerHTML += `<option value="${s.id}">${s.name}</option>`);
        });
});
</script>
