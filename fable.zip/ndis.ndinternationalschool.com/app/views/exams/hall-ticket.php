<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-id-card me-2"></i>Hall Ticket</h4>
    <?php if ($exam && $student): ?>
    <div class="d-flex gap-2 no-print">
        <a href="<?php echo url('exams/hall-ticket?exam_id=' . $selectedExam . '&student_id=' . $selectedStudent . '&format=pdf'); ?>"
           class="btn btn-danger btn-sm">
            <i class="fas fa-file-pdf me-1"></i>Download PDF
        </a>
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-print me-1"></i>Print
        </button>
    </div>
    <?php endif; ?>
</div>

<!-- Selector -->
<div class="card mb-3 no-print">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('exams/hall-ticket'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-medium mb-1">Exam</label>
                <select name="exam_id" class="form-select form-select-sm">
                    <option value="">-- Select Exam --</option>
                    <?php foreach ($exams as $e): ?>
                    <option value="<?php echo $e['id']; ?>" <?php echo $selectedExam == $e['id'] ? 'selected' : ''; ?>>
                        <?php echo e($e['name']); ?> — <?php echo e($e['class_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-medium mb-1">Admission Number</label>
                <input type="text" name="search" class="form-control form-control-sm"
                       value="<?php echo e($search ?? ''); ?>" placeholder="Enter admission number">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">
                    <i class="fas fa-search me-1"></i>Generate
                </button>
            </div>
        </form>
    </div>
</div>

<?php if ($exam && $student && !empty($schedules)):
    $settings = app_settings();
?>
<!-- Hall Ticket Card -->
<div class="card border-2" id="hallTicket" style="max-width:700px;margin:auto;">
    <div class="card-body p-4">
        <!-- Header -->
        <div class="text-center border-bottom pb-3 mb-3">
            <h4 class="mb-0"><?php echo e($settings['app_name'] ?? APP_NAME); ?></h4>
            <p class="text-muted small mb-0"><?php echo e($settings['address'] ?? ''); ?></p>
            <h5 class="mt-2 mb-0 text-uppercase">Hall Ticket / Admit Card</h5>
            <div class="badge bg-primary fs-6 mt-1"><?php echo e($exam['name']); ?></div>
        </div>

        <!-- Student Info + Photo -->
        <div class="row mb-4">
            <div class="col-md-9">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted" width="140">Student Name</td><td><strong><?php echo e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))); ?></strong></td></tr>
                    <tr><td class="text-muted">Admission No.</td><td><?php echo e($student['admission_number'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Class / Section</td><td><?php echo e(($student['class_name'] ?? '—') . (isset($student['section_name']) ? ' / ' . $student['section_name'] : '')); ?></td></tr>
                    <tr><td class="text-muted">Roll Number</td><td><?php echo e($student['roll_number'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Father Name</td><td><?php echo e($student['father_name'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Exam Dates</td><td><?php echo formatDate($exam['start_date']); ?> — <?php echo formatDate($exam['end_date']); ?></td></tr>
                </table>
            </div>
            <div class="col-md-3 text-center">
                <?php if (!empty($student['photo'])): ?>
                <img src="<?php echo asset($student['photo']); ?>" class="img-thumbnail" style="width:100px;height:120px;object-fit:cover;">
                <?php else: ?>
                <div class="border rounded d-flex align-items-center justify-content-center bg-light" style="width:100px;height:120px;margin:auto;">
                    <i class="fas fa-user fa-3x text-muted"></i>
                </div>
                <?php endif; ?>
                <div class="text-muted small mt-1">Photo</div>
            </div>
        </div>

        <!-- Schedule Table -->
        <h6 class="border-bottom pb-1 mb-2">Exam Schedule</h6>
        <table class="table table-sm table-bordered mb-3">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Max Marks</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($schedules as $i => $sched): ?>
            <tr>
                <td><?php echo $i + 1; ?></td>
                <td class="fw-medium"><?php echo e($sched['subject_name']); ?></td>
                <td><?php echo formatDate($sched['exam_date']); ?></td>
                <td><?php echo e($sched['start_time'] ?? '09:00'); ?> – <?php echo e($sched['end_time'] ?? '12:00'); ?></td>
                <td><?php echo (int)$sched['total_marks']; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Instructions -->
        <div class="border rounded p-2 mb-3 bg-light">
            <h6 class="mb-1 small fw-bold">Instructions:</h6>
            <ul class="mb-0 small ps-3">
                <li>Carry this hall ticket to the examination hall.</li>
                <li>Report 15 minutes before exam start time.</li>
                <li>Mobile phones are strictly prohibited.</li>
                <li>School ID card is mandatory.</li>
            </ul>
        </div>

        <!-- Signature -->
        <div class="row mt-4">
            <div class="col-6 text-center">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Student Signature</div>
            </div>
            <div class="col-6 text-center">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Principal Signature</div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar { display: none !important; }
    #hallTicket { max-width: 100% !important; box-shadow: none !important; border: 2px solid #000 !important; }
    body { background: white !important; }
}
</style>

<?php elseif ($selectedExam && isset($search) && $search): ?>
<div class="alert alert-warning mt-3">
    <i class="fas fa-exclamation-triangle me-2"></i>
    No student found with admission number "<?php echo e($search); ?>".
</div>
<?php endif; ?>
