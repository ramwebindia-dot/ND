<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-pen me-2"></i>Marks Entry</h4>
    <?php if ($exam): ?>
    <a href="<?php echo url('exams/class-results?exam_id=' . $selectedExam); ?>" class="btn btn-info btn-sm">
        <i class="fas fa-chart-bar me-1"></i>View Results
    </a>
    <?php endif; ?>
</div>

<!-- Exam Selector -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('exams/marks-entry'); ?>" class="d-flex align-items-center gap-3">
            <label class="fw-medium mb-0">Exam:</label>
            <select name="exam_id" class="form-select" style="width:auto;" onchange="this.form.submit()">
                <option value="">-- Select Exam --</option>
                <?php foreach ($exams as $e): ?>
                <option value="<?php echo $e['id']; ?>" <?php echo $selectedExam == $e['id'] ? 'selected' : ''; ?>>
                    <?php echo e($e['name']); ?> — <?php echo e($e['class_name']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<?php if ($exam && !empty($subjects)): ?>
<form method="POST" action="<?php echo url('exams/marks-entry?exam_id=' . $selectedExam); ?>">
    <?php echo CSRF::field(); ?>
    <input type="hidden" name="exam_id" value="<?php echo $selectedExam; ?>">

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center fw-bold">
            <span><?php echo e($exam['name']); ?> — <?php echo e($exam['class_name'] ?? ''); ?><?php echo !empty($exam['section_name']) ? ' / '.$exam['section_name'] : ''; ?></span>
            <span class="text-muted small"><?php echo count($students); ?> students &bull; <?php echo count($subjects); ?> subjects</span>
        </div>
        <div class="card-body p-0" style="overflow-x:auto;">
            <table class="table table-sm table-bordered mb-0 align-middle">
                <thead class="table-dark" style="position:sticky;top:0;z-index:1;">
                    <tr>
                        <th rowspan="1">#</th>
                        <th rowspan="1">Student</th>
                        <th rowspan="1">Roll</th>
                        <?php foreach ($subjects as $sub): ?>
                        <th class="text-center">
                            <?php echo e($sub['subject_name']); ?>
                            <div class="small fw-normal text-warning">/ <?php echo (int)$sub['total_marks']; ?> (P:<?php echo (int)$sub['passing_marks']; ?>)</div>
                        </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($students as $i => $s): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td class="fw-medium text-nowrap"><?php echo e(trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))); ?></td>
                    <td><?php echo e($s['roll_number'] ?? '—'); ?></td>
                    <?php foreach ($subjects as $sub): ?>
                    <td style="padding:2px;">
                        <?php $val = $existingMarks[$s['id']][$sub['subject_id']] ?? ''; ?>
                        <input type="number"
                               name="marks[<?php echo $s['id']; ?>][<?php echo $sub['subject_id']; ?>]"
                               class="form-control form-control-sm text-center marks-inp"
                               value="<?php echo $val; ?>"
                               min="0" max="<?php echo (int)$sub['total_marks']; ?>" step="0.5"
                               style="width:68px;"
                               data-pass="<?php echo (int)$sub['passing_marks']; ?>"
                               data-max="<?php echo (int)$sub['total_marks']; ?>"
                               oninput="highlight(this)">
                    </td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer d-flex align-items-center gap-3">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save All Marks</button>
            <small class="text-muted"><span style="background:rgba(220,53,69,0.1);padding:2px 6px;border-radius:4px;">Red</span> = below passing marks</small>
        </div>
    </div>
</form>

<script>
function highlight(inp) {
    const v = parseFloat(inp.value), p = parseFloat(inp.dataset.pass), m = parseFloat(inp.dataset.max);
    inp.style.background = (!isNaN(v) && v < p) ? 'rgba(220,53,69,0.15)' : '';
    if (!isNaN(v) && v > m) inp.value = m;
}
// Initialise existing marks highlighting
document.querySelectorAll('.marks-inp').forEach(inp => { if (inp.value !== '') highlight(inp); });
// Tab/Enter navigation across cells
const inputs = [...document.querySelectorAll('.marks-inp')];
inputs.forEach((inp, i) => {
    inp.addEventListener('keydown', e => {
        if (e.key === 'Tab' || e.key === 'Enter') { e.preventDefault(); inputs[i+1]?.focus(); }
    });
});
</script>

<?php elseif ($selectedExam): ?>
<div class="alert alert-warning mt-3">
    <i class="fas fa-exclamation-triangle me-2"></i>
    No subject schedule found for this exam.
    <a href="<?php echo url('exams/edit?id=' . $selectedExam); ?>" class="alert-link">Edit exam</a> and add subjects first.
</div>
<?php endif; ?>
