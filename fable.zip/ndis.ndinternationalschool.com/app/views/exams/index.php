<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-file-alt me-2"></i>Examinations</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('exams/create'); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus me-1"></i>Create Exam</a>
        <a href="<?php echo url('exams/hall-ticket'); ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-id-card me-1"></i>Hall Tickets</a>
        <a href="<?php echo url('exams/class-results'); ?>" class="btn btn-outline-info btn-sm"><i class="fas fa-chart-bar me-1"></i>Class Results</a>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Exam Name</th>
                        <th>Class / Section</th>
                        <th>Type</th>
                        <th>Dates</th>
                        <th>Subjects</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($exams)): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No exams created yet.</td></tr>
                <?php else: foreach ($exams as $i => $exam): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td class="fw-medium"><?php echo e($exam['name']); ?></td>
                    <td>
                        <?php echo e($exam['class_name'] ?? '—'); ?>
                        <?php if ($exam['section_name']): ?>
                        <span class="badge bg-light text-dark ms-1"><?php echo e($exam['section_name']); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><small><?php echo e($exam['exam_type'] ?? '—'); ?></small></td>
                    <td>
                        <small><?php echo formatDate($exam['start_date']); ?></small>
                        <?php if ($exam['end_date'] !== $exam['start_date']): ?>
                        <small class="text-muted"> – <?php echo formatDate($exam['end_date']); ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge bg-secondary"><?php echo (int)($exam['schedule_count'] ?? 0); ?> subjects</span>
                    </td>
                    <td>
                        <?php
                        $badgeClass = match($exam['status']) {
                            'Completed' => 'bg-success',
                            'Ongoing'   => 'bg-warning text-dark',
                            default     => 'bg-info text-dark',
                        };
                        ?>
                        <span class="badge <?php echo $badgeClass; ?>"><?php echo e($exam['status']); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo url('exams/marks-entry?exam_id=' . $exam['id']); ?>" class="btn btn-sm btn-outline-success" title="Marks Entry">
                            <i class="fas fa-pen"></i>
                        </a>
                        <a href="<?php echo url('exams/edit?id=' . $exam['id']); ?>" class="btn btn-sm btn-outline-warning" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="<?php echo url('exams/class-results?exam_id=' . $exam['id']); ?>" class="btn btn-sm btn-outline-info" title="Results">
                            <i class="fas fa-chart-bar"></i>
                        </a>
                        <?php if ($exam['status'] !== 'Completed'): ?>
                        <form method="POST" action="<?php echo url('exams/publish-results'); ?>" class="d-inline"
                              onsubmit="return confirm('Publish results and notify students?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-success" title="Publish Results">
                                <i class="fas fa-bullhorn"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo url('exams/delete'); ?>" class="d-inline"
                              onsubmit="return confirm('Delete this exam and all its marks?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $exam['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
