<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-plus-circle me-2"></i>Create Exam</h4>
    <a href="<?php echo url('exams'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('exams/create'); ?>">
    <?php echo CSRF::field(); ?>

    <div class="card mb-3">
        <div class="card-header fw-bold">Exam Details</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Exam Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. Mid Term Exam 2025">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Type</label>
                    <select name="exam_type" class="form-select">
                        <option>Unit Test</option><option>Mid Term</option><option>Final</option><option>Other</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option selected>Upcoming</option><option>Ongoing</option><option>Completed</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" id="classSelect" class="form-select" required onchange="loadSections(this.value); loadSubjects(this.value);">
                        <option value="">-- Select --</option>
                        <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Section</label>
                    <select name="section_id" id="sectionSelect" class="form-select">
                        <option value="">All Sections</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Start Date <span class="text-danger">*</span></label>
                    <input type="date" name="start_date" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">End Date <span class="text-danger">*</span></label>
                    <input type="date" name="end_date" class="form-control" required>
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Optional notes"></textarea>
                </div>
            </div>
        </div>
    </div>

    <!-- Subject Schedule -->
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center fw-bold">
            <span>Subject Schedule <small class="fw-normal text-muted">(Optional — can add later)</small></span>
            <button type="button" class="btn btn-success btn-sm" onclick="addRow()">
                <i class="fas fa-plus me-1"></i>Add Subject
            </button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Subject</th>
                            <th>Exam Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Marks</th>
                            <th>Pass Marks</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="schedBody"></tbody>
                </table>
            </div>
            <div id="noSchedule" class="text-center py-3 text-muted">
                <i class="fas fa-info-circle me-1"></i> Select a class above to load its subjects, then add rows.
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Create Exam</button>
    <a href="<?php echo url('exams'); ?>" class="btn btn-secondary ms-2">Cancel</a>
</form>

<script>
let subjectOpts = [];

function loadSections(classId) {
    const sel = document.getElementById('sectionSelect');
    if (!classId) { sel.innerHTML = '<option value="">All Sections</option>'; return; }
    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + classId)
        .then(r => r.json())
        .then(data => {
            sel.innerHTML = '<option value="">All Sections</option>';
            data.forEach(s => sel.innerHTML += `<option value="${s.id}">${s.name}</option>`);
        });
}

function loadSubjects(classId) {
    if (!classId) return;
    fetch('<?php echo url("academic/get-subjects?class_id="); ?>' + classId)
        .then(r => r.json())
        .then(data => {
            subjectOpts = data;
            document.getElementById('noSchedule').style.display = data.length ? 'none' : '';
        })
        .catch(() => {
            // Fallback: use all subjects
            subjectOpts = <?php echo json_encode(array_map(fn($s) => ['id'=>$s['id'],'name'=>$s['name']], $subjects)); ?>;
        });
}

// Preload all subjects as fallback
subjectOpts = <?php echo json_encode(array_map(fn($s) => ['id'=>$s['id'],'name'=>$s['name']], $subjects)); ?>;

function buildOpts(selected = '') {
    return '<option value="">-- Subject --</option>' + subjectOpts.map(s =>
        `<option value="${s.id}" ${s.id == selected ? 'selected' : ''}>${s.name}</option>`
    ).join('');
}

function addRow() {
    document.getElementById('noSchedule').style.display = 'none';
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><select name="subjects[]" class="form-select form-select-sm" required>${buildOpts()}</select></td>
        <td><input type="date" name="exam_dates[]" class="form-control form-control-sm" required></td>
        <td><input type="time" name="start_times[]" class="form-control form-control-sm" value="09:00"></td>
        <td><input type="time" name="end_times[]" class="form-control form-control-sm" value="12:00"></td>
        <td><input type="number" name="total_marks[]" class="form-control form-control-sm" value="100" min="1" required style="width:75px;"></td>
        <td><input type="number" name="pass_marks[]" class="form-control form-control-sm" value="33" min="0" style="width:75px;"></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove()"><i class="fas fa-times"></i></button></td>
    `;
    document.getElementById('schedBody').appendChild(tr);
}
</script>
