<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-chart-bar me-2"></i>Class Results</h4>
    <?php if (!empty($results)): ?>
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm no-print">
        <i class="fas fa-print me-1"></i>Print
    </button>
    <?php endif; ?>
</div>

<!-- Exam Selector -->
<div class="card mb-3 no-print">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('exams/class-results'); ?>" class="d-flex align-items-center gap-3">
            <label class="fw-medium mb-0">Exam:</label>
            <select name="exam_id" class="form-select" style="width:auto;" onchange="this.form.submit()">
                <option value="">-- Select Exam --</option>
                <?php foreach ($exams as $e): ?>
                <option value="<?php echo $e['id']; ?>" <?php echo $selectedExam == $e['id'] ? 'selected' : ''; ?>>
                    <?php echo e($e['name']); ?> — <?php echo e($e['class_name']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<?php if ($exam && !empty($results)):
    $passed  = count(array_filter($results, fn($r) => $r['result'] === 'Pass'));
    $failed  = count($results) - $passed;
    $highest = $results[0]['obtained'] ?? 0;
    $avgPct  = count($results) ? round(array_sum(array_column($results, 'percentage')) / count($results), 1) : 0;
?>
<!-- Summary Cards -->
<div class="row g-3 mb-3">
    <div class="col-md-3"><div class="stat-card"><div class="stat-value"><?php echo count($results); ?></div><div class="stat-label">Students Appeared</div></div></div>
    <div class="col-md-3"><div class="stat-card"><div class="stat-value text-success"><?php echo $passed; ?></div><div class="stat-label">Passed</div></div></div>
    <div class="col-md-3"><div class="stat-card"><div class="stat-value text-danger"><?php echo $failed; ?></div><div class="stat-label">Failed</div></div></div>
    <div class="col-md-3"><div class="stat-card"><div class="stat-value"><?php echo $avgPct; ?>%</div><div class="stat-label">Class Average</div></div></div>
</div>

<div class="card">
    <div class="card-header fw-bold">
        <?php echo e($exam['name']); ?> — Result Sheet
        <span class="badge bg-<?php echo $passed == count($results) ? 'success' : 'warning text-dark'; ?> ms-2">
            <?php echo round($passed / count($results) * 100, 0); ?>% Pass Rate
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-sm mb-0 align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Rank</th>
                        <th>Roll No.</th>
                        <th>Student Name</th>
                        <th>Adm. No.</th>
                        <th class="text-center">Max Marks</th>
                        <th class="text-center">Obtained</th>
                        <th class="text-center">Percentage</th>
                        <th class="text-center">Result</th>
                        <th class="no-print">Report Card</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($results as $r): ?>
                <tr class="<?php echo $r['result'] === 'Fail' ? 'table-danger bg-opacity-25' : ''; ?>">
                    <td>
                        <span class="fw-bold <?php echo $r['rank'] <= 3 ? 'text-warning' : ''; ?>">
                            <?php if ($r['rank'] == 1): ?>🥇<?php elseif ($r['rank'] == 2): ?>🥈<?php elseif ($r['rank'] == 3): ?>🥉<?php else: ?>#<?php echo $r['rank']; ?><?php endif; ?>
                        </span>
                    </td>
                    <td><?php echo e($r['roll_number'] ?? '—'); ?></td>
                    <td class="fw-medium"><?php echo e(trim($r['first_name'] . ' ' . $r['last_name'])); ?></td>
                    <td><small><?php echo e($r['admission_number'] ?? '—'); ?></small></td>
                    <td class="text-center"><?php echo (int)$r['max_marks']; ?></td>
                    <td class="text-center fw-bold"><?php echo (float)$r['obtained']; ?></td>
                    <td class="text-center">
                        <span class="badge bg-<?php echo $r['percentage'] >= 75 ? 'success' : ($r['percentage'] >= 50 ? 'warning text-dark' : 'danger'); ?>">
                            <?php echo $r['percentage']; ?>%
                        </span>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-<?php echo $r['result'] === 'Pass' ? 'success' : 'danger'; ?>">
                            <?php echo $r['result']; ?>
                        </span>
                    </td>
                    <td class="no-print">
                        <a href="<?php echo url('exams/report-card?exam_id=' . $selectedExam . '&student_id=' . $r['student_id']); ?>"
                           class="btn btn-xs btn-outline-primary btn-sm">
                            <i class="fas fa-file-alt"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar { display: none !important; }
    body { background: white !important; }
}
</style>

<?php elseif ($selectedExam): ?>
<div class="alert alert-info"><i class="fas fa-info-circle me-2"></i>No marks entered for this exam yet.</div>
<?php endif; ?>
