<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-file-alt me-2"></i>Report Card</h4>
    <?php if ($student && !empty($marks)): ?>
    <div class="d-flex gap-2 no-print">
        <a href="<?php echo url('exams/report-card?exam_id=' . $selectedExam . '&student_id=' . $selectedStudent . '&format=pdf'); ?>"
           class="btn btn-danger btn-sm">
            <i class="fas fa-file-pdf me-1"></i>Download PDF
        </a>
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-print me-1"></i>Print
        </button>
    </div>
    <?php endif; ?>
</div>

<!-- Selector -->
<div class="card mb-3 no-print">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('exams/report-card'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-medium mb-1">Exam</label>
                <select name="exam_id" class="form-select form-select-sm" required>
                    <option value="">-- Select Exam --</option>
                    <?php foreach ($exams as $e): ?>
                    <option value="<?php echo $e['id']; ?>" <?php echo $selectedExam == $e['id'] ? 'selected' : ''; ?>>
                        <?php echo e($e['name']); ?> — <?php echo e($e['class_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-medium mb-1">Student (Adm. No / Name)</label>
                <input type="text" name="search" class="form-control form-control-sm"
                       value="<?php echo e($_GET['search'] ?? ''); ?>"
                       placeholder="Admission number or name">
                <input type="hidden" name="student_id" value="">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">
                    <i class="fas fa-search me-1"></i>Generate
                </button>
            </div>
        </form>
    </div>
</div>

<?php if ($student && !empty($marks)):
    $totalMax  = array_sum(array_column($marks, 'total_marks'));
    $totalObt  = array_sum(array_column($marks, 'marks_obtained'));
    $pct       = $totalMax > 0 ? round($totalObt / $totalMax * 100, 1) : 0;
    $allPass   = true;
    foreach ($marks as $m) {
        if ((float)$m['marks_obtained'] < (float)($m['passing_marks'] ?? 33)) { $allPass = false; break; }
    }
    $settings = app_settings();
?>
<div class="card" id="reportCard">
    <div class="card-body p-4">
        <!-- School header -->
        <div class="text-center border-bottom pb-3 mb-3">
            <h4 class="mb-0"><?php echo e($settings['app_name'] ?? APP_NAME); ?></h4>
            <p class="text-muted mb-1 small"><?php echo e($settings['address'] ?? ''); ?></p>
            <h5 class="mt-2 mb-0">REPORT CARD</h5>
            <?php foreach ($exams as $e): if ((int)$e['id'] === $selectedExam): ?>
            <div class="text-muted small"><?php echo e($e['name']); ?></div>
            <?php endif; endforeach; ?>
        </div>

        <!-- Student Info -->
        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted" width="130">Student Name</td><td><strong><?php echo e(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))); ?></strong></td></tr>
                    <tr><td class="text-muted">Admission No.</td><td><?php echo e($student['admission_number'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Class / Section</td><td><?php echo e(($student['class_name'] ?? '—') . (isset($student['section_name']) ? ' / ' . $student['section_name'] : '')); ?></td></tr>
                    <tr><td class="text-muted">Roll Number</td><td><?php echo e($student['roll_number'] ?? '—'); ?></td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted" width="130">Father Name</td><td><?php echo e($student['father_name'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Session</td><td><?php echo e($student['session_name'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Rank in Class</td><td><strong><?php echo $rank ? "#$rank" : '—'; ?></strong></td></tr>
                </table>
            </div>
        </div>

        <!-- Marks Table -->
        <table class="table table-bordered align-middle mb-3">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Subject</th>
                    <th class="text-center">Max Marks</th>
                    <th class="text-center">Obtained</th>
                    <th class="text-center">%</th>
                    <th class="text-center">Grade</th>
                    <th class="text-center">Result</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($marks as $i => $m):
                $subPass = (float)$m['marks_obtained'] >= (float)($m['passing_marks'] ?? 33);
                $subPct  = ($m['total_marks'] > 0) ? round($m['marks_obtained'] / $m['total_marks'] * 100, 1) : 0;
            ?>
            <tr>
                <td><?php echo $i + 1; ?></td>
                <td><?php echo e($m['subject_name']); ?></td>
                <td class="text-center"><?php echo (int)$m['total_marks']; ?></td>
                <td class="text-center fw-bold"><?php echo (float)$m['marks_obtained']; ?></td>
                <td class="text-center"><?php echo $subPct; ?>%</td>
                <td class="text-center"><span class="badge bg-secondary"><?php echo e($m['grade'] ?? '—'); ?></span></td>
                <td class="text-center">
                    <span class="badge bg-<?php echo $subPass ? 'success' : 'danger'; ?>">
                        <?php echo $subPass ? 'Pass' : 'Fail'; ?>
                    </span>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="fw-bold table-secondary">
                    <td colspan="2">TOTAL</td>
                    <td class="text-center"><?php echo $totalMax; ?></td>
                    <td class="text-center"><?php echo $totalObt; ?></td>
                    <td class="text-center"><?php echo $pct; ?>%</td>
                    <td class="text-center"><span class="badge bg-<?php echo $pct >= 90 ? 'success' : ($pct >= 75 ? 'info' : ($pct >= 60 ? 'primary' : ($pct >= 33 ? 'warning text-dark' : 'danger'))); ?>">
                        <?php echo $pct >= 90 ? 'A+' : ($pct >= 80 ? 'A' : ($pct >= 70 ? 'B+' : ($pct >= 60 ? 'B' : ($pct >= 50 ? 'C' : ($pct >= 33 ? 'D' : 'F'))))); ?>
                    </span></td>
                    <td class="text-center">
                        <span class="badge bg-<?php echo $allPass ? 'success' : 'danger'; ?> fs-6">
                            <?php echo $allPass ? 'PASS' : 'FAIL'; ?>
                        </span>
                    </td>
                </tr>
            </tfoot>
        </table>

        <!-- Summary -->
        <div class="row g-3 mb-3">
            <div class="col-md-3">
                <div class="border rounded p-2 text-center">
                    <div class="fs-4 fw-bold"><?php echo $totalObt; ?>/<?php echo $totalMax; ?></div>
                    <div class="text-muted small">Total Marks</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-2 text-center">
                    <div class="fs-4 fw-bold"><?php echo $pct; ?>%</div>
                    <div class="text-muted small">Percentage</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-2 text-center">
                    <div class="fs-4 fw-bold"><?php echo $rank ? "#$rank" : '—'; ?></div>
                    <div class="text-muted small">Class Rank</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border rounded p-2 text-center bg-<?php echo $allPass ? 'success' : 'danger'; ?> text-white">
                    <div class="fs-4 fw-bold"><?php echo $allPass ? 'PASS' : 'FAIL'; ?></div>
                    <div class="small">Overall Result</div>
                </div>
            </div>
        </div>

        <!-- Signatures -->
        <div class="row mt-4 pt-2 border-top">
            <div class="col-4 text-center">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Class Teacher</div>
            </div>
            <div class="col-4 text-center">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Principal</div>
            </div>
            <div class="col-4 text-center">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Parent Signature</div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar, .page-header { display: none !important; }
    #reportCard { box-shadow: none !important; border: none !important; }
    body { background: white !important; }
}
</style>

<?php elseif (!empty($_GET['exam_id'])): ?>
<div class="alert alert-info mt-3">
    <i class="fas fa-info-circle me-2"></i>
    No marks found. Search by admission number or student name above.
</div>
<?php endif; ?>
