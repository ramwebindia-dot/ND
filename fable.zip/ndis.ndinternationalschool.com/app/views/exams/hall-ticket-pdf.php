<?php
// Variables available: $exam, $student, $schedules, $settings
$schoolName = $settings['app_name'] ?? APP_NAME;
$address    = $settings['address'] ?? '';
?>
<div style="border:2px solid #000; padding:20px; max-width:680px; font-family:Arial,sans-serif; font-size:12px;">
    <div style="text-align:center; border-bottom:2px solid #000; padding-bottom:10px; margin-bottom:12px;">
        <div style="font-size:18px; font-weight:bold;"><?php echo htmlspecialchars($schoolName); ?></div>
        <?php if ($address): ?><div style="font-size:11px;"><?php echo htmlspecialchars($address); ?></div><?php endif; ?>
        <div style="font-size:15px; font-weight:bold; margin-top:6px; text-transform:uppercase;">Hall Ticket / Admit Card</div>
        <div style="font-size:13px; color:#333;"><?php echo htmlspecialchars($exam['name'] ?? ''); ?></div>
    </div>

    <table style="width:100%; margin-bottom:12px;">
        <tr>
            <td style="width:75%; vertical-align:top;">
                <table style="border-collapse:collapse; width:100%;">
                    <?php foreach ([
                        'Student Name'  => trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')),
                        'Admission No.' => $student['admission_number'] ?? '—',
                        'Class/Section' => ($student['class_name'] ?? '—') . (isset($student['section_name']) ? ' / '.$student['section_name'] : ''),
                        'Roll Number'   => $student['roll_number'] ?? '—',
                        'Father Name'   => $student['father_name'] ?? '—',
                    ] as $label => $val): ?>
                    <tr>
                        <td style="color:#555; width:35%; padding:3px 0;"><?php echo $label; ?></td>
                        <td style="font-weight:bold; padding:3px 0;"><?php echo htmlspecialchars($val); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </td>
            <td style="width:25%; text-align:center; vertical-align:top;">
                <div style="border:1px solid #999; width:90px; height:110px; margin:auto; display:flex; align-items:center; justify-content:center; font-size:10px; color:#999;">
                    Photo
                </div>
            </td>
        </tr>
    </table>

    <table style="border-collapse:collapse; width:100%; margin-bottom:12px;">
        <thead>
            <tr style="background:#333; color:#fff;">
                <th style="border:1px solid #999; padding:5px 8px;">#</th>
                <th style="border:1px solid #999; padding:5px 8px;">Subject</th>
                <th style="border:1px solid #999; padding:5px 8px;">Date</th>
                <th style="border:1px solid #999; padding:5px 8px;">Time</th>
                <th style="border:1px solid #999; padding:5px 8px;">Max Marks</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($schedules as $i => $s): ?>
        <tr>
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo $i + 1; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; font-weight:bold;"><?php echo htmlspecialchars($s['subject_name']); ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo date('d-m-Y', strtotime($s['exam_date'])); ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo $s['start_time'] ?? '09:00'; ?> – <?php echo $s['end_time'] ?? '12:00'; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:center;"><?php echo (int)$s['total_marks']; ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div style="background:#f5f5f5; border:1px solid #ddd; padding:8px; margin-bottom:15px; font-size:11px;">
        <strong>Instructions:</strong> Carry this hall ticket. Report 15 mins early. No mobile phones. School ID mandatory.
    </div>

    <table style="width:100%; margin-top:20px;">
        <tr>
            <td style="text-align:center; width:50%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Student Signature</div>
            </td>
            <td style="text-align:center; width:50%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px;">Principal Signature</div>
            </td>
        </tr>
    </table>
</div>
