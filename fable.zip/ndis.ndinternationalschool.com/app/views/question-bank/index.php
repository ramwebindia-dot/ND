<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-database me-2"></i>Question Bank</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('question-bank/papers'); ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-file-alt me-1"></i>Question Papers</a>
        <a href="<?php echo url('question-bank/create'); ?>" class="btn btn-primary-custom btn-sm"><i class="fas fa-plus me-1"></i>Add Question</a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">Class</label>
                <select name="class_id" class="form-select form-select-sm" id="filterClass" onchange="this.form.submit()">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo ($filters['classId']==$c['id'])?'selected':''; ?>><?php echo e($c['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Subject</label>
                <select name="subject_id" class="form-select form-select-sm">
                    <option value="">All Subjects</option>
                    <?php foreach ($subjects as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo ($filters['subjectId']==$s['id'])?'selected':''; ?>><?php echo e($s['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Type</label>
                <select name="type" class="form-select form-select-sm">
                    <option value="">All Types</option>
                    <?php foreach (['MCQ','Short Answer','Long Answer','True/False','Fill in Blank'] as $t): ?>
                    <option value="<?php echo $t; ?>" <?php echo ($filters['type']===$t)?'selected':''; ?>><?php echo $t; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Difficulty</label>
                <select name="difficulty" class="form-select form-select-sm">
                    <option value="">All</option>
                    <?php foreach (['Easy','Medium','Hard'] as $d): ?>
                    <option value="<?php echo $d; ?>" <?php echo ($filters['difficulty']===$d)?'selected':''; ?>><?php echo $d; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Stats -->
<?php
$easy   = count(array_filter($questions, fn($q)=>$q['difficulty']==='Easy'));
$medium = count(array_filter($questions, fn($q)=>$q['difficulty']==='Medium'));
$hard   = count(array_filter($questions, fn($q)=>$q['difficulty']==='Hard'));
$mcq    = count(array_filter($questions, fn($q)=>$q['question_type']==='MCQ'));
?>
<div class="row g-2 mb-3">
    <div class="col"><div class="card text-center py-2"><div class="fw-bold"><?php echo count($questions); ?></div><small class="text-muted">Total</small></div></div>
    <div class="col"><div class="card text-center py-2 border-success"><div class="fw-bold text-success"><?php echo $easy; ?></div><small class="text-muted">Easy</small></div></div>
    <div class="col"><div class="card text-center py-2 border-warning"><div class="fw-bold text-warning"><?php echo $medium; ?></div><small class="text-muted">Medium</small></div></div>
    <div class="col"><div class="card text-center py-2 border-danger"><div class="fw-bold text-danger"><?php echo $hard; ?></div><small class="text-muted">Hard</small></div></div>
    <div class="col"><div class="card text-center py-2 border-info"><div class="fw-bold text-info"><?php echo $mcq; ?></div><small class="text-muted">MCQ</small></div></div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Question</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Chapter</th>
                        <th>Type</th>
                        <th>Marks</th>
                        <th>Difficulty</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($questions)): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">No questions found. <a href="<?php echo url('question-bank/create'); ?>">Add first question</a></td></tr>
                <?php else: ?>
                <?php foreach ($questions as $i => $q): ?>
                <?php
$diffColor = match($q['difficulty']) {
    'Easy'   => 'success',
    'Medium' => 'warning',
    'Hard'   => 'danger',
    default  => 'secondary'
};
?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td>
                        <div style="max-width:300px;">
                            <?php echo e(substr($q['question_text'], 0, 80)); ?><?php echo strlen($q['question_text'])>80?'…':''; ?>
                        </div>
                        <?php if ($q['question_type'] === 'MCQ'): ?>
                        <small class="text-muted">
                            A:<?php echo e(substr($q['option_a']??'',0,20)); ?> |
                            B:<?php echo e(substr($q['option_b']??'',0,20)); ?>
                        </small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($q['class_name']); ?></td>
                    <td><?php echo e($q['subject_name']); ?></td>
                    <td><?php echo e($q['chapter'] ? substr($q['chapter'],0,20) : '—'); ?></td>
                    <td><span class="badge bg-secondary"><?php echo e($q['question_type']); ?></span></td>
                    <td><?php echo $q['marks']; ?></td>
                    <td><span class="badge bg-<?php echo $diffColor; ?>"><?php echo $q['difficulty']; ?></span></td>
                    <td>
                        <a href="<?php echo url('question-bank/edit?id='.$q['id']); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                        <form method="POST" action="<?php echo url('question-bank/delete'); ?>" class="d-inline" onsubmit="return confirm('Delete this question?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $q['id']; ?>">
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
