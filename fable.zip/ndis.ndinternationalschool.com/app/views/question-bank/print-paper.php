<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo e($paper['title']); ?></title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Times New Roman', serif; font-size:12pt; padding:20mm; color:#000; }
.school-header { text-align:center; border-bottom:2px solid #000; padding-bottom:8px; margin-bottom:12px; }
.school-header h2 { font-size:16pt; font-weight:bold; }
.school-header h3 { font-size:13pt; }
.paper-meta { display:flex; justify-content:space-between; margin-bottom:10px; font-size:11pt; }
.instructions { border:1px solid #999; padding:6px 10px; margin-bottom:15px; font-size:10pt; }
.instructions p { margin-bottom:2px; }
.section-header { font-size:13pt; font-weight:bold; border-bottom:1px solid #000; margin:15px 0 10px; }
.question { margin-bottom:12px; }
.question-num { font-weight:bold; }
.mcq-options { margin-top:4px; padding-left:20px; }
.mcq-options span { margin-right:20px; }
.answer-space { margin-top:4px; border-bottom:1px dotted #999; min-height:30px; }
.long-answer-space { margin-top:4px; border-bottom:1px dotted #999; min-height:80px; }
@media print {
    body { padding:15mm; }
    .no-print { display:none; }
    .question { page-break-inside:avoid; }
}
</style>
</head>
<body>

<div class="no-print" style="padding:10px; background:#f8f9fa; margin-bottom:20px; text-align:center;">
    <button onclick="window.print()" style="padding:8px 20px; background:#007bff; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:14px;">
        🖨️ Print Paper
    </button>
    <button onclick="window.close()" style="padding:8px 20px; background:#6c757d; color:#fff; border:none; border-radius:4px; cursor:pointer; margin-left:8px; font-size:14px;">
        ✕ Close
    </button>
</div>

<!-- School Header -->
<div class="school-header">
    <h2><?php echo defined('APP_NAME') ? e(APP_NAME) : 'School Name'; ?></h2>
    <h3><?php echo e($paper['title']); ?></h3>
    <div style="margin-top:4px; font-size:11pt;">
        Class: <?php echo e($paper['class_name']); ?> &nbsp;|&nbsp;
        Subject: <?php echo e($paper['subject_name']); ?>
        <?php if ($paper['exam_type']): ?> &nbsp;|&nbsp; <?php echo e($paper['exam_type']); ?><?php endif; ?>
    </div>
</div>

<!-- Meta Row -->
<div class="paper-meta">
    <span><strong>Max. Marks:</strong> <?php echo $paper['total_marks']; ?></span>
    <span><strong>Time Allowed:</strong> <?php echo floor($paper['duration_mins']/60); ?> Hour <?php echo $paper['duration_mins']%60; ?> Min</span>
    <span><strong>Date:</strong> ________________</span>
</div>
<div style="margin-bottom:8px;">
    <strong>Name:</strong> ________________________________________________ &nbsp;&nbsp;
    <strong>Roll No.:</strong> ____________
</div>

<!-- Instructions -->
<?php if ($paper['instructions']): ?>
<div class="instructions">
    <strong>General Instructions:</strong>
    <?php foreach (explode("\n", $paper['instructions']) as $line): ?>
    <?php if (trim($line)): ?><p><?php echo e(trim($line)); ?></p><?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Sections -->
<?php $qNo = 1; foreach ($sections as $sectionName => $qs): ?>
<?php
$sTotal = array_sum(array_column($qs, 'marks_override'));
?>
<div class="section-header">
    <?php echo e($sectionName); ?>
    <span style="font-weight:normal; font-size:11pt;"> (<?php echo count($qs); ?> Questions — <?php echo $sTotal; ?> Marks)</span>
</div>

<?php foreach ($qs as $item):
    $marks = $item['marks_override'] ?? $item['marks'];
    $isLong = $item['question_type'] === 'Long Answer';
    $isMCQ  = $item['question_type'] === 'MCQ';
    $isTF   = $item['question_type'] === 'True/False';
?>
<div class="question">
    <div>
        <span class="question-num">Q<?php echo $qNo++; ?>.</span>
        <?php echo e($item['question_text']); ?>
        <span style="float:right;">[<?php echo $marks; ?> Mark<?php echo $marks>1?'s':''; ?>]</span>
    </div>
    <?php if ($isMCQ): ?>
    <div class="mcq-options">
        <span>(a) <?php echo e($item['option_a']??''); ?></span>
        <span>(b) <?php echo e($item['option_b']??''); ?></span>
        <span>(c) <?php echo e($item['option_c']??''); ?></span>
        <span>(d) <?php echo e($item['option_d']??''); ?></span>
    </div>
    <?php elseif ($isTF): ?>
    <div class="mcq-options"><span>(a) True</span><span>(b) False</span></div>
    <?php elseif ($isLong): ?>
    <div class="long-answer-space"></div>
    <?php else: ?>
    <div class="answer-space"></div>
    <?php endif; ?>
</div>
<?php endforeach; ?>
<?php endforeach; ?>

<div style="margin-top:30px; text-align:center; font-size:10pt; color:#555;">
    — End of Question Paper —
</div>

</body>
</html>
