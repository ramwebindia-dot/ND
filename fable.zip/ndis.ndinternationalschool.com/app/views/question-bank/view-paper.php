<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-file-alt me-2"></i><?php echo e($paper['title']); ?></h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('question-bank/print-paper?id='.$paper['id']); ?>" target="_blank" class="btn btn-outline-secondary btn-sm"><i class="fas fa-print me-1"></i>Print</a>
        <?php if ($paper['status'] === 'Draft'): ?>
        <form method="POST" action="<?php echo url('question-bank/finalize-paper'); ?>" class="d-inline">
            <?php echo CSRF::field(); ?>
            <input type="hidden" name="id" value="<?php echo $paper['id']; ?>">
            <button class="btn btn-success btn-sm"><i class="fas fa-lock me-1"></i>Finalize Paper</button>
        </form>
        <?php endif; ?>
        <a href="<?php echo url('question-bank/papers'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<!-- Paper Meta -->
<div class="card mb-3">
    <div class="card-body">
        <div class="row g-2">
            <div class="col-md-3"><strong>Class:</strong> <?php echo e($paper['class_name']); ?></div>
            <div class="col-md-3"><strong>Subject:</strong> <?php echo e($paper['subject_name']); ?></div>
            <div class="col-md-2"><strong>Total Marks:</strong> <?php echo (int)$paper['total_marks']; ?></div>
            <div class="col-md-2"><strong>Duration:</strong> <?php echo (int)$paper['duration_mins']; ?> min</div>
            <div class="col-md-2"><strong>Status:</strong> <span class="badge bg-<?php echo $paper['status']==='Final'?'success':'warning text-dark'; ?>"><?php echo e($paper['status']); ?></span></div>
            <div class="col-12">
                <strong>Total Questions:</strong> <?php echo array_sum(array_map('count', $sections)); ?>
                &nbsp;|&nbsp;
                <?php
$sectionTotals = [];
foreach ($sections as $sName => $qs) {
    $sectionTotals[$sName] = array_sum(array_column($qs, 'marks_override'));
}
foreach ($sectionTotals as $sName => $total): ?>
                <strong><?php echo e($sName); ?>:</strong> <?php echo $total; ?> marks &nbsp;
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Questions by Section -->
<?php $qNo = 1; foreach ($sections as $sectionName => $qs): ?>
<div class="card mb-3">
    <div class="card-header fw-bold bg-light">
        <?php echo e($sectionName); ?>
        <span class="text-muted small ms-2">(<?php echo count($qs); ?> questions — <?php echo $sectionTotals[$sectionName]; ?> marks)</span>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>#</th><th>Question</th><th>Type</th><th>Difficulty</th><th>Marks</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($qs as $item): ?>
            <?php
$diffColor = match($item['difficulty']) {
    'Easy'   => 'success',
    'Medium' => 'warning',
    'Hard'   => 'danger',
    default  => 'secondary'
};
?>
            <tr>
                <td><?php echo $qNo++; ?></td>
                <td>
                    <div><?php echo e($item['question_text']); ?></div>
                    <?php if ($item['question_type'] === 'MCQ'): ?>
                    <div class="text-muted small mt-1">
                        A) <?php echo e($item['option_a']??''); ?> &nbsp;
                        B) <?php echo e($item['option_b']??''); ?> &nbsp;
                        C) <?php echo e($item['option_c']??''); ?> &nbsp;
                        D) <?php echo e($item['option_d']??''); ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($item['chapter']): ?>
                    <small class="text-muted"><i class="fas fa-bookmark me-1"></i><?php echo e($item['chapter']); ?></small>
                    <?php endif; ?>
                </td>
                <td><span class="badge bg-secondary"><?php echo e($item['question_type']); ?></span></td>
                <td><span class="badge bg-<?php echo $diffColor; ?>"><?php echo e($item['difficulty']); ?></span></td>
                <td><?php echo $item['marks_override'] ?? $item['marks']; ?></td>
                <td>
                    <?php if ($paper['status'] === 'Draft'): ?>
                    <form method="POST" action="<?php echo url('question-bank/remove-question'); ?>" class="d-inline" onsubmit="return confirm('Remove this question?')">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <input type="hidden" name="paper_id" value="<?php echo $paper['id']; ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="fas fa-times"></i></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endforeach; ?>
