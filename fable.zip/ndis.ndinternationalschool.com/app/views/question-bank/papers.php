<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-file-alt me-2"></i>Question Papers</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('question-bank'); ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-database me-1"></i>Question Bank</a>
        <a href="<?php echo url('question-bank/generate-paper'); ?>" class="btn btn-primary-custom btn-sm"><i class="fas fa-magic me-1"></i>Generate Paper</a>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Exam Type</th>
                        <th>Total Marks</th>
                        <th>Duration</th>
                        <th>Questions</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($papers)): ?>
                    <tr><td colspan="10" class="text-center text-muted py-4">
                        No papers generated yet. <a href="<?php echo url('question-bank/generate-paper'); ?>">Generate first paper</a>
                    </td></tr>
                <?php else: ?>
                <?php foreach ($papers as $i => $p): ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td><strong><?php echo e($p['title']); ?></strong></td>
                    <td><?php echo e($p['class_name']); ?></td>
                    <td><?php echo e($p['subject_name']); ?></td>
                    <td><?php echo e($p['exam_type'] ?: '—'); ?></td>
                    <td><?php echo $p['total_marks']; ?></td>
                    <td><?php echo $p['duration_mins']; ?> min</td>
                    <td><span class="badge bg-info"><?php echo $p['question_count']; ?> Qs</span></td>
                    <td>
                        <span class="badge bg-<?php echo $p['status']==='Final'?'success':'warning text-dark'; ?>">
                            <?php echo $p['status']; ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?php echo url('question-bank/view-paper?id='.$p['id']); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo url('question-bank/print-paper?id='.$p['id']); ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Print"><i class="fas fa-print"></i></a>
                        <?php if ($p['status'] === 'Draft'): ?>
                        <form method="POST" action="<?php echo url('question-bank/finalize-paper'); ?>" class="d-inline">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                            <button class="btn btn-sm btn-outline-success" title="Finalize"><i class="fas fa-lock"></i></button>
                        </form>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo url('question-bank/delete-paper'); ?>" class="d-inline" onsubmit="return confirm('Delete this paper?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                            <button class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
