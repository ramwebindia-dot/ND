<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-plus-circle me-2"></i>Add Question to Bank</h4>
    <a href="<?php echo url('question-bank'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:800px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('question-bank/create'); ?>" id="qForm">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" class="form-select" id="classSelect" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo ($prefillClass==$c['id'])?'selected':''; ?>><?php echo e($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Subject <span class="text-danger">*</span></label>
                    <select name="subject_id" class="form-select" id="subjectSelect" required>
                        <option value="">Select Class first</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Chapter / Topic</label>
                    <input type="text" name="chapter" class="form-control" placeholder="e.g. Chapter 3 - Gravitation">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Question Type <span class="text-danger">*</span></label>
                    <select name="question_type" class="form-select" id="qTypeSelect" onchange="toggleOptions()">
                        <option value="Short Answer">Short Answer</option>
                        <option value="Long Answer">Long Answer</option>
                        <option value="MCQ">MCQ</option>
                        <option value="True/False">True / False</option>
                        <option value="Fill in Blank">Fill in Blank</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Marks <span class="text-danger">*</span></label>
                    <input type="number" name="marks" class="form-control" value="1" min="0.5" step="0.5" required>
                </div>
                <div class="col-md-1">
                    <label class="form-label">Difficulty</label>
                    <select name="difficulty" class="form-select">
                        <option value="Easy">Easy</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="Hard">Hard</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Question <span class="text-danger">*</span></label>
                    <textarea name="question_text" class="form-control" rows="3" required
                              placeholder="Type the question here..."></textarea>
                </div>

                <!-- MCQ Options -->
                <div id="mcqOptions" class="col-12 d-none">
                    <div class="card border-info">
                        <div class="card-header bg-info bg-opacity-10 fw-bold">MCQ Options</div>
                        <div class="card-body">
                            <div class="row g-2">
                                <div class="col-md-6"><label class="form-label">Option A</label><input type="text" name="option_a" class="form-control" placeholder="Option A"></div>
                                <div class="col-md-6"><label class="form-label">Option B</label><input type="text" name="option_b" class="form-control" placeholder="Option B"></div>
                                <div class="col-md-6"><label class="form-label">Option C</label><input type="text" name="option_c" class="form-control" placeholder="Option C"></div>
                                <div class="col-md-6"><label class="form-label">Option D</label><input type="text" name="option_d" class="form-control" placeholder="Option D"></div>
                                <div class="col-md-6">
                                    <label class="form-label">Correct Answer <span class="text-danger">*</span></label>
                                    <select name="correct_answer" class="form-select" id="mcqCorrect">
                                        <option value="">Select</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                        <option value="D">D</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- True/False -->
                <div id="tfOptions" class="col-12 d-none">
                    <label class="form-label">Correct Answer</label>
                    <select name="correct_answer" class="form-select" style="max-width:200px;">
                        <option value="True">True</option>
                        <option value="False">False</option>
                    </select>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" name="add_another" value="1" class="btn btn-outline-primary">
                    <i class="fas fa-plus me-2"></i>Save & Add Another
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check me-2"></i>Save Question
                </button>
                <a href="<?php echo url('question-bank'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
// Load subjects on class change
document.getElementById('classSelect').addEventListener('change', function() {
    const cid = this.value;
    const sel = document.getElementById('subjectSelect');
    sel.innerHTML = '<option value="">Loading...</option>';
    if (!cid) { sel.innerHTML = '<option value="">Select Class first</option>'; return; }
    fetch('<?php echo url("academic/get-subjects?class_id="); ?>' + cid)
        .then(r => r.json()).then(data => {
            sel.innerHTML = '<option value="">Select Subject</option>';
            data.forEach(s => sel.innerHTML += `<option value="${s.id}" ${<?php echo json_encode((int)($prefillSubject??0)); ?> === s.id ? 'selected' : ''}>${s.name}</option>`);
        });
});

// Auto-trigger if prefill class
<?php if ($prefillClass): ?>
document.getElementById('classSelect').dispatchEvent(new Event('change'));
<?php endif; ?>

function toggleOptions() {
    const type = document.getElementById('qTypeSelect').value;
    document.getElementById('mcqOptions').classList.toggle('d-none', type !== 'MCQ');
    document.getElementById('tfOptions').classList.toggle('d-none', type !== 'True/False');
}
</script>
