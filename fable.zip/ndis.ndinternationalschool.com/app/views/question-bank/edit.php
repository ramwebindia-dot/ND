<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-edit me-2"></i>Edit Question</h4>
    <a href="<?php echo url('question-bank'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:800px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('question-bank/edit?id='.$q['id']); ?>">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Class</label>
                    <input type="text" class="form-control" value="<?php echo e($q['class_id']); ?>" readonly>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Subject</label>
                    <select name="subject_id" class="form-select">
                        <?php foreach ($subjects as $s): ?>
                        <option value="<?php echo $s['id']; ?>" <?php echo $s['id']==$q['subject_id']?'selected':''; ?>><?php echo e($s['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Chapter / Topic</label>
                    <input type="text" name="chapter" class="form-control" value="<?php echo e($q['chapter']??''); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Question Type</label>
                    <select name="question_type" class="form-select" id="qTypeSelect" onchange="toggleOptions()">
                        <?php foreach (['Short Answer','Long Answer','MCQ','True/False','Fill in Blank'] as $t): ?>
                        <option value="<?php echo $t; ?>" <?php echo $q['question_type']===$t?'selected':''; ?>><?php echo $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Marks</label>
                    <input type="number" name="marks" class="form-control" value="<?php echo $q['marks']; ?>" min="0.5" step="0.5" required>
                </div>
                <div class="col-md-1">
                    <label class="form-label">Difficulty</label>
                    <select name="difficulty" class="form-select">
                        <?php foreach (['Easy','Medium','Hard'] as $d): ?>
                        <option value="<?php echo $d; ?>" <?php echo $q['difficulty']===$d?'selected':''; ?>><?php echo $d; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Question <span class="text-danger">*</span></label>
                    <textarea name="question_text" class="form-control" rows="3" required><?php echo e($q['question_text']); ?></textarea>
                </div>
                <div id="mcqOptions" class="col-12 <?php echo $q['question_type']!=='MCQ'?'d-none':''; ?>">
                    <div class="card border-info">
                        <div class="card-header bg-info bg-opacity-10 fw-bold">MCQ Options</div>
                        <div class="card-body">
                            <div class="row g-2">
                                <div class="col-md-6"><label class="form-label">Option A</label><input type="text" name="option_a" class="form-control" value="<?php echo e($q['option_a']??''); ?>"></div>
                                <div class="col-md-6"><label class="form-label">Option B</label><input type="text" name="option_b" class="form-control" value="<?php echo e($q['option_b']??''); ?>"></div>
                                <div class="col-md-6"><label class="form-label">Option C</label><input type="text" name="option_c" class="form-control" value="<?php echo e($q['option_c']??''); ?>"></div>
                                <div class="col-md-6"><label class="form-label">Option D</label><input type="text" name="option_d" class="form-control" value="<?php echo e($q['option_d']??''); ?>"></div>
                                <div class="col-md-6">
                                    <label class="form-label">Correct Answer</label>
                                    <select name="correct_answer" class="form-select">
                                        <?php foreach (['A','B','C','D'] as $opt): ?>
                                        <option value="<?php echo $opt; ?>" <?php echo ($q['correct_answer']===$opt)?'selected':''; ?>><?php echo $opt; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tfOptions" class="col-12 <?php echo $q['question_type']!=='True/False'?'d-none':''; ?>">
                    <label class="form-label">Correct Answer</label>
                    <select name="correct_answer" class="form-select" style="max-width:200px;">
                        <option value="True" <?php echo ($q['correct_answer']==='True')?'selected':''; ?>>True</option>
                        <option value="False" <?php echo ($q['correct_answer']==='False')?'selected':''; ?>>False</option>
                    </select>
                </div>
            </div>
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Update Question</button>
                <a href="<?php echo url('question-bank'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<script>
function toggleOptions() {
    const type = document.getElementById('qTypeSelect').value;
    document.getElementById('mcqOptions').classList.toggle('d-none', type !== 'MCQ');
    document.getElementById('tfOptions').classList.toggle('d-none', type !== 'True/False');
}
</script>
