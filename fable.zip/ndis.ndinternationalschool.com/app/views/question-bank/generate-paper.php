<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-magic me-2"></i>Generate Question Paper</h4>
    <a href="<?php echo url('question-bank/papers'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('question-bank/generate-paper'); ?>" id="genForm">
<?php echo CSRF::field(); ?>
<div class="row g-3">
    <!-- Paper Settings -->
    <div class="col-md-7">
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-cog me-2"></i>Paper Settings</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">Paper Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" required
                               placeholder="e.g. Mathematics Mid-Term Examination 2026">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" id="classSelect" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Subject <span class="text-danger">*</span></label>
                        <select name="subject_id" id="subjectSelect" class="form-select" required>
                            <option value="">Select Class first</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Exam Type</label>
                        <select name="exam_type" class="form-select">
                            <option value="">General</option>
                            <option value="Unit Test">Unit Test</option>
                            <option value="Mid-Term">Mid-Term</option>
                            <option value="Final">Final Exam</option>
                            <option value="Practice">Practice</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Total Marks</label>
                        <input type="number" name="total_marks" class="form-control" value="100" min="10" step="5" id="totalMarksInput">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Duration (min)</label>
                        <input type="number" name="duration_mins" class="form-control" value="180" min="30" step="15">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Instructions</label>
                        <textarea name="instructions" class="form-control" rows="3"
                                  placeholder="1. All questions are compulsory.&#10;2. Marks are indicated against each question.&#10;3. Write neatly and clearly.">1. All questions are compulsory.
2. Marks are indicated against each question.
3. Write neatly and clearly.</textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sections -->
    <div class="col-md-5">
        <div class="card mb-3">
            <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                <span><i class="fas fa-list me-2"></i>Sections</span>
                <button type="button" class="btn btn-sm btn-outline-primary" onclick="addSection()"><i class="fas fa-plus me-1"></i>Add Section</button>
            </div>
            <div class="card-body p-2" id="sectionsContainer">
                <!-- default sections added by JS -->
            </div>
            <div class="card-footer text-muted small">
                <i class="fas fa-info-circle me-1"></i>
                Total questions will be picked randomly from the bank matching these criteria.
                <div id="marksWarning" class="text-danger mt-1 d-none">
                    ⚠️ Section marks do not add up to total marks!
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex gap-2">
    <button type="submit" class="btn btn-primary btn-lg">
        <i class="fas fa-magic me-2"></i>Auto-Generate Paper
    </button>
    <a href="<?php echo url('question-bank/papers'); ?>" class="btn btn-secondary btn-lg">Cancel</a>
</div>
</form>

<script>
let sectionCount = 0;

const defaultSections = [
    { name:'Section A', type:'MCQ',          difficulty:'Easy',   count:10, marks:1 },
    { name:'Section B', type:'Short Answer',  difficulty:'Medium', count:5,  marks:4 },
    { name:'Section C', type:'Long Answer',   difficulty:'Hard',   count:3,  marks:10 },
];

function addSection(data = {}) {
    const i = sectionCount++;
    const name  = data.name  || `Section ${String.fromCharCode(65+i)}`;
    const type  = data.type  || '';
    const diff  = data.difficulty || '';
    const count = data.count || 5;
    const marks = data.marks || 2;

    const html = `
    <div class="border rounded p-2 mb-2 section-row" id="sec_${i}">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <strong class="small">Section ${i+1}</strong>
            <button type="button" class="btn btn-xs btn-outline-danger btn-sm" onclick="document.getElementById('sec_${i}').remove(); calcMarks()">✕</button>
        </div>
        <div class="row g-1">
            <div class="col-12">
                <input type="text" name="sections[${i}][name]" class="form-control form-control-sm" placeholder="Section Name" value="${name}" required>
            </div>
            <div class="col-6">
                <select name="sections[${i}][type]" class="form-select form-select-sm">
                    <option value="">Any Type</option>
                    ${['MCQ','Short Answer','Long Answer','True/False','Fill in Blank'].map(t =>
                        `<option value="${t}" ${t===type?'selected':''}>${t}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="col-6">
                <select name="sections[${i}][difficulty]" class="form-select form-select-sm">
                    <option value="">Any Difficulty</option>
                    ${['Easy','Medium','Hard'].map(d =>
                        `<option value="${d}" ${d===diff?'selected':''}>${d}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="col-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text">Qs</span>
                    <input type="number" name="sections[${i}][count]" class="form-control" value="${count}" min="1" max="50" onchange="calcMarks()">
                </div>
            </div>
            <div class="col-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text">×</span>
                    <input type="number" name="sections[${i}][marks_each]" class="form-control" value="${marks}" min="0.5" step="0.5" onchange="calcMarks()">
                    <span class="input-group-text">m</span>
                </div>
            </div>
        </div>
    </div>`;

    document.getElementById('sectionsContainer').insertAdjacentHTML('beforeend', html);
    calcMarks();
}

function calcMarks() {
    let total = 0;
    document.querySelectorAll('.section-row').forEach(row => {
        const count = parseFloat(row.querySelector('[name*="[count]"]')?.value || 0);
        const marks = parseFloat(row.querySelector('[name*="[marks_each]"]')?.value || 0);
        total += count * marks;
    });
    const expected = parseFloat(document.getElementById('totalMarksInput').value || 100);
    const warn = document.getElementById('marksWarning');
    if (Math.abs(total - expected) > 0.01 && total > 0) {
        warn.classList.remove('d-none');
        warn.textContent = `⚠️ Sections total = ${total} marks, but Total Marks = ${expected}`;
    } else {
        warn.classList.add('d-none');
    }
}

// Load subjects
document.getElementById('classSelect').addEventListener('change', function() {
    const cid = this.value;
    const sel = document.getElementById('subjectSelect');
    sel.innerHTML = '<option value="">Loading...</option>';
    if (!cid) { sel.innerHTML = '<option value="">Select Class first</option>'; return; }
    fetch('<?php echo url("academic/get-subjects?class_id="); ?>' + cid)
        .then(r => r.json()).then(data => {
            sel.innerHTML = '<option value="">Select Subject</option>';
            data.forEach(s => sel.innerHTML += `<option value="${s.id}">${s.name}</option>`);
        });
});

// Add default sections on load
defaultSections.forEach(s => addSection(s));
</script>
