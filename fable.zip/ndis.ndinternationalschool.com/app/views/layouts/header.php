<!-- Top Header -->
<header class="top-header">
    <div class="header-left">
        <button class="sidebar-toggle" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="header-search" id="headerSearchWrap" style="position:relative;display:flex;align-items:center;gap:6px;">
            <i class="fas fa-search" style="pointer-events:none;"></i>
            <input type="text" placeholder="Search students, teachers..." id="globalSearch" autocomplete="off" style="flex:1;">
            <button id="searchNowBtn" type="button" style="white-space:nowrap;padding:4px 12px;font-size:12px;font-weight:600;border:none;border-radius:6px;background:var(--primary,#4e73df);color:#fff;cursor:pointer;display:flex;align-items:center;gap:5px;">
                <i class="fas fa-search" style="font-size:11px;"></i> Search Now
            </button>
            <!-- Dropdown -->
            <div id="searchDropdown" style="display:none;position:absolute;top:calc(100% + 8px);left:0;width:420px;background:var(--card-bg,#fff);border:1px solid var(--border-color,#e0e0e0);border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.15);z-index:99999;overflow:hidden;">
                <div id="searchResults"></div>
            </div>
        </div>
    </div>
    <div class="header-right">
        <!-- Dark Mode Toggle -->
        <button class="dark-mode-toggle" id="darkModeToggle" title="Toggle Dark Mode">
            <i class="fas fa-moon"></i>
        </button>

        <!-- Notifications -->
        <div class="dropdown">
            <button class="header-icon-btn" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell"></i>
                <span class="badge" id="notifBadge">0</span>
            </button>
            <div class="dropdown-menu dropdown-menu-end p-0" style="width: 320px; max-height: 400px; overflow-y: auto;">
                <div class="p-3 border-bottom">
                    <h6 class="mb-0">Notifications</h6>
                </div>
                <div id="notificationList" class="p-2">
                    <p class="text-center text-muted py-3 mb-0" style="font-size: 13px;">No new notifications</p>
                </div>
            </div>
        </div>

        <!-- User Menu -->
        <div class="dropdown">
            <div class="header-user" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="user-avatar">
                    <?php echo e(strtoupper(substr($currentUser['name'] ?? 'U', 0, 1))); ?>
                </div>
                <div class="user-info d-none d-sm-block">
                    <div class="user-name"><?php echo e($currentUser['name'] ?? 'User'); ?></div>
                    <div class="user-role"><?php echo e($currentUser['role'] ?? 'Role'); ?></div>
                </div>
                <i class="fas fa-chevron-down ms-1" style="font-size: 10px;"></i>
            </div>
            <div class="dropdown-menu dropdown-menu-end">
                <a class="dropdown-item" href="<?php echo url('settings/profile'); ?>">
                    <i class="fas fa-user me-2"></i>My Profile
                </a>
                <a class="dropdown-item" href="<?php echo url('settings/change-password'); ?>">
                    <i class="fas fa-key me-2"></i>Change Password
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-danger" href="<?php echo url('auth/logout'); ?>">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </div>
</header>
