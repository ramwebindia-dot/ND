<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle ?? 'Dashboard'); ?> - <?php echo e($schoolName ?? APP_NAME); ?></title>
    <?php echo CSRF::meta(); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="<?php echo asset('css/style.css'); ?>" rel="stylesheet">
    <script>window._appBase = "<?php echo rtrim(APP_URL, '/'); ?>/"; window.url = function(p){ return window._appBase + p; };</script>
    <link href="<?php echo asset('css/dark-mode.css'); ?>" rel="stylesheet">
</head>
<body>
    <!-- Sidebar Overlay (mobile) -->
    <div class="sidebar-overlay"></div>

    <!-- Sidebar -->
    <?php require APP_ROOT . '/app/views/layouts/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <?php require APP_ROOT . '/app/views/layouts/header.php'; ?>

        <!-- Page Content -->
        <div class="page-content">
            <!-- Flash Messages -->
            <?php if (!empty($flash)): ?>
                <?php if (isset($flash['success'])): ?>
                    <div class="alert alert-success alert-auto-dismiss">
                        <i class="fas fa-check-circle me-2"></i><?php echo e($flash['success']); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($flash['error'])): ?>
                    <div class="alert alert-danger alert-auto-dismiss">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo e($flash['error']); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($flash['warning'])): ?>
                    <div class="alert alert-warning alert-auto-dismiss">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo e($flash['warning']); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($flash['info'])): ?>
                    <div class="alert alert-info alert-auto-dismiss">
                        <i class="fas fa-info-circle me-2"></i><?php echo e($flash['info']); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Active Session Warning -->
            <?php if (!Session::get('active_session_id') && !in_array(Session::get('role_name'), ['Student','Parent'])): ?>
            <div class="alert alert-warning d-flex align-items-center mb-3" style="border-radius:8px;">
                <i class="fas fa-exclamation-triangle me-2 fs-5"></i>
                <div>
                    <strong>No active academic session!</strong>
                    All data will appear empty until you activate a session.
                    <a href="<?php echo url('sessions'); ?>" class="alert-link ms-2">Go to Sessions →</a>
                </div>
            </div>
            <?php endif; ?>

            <!-- Page Body -->
            <?php echo $content; ?>
        </div>

        <!-- Footer -->
        <?php require APP_ROOT . '/app/views/layouts/footer.php'; ?>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="<?php echo asset('js/charts.js'); ?>"></script>
    <script src="<?php echo asset('js/app.js'); ?>"></script>

    <!-- Notification Bell Live Polling -->
    <script>
    (function() {
        var NOTIF_COUNT_URL = '<?php echo url("notifications/get-unread-count"); ?>';
        var NOTIF_LIST_URL  = '<?php echo url("notifications/get-recent"); ?>';
        var badge = document.getElementById('notifBadge');
        var list  = document.getElementById('notificationList');
        if (!badge || !list) return;

        function fetchNotifications() {
            fetch(NOTIF_LIST_URL, {credentials:'same-origin'})
                .then(function(r){ return r.json(); })
                .then(function(data) {
                    var items = data.notifications || [];
                    badge.textContent = items.length;
                    badge.style.display = items.length ? '' : 'none';
                    if (!items.length) {
                        list.innerHTML = '<p class="text-center text-muted py-3 mb-0 small">No new notifications</p>';
                        return;
                    }
                    var typeIcons = {Fee:'fa-rupee-sign',Attendance:'fa-clipboard-check',Homework:'fa-book',Exam:'fa-file-alt',Leave:'fa-calendar-times',Notice:'fa-bullhorn',General:'fa-bell'};
                    var typeColors = {Fee:'text-success',Attendance:'text-warning',Homework:'text-info',Exam:'text-primary',Leave:'text-secondary',Notice:'text-danger',General:'text-muted'};
                    var html = '';
                    items.forEach(function(n) {
                        var icon  = typeIcons[n.type]  || 'fa-bell';
                        var color = typeColors[n.type] || 'text-muted';
                        var link  = n.link ? n.link : '<?php echo url("notifications"); ?>';
                        var markUrl = '<?php echo url("notifications/mark-read?id="); ?>' + n.id + '&redirect=' + encodeURIComponent(link);
                        html += '<a href="' + markUrl + '" class="d-flex gap-2 p-2 border-bottom text-decoration-none text-dark" style="font-size:13px;">'
                            + '<span class="mt-1"><i class="fas ' + icon + ' ' + color + '"></i></span>'
                            + '<span><div class="fw-medium">' + escHtml(n.title) + '</div>'
                            + '<div class="text-muted small">' + escHtml(n.message.substring(0,70)) + (n.message.length>70?'…':'') + '</div></span>'
                            + '</a>';
                    });
                    html += '<div class="p-2 text-center border-top">'
                        + '<a href="<?php echo url("notifications"); ?>" class="small text-primary">View all</a>'
                        + ' · <a href="<?php echo url("notifications/mark-all-read"); ?>" class="small text-muted">Mark all read</a></div>';
                    list.innerHTML = html;
                })
                .catch(function(){});
        }

        function escHtml(s) { var d=document.createElement('div'); d.appendChild(document.createTextNode(s||'')); return d.innerHTML; }

        fetchNotifications();
        setInterval(fetchNotifications, 60000); // poll every 60s
    })();
    </script>

    <!-- Global Search -->
    <script>
    (function() {
        var SEARCH_URL = '<?php echo url("search"); ?>';
        var input    = document.getElementById('globalSearch');
        var btn      = document.getElementById('searchNowBtn');
        var dropdown = document.getElementById('searchDropdown');
        var results  = document.getElementById('searchResults');

        if (!input || !btn || !dropdown || !results) return;

        var timer = null;

        function closeDropdown() { dropdown.style.display = 'none'; }

        function showLoading() {
            results.innerHTML = '<div style="padding:14px;text-align:center;color:#999;font-size:13px;">Searching...</div>';
            dropdown.style.display = '';
        }

        function renderResults(data) {
            if (!data || !data.results || !data.results.length) {
                results.innerHTML = '<div style="padding:16px;text-align:center;color:#aaa;font-size:13px;">No results found</div>';
                dropdown.style.display = '';
                return;
            }
            var colors = { student:'#4e73df', teacher:'#1cc88a', receipt:'#f6c23e' };
            var labels = { student:'Students', teacher:'Teachers', receipt:'Fee Receipts' };
            var icons  = { student:'fas fa-user-graduate', teacher:'fas fa-chalkboard-teacher', receipt:'fas fa-receipt' };
            var groups = {};
            data.results.forEach(function(r){ (groups[r.type]=groups[r.type]||[]).push(r); });
            var html = '';
            Object.keys(groups).forEach(function(type) {
                html += '<div style="padding:6px 12px 2px;font-size:10px;font-weight:700;text-transform:uppercase;color:#bbb;">' + (labels[type]||type) + '</div>';
                groups[type].forEach(function(r) {
                    html += '<a href="' + r.url + '" class="gsearch-item" style="display:flex;align-items:center;gap:10px;padding:9px 14px;text-decoration:none;color:inherit;">'
                        + '<span style="width:32px;height:32px;border-radius:8px;background:' + (colors[type]||'#eee') + '22;display:flex;align-items:center;justify-content:center;">'
                        + '<i class="' + (icons[type]||'fas fa-circle') + '" style="color:' + (colors[type]||'#999') + ';font-size:13px;"></i></span>'
                        + '<span><div style="font-size:13px;font-weight:600;">' + r.label + '</div>'
                        + '<div style="font-size:11px;color:#999;">' + r.sub + '</div></span></a>';
                });
            });
            html += '<div style="padding:6px 12px;border-top:1px solid #f0f0f0;text-align:right;"><small style="color:#ccc;">' + data.results.length + ' result(s)</small></div>';
            results.innerHTML = html;
            dropdown.style.display = '';
            dropdown.querySelectorAll('.gsearch-item').forEach(function(a) {
                a.addEventListener('mouseenter', function(){ this.style.background='#f5f7ff'; });
                a.addEventListener('mouseleave', function(){ this.style.background=''; });
            });
        }

        function doSearch() {
            var q = input.value.trim();
            if (q.length < 2) {
                results.innerHTML = '<div style="padding:14px;text-align:center;color:#aaa;font-size:13px;">Type at least 2 characters</div>';
                dropdown.style.display = '';
                return;
            }
            showLoading();
            fetch(SEARCH_URL + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
                .then(function(res) { return res.json(); })
                .then(renderResults)
                .catch(function(err) {
                    results.innerHTML = '<div style="padding:14px;text-align:center;color:#e74c3c;font-size:13px;">Error: ' + err.message + '</div>';
                    dropdown.style.display = '';
                });
        }

        input.addEventListener('input', function() {
            clearTimeout(timer);
            if (this.value.trim().length >= 2) timer = setTimeout(doSearch, 300);
            else closeDropdown();
        });

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); clearTimeout(timer); doSearch(); }
            if (e.key === 'Escape') closeDropdown();
        });

        btn.addEventListener('click', function() { clearTimeout(timer); doSearch(); });

        document.addEventListener('click', function(e) {
            if (!document.getElementById('headerSearchWrap').contains(e.target)) closeDropdown();
        });
    })();
    </script>
</body>
</html>