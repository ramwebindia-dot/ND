<!-- Sidebar -->
<nav class="sidebar">
    <!-- Brand -->
    <div class="sidebar-brand">
        <img src="<?php echo $schoolLogo ?? asset('img/logo.png'); ?>"
             alt="Logo"
             onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22><rect width=%2240%22 height=%2240%22 rx=%228%22 fill=%22%23F5A623%22/><text x=%2220%22 y=%2227%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2218%22 font-weight=%22bold%22>ND</text></svg>'">

        <div>
            <h5><?php echo e($schoolName ?? APP_NAME); ?></h5>
            <small>School Management</small>
        </div>
    </div>

    <!-- Active Session -->
    <?php if (!empty($activeSession)): ?>
        <div class="sidebar-session">
            <span class="label">Active Session</span>
            <span class="value">
                <i class="fas fa-calendar-alt me-1"></i>
                <?php echo e($activeSession['name']); ?>
            </span>
        </div>
    <?php endif; ?>

    <!-- Navigation -->
    <div class="sidebar-nav">

        <?php
        $menuItems = Permission::getSidebarMenu($currentRole ?? 'Student');
        $currentUrl = filter_input(INPUT_GET, 'url', FILTER_SANITIZE_URL) ?? 'dashboard';

        // A url is "active" when it equals the current url or is a path-prefix of it.
        $isActiveUrl = static function (string $u) use ($currentUrl): bool {
            if ($u === '') return false;
            return $currentUrl === $u || strpos($currentUrl, $u . '/') === 0;
        };

        foreach ($menuItems as $item):

            $itemUrl    = $item['url'] ?? '';
            $itemTitle  = $item['title'] ?? '';
            $itemIcon   = $item['icon'] ?? 'fas fa-circle';
            $hasSubmenu = !empty($item['submenu']);

            if (!$hasSubmenu):
                $isActive = $isActiveUrl($itemUrl);
        ?>
                <div class="nav-item">
                    <a href="<?php echo url($itemUrl); ?>"
                       class="nav-link <?php echo $isActive ? 'active' : ''; ?>">
                        <i class="<?php echo e($itemIcon); ?>"></i>
                        <span><?php echo e($itemTitle); ?></span>
                    </a>
                </div>
        <?php
            else:
                // Within a group highlight only the most specific (longest) matching child,
                // and auto-expand the group that contains the current page.
                $groupId   = 'menu-' . preg_replace('/[^a-z0-9]+/', '-', strtolower($itemTitle));
                $bestMatch = '';
                foreach ($item['submenu'] as $s) {
                    $u = $s['url'] ?? '';
                    if ($isActiveUrl($u) && strlen($u) > strlen($bestMatch)) {
                        $bestMatch = $u;
                    }
                }
                $groupActive = $bestMatch !== '';
        ?>
                <div class="nav-item nav-group">
                    <a href="#<?php echo $groupId; ?>"
                       class="nav-link nav-group-toggle <?php echo $groupActive ? 'active-parent' : ''; ?>"
                       aria-expanded="<?php echo $groupActive ? 'true' : 'false'; ?>">
                        <i class="<?php echo e($itemIcon); ?>"></i>
                        <span><?php echo e($itemTitle); ?></span>
                        <i class="fas fa-chevron-right submenu-arrow"></i>
                    </a>
                    <ul class="submenu <?php echo $groupActive ? 'show' : ''; ?>" id="<?php echo $groupId; ?>">
                        <?php foreach ($item['submenu'] as $subItem):
                            $subUrl   = $subItem['url'] ?? '';
                            $subTitle = $subItem['title'] ?? '';
                            $subIcon  = $subItem['icon'] ?? 'fas fa-circle';
                            $subIsActive = ($subUrl !== '' && $subUrl === $bestMatch);
                        ?>
                        <li class="nav-item">
                            <a href="<?php echo url($subUrl); ?>"
                               class="nav-link <?php echo $subIsActive ? 'active' : ''; ?>">
                                <i class="<?php echo e($subIcon); ?>"></i>
                                <span><?php echo e($subTitle); ?></span>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
        <?php endif; ?>

        <?php endforeach; ?>

    </div>
</nav>
