<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle ?? 'Print'); ?> - <?php echo e(APP_NAME); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="<?php echo asset('css/style.css'); ?>" rel="stylesheet">
    <style>
        body { background: white; }
        .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #F5A623; padding-bottom: 15px; }
        .print-header h4 { margin: 0; font-size: 18px; }
        .print-header p { margin: 2px 0; font-size: 12px; color: #666; }
        .no-print { margin-bottom: 15px; }
        @media print { .no-print { display: none !important; } }
    </style>
</head>
<body>
    <div class="container-fluid p-4">
        <!-- Print Controls -->
        <div class="no-print text-center mb-3">
            <button class="btn btn-primary-custom me-2" onclick="window.print()">
                <i class="fas fa-print me-1"></i> Print
            </button>
            <button class="btn btn-secondary-custom" onclick="window.close()">
                <i class="fas fa-times me-1"></i> Close
            </button>
        </div>

        <!-- School Header -->
        <div class="print-header">
            <h4><?php echo e($schoolName ?? APP_NAME); ?></h4>
            <p><?php echo e($schoolAddress ?? ''); ?></p>
            <p>Phone: <?php echo e($schoolPhone ?? ''); ?> | Email: <?php echo e($schoolEmail ?? ''); ?></p>
        </div>

        <!-- Content -->
        <?php echo $content; ?>
    </div>
</body>
</html>
