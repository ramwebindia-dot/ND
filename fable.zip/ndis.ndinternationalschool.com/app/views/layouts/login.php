<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo e(APP_NAME); ?></title>
    <?php echo CSRF::meta(); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="<?php echo asset('css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/dark-mode.css'); ?>" rel="stylesheet">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            <!-- Header -->
            <div class="login-header">
                <img src="<?php echo asset('img/logo.png'); ?>" alt="Logo"
                     onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2270%22 height=%2270%22><rect width=%2270%22 height=%2270%22 rx=%2235%22 fill=%22rgba(255,255,255,0.2)%22/><text x=%2235%22 y=%2245%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2230%22 font-weight=%22bold%22>ND</text></svg>'">
                <h4><?php echo e(APP_NAME); ?></h4>
                <p>School Management System</p>
            </div>

            <!-- Body -->
            <div class="login-body">
                <?php echo $content; ?>
            </div>

            <!-- Footer -->
            <div class="login-footer">
                &copy; <?php echo date('Y'); ?> <?php echo e(APP_NAME); ?>. Developed by <?php echo e(DEVELOPER_NAME); ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo asset('js/app.js'); ?>"></script>
</body>
</html>
