<!-- Footer -->
<footer class="main-footer">
    &copy; <?php echo date('Y'); ?> <?php echo e(APP_NAME); ?>. Developed by <?php echo e(DEVELOPER_NAME); ?>
</footer>
