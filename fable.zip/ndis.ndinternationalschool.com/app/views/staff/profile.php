<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-id-card me-2"></i>Staff Profile</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('staff/edit?id=' . $staff['id']); ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-edit me-1"></i>Edit
        </a>
        <a href="<?php echo url('staff'); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>
</div>

<div class="row">
    <!-- Left column -->
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-body text-center">
                <?php if (!empty($staff['photo'])): ?>
                    <img src="<?php echo asset($staff['photo']); ?>" class="rounded-circle mb-3" width="100" height="100" style="object-fit:cover;" alt="">
                <?php else: ?>
                    <i class="fas fa-user-circle fa-5x text-muted mb-3 d-block"></i>
                <?php endif; ?>
                <h5 class="mb-1"><?php echo e(trim($staff['first_name'] . ' ' . ($staff['last_name'] ?? ''))); ?></h5>
                <p class="text-muted mb-1"><small><?php echo e($staff['designation'] ?? 'Non-Teaching Staff'); ?></small></p>
                <p class="text-muted mb-2"><small>Emp: <strong><?php echo e($staff['employee_id']); ?></strong></small></p>
                <span class="badge bg-<?php echo $staff['status'] === 'Active' ? 'success' : ($staff['status'] === 'Resigned' ? 'danger' : 'secondary'); ?>">
                    <?php echo e($staff['status']); ?>
                </span>
                <?php if (!empty($staff['department_name'])): ?>
                    <div class="mt-2"><span class="badge bg-info text-dark"><?php echo e($staff['department_name']); ?></span></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-info-circle me-2"></i>Details</div>
            <div class="card-body p-0">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted ps-3" width="40%">Gender</td><td><?php echo e($staff['gender'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">DOB</td><td><?php echo !empty($staff['dob']) ? formatDate($staff['dob']) : '—'; ?></td></tr>
                    <tr><td class="text-muted ps-3">Phone</td><td><?php echo e($staff['phone'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Email</td><td><?php echo e($staff['email'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Qualification</td><td><?php echo e($staff['qualification'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Joined</td><td><?php echo !empty($staff['join_date']) ? formatDate($staff['join_date']) : '—'; ?></td></tr>
                    <tr><td class="text-muted ps-3">Salary</td><td>₹<?php echo number_format((float)($staff['salary'] ?? 0), 0); ?>/mo</td></tr>
                </table>
            </div>
        </div>

        <?php if (!empty($staff['address'])): ?>
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-map-marker-alt me-2"></i>Address</div>
            <div class="card-body">
                <p class="mb-0 text-muted" style="font-size:14px;"><?php echo nl2br(e($staff['address'])); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Right column -->
    <div class="col-lg-8">
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-briefcase me-2"></i>Employment Summary</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="border rounded p-3 text-center">
                            <div class="text-muted small mb-1">Employee ID</div>
                            <div class="fw-bold"><?php echo e($staff['employee_id']); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="border rounded p-3 text-center">
                            <div class="text-muted small mb-1">Designation</div>
                            <div class="fw-bold"><?php echo e($staff['designation'] ?? '—'); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="border rounded p-3 text-center">
                            <div class="text-muted small mb-1">Monthly Salary</div>
                            <div class="fw-bold text-success">₹<?php echo number_format((float)($staff['salary'] ?? 0), 0); ?></div>
                        </div>
                    </div>
                </div>

                <?php if (!empty($staff['join_date'])): ?>
                <div class="mt-3 text-muted" style="font-size:13px;">
                    <i class="fas fa-calendar-check me-1"></i>
                    Joined on <strong><?php echo formatDate($staff['join_date']); ?></strong>
                    (<?php
                        $joined = new DateTime($staff['join_date']);
                        $now    = new DateTime();
                        $diff   = $joined->diff($now);
                        if ($diff->y > 0)      echo $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
                        elseif ($diff->m > 0)  echo $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
                        else                   echo $diff->d . ' day' . ($diff->d > 1 ? 's' : '');
                    ?> ago)
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header fw-bold"><i class="fas fa-tools me-2"></i>Actions</div>
            <div class="card-body d-flex gap-2 flex-wrap">
                <a href="<?php echo url('staff/edit?id=' . $staff['id']); ?>" class="btn btn-outline-primary">
                    <i class="fas fa-edit me-1"></i>Edit Details
                </a>
                <?php if ($staff['status'] !== 'Resigned'): ?>
                <form method="POST" action="<?php echo url('staff/delete'); ?>"
                      onsubmit="return confirm('Mark this staff member as resigned?')">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="id" value="<?php echo $staff['id']; ?>">
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="fas fa-user-times me-1"></i>Mark Resigned
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
