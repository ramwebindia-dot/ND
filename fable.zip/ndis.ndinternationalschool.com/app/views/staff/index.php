<div class="page-header">
    <h4><i class="fas fa-users-cog"></i> Non-Teaching Staff</h4>
    <a href="<?php echo url('staff/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Add Staff</a>
</div>

<!-- Search/Filter -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('staff'); ?>" class="row g-2 align-items-end">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control" placeholder="Search by name, emp. no., designation..." value="<?php echo e($search); ?>">
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="Active"   <?php echo $status === 'Active'   ? 'selected' : ''; ?>>Active</option>
                    <option value="Inactive" <?php echo $status === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    <option value="Resigned" <?php echo $status === 'Resigned' ? 'selected' : ''; ?>>Resigned</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-search me-1"></i>Search</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo url('staff'); ?>" class="btn btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<!-- Summary badges -->
<div class="mb-3 d-flex gap-2 flex-wrap">
    <span class="badge badge-success-custom fs-6">Total: <?php echo count($staffList); ?></span>
    <span class="badge badge-info-custom fs-6">Active: <?php echo count(array_filter($staffList, fn($s) => $s['status'] === 'Active')); ?></span>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Emp. No.</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Mobile</th>
                        <th>Salary</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($staffList)): ?>
                        <tr><td colspan="9" class="text-center text-muted py-4">No staff members found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($staffList as $i => $s): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($s['employee_id']); ?></strong></td>
                            <td>
                                <?php if (!empty($s['photo'])): ?>
                                    <img src="<?php echo asset($s['photo']); ?>" class="rounded-circle me-1" width="28" height="28" style="object-fit:cover;" alt="">
                                <?php endif; ?>
                                <?php echo e(trim($s['first_name'] . ' ' . ($s['last_name'] ?? ''))); ?>
                            </td>
                            <td><?php echo e($s['designation'] ?? '-'); ?></td>
                            <td><?php echo e($s['department_name'] ?? '-'); ?></td>
                            <td><?php echo e($s['phone'] ?? '-'); ?></td>
                            <td>₹<?php echo number_format((float)($s['salary'] ?? 0), 0); ?></td>
                            <td>
                                <span class="badge <?php echo $s['status'] === 'Active' ? 'badge-success-custom' : ($s['status'] === 'Resigned' ? 'badge-danger-custom' : 'badge-secondary-custom'); ?>">
                                    <?php echo e($s['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo url('staff/profile?id=' . $s['id']); ?>" class="btn btn-sm btn-outline-primary-custom" title="View"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo url('staff/edit?id=' . $s['id']); ?>" class="btn btn-sm btn-outline-info" title="Edit"><i class="fas fa-edit"></i></a>
                                <?php if ($s['status'] !== 'Resigned'): ?>
                                <form method="POST" action="<?php echo url('staff/delete'); ?>" class="d-inline"
                                      onsubmit="return confirm('Mark this staff member as resigned?')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Deactivate"><i class="fas fa-user-times"></i></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
<?php if (($pagination['total_pages'] ?? 1) > 1): ?>
<nav class="mt-3">
    <ul class="pagination">
        <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
        <li class="page-item <?php echo $p === $pagination['page'] ? 'active' : ''; ?>">
            <a class="page-link" href="<?php echo url('staff?page=' . $p . '&search=' . urlencode($search) . '&status=' . urlencode($status)); ?>"><?php echo $p; ?></a>
        </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
