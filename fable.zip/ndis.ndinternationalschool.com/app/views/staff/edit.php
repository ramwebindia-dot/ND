<?php $departments = $departments ?? []; ?>
<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Staff Member</h4>
    <a href="<?php echo url('staff/profile?id=' . $staff['id']); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('staff/edit?id=' . $staff['id']); ?>" enctype="multipart/form-data">
    <?php echo CSRF::field(); ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-3">
                <div class="card-header"><h6>Personal Information</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">First Name *</label>
                            <input type="text" name="first_name" class="form-control" value="<?php echo e($staff['first_name']); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?php echo e($staff['last_name'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="Male"   <?php echo ($staff['gender'] ?? '') === 'Male'   ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo ($staff['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other"  <?php echo ($staff['gender'] ?? '') === 'Other'  ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="date_of_birth" class="form-control" value="<?php echo e($staff['dob'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Mobile *</label>
                            <input type="text" name="mobile" class="form-control" value="<?php echo e($staff['phone'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e($staff['email'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Designation *</label>
                            <input type="text" name="designation" class="form-control" value="<?php echo e($staff['designation'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Department</label>
                            <select name="department_id" class="form-select">
                                <option value="">Select</option>
                                <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>" <?php echo ($staff['department_id'] ?? '') == $dept['id'] ? 'selected' : ''; ?>><?php echo e($dept['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Joining Date</label>
                            <input type="date" name="joining_date" class="form-control" value="<?php echo e($staff['join_date'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Qualification</label>
                            <input type="text" name="qualification" class="form-control" value="<?php echo e($staff['qualification'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Monthly Salary (₹)</label>
                            <input type="number" name="salary" class="form-control" value="<?php echo e($staff['salary'] ?? '0'); ?>" min="0" step="0.01">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="Active"   <?php echo ($staff['status'] ?? '') === 'Active'   ? 'selected' : ''; ?>>Active</option>
                                <option value="Inactive" <?php echo ($staff['status'] ?? '') === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="Resigned" <?php echo ($staff['status'] ?? '') === 'Resigned' ? 'selected' : ''; ?>>Resigned</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control" rows="2"><?php echo e($staff['address'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card mb-3">
                <div class="card-header"><h6>Photo</h6></div>
                <div class="card-body text-center">
                    <?php if (!empty($staff['photo'])): ?>
                        <img src="<?php echo asset($staff['photo']); ?>" class="rounded-circle mb-2" width="80" height="80" style="object-fit:cover;" alt="">
                        <br>
                    <?php endif; ?>
                    <input type="file" name="photo" class="form-control" accept="image/*">
                    <small class="text-muted d-block mt-1">Leave blank to keep existing</small>
                </div>
            </div>
            <button type="submit" class="btn btn-primary-custom w-100">
                <i class="fas fa-save me-1"></i>Update Staff Member
            </button>
        </div>
    </div>
</form>
