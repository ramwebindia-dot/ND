<?php $pageTitle = 'Family / Sibling Payment'; ?>
<div class="page-header">
    <h4><i class="fas fa-users"></i> Family / Sibling Fee Payment</h4>
    <a href="fees/collect?student_id=<?= $studentId ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<form method="post" action="fees/processPayment" id="familyForm">
    <?= CSRF::field() ?>
    <input type="hidden" name="student_id" value="<?= $studentId ?>">
    <input type="hidden" name="session_id" value="<?= $sessionId ?>">

    <?php $rowIdx = 0; ?>
    <?php foreach ($payData as $sid => $pd): ?>
    <div class="card shadow-sm mb-3">
        <div class="card-header bg-light d-flex justify-content-between">
            <strong><?= e($pd['student']['full_name']) ?></strong>
            <span class="text-muted small">
                <?= e($pd['student']['admission_number']) ?> &bull; <?= e($pd['student']['class_name']) ?>
                &nbsp;|&nbsp; Outstanding: <span class="text-danger fw-bold">&#8377;<?= number_format($pd['outstanding'],2) ?></span>
            </span>
        </div>
        <div class="card-body p-0">
            <table class="table table-sm table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th><input type="checkbox" class="student-all-check" data-sid="<?= $sid ?>"></th>
                        <th>Month</th><th>Fee Head</th>
                        <th class="text-end">Due</th><th class="text-end">Paying</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($pd['months'] as $my => $mData): foreach ($mData['heads'] as $h):
                    $due = (float)$h['charged_amount'] + (float)$h['late_fee_amount'] - (float)$h['discount_amount'] - (float)$h['paid_amount'];
                    $due = max(0, $due);
                    if ($due <= 0) continue;
                ?>
                <tr>
                    <td class="text-center">
                        <input type="checkbox" class="family-check" data-sid="<?= $sid ?>" data-idx="<?= $rowIdx ?>" checked>
                    </td>
                    <td class="small"><?= date('M Y', strtotime($my.'-01')) ?></td>
                    <td class="small"><?= e($h['head_name']) ?></td>
                    <td class="text-end small fw-semibold text-danger">&#8377;<?= number_format($due,2) ?></td>
                    <td>
                        <input type="hidden" name="items[<?= $rowIdx ?>][student_id]" value="<?= $sid ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][fee_category_id]" value="<?= $h['fee_category_id'] ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][month_year]" value="<?= $my ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][charged_amount]" value="<?= (float)$h['charged_amount'] ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][discount_amount]" value="<?= (float)$h['discount_amount'] ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][late_fee_amount]" value="<?= (float)$h['late_fee_amount'] ?>">
                        <input type="number" name="items[<?= $rowIdx ?>][paid_amount]"
                               class="form-control form-control-sm family-pay-input" step="0.01" min="0"
                               value="<?= $due ?>" data-idx="<?= $rowIdx ?>">
                    </td>
                </tr>
                <?php $rowIdx++; endforeach; endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="card shadow-sm mb-3">
        <div class="card-header"><strong>Payment Details — Combined Receipt</strong></div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Date <span class="text-danger">*</span></label>
                    <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Mode <span class="text-danger">*</span></label>
                    <select name="payment_method" class="form-select" required>
                        <option value="Cash">Cash</option>
                        <option value="Cheque">Cheque</option>
                        <option value="DD">DD</option>
                        <option value="NEFT">NEFT</option>
                        <option value="UPI">UPI</option>
                        <option value="Card">Card</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Bank Account</label>
                    <select name="bank_account_id" class="form-select">
                        <option value="">-- Cash / None --</option>
                        <?php foreach ($accounts as $a): ?>
                        <option value="<?= $a['id'] ?>"><?= e($a['account_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Remarks</label>
                    <input type="text" name="remarks" class="form-control" placeholder="Family payment">
                </div>
            </div>
            <div class="mt-3 text-end">
                <h5>Total Paying: <span class="text-success fw-bold" id="familyTotal">&#8377;0.00</span></h5>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-success btn-lg px-5">
            <i class="fas fa-check"></i> Collect Combined Payment
        </button>
    </div>
</form>

<script>
function calcFamilyTotal(){
    let total = 0;
    document.querySelectorAll('.family-check:checked').forEach(cb=>{
        const inp = document.querySelector(`input[name="items[${cb.dataset.idx}][paid_amount]"]`);
        if(inp) total += parseFloat(inp.value||0);
    });
    document.getElementById('familyTotal').innerHTML='&#8377;'+total.toFixed(2);
}
document.querySelectorAll('.family-check').forEach(cb=>cb.addEventListener('change',calcFamilyTotal));
document.querySelectorAll('.family-pay-input').forEach(inp=>inp.addEventListener('input',calcFamilyTotal));
document.querySelectorAll('.student-all-check').forEach(cb=>cb.addEventListener('change',function(){
    document.querySelectorAll(`.family-check[data-sid="${this.dataset.sid}"]`).forEach(c=>c.checked=this.checked);
    calcFamilyTotal();
}));
calcFamilyTotal();
</script>
