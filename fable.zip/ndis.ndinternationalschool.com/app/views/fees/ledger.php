<?php $pageTitle = 'Student Fee Ledger'; ?>
<div class="page-header">
    <h4><i class="fas fa-book-open"></i> Student Fee Ledger</h4>
    <a href="fees" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<!-- Search -->
<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="get" action="fees/ledger" class="row g-2 align-items-center">
            <div class="col-md-3">
                <select name="class_id" id="ledgerClass" class="form-select form-select-sm">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= (!empty($student) && $student['class_id'] == $c['id']) ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" id="ledgerSearch" class="form-control form-control-sm" placeholder="Search student...">
                <input type="hidden" name="student_id" id="ledgerStudentId" value="<?= $studentId ?>">
                <div id="ledgerResults" class="position-absolute bg-white border rounded shadow-sm" style="z-index:100;min-width:300px"></div>
            </div>
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">View Ledger</button>
            </div>
        </form>
    </div>
</div>

<?php if ($student): ?>
<!-- Student Summary -->
<div class="card shadow-sm mb-3 border-primary">
    <div class="card-body py-2">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h5 class="mb-0"><?= e($student['full_name']) ?></h5>
                <small class="text-muted">
                    <?= e($student['admission_number']) ?> &bull;
                    <?= e($student['class_name']) ?><?= $student['section_name'] ? ' - '.e($student['section_name']) : '' ?>
                </small>
            </div>
            <div class="col-md-6 text-md-end mt-2 mt-md-0">
                <span class="badge bg-danger fs-6 me-2">Outstanding: &#8377;<?= number_format($outstanding, 2) ?></span>
                <a href="fees/collect?student_id=<?= $student['id'] ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-rupee-sign"></i> Collect Fee
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Month-wise Status -->
<?php if ($months): ?>
<div class="card shadow-sm mb-3">
    <div class="card-header"><strong>Month-wise Status</strong></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Month</th>
                        <th>Fee Head</th>
                        <th class="text-end">Charged</th>
                        <th class="text-end">Discount</th>
                        <th class="text-end">Late Fee</th>
                        <th class="text-end">Paid</th>
                        <th class="text-end">Balance</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($months as $my => $mData): ?>
                    <?php foreach ($mData['heads'] as $i => $h):
                        $due = (float)$h['charged_amount'] + (float)$h['late_fee_amount'] - (float)$h['discount_amount'];
                        $bal = max(0, $due - (float)$h['paid_amount']);
                    ?>
                    <tr class="<?= $h['status']==='Paid'?'table-success':($h['status']==='Partial'?'table-warning':'') ?>">
                        <?php if ($i === 0): ?>
                        <td rowspan="<?= count($mData['heads']) ?>" class="fw-semibold align-middle">
                            <?= date('M Y', strtotime($my.'-01')) ?>
                        </td>
                        <?php endif; ?>
                        <td class="small"><?= e($h['head_name']) ?></td>
                        <td class="text-end small">&#8377;<?= number_format((float)$h['charged_amount'],2) ?></td>
                        <td class="text-end small text-success"><?= $h['discount_amount']>0?'-&#8377;'.number_format((float)$h['discount_amount'],2):'-' ?></td>
                        <td class="text-end small text-danger"><?= $h['late_fee_amount']>0?'+&#8377;'.number_format((float)$h['late_fee_amount'],2):'-' ?></td>
                        <td class="text-end small">&#8377;<?= number_format((float)$h['paid_amount'],2) ?></td>
                        <td class="text-end small fw-semibold"><?= $bal>0?'&#8377;'.number_format($bal,2):'—' ?></td>
                        <td class="text-center">
                            <?php $bsc = ($h['status']==='Paid'?'success':($h['status']==='Partial'?'warning':($h['status']==='Advance'?'info':'danger'))); ?>
                            <span class="badge bg-<?= $bsc ?>">
                                <?= e($h['status']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Full Ledger -->
<?php if (!empty($ledger)): ?>
<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between">
        <strong>Full Ledger (Immutable History)</strong>
        <small class="text-muted">All entries are permanent and cannot be edited</small>
    </div>
    <div class="card-body p-0">
        <table class="table table-sm table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Month</th>
                    <th>Head</th>
                    <th>Description</th>
                    <th class="text-end">Amount</th>
                    <th>By</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($ledger as $entry):
                $isCredit = $entry['amount'] < 0;
            ?>
            <tr class="<?= $isCredit ? 'table-success' : ($entry['entry_type']==='Cancellation'?'table-danger':'') ?>">
                <td class="small"><?= date('d/m/Y', strtotime($entry['created_at'])) ?></td>
                <?php $etc = ($entry['entry_type']==='Payment'?'success':($entry['entry_type']==='Discount'?'info':($entry['entry_type']==='Cancellation'?'danger':($entry['entry_type']==='LateFee'?'warning':'secondary')))); ?>
                <td><span class="badge bg-<?= $etc ?>"><?= e($entry['entry_type']) ?></span></td>
                <td class="small"><?= $entry['month_year'] ? date('M Y', strtotime($entry['month_year'].'-01')) : '-' ?></td>
                <td class="small"><?= e($entry['head_name'] ?? '-') ?></td>
                <td class="small"><?= e($entry['description']) ?></td>
                <td class="text-end <?= $isCredit?'text-success fw-semibold':'text-danger' ?>">
                    <?= $isCredit ? '-' : '+' ?>&#8377;<?= number_format(abs((float)$entry['amount']),2) ?>
                </td>
                <td class="small text-muted"><?= e($entry['by_name'] ?? '') ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php else: ?>
<div class="alert alert-info">Search and select a student to view their fee ledger.</div>
<?php endif; ?>

<script>
let lTimer;
document.getElementById('ledgerSearch').addEventListener('input', function(){
    clearTimeout(lTimer);
    const q = this.value.trim();
    if(q.length < 2){ document.getElementById('ledgerResults').innerHTML=''; return; }
    lTimer = setTimeout(()=>{
        const cid = document.getElementById('ledgerClass').value;
        fetch(url(`fees/searchStudents?q=${encodeURIComponent(q)}&class_id=${cid}`))
            .then(r=>r.json()).then(data=>{
                const el = document.getElementById('ledgerResults');
                if(!data.length){ el.innerHTML='<div class="p-2 text-muted small">No results</div>'; return; }
                el.innerHTML = data.map(s=>
                    `<div class="p-2 border-bottom cursor-pointer hover-bg" onclick="selectStudent(${s.id},'${s.name}')">
                        <strong>${s.name}</strong> <small class="text-muted">${s.admission_number} — ${s.class_name}</small>
                    </div>`
                ).join('');
            });
    },300);
});
function selectStudent(id, name){
    document.getElementById('ledgerStudentId').value = id;
    document.getElementById('ledgerSearch').value = name;
    document.getElementById('ledgerResults').innerHTML = '';
}
</script>
