<?php $pageTitle = 'Fee Heads'; ?>
<div class="page-header">
    <h4><i class="fas fa-tags"></i> Fee Heads</h4>
    <?php if (Permission::check('fees.manage')): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#headModal" onclick="resetForm()">
        <i class="fas fa-plus"></i> Add Fee Head
    </button>
    <?php endif; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th class="text-center">Sort</th>
                    <th class="text-center">Mandatory</th>
                    <th class="text-center">Status</th>
                    <?php if (Permission::check('fees.manage')): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($heads as $i => $h): ?>
            <tr class="<?= $h['is_active'] ? '' : 'table-secondary text-muted' ?>">
                <td><?= $i + 1 ?></td>
                <td><strong><?= e($h['name']) ?></strong></td>
                <td><span class="badge bg-light text-dark border"><?= e($h['head_type']) ?></span></td>
                <td class="small"><?= e($h['description']) ?></td>
                <td class="text-center"><?= (int)$h['sort_order'] ?></td>
                <td class="text-center">
                    <?php if ($h['is_mandatory']): ?>
                    <span class="badge bg-warning text-dark">Yes</span>
                    <?php else: ?>
                    <span class="text-muted">-</span>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <span class="badge bg-<?= $h['is_active'] ? 'success' : 'secondary' ?>">
                        <?= $h['is_active'] ? 'Active' : 'Inactive' ?>
                    </span>
                </td>
                <?php if (Permission::check('fees.manage')): ?>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editHead(<?= htmlspecialchars(json_encode($h), ENT_QUOTES) ?>)">
                        <i class="fas fa-edit"></i>
                    </button>
                    <?php if ($h['is_active']): ?>
                    <form method="post" action="fees/deleteHead" class="d-inline" onsubmit="return confirm('Deactivate this fee head?')">
                        <?= CSRF::field() ?>
                        <input type="hidden" name="id" value="<?= (int)$h['id'] ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="fas fa-ban"></i></button>
                    </form>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($heads)): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">No fee heads found. Add one to get started.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (Permission::check('fees.manage')): ?>
<!-- Add / Edit Modal -->
<div class="modal fade" id="headModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="fees/saveHead">
            <?= CSRF::field() ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="headModalTitle">Add Fee Head</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="headId">
                    <div class="mb-3">
                        <label class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="headName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="head_type" id="headType" class="form-select">
                            <?php foreach (['Tuition','Admission','Annual','Transport','Exam','Library','Lab','Sports','Activity','Computer','SmartClass','Miscellaneous','Custom'] as $t): ?>
                            <option value="<?= $t ?>"><?= $t ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <input type="text" name="description" id="headDesc" class="form-control">
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label">Sort Order</label>
                            <input type="number" name="sort_order" id="headSort" class="form-control" value="0" min="0">
                        </div>
                        <div class="col-6 mb-3 d-flex align-items-end">
                            <div class="form-check mb-2">
                                <input type="checkbox" name="is_mandatory" id="headMandatory" class="form-check-input" value="1">
                                <label class="form-check-label" for="headMandatory">Mandatory</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Fee Head</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
function resetForm(){
    document.getElementById('headId').value='';
    document.getElementById('headName').value='';
    document.getElementById('headType').value='Custom';
    document.getElementById('headDesc').value='';
    document.getElementById('headSort').value='0';
    document.getElementById('headMandatory').checked=false;
    document.getElementById('headModalTitle').textContent='Add Fee Head';
}
function editHead(h){
    document.getElementById('headId').value=h.id;
    document.getElementById('headName').value=h.name;
    document.getElementById('headType').value=h.head_type;
    document.getElementById('headDesc').value=h.description||'';
    document.getElementById('headSort').value=h.sort_order;
    document.getElementById('headMandatory').checked=h.is_mandatory=='1';
    document.getElementById('headModalTitle').textContent='Edit Fee Head';
    new bootstrap.Modal(document.getElementById('headModal')).show();
}
</script>
<?php endif; ?>
