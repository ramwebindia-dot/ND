<?php $pageTitle = 'Fee Discounts'; ?>
<div class="page-header">
    <h4><i class="fas fa-percent"></i> Fee Discounts</h4>
    <a href="fees" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<!-- Search Student -->
<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="get" action="fees/discounts" class="row g-2 align-items-center">
            <div class="col-md-5">
                <div class="position-relative">
                    <input type="text" id="dsSearch" class="form-control form-control-sm" placeholder="Search student by name or admission no..." value="<?= $student ? e($student['full_name']) : '' ?>">
                    <input type="hidden" name="student_id" id="dsStudentId" value="<?= $studentId ?>">
                    <div id="dsResults" class="position-absolute bg-white border rounded shadow-sm" style="z-index:100;min-width:300px"></div>
                </div>
            </div>
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">View Discounts</button>
            </div>
        </form>
    </div>
</div>

<?php if ($student): ?>
<div class="card shadow-sm mb-3 border-info">
    <div class="card-body py-2">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h6 class="mb-0"><?= e($student['full_name']) ?></h6>
                <small class="text-muted"><?= e($student['admission_number']) ?> &bull; <?= e($student['class_name']) ?></small>
            </div>
            <?php if (Permission::check('fees.manage')): ?>
            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#discountModal">
                <i class="fas fa-plus"></i> Add Discount
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if (empty($discounts)): ?>
<div class="alert alert-info">No discounts configured for this student in this session.</div>
<?php else: ?>
<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Type</th>
                    <th>Fee Head</th>
                    <th>Value</th>
                    <th>Reason</th>
                    <th>Valid From</th>
                    <th>Valid Until</th>
                    <th>Approved By</th>
                    <th class="text-center">Status</th>
                    <?php if (Permission::check('fees.manage')): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($discounts as $d): ?>
            <tr>
                <td><span class="badge bg-info text-dark"><?= e($d['discount_type']) ?></span></td>
                <td><?= $d['fee_category_id'] ? e($d['head_name']) : '<span class="text-muted">All Heads</span>' ?></td>
                <td class="fw-semibold">
                    <?= $d['discount_type'] === 'Percentage' ? number_format((float)$d['discount_value'],2).'%' : '&#8377;'.number_format((float)$d['discount_value'],2) ?>
                </td>
                <td class="small"><?= e($d['reason'] ?? '-') ?></td>
                <td class="small"><?= $d['valid_from'] ? date('d/m/Y', strtotime($d['valid_from'])) : '-' ?></td>
                <td class="small"><?= $d['valid_until'] ? date('d/m/Y', strtotime($d['valid_until'])) : '-' ?></td>
                <td class="small"><?= e($d['approved_by_name'] ?? '-') ?></td>
                <td class="text-center">
                    <span class="badge bg-<?= $d['is_active'] ? 'success' : 'secondary' ?>">
                        <?= $d['is_active'] ? 'Active' : 'Inactive' ?>
                    </span>
                </td>
                <?php if (Permission::check('fees.manage')): ?>
                <td>
                    <form method="post" action="fees/deleteDiscount" class="d-inline" onsubmit="return confirm('Remove this discount?')">
                        <?= CSRF::field() ?>
                        <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                        <input type="hidden" name="student_id" value="<?= $studentId ?>">
                        <input type="hidden" name="session_id" value="<?= $sessId ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Add Discount Modal -->
<?php if (Permission::check('fees.manage')): ?>
<div class="modal fade" id="discountModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="fees/saveDiscount">
            <?= CSRF::field() ?>
            <input type="hidden" name="student_id" value="<?= $studentId ?>">
            <input type="hidden" name="session_id" value="<?= $sessId ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Fee Discount</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Discount Type <span class="text-danger">*</span></label>
                        <select name="discount_type" class="form-select" required>
                            <option value="Fixed">Fixed Amount</option>
                            <option value="Percentage">Percentage</option>
                            <option value="Scholarship">Scholarship</option>
                            <option value="StaffConcession">Staff Concession</option>
                            <option value="SiblingConcession">Sibling Concession</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Apply On (leave blank for all heads)</label>
                        <select name="fee_category_id" class="form-select">
                            <option value="">All Fee Heads</option>
                            <?php foreach ($heads as $h): ?>
                            <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Value <span class="text-danger">*</span></label>
                        <input type="number" name="discount_value" class="form-control" step="0.01" min="0" required placeholder="Amount or %">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <input type="text" name="reason" class="form-control" placeholder="Reason for discount">
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label">Valid From</label>
                            <input type="date" name="valid_from" class="form-control">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Valid Until</label>
                            <input type="date" name="valid_until" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Save Discount</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php else: ?>
<div class="alert alert-info">Search and select a student to manage their discounts.</div>
<?php endif; ?>

<script>
let dTimer;
document.getElementById('dsSearch').addEventListener('input', function(){
    clearTimeout(dTimer);
    const q = this.value.trim();
    if(q.length<2){ document.getElementById('dsResults').innerHTML=''; return; }
    dTimer = setTimeout(()=>{
        fetch(url(`fees/searchStudents?q=${encodeURIComponent(q)}`))
            .then(r=>r.json()).then(data=>{
                const el = document.getElementById('dsResults');
                el.innerHTML = data.map(s=>
                    `<div class="p-2 border-bottom" style="cursor:pointer" onclick="selStudent(${s.id},'${s.name.replace(/'/g,"\\\'")}')">
                        <strong>${s.name}</strong> <small class="text-muted">${s.admission_number} — ${s.class_name}</small>
                    </div>`
                ).join('') || '<div class="p-2 text-muted small">No results</div>';
            });
    },300);
});
function selStudent(id,name){
    document.getElementById('dsStudentId').value=id;
    document.getElementById('dsSearch').value=name;
    document.getElementById('dsResults').innerHTML='';
}
</script>
