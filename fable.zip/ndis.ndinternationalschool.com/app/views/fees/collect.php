<?php $pageTitle = 'Collect Fee'; ?>
<div class="page-header">
    <h4><i class="fas fa-rupee-sign"></i> Collect Fee</h4>
    <a href="fees" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<?php if (!$student): ?>
<!-- STUDENT SELECTION — pick Class (+ Section) and the student list loads automatically -->
<div class="card shadow-sm">
    <div class="card-header"><strong>Select Student</strong></div>
    <div class="card-body">
        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <label class="form-label">Class</label>
                <select id="filterClass" class="form-select">
                    <option value="">-- Select Class --</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Section</label>
                <select id="filterSection" class="form-select">
                    <option value="">All Sections</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Quick filter (optional)</label>
                <input type="text" id="studentFilter" class="form-control" placeholder="Type name or admission no...">
            </div>
        </div>
        <div id="studentResults"><p class="text-muted mb-0">Select a class to load its students.</p></div>
    </div>
</div>
<script>
const _cls = document.getElementById('filterClass');
const _sec = document.getElementById('filterSection');
const _flt = document.getElementById('studentFilter');
const _res = document.getElementById('studentResults');
let _students = [];

// Load sections when class changes, then load students.
_cls.addEventListener('change', function(){
    _sec.innerHTML = '<option value="">All Sections</option>';
    if (this.value) {
        fetch(url('academic/get-sections?class_id=' + this.value))
            .then(r=>r.json())
            .then(list => { (list||[]).forEach(s => _sec.innerHTML += `<option value="${s.id}">${s.name}</option>`); });
    }
    loadStudents();
});
_sec.addEventListener('change', loadStudents);
_flt.addEventListener('input', renderStudents);

function loadStudents(){
    const cid = _cls.value, sid = _sec.value;
    if(!cid){ _students=[]; _res.innerHTML='<p class="text-muted mb-0">Select a class to load its students.</p>'; return; }
    _res.innerHTML = '<p class="text-muted mb-0">Loading…</p>';
    fetch(url(`fees/studentsByClass?class_id=${cid}&section_id=${sid}`))
        .then(r=>r.json()).then(data=>{ _students = data||[]; renderStudents(); });
}

function renderStudents(){
    const q = (_flt.value||'').toLowerCase().trim();
    const rows = _students.filter(s =>
        !q || (s.name||'').toLowerCase().includes(q) || (s.admission_number||'').toLowerCase().includes(q));
    if(!rows.length){ _res.innerHTML='<p class="text-muted mb-0">No students found.</p>'; return; }
    _res.innerHTML = `<div class="table-responsive"><table class="table table-hover mb-0"><thead class="table-light">
        <tr><th style="width:70px">Roll</th><th>Name</th><th>Adm. No.</th><th class="text-end">Action</th></tr></thead><tbody>`
      + rows.map(s=>`<tr>
            <td>${s.roll_number||'-'}</td>
            <td class="fw-medium">${s.name}</td>
            <td><span class="badge bg-secondary">${s.admission_number}</span></td>
            <td class="text-end"><a href="${url('fees/collect?student_id='+s.id)}" class="btn btn-sm btn-primary-custom">
                <i class="fas fa-rupee-sign me-1"></i>Collect</a></td>
        </tr>`).join('') + `</tbody></table></div>`;
}
</script>

<?php else: ?>
<!-- PAYMENT FORM -->
<div class="row mb-3">
    <div class="col-md-8">
        <div class="card shadow-sm border-primary">
            <div class="card-body py-2">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h5 class="mb-0"><?= e($student['full_name']) ?></h5>
                        <small class="text-muted">
                            <?= e($student['admission_number']) ?> &bull;
                            <?= e($student['class_name']) ?><?= $student['section_name'] ? ' - '.e($student['section_name']) : '' ?>
                            <?php if ($student['parent_name']): ?>&bull; Parent: <?= e($student['parent_name']) ?><?php endif; ?>
                        </small>
                    </div>
                    <div class="ms-auto text-end">
                        <?php $outstanding = 0; foreach ($monthStatus as $ms) { $outstanding += $ms['total_charged'] + $ms['total_late_fee'] - $ms['total_discount'] - $ms['total_paid']; } $outstanding = max(0, $outstanding); ?>
                        <div class="text-danger fw-bold">Outstanding: &#8377;<?= number_format($outstanding, 2) ?></div>
                        <?php if ($credit > 0): ?>
                        <div class="text-success small">Credit Balance: &#8377;<?= number_format($credit, 2) ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4 d-flex gap-2 align-items-center">
        <?php if (!empty($siblings)): ?>
        <a href="fees/familyPayment?student_id=<?= $studentId ?>" class="btn btn-outline-info btn-sm">
            <i class="fas fa-users"></i> Family Payment (<?= count($siblings) + 1 ?> students)
        </a>
        <?php endif; ?>
        <a href="fees/ledger?student_id=<?= $studentId ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-book"></i> Ledger
        </a>
    </div>
</div>

<?php $canDiscount = Permission::check('fees.modify_discount'); ?>
<form method="post" action="fees/processPayment" id="paymentForm">
    <?= CSRF::field() ?>
    <input type="hidden" name="student_id" value="<?= $studentId ?>">
    <input type="hidden" name="session_id" value="<?= $sessionId ?>">

    <!-- Month × Fee Head Grid -->
    <div class="card shadow-sm mb-3">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <strong>Fee Items</strong>
            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-1">
                    <label class="small mb-0 text-nowrap">Pay for:</label>
                    <select id="payPeriod" class="form-select form-select-sm" style="min-width:150px">
                        <option value="custom">Custom (tick manually)</option>
                        <option value="1">1 Month (Monthly)</option>
                        <option value="3">Quarter (3 Months)</option>
                        <option value="6">Half Year (6 Months)</option>
                        <option value="12">Full Year (Annually)</option>
                    </select>
                </div>
                <div class="form-check form-switch mb-0">
                    <input class="form-check-input" type="checkbox" id="showPaidMonths">
                    <label class="form-check-label small" for="showPaidMonths">Show Paid Months</label>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm table-bordered mb-0" id="feeGrid">
                    <thead class="table-light">
                        <tr>
                            <th><input type="checkbox" id="selectAll" title="Select All" checked></th>
                            <th>Month</th>
                            <th>Fee Head</th>
                            <th class="text-end">Charged</th>
                            <th class="text-end">Late Fee</th>
                            <th class="text-end">Balance (Payable)</th>
                        </tr>
                    </thead>
                    <tbody id="feeRows">
                    <?php
                    $rowIdx = 0;
                    foreach ($monthStatus as $my => $monthData):
                        foreach ($monthData['heads'] as $head):
                            $charged  = (float)$head['charged_amount'];
                            $late     = (float)$head['late_fee_amount'];
                            $standing = (float)$head['discount_amount'];   // scholarship / standing discount
                            $paidPrev = (float)$head['paid_amount'];
                            $bal      = max(0, $charged + $late - $standing - $paidPrev);
                            $isPaid   = $head['status'] === 'Paid';
                    ?>
                    <tr class="fee-row <?= $isPaid ? 'paid-row text-muted' : '' ?>" <?= $isPaid ? 'style="display:none"' : '' ?>>
                        <td class="text-center">
                            <?php if (!$isPaid && $bal > 0): ?>
                            <input type="checkbox" class="row-check" data-idx="<?= $rowIdx ?>" data-month="<?= $my ?>"
                                   data-charged="<?= $charged ?>" data-standing="<?= $standing ?>" data-balance="<?= $bal ?>" checked>
                            <?php endif; ?>
                        </td>
                        <td class="small"><?= date('M Y', strtotime($my.'-01')) ?></td>
                        <td class="small"><?= e($head['head_name']) ?></td>
                        <td class="text-end small">&#8377;<?= number_format($charged, 2) ?></td>
                        <td class="text-end small <?= $late>0?'text-danger':'' ?>"><?= $late > 0 ? '+&#8377;'.number_format($late,2) : '-' ?></td>
                        <td class="text-end small fw-semibold <?= $bal > 0 ? 'text-danger' : 'text-success' ?>">
                            <?= $bal > 0 ? '&#8377;'.number_format($bal,2) : '<span class="badge bg-success">Paid</span>' ?>
                        </td>
                        <?php if (!$isPaid && $bal > 0): ?>
                        <input type="hidden" name="items[<?= $rowIdx ?>][student_id]" value="<?= $studentId ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][fee_category_id]" value="<?= $head['fee_category_id'] ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][month_year]" value="<?= $my ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][charged_amount]" value="<?= $charged ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][late_fee_amount]" value="<?= $late ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][discount_amount]" class="disc-hidden" data-idx="<?= $rowIdx ?>" value="<?= $standing ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][paid_amount]" class="paid-hidden" data-idx="<?= $rowIdx ?>" value="<?= $bal ?>">
                        <?php endif; ?>
                    </tr>
                    <?php $rowIdx++; endforeach; endforeach; ?>

                    <!-- Additional Charges (one-time extras) -->
                    <?php foreach ($additional as $ac): if (!$ac['is_paid']): $acAmt = (float)$ac['amount']; ?>
                    <tr class="fee-row table-warning">
                        <td class="text-center">
                            <input type="checkbox" class="row-check" data-idx="<?= $rowIdx ?>"
                                   data-charged="<?= $acAmt ?>" data-standing="0" data-balance="<?= $acAmt ?>" checked>
                        </td>
                        <td class="small">-</td>
                        <td class="small"><?= e($ac['head_label'] ?: $ac['charge_type']) ?> <span class="badge bg-warning text-dark">Extra</span></td>
                        <td class="text-end small">&#8377;<?= number_format($acAmt,2) ?></td>
                        <td>-</td>
                        <td class="text-end small fw-semibold text-danger">&#8377;<?= number_format($acAmt,2) ?></td>
                        <input type="hidden" name="items[<?= $rowIdx ?>][student_id]" value="<?= $studentId ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][charged_amount]" value="<?= $acAmt ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][remarks]" value="<?= e($ac['charge_type']) ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][discount_amount]" class="disc-hidden" data-idx="<?= $rowIdx ?>" value="0">
                        <input type="hidden" name="items[<?= $rowIdx ?>][paid_amount]" class="paid-hidden" data-idx="<?= $rowIdx ?>" value="<?= $acAmt ?>">
                    </tr>
                    <?php $rowIdx++; endif; endforeach; ?>

                    <!-- Transport Fee (opt-in) — rates from Transport → Fee Rate Settings -->
                    <?php if (!empty($transportRates)):
                        $trAmt0 = (float)$transportRates[0]['amount'];
                        $trType0 = $transportRates[0]['fee_type'];
                        $trMonth0 = $months[0]['month_year'] ?? date('Y-m');
                    ?>
                    <tr class="fee-row table-info">
                        <td class="text-center">
                            <input type="checkbox" class="row-check" id="transportCheck" data-idx="<?= $rowIdx ?>"
                                   data-charged="<?= $trAmt0 ?>" data-standing="0" data-balance="<?= $trAmt0 ?>">
                        </td>
                        <td class="small">
                            <select id="transportMonth" class="form-select form-select-sm" style="min-width:100px">
                                <?php foreach ($months as $mo): ?>
                                <option value="<?= $mo['month_year'] ?>"><?= e($mo['label']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="small">
                            <span class="badge bg-info text-dark">Transport</span>
                            <select id="transportType" class="form-select form-select-sm mt-1">
                                <?php foreach ($transportRates as $tr): ?>
                                <option value="<?= e($tr['fee_type']) ?>" data-amount="<?= (float)$tr['amount'] ?>">
                                    <?= e($tr['label'] ?: $tr['fee_type']) ?> — &#8377;<?= number_format((float)$tr['amount'], 0) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="text-end small" id="transportCharged">&#8377;<?= number_format($trAmt0, 2) ?></td>
                        <td>-</td>
                        <td class="text-end small fw-semibold text-danger" id="transportBal">&#8377;<?= number_format($trAmt0, 2) ?></td>
                        <input type="hidden" name="items[<?= $rowIdx ?>][student_id]" value="<?= $studentId ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][is_transport]" value="1">
                        <input type="hidden" name="items[<?= $rowIdx ?>][transport_fee_type]" id="transportTypeHidden" value="<?= e($trType0) ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][month_year]" id="transportMonthHidden" value="<?= e($trMonth0) ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][charged_amount]" id="transportChargedHidden" value="<?= $trAmt0 ?>">
                        <input type="hidden" name="items[<?= $rowIdx ?>][discount_amount]" class="disc-hidden" data-idx="<?= $rowIdx ?>" value="0">
                        <input type="hidden" name="items[<?= $rowIdx ?>][paid_amount]" class="paid-hidden" data-idx="<?= $rowIdx ?>" value="0">
                    </tr>
                    <?php $rowIdx++; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Payment Summary: single discount on TOTAL + custom amount received -->
    <div class="card shadow-sm mb-3">
        <div class="card-header"><strong>Payment Summary</strong></div>
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Total Selected</label>
                    <div class="form-control bg-light fw-bold text-end" id="totalSelectedBox">&#8377;0.00</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Discount (on total)</label>
                    <div class="input-group">
                        <span class="input-group-text">&#8377;</span>
                        <input type="number" id="totalDiscount" class="form-control text-end" value="0" min="0" step="0.01"
                               <?= $canDiscount ? '' : 'readonly title="You do not have discount permission"' ?>>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Net Payable</label>
                    <div class="form-control bg-light fw-bold text-end text-primary" id="netPayableBox">&#8377;0.00</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Amount Received <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text">&#8377;</span>
                        <input type="number" id="amountReceived" class="form-control text-end fw-bold" value="0" min="0" step="0.01">
                    </div>
                </div>
            </div>
            <div class="mt-2 text-end">
                <span class="me-3">Paying Now: <strong class="text-success" id="payingNowLbl">&#8377;0.00</strong></span>
                <span>Remaining (stays outstanding): <strong class="text-danger" id="remainingLbl">&#8377;0.00</strong></span>
            </div>
            <div class="form-text">Discount poore total par lagta hai. Amount Received kam bhi ho sakta hai (partial) — baaki outstanding me rahega.</div>
        </div>
    </div>

    <!-- Payment Details -->
    <div class="card shadow-sm mb-3">
        <div class="card-header"><strong>Payment Details</strong></div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Payment Date <span class="text-danger">*</span></label>
                    <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Payment Mode <span class="text-danger">*</span></label>
                    <select name="payment_method" id="payMethod" class="form-select" onchange="togglePayFields()" required>
                        <option value="Cash">Cash</option>
                        <option value="Cheque">Cheque</option>
                        <option value="DD">DD (Demand Draft)</option>
                        <option value="NEFT">NEFT / RTGS</option>
                        <option value="UPI">UPI</option>
                        <option value="Card">Card</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Receipt No. <span class="text-danger">*</span></label>
                    <input type="text" name="receipt_number" class="form-control" placeholder="Enter receipt number" required>
                </div>
                <div class="col-md-3" id="bankField" style="display:none">
                    <label class="form-label">Bank Account</label>
                    <select name="bank_account_id" class="form-select">
                        <option value="">-- Select --</option>
                        <?php foreach ($accounts as $a): ?>
                        <option value="<?= $a['id'] ?>"><?= e($a['account_name']) ?> (<?= e($a['bank_name']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3" id="chequeField" style="display:none">
                    <label class="form-label">Cheque No.</label>
                    <input type="text" name="cheque_number" class="form-control" placeholder="Cheque number">
                </div>
                <div class="col-md-3" id="chequeDateField" style="display:none">
                    <label class="form-label">Cheque Date</label>
                    <input type="date" name="cheque_date" class="form-control">
                </div>
                <div class="col-md-3" id="upiField" style="display:none">
                    <label class="form-label">UPI Txn ID</label>
                    <input type="text" name="upi_transaction_id" class="form-control" placeholder="Transaction ID">
                </div>
                <div class="col-md-3" id="ddField" style="display:none">
                    <label class="form-label">DD Number</label>
                    <input type="text" name="dd_number" class="form-control" placeholder="DD number">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Remarks</label>
                    <input type="text" name="remarks" class="form-control" placeholder="Optional note">
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between">
        <a href="fees/collect" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-success btn-lg px-5" id="submitBtn" disabled>
            <i class="fas fa-check"></i> Collect Payment
        </button>
    </div>
</form>

<script>
const money = v => '&#8377;' + (Number(v)||0).toFixed(2);
const totalDiscountEl = document.getElementById('totalDiscount');
const amountReceivedEl = document.getElementById('amountReceived');

// Sum of selected rows' balances (already net of standing scholarship discounts).
function selectedRows(){ return Array.from(document.querySelectorAll('.row-check:checked')); }
function totalSelected(){ return selectedRows().reduce((s,cb)=> s + (parseFloat(cb.dataset.balance)||0), 0); }

// Distribute the single total-discount and the received amount across the selected
// lines, writing each line's hidden discount_amount (standing + counter share) and
// paid_amount. Lines that receive no payment are left at paid=0 (server skips them).
function allocate(){
    const rows = selectedRows();
    const total = totalSelected();
    let disc = Math.max(0, Math.min(parseFloat(totalDiscountEl.value)||0, total));
    const net = Math.max(0, total - disc);

    // default amount received = net payable (kept in sync unless user edited it lower/higher)
    let recv = parseFloat(amountReceivedEl.value);
    if (isNaN(recv)) recv = net;
    recv = Math.max(0, Math.min(recv, net));   // never pay more than net payable

    // reset all hidden inputs first
    document.querySelectorAll('.paid-hidden').forEach(i=> i.value = 0);
    document.querySelectorAll('.disc-hidden').forEach(i=> {
        // keep standing discount only for rows that end up paid; reset others to their standing baseline via data
    });

    let dLeft = disc, rLeft = recv;
    rows.forEach(cb=>{
        const idx = cb.dataset.idx;
        const charged  = parseFloat(cb.dataset.charged)  || 0;
        const standing = parseFloat(cb.dataset.standing) || 0;
        const bal      = parseFloat(cb.dataset.balance)  || 0;
        const discEl = document.querySelector(`.disc-hidden[data-idx="${idx}"]`);
        const paidEl = document.querySelector(`.paid-hidden[data-idx="${idx}"]`);
        if(!paidEl){ return; }
        const maxCounter = Math.max(0, charged - standing);       // standing + counter ≤ charged
        const cDisc = Math.min(dLeft, bal, maxCounter);
        const dueAfter = bal - cDisc;
        const pay = Math.min(rLeft, dueAfter);
        if (pay <= 0.0001) { if(discEl) discEl.value = 0; paidEl.value = 0; return; }
        if (discEl) discEl.value = (standing + cDisc).toFixed(2);
        paidEl.value = pay.toFixed(2);
        dLeft -= cDisc; rLeft -= pay;
    });

    document.getElementById('totalSelectedBox').innerHTML = money(total);
    document.getElementById('netPayableBox').innerHTML    = money(net);
    document.getElementById('payingNowLbl').innerHTML     = money(recv);
    document.getElementById('remainingLbl').innerHTML     = money(net - recv);
    document.getElementById('submitBtn').disabled = recv <= 0;
}

// When selection/discount changes, reset received to net payable; when the user edits
// received directly, respect their number (partial payments).
function refreshDefaultsThenAllocate(){
    const total = totalSelected();
    const disc = Math.max(0, Math.min(parseFloat(totalDiscountEl.value)||0, total));
    amountReceivedEl.value = Math.max(0, total - disc).toFixed(2);
    allocate();
}

document.getElementById('selectAll').addEventListener('change', function(){
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = this.checked);
    document.getElementById('payPeriod').value = 'custom';
    refreshDefaultsThenAllocate();
});
// Manual tick → switch the period selector back to "Custom".
document.querySelectorAll('.row-check').forEach(cb => cb.addEventListener('change', function(){
    document.getElementById('payPeriod').value = 'custom';
    refreshDefaultsThenAllocate();
}));
totalDiscountEl.addEventListener('input', refreshDefaultsThenAllocate);
amountReceivedEl.addEventListener('input', allocate);

// "Pay for" period → auto-tick the first N unpaid months (monthly rows). Rows without a
// month (extra charges / transport) are left untouched so the cashier controls those.
document.getElementById('payPeriod').addEventListener('change', function(){
    if (this.value === 'custom') return;
    const n = parseInt(this.value, 10);
    const monthChecks = Array.from(document.querySelectorAll('.row-check[data-month]'));
    const months = [...new Set(monthChecks.map(c => c.dataset.month))].sort();
    const pick = new Set(months.slice(0, n));
    monthChecks.forEach(c => { c.checked = pick.has(c.dataset.month); });
    refreshDefaultsThenAllocate();
});

// Show/hide paid months
document.getElementById('showPaidMonths').addEventListener('change', function(){
    document.querySelectorAll('.paid-row').forEach(r => r.style.display = this.checked ? '' : 'none');
});

// Payment mode fields
function togglePayFields(){
    const m = document.getElementById('payMethod').value;
    document.getElementById('bankField').style.display = ['Cheque','DD','NEFT','Card','UPI'].includes(m)?'':'none';
    document.getElementById('chequeField').style.display = m==='Cheque'?'':'none';
    document.getElementById('chequeDateField').style.display = m==='Cheque'?'':'none';
    document.getElementById('upiField').style.display = m==='UPI'?'':'none';
    document.getElementById('ddField').style.display = m==='DD'?'':'none';
}

// Transport fee (opt-in)
(function(){
    const tType = document.getElementById('transportType');
    if (!tType) return;
    const tCheck = document.getElementById('transportCheck');
    const tMonth = document.getElementById('transportMonth');
    function amt(){ return parseFloat(tType.options[tType.selectedIndex].dataset.amount) || 0; }
    function refresh(){
        const a = amt();
        document.getElementById('transportTypeHidden').value    = tType.value;
        document.getElementById('transportChargedHidden').value = a;
        document.getElementById('transportCharged').innerHTML   = money(a);
        document.getElementById('transportBal').innerHTML       = money(a);
        tCheck.dataset.charged = a; tCheck.dataset.balance = a;
        refreshDefaultsThenAllocate();
    }
    tType.addEventListener('change', refresh);
    tMonth.addEventListener('change', function(){ document.getElementById('transportMonthHidden').value = this.value; });
})();

refreshDefaultsThenAllocate();
</script>
<?php endif; ?>
