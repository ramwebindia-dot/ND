<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-plus-circle"></i> Additional Charges</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('fees/additionalCharges'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $cls): ?>
                    <option value="<?php echo $cls['id']; ?>" <?php echo $classId == $cls['id'] ? 'selected' : ''; ?>>
                        <?php echo e($cls['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if (!empty($students)): ?>
            <div class="col-md-3">
                <label class="form-label">Student</label>
                <select name="student_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Select Student</option>
                    <?php foreach ($students as $st): ?>
                    <option value="<?php echo $st['id']; ?>" <?php echo $studentId == $st['id'] ? 'selected' : ''; ?>>
                        <?php echo e($st['first_name'] . ' ' . $st['last_name']); ?> (<?php echo e($st['admission_number']); ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <input type="hidden" name="class_id" value="<?php echo $classId; ?>">
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if ($student): ?>
<div class="row">
    <div class="col-lg-8">
        <div class="card mb-3">
            <div class="card-header">
                <strong><?php echo e($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                <small class="text-muted ms-2"><?php echo e($student['admission_number']); ?></small>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Description</th>
                            <th class="text-end">Amount</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($charges as $ch): ?>
                        <tr class="<?php echo $ch['is_paid'] ? 'table-success' : ''; ?>">
                            <td><?php echo formatDate($ch['charge_date']); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($ch['charge_type']); ?></span></td>
                            <td><small><?php echo e($ch['description'] ?? ''); ?></small></td>
                            <td class="text-end"><strong><?php echo formatCurrency($ch['amount']); ?></strong></td>
                            <td>
                                <?php if ($ch['is_paid']): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Unpaid</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$ch['is_paid']): ?>
                                <form method="POST" action="<?php echo url('fees/markChargesPaid'); ?>" class="d-inline">
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                    <input type="hidden" name="id" value="<?php echo $ch['id']; ?>">
                                    <input type="hidden" name="student_id" value="<?php echo $studentId; ?>">
                                    <button type="submit" class="btn btn-xs btn-outline-success" onclick="return confirm('Mark as paid?')">
                                        <i class="fas fa-check"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($charges)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No additional charges for this student.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($charges)): ?>
                    <tfoot class="table-light">
                        <tr>
                            <td colspan="3"><strong>Total</strong></td>
                            <td class="text-end"><strong><?php echo formatCurrency(array_sum(array_column($charges, 'amount'))); ?></strong></td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Add Charge</h6></div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('fees/saveAdditionalCharge'); ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="student_id" value="<?php echo $studentId; ?>">
                    <div class="mb-2">
                        <label class="form-label small">Charge Type</label>
                        <select name="charge_type" class="form-select form-select-sm" required>
                            <option value="Library Fine">Library Fine</option>
                            <option value="Lost ID Card">Lost ID Card</option>
                            <option value="Exam Fee">Exam Fee</option>
                            <option value="Sports Fee">Sports Fee</option>
                            <option value="Trip Fee">Trip Fee</option>
                            <option value="Damage Charge">Damage Charge</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Amount (₹)</label>
                        <input type="number" name="amount" class="form-control form-control-sm"
                               step="0.01" min="0.01" required placeholder="0.00">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Date</label>
                        <input type="date" name="charge_date" class="form-control form-control-sm"
                               value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">Description / Reason</label>
                        <textarea name="description" class="form-control form-control-sm" rows="2"
                                  placeholder="Optional details"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary-custom btn-sm w-100">
                        <i class="fas fa-save me-1"></i>Save Charge
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="alert alert-info">Select a class and student to view and add charges.</div>
<?php endif; ?>
<style>.btn-xs{padding:.15rem .4rem;font-size:.7rem}</style>
