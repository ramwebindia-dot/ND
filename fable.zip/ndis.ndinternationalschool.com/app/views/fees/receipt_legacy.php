<div class="page-header">
    <h4><i class="fas fa-print"></i> Fee Receipt (Legacy)</h4>
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm no-print">
        <i class="fas fa-print me-1"></i>Print
    </button>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm no-print">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<div class="card" style="max-width:600px; margin:0 auto;">
  <div class="card-header text-center bg-primary-custom text-white">
    <h5><?php echo e($schoolSettings['school_name'] ?? APP_NAME); ?></h5>
    <small><?php echo e($schoolSettings['school_address'] ?? ''); ?></small>
  </div>
  <div class="card-body">
    <h6 class="text-center mb-3 text-uppercase">Fee Receipt</h6>
    <table class="table table-sm table-borderless">
      <tr>
        <td class="text-muted">Receipt No:</td><td><strong><?php echo e($collection['receipt_number']); ?></strong></td>
        <td class="text-muted">Date:</td><td><?php echo formatDate($collection['payment_date']); ?></td>
      </tr>
      <tr>
        <td class="text-muted">Student:</td><td><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></td>
        <td class="text-muted">Adm No:</td><td><?php echo e($student['admission_number']); ?></td>
      </tr>
      <tr>
        <td class="text-muted">Class:</td><td><?php echo e($student['class_name']??'—'); ?></td>
        <td class="text-muted">Method:</td><td><?php echo e($collection['payment_method']); ?></td>
      </tr>
    </table>
    <hr>
    <table class="table table-sm">
      <thead><tr><th>#</th><th>Fee Type</th><th class="text-end">Amount</th></tr></thead>
      <tbody>
      <?php $i=1; foreach ($lines as $l):
          $name = $l['category_name'] ?? ('Transport ('.$l['transport_fee_type'].')');
      ?>
        <tr>
          <td class="text-muted small"><?php echo $i++; ?></td>
          <td><?php echo e($name); ?></td>
          <td class="text-end"><?php echo formatCurrency($l['amount']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot class="table-light">
        <?php if ($totalDiscount > 0): ?>
        <tr><td colspan="2" class="text-end text-muted">Discount</td>
            <td class="text-end text-danger">-<?php echo formatCurrency($totalDiscount); ?></td></tr>
        <?php endif; ?>
        <tr class="fw-bold">
          <td colspan="2" class="text-end">Net Amount Paid</td>
          <td class="text-end text-success"><?php echo formatCurrency($totalPaid); ?></td>
        </tr>
        <?php $bal = round(($grandLineTotal - $totalDiscount) - $totalPaid, 2);
              if ($bal > 0.004): ?>
        <tr><td colspan="2" class="text-end text-danger">Balance</td>
            <td class="text-end text-danger fw-bold"><?php echo formatCurrency($bal); ?></td></tr>
        <?php endif; ?>
      </tfoot>
    </table>
  </div>
  <div class="card-footer text-center">
    <small>© <?php echo date('Y'); ?> <?php echo e($schoolSettings['school_name'] ?? APP_NAME); ?></small>
  </div>
</div>
<style>@media print { .no-print { display:none !important; } }</style>
