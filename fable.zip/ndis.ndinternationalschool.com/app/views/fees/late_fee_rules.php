<div class="page-header">
    <h4><i class="fas fa-clock"></i> Late Fee Rules</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<div class="row">
<div class="col-lg-8">
  <div class="card">
    <div class="card-header"><h6 class="mb-0">Configured Rules</h6></div>
    <div class="table-responsive">
      <table class="table table-sm table-bordered mb-0">
        <thead class="table-light">
          <tr><th>Class</th><th>Fee Category</th><th>Due Day</th><th>Grace Days</th>
              <th>Late Fee</th><th>Active</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($rules as $r): ?>
          <tr>
            <td><?php echo e($r['class_name'] ?? 'All Classes'); ?></td>
            <td><?php echo e($r['category_name'] ?? 'All Categories'); ?></td>
            <td><?php echo $r['due_day']; ?>th</td>
            <td><?php echo $r['grace_days']; ?> days</td>
            <td>
              <?php echo $r['late_fee_type'] === 'Percentage'
                  ? number_format($r['late_fee_amount'],2).'%'
                  : '₹'.number_format($r['late_fee_amount'],2); ?>
              <?php if (!empty($r['max_late_fee'])): ?>
                <small class="text-muted">(max ₹<?php echo number_format($r['max_late_fee'],2); ?>)</small>
              <?php endif; ?>
            </td>
            <td>
              <?php echo $r['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'; ?>
            </td>
            <td>
              <button class="btn btn-xs btn-outline-primary"
                      onclick="editRule(<?php echo htmlspecialchars(json_encode($r)); ?>)">
                <i class="fas fa-edit"></i>
              </button>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rules)): ?>
          <tr><td colspan="7" class="text-center text-muted py-3">No rules configured yet.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="col-lg-4">
  <div class="card">
    <div class="card-header"><h6 class="mb-0" id="formTitle">Add Late Fee Rule</h6></div>
    <div class="card-body">
      <form method="POST" action="<?php echo url('fees/saveLateFeeRule'); ?>">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        <input type="hidden" name="id" id="ruleId">
        <div class="mb-2">
          <label class="form-label small">Class (leave blank for all)</label>
          <select name="class_id" id="ruleClassId" class="form-select form-select-sm">
            <option value="">All Classes</option>
            <?php foreach ($classes as $cls): ?>
              <option value="<?php echo $cls['id']; ?>"><?php echo e($cls['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label small">Fee Category (leave blank for all)</label>
          <select name="fee_category_id" id="ruleCatId" class="form-select form-select-sm">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?php echo $cat['id']; ?>"><?php echo e($cat['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row g-2 mb-2">
          <div class="col-6">
            <label class="form-label small">Due Day of Month</label>
            <input type="number" name="due_day" id="ruleDueDay" class="form-control form-control-sm"
                   value="10" min="1" max="31" required>
          </div>
          <div class="col-6">
            <label class="form-label small">Grace Days</label>
            <input type="number" name="grace_days" id="ruleGraceDays" class="form-control form-control-sm"
                   value="0" min="0" max="30">
          </div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Late Fee Type</label>
          <select name="late_fee_type" id="ruleType" class="form-select form-select-sm">
            <option value="Fixed">Fixed Amount</option>
            <option value="Percentage">Percentage</option>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label small">Late Fee Amount / Percentage</label>
          <div class="input-group input-group-sm">
            <span class="input-group-text" id="lateSymbol">₹</span>
            <input type="number" name="late_fee_amount" id="ruleLateAmt" class="form-control"
                   value="0" min="0" step="0.01" required>
          </div>
        </div>
        <div class="mb-2" id="maxFeeRow">
          <label class="form-label small">Maximum Late Fee (₹, optional cap)</label>
          <input type="number" name="max_late_fee" class="form-control form-control-sm"
                 placeholder="Leave blank for no cap" min="0" step="0.01">
        </div>
        <div class="mb-3">
          <label class="form-label small">Active</label>
          <select name="is_active" id="ruleActive" class="form-select form-select-sm">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary-custom btn-sm w-100">Save Rule</button>
        <button type="button" class="btn btn-outline-secondary btn-sm w-100 mt-2" onclick="resetForm()">Reset</button>
      </form>
    </div>
  </div>
</div>
</div>

<script>
document.getElementById('ruleType').addEventListener('change', function() {
    document.getElementById('lateSymbol').textContent = this.value === 'Percentage' ? '%' : '₹';
    document.getElementById('maxFeeRow').style.display = this.value === 'Percentage' ? '' : 'none';
});

function editRule(r) {
    document.getElementById('formTitle').textContent   = 'Edit Rule #' + r.id;
    document.getElementById('ruleId').value            = r.id;
    document.getElementById('ruleClassId').value       = r.class_id || '';
    document.getElementById('ruleCatId').value         = r.fee_category_id || '';
    document.getElementById('ruleDueDay').value        = r.due_day;
    document.getElementById('ruleGraceDays').value     = r.grace_days;
    document.getElementById('ruleType').value          = r.late_fee_type;
    document.getElementById('ruleLateAmt').value       = r.late_fee_amount;
    document.getElementById('ruleActive').value        = r.is_active;
    document.getElementById('lateSymbol').textContent  = r.late_fee_type === 'Percentage' ? '%' : '₹';
    document.getElementById('maxFeeRow').style.display = r.late_fee_type === 'Percentage' ? '' : 'none';
    window.scrollTo(0, document.querySelector('.col-lg-4').offsetTop);
}

function resetForm() {
    document.getElementById('ruleId').value = '';
    document.getElementById('formTitle').textContent = 'Add Late Fee Rule';
}
</script>
<style>.btn-xs { padding:.15rem .4rem; font-size:.7rem; }</style>
