<?php $pageTitle = 'Fee Management'; ?>
<div class="page-header">
    <h4><i class="fas fa-rupee-sign"></i> Fee Management</h4>
    <div class="d-flex gap-2 flex-wrap">
        <?php if (Permission::check('fees.collect')): ?>
        <a href="fees/collect" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Collect Fee</a>
        <?php endif; ?>
        <?php if (Permission::check('fees.manage')): ?>
        <a href="fees/heads" class="btn btn-outline-secondary btn-sm"><i class="fas fa-tags"></i> Fee Heads</a>
        <a href="fees/structures" class="btn btn-outline-secondary btn-sm"><i class="fas fa-table"></i> Fee Structure</a>
        <?php endif; ?>
        <?php if (Permission::check('fees.reports')): ?>
        <a href="fees/reports" class="btn btn-outline-info btn-sm"><i class="fas fa-chart-bar"></i> Reports</a>
        <?php endif; ?>
        <a href="fees/receipts" class="btn btn-outline-dark btn-sm"><i class="fas fa-receipt"></i> Receipts</a>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="text-muted small mb-1">Today's Collection</div>
                <h4 class="text-success mb-0">&#8377;<?= number_format($summary['today'], 2) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="text-muted small mb-1">This Month</div>
                <h4 class="text-primary mb-0">&#8377;<?= number_format($summary['month'], 2) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="text-muted small mb-1">Session Total</div>
                <h4 class="text-info mb-0">&#8377;<?= number_format($summary['session'], 2) ?></h4>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body text-center">
                <div class="text-muted small mb-1">Outstanding</div>
                <h4 class="text-danger mb-0">&#8377;<?= number_format($summary['outstanding'], 2) ?></h4>
            </div>
        </div>
    </div>
</div>

<!-- Payment Method Breakdown -->
<?php if (!empty($summary['by_method'])): ?>
<div class="card shadow-sm mb-4">
    <div class="card-header"><strong>Today's Collection by Payment Mode</strong></div>
    <div class="card-body p-0">
        <table class="table table-sm mb-0">
            <thead class="table-light"><tr>
                <th>Payment Mode</th><th class="text-end">Count</th><th class="text-end">Amount</th>
            </tr></thead>
            <tbody>
            <?php foreach ($summary['by_method'] as $m): ?>
            <tr>
                <td><?= e($m['payment_method']) ?></td>
                <td class="text-end"><?= (int)$m['cnt'] ?></td>
                <td class="text-end">&#8377;<?= number_format($m['total'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Quick Actions -->
<div class="row g-3">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header"><strong>Quick Search — Collect Fee</strong></div>
            <div class="card-body">
                <div class="input-group">
                    <input type="text" id="quickSearch" class="form-control" placeholder="Search student by name or admission no...">
                    <button class="btn btn-primary" onclick="doSearch()"><i class="fas fa-search"></i></button>
                </div>
                <div id="searchResults" class="list-group mt-2"></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header"><strong>Quick Links</strong></div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <a href="fees/reportDaily?date=<?= date('Y-m-d') ?>" class="list-group-item list-group-item-action"><i class="fas fa-calendar-day text-primary me-2"></i>Daily Collection Report</a>
                    <a href="fees/reportOutstanding" class="list-group-item list-group-item-action"><i class="fas fa-exclamation-triangle text-danger me-2"></i>Outstanding Report</a>
                    <a href="fees/reportMonthly?month_year=<?= date('Y-m') ?>" class="list-group-item list-group-item-action"><i class="fas fa-calendar-alt text-info me-2"></i>Monthly Fee Report</a>
                    <a href="fees/discounts" class="list-group-item list-group-item-action"><i class="fas fa-percent text-success me-2"></i>Manage Discounts</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (Permission::check('fees.manage')): ?>
<!-- Session Lock/Unlock -->
<div class="card shadow-sm mt-4">
    <div class="card-header"><strong>Session Fee Lock</strong></div>
    <div class="card-body">
        <p class="text-muted small mb-2">Locking a session prevents any further fee collection or edits for that session.</p>
        <form method="post" action="fees/lockSession" class="d-inline me-2">
            <?= CSRF::field() ?>
            <input type="hidden" name="session_id" value="<?= $sessionId ?>">
            <button class="btn btn-warning btn-sm" onclick="return confirm('Lock this session?')"><i class="fas fa-lock"></i> Lock Current Session</button>
        </form>
        <form method="post" action="fees/unlockSession" class="d-inline">
            <?= CSRF::field() ?>
            <input type="hidden" name="session_id" value="<?= $sessionId ?>">
            <button class="btn btn-outline-secondary btn-sm" onclick="return confirm('Unlock this session?')"><i class="fas fa-unlock"></i> Unlock</button>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
let searchTimer;
document.getElementById('quickSearch').addEventListener('input', function(){
    clearTimeout(searchTimer);
    searchTimer = setTimeout(doSearch, 300);
});
function doSearch(){
    const q = document.getElementById('quickSearch').value.trim();
    if(q.length < 2){ document.getElementById('searchResults').innerHTML=''; return; }
    fetch('fees/searchStudents?q='+encodeURIComponent(q))
        .then(r=>r.json()).then(data=>{
            const el = document.getElementById('searchResults');
            if(!data.length){ el.innerHTML='<div class="list-group-item text-muted">No students found</div>'; return; }
            el.innerHTML = data.map(s=>
                `<a href="fees/collect?student_id=${s.id}" class="list-group-item list-group-item-action">
                    <strong>${s.name}</strong> <span class="badge bg-secondary">${s.admission_number}</span>
                    <small class="text-muted ms-2">${s.class_name}${s.section_name?' - '+s.section_name:''}</small>
                </a>`
            ).join('');
        });
}
</script>
