<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-university"></i> Bank Reconciliation</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('fees/bankReconciliation'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Date</label>
                <input type="date" name="date" class="form-control" value="<?php echo e($date); ?>">
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary-custom"><i class="fas fa-search"></i> View</button>
            </div>
        </form>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header"><h6 class="mb-0">Collections by Payment Method — <?php echo date('d M Y', strtotime($date)); ?></h6></div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Method</th><th class="text-center">Transactions</th><th class="text-end">Total Amount</th></tr>
            </thead>
            <tbody>
            <?php $grandTotal = 0; ?>
            <?php foreach ($byMethod as $row): $grandTotal += $row['total']; ?>
            <tr>
                <td><strong><?php echo e($row['method']); ?></strong></td>
                <td class="text-center"><?php echo $row['count']; ?></td>
                <td class="text-end"><?php echo formatCurrency($row['total']); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot class="table-light">
                <tr>
                    <td colspan="2"><strong>Grand Total</strong></td>
                    <td class="text-end"><strong><?php echo formatCurrency($grandTotal); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php if (!empty($pendingCheques)): ?>
<div class="card">
    <div class="card-header text-warning"><i class="fas fa-exclamation-triangle me-2"></i>Pending Cheques (post-dated)</div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Receipt No.</th><th>Cheque No.</th><th>Cheque Date</th><th class="text-end">Amount</th></tr>
            </thead>
            <tbody>
            <?php foreach ($pendingCheques as $ch): ?>
            <tr>
                <td><?php echo e($ch['receipt_number']); ?></td>
                <td><?php echo e($ch['cheque_number']); ?></td>
                <td><?php echo formatDate($ch['cheque_date']); ?></td>
                <td class="text-end"><?php echo formatCurrency($ch['total_amount']); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
