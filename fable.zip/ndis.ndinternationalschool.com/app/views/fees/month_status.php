<div class="page-header">
    <h4><i class="fas fa-calendar-check"></i> Month-wise Fee Status</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<!-- Student Selector -->
<div class="card mb-3">
  <div class="card-body">
    <form method="GET" action="<?php echo url('fees/monthStatus'); ?>" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Class</label>
        <select id="classFilter" class="form-select" onchange="loadStudents(this.value)">
          <option value="">All Classes</option>
          <?php foreach ($classes as $cls): ?>
            <option value="<?php echo $cls['id']; ?>"><?php echo e($cls['name']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-5">
        <label class="form-label">Student</label>
        <select name="student_id" id="studentSelect" class="form-select">
          <option value="">Select class first</option>
          <?php if ($student): ?>
            <option value="<?php echo $student['id']; ?>" selected>
              <?php echo e(trim($student['first_name'].' '.($student['last_name']??'')).' ('.$student['admission_number'].')'); ?>
            </option>
          <?php endif; ?>
        </select>
      </div>
      <div class="col-md-3">
        <button type="submit" class="btn btn-primary-custom w-100">
          <i class="fas fa-search me-1"></i>View Status
        </button>
      </div>
    </form>
  </div>
</div>

<?php if ($student && !empty($monthData)): ?>
<!-- Student header -->
<div class="alert alert-light border mb-3">
  <strong><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></strong>
  <span class="text-muted ms-2"><?php echo e($student['admission_number']); ?></span>
  <span class="badge bg-secondary ms-2"><?php echo e($student['class_name']??''); ?></span>
</div>

<!-- Legend -->
<div class="d-flex gap-3 mb-3 flex-wrap">
  <span><span class="badge bg-success px-2">⬤</span> Paid</span>
  <span><span class="badge bg-warning text-dark px-2">⬤</span> Partially Paid</span>
  <span><span class="badge bg-danger px-2">⬤</span> Pending</span>
  <span><span class="badge bg-info text-dark px-2">⬤</span> Advance</span>
</div>

<!-- Month grid -->
<div class="row g-3 mb-4">
  <?php foreach ($monthData as $my => $md):
      $color   = $md['status'] === 'Paid' ? 'success' : ($md['status'] === 'Partial' ? 'warning' : ($md['status'] === 'Advance' ? 'info' : 'danger'));
      $textCol = in_array($md['status'], ['Partial','Advance']) ? 'dark' : 'white';
      $icon    = $md['status'] === 'Paid' ? 'fa-check-circle' : ($md['status'] === 'Partial' ? 'fa-adjust' : ($md['status'] === 'Advance' ? 'fa-forward' : 'fa-times-circle'));
      $balance = $md['total_charged'] + $md['total_late_fee'] - $md['total_discount'] - $md['total_paid'];
  ?>
  <div class="col-6 col-md-3 col-lg-2">
    <div class="card border-<?php echo $color; ?> h-100 text-center"
         style="border-width:2px; cursor:pointer;"
         onclick="toggleDetail('detail-<?php echo str_replace('-','_',$my); ?>')">
      <div class="card-header bg-<?php echo $color; ?> text-<?php echo $textCol; ?> py-2">
        <i class="fas <?php echo $icon; ?> me-1"></i>
        <strong><?php echo e($md['label']); ?></strong>
      </div>
      <div class="card-body py-2 px-2">
        <div class="small">
          <div>Charged: <strong>₹<?php echo number_format($md['total_charged'],2); ?></strong></div>
          <div>Paid: <strong class="text-<?php echo $color; ?>">₹<?php echo number_format($md['total_paid'],2); ?></strong></div>
          <?php if ($balance > 0.004): ?>
          <div class="text-danger">Balance: ₹<?php echo number_format($balance,2); ?></div>
          <?php endif; ?>
          <?php if ($md['total_discount'] > 0): ?>
          <div class="text-success small">Disc: -₹<?php echo number_format($md['total_discount'],2); ?></div>
          <?php endif; ?>
        </div>
        <span class="badge bg-<?php echo $color; ?> text-<?php echo $textCol; ?> mt-1">
          <?php echo $md['status']; ?>
        </span>
      </div>
    </div>
    <!-- Expandable detail -->
    <div id="detail-<?php echo str_replace('-','_',$my); ?>" style="display:none;" class="mt-1">
      <?php if (!empty($md['categories'])): ?>
      <ul class="list-group list-group-flush" style="font-size:.78rem;">
        <?php foreach ($md['categories'] as $cat): ?>
        <li class="list-group-item px-2 py-1">
          <?php echo e($cat['category_name']??'Fee'); ?>:
          <span class="float-end">₹<?php echo number_format($cat['paid_amount'],2); ?>
            <span class="text-muted">/ ₹<?php echo number_format($cat['charged_amount'],2); ?></span>
          </span>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
      <?php if ($md['status'] !== 'Paid'): ?>
      <a href="<?php echo url('fees/collect?student_id='.$studentId); ?>"
         class="btn btn-xs btn-<?php echo $color; ?> w-100 mt-1">
        <i class="fas fa-rupee-sign me-1"></i>Collect
      </a>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Summary Table -->
<div class="card">
  <div class="card-header"><h6 class="mb-0">Annual Summary</h6></div>
  <div class="table-responsive">
    <table class="table table-sm table-bordered mb-0">
      <thead class="table-light">
        <tr><th>Month</th><th class="text-end">Charged</th><th class="text-end">Late Fee</th>
            <th class="text-end">Discount</th><th class="text-end">Paid</th>
            <th class="text-end">Balance</th><th>Status</th></tr>
      </thead>
      <tbody>
      <?php
      $totC=$totL=$totD=$totP=$totB=0;
      foreach ($monthData as $my => $md):
          $bal = $md['total_charged']+$md['total_late_fee']-$md['total_discount']-$md['total_paid'];
          $totC+=$md['total_charged']; $totL+=$md['total_late_fee'];
          $totD+=$md['total_discount']; $totP+=$md['total_paid']; $totB+=max(0,$bal);
          $color = $md['status']==='Paid'?'success':($md['status']==='Partial'?'warning':($md['status']==='Advance'?'info':'danger'));
      ?>
        <tr>
          <td><?php echo e($md['label']); ?></td>
          <td class="text-end">₹<?php echo number_format($md['total_charged'],2); ?></td>
          <td class="text-end"><?php echo $md['total_late_fee']>0?'₹'.number_format($md['total_late_fee'],2):'—'; ?></td>
          <td class="text-end text-success"><?php echo $md['total_discount']>0?'-₹'.number_format($md['total_discount'],2):'—'; ?></td>
          <td class="text-end fw-semibold">₹<?php echo number_format($md['total_paid'],2); ?></td>
          <td class="text-end <?php echo $bal>0?'text-danger':'text-success'; ?>">
            <?php echo $bal>0?'₹'.number_format($bal,2):'Paid'; ?>
          </td>
          <td><span class="badge bg-<?php echo $color; ?>"><?php echo $md['status']; ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot class="table-light fw-bold">
        <tr>
          <td>Total</td>
          <td class="text-end">₹<?php echo number_format($totC,2); ?></td>
          <td class="text-end">₹<?php echo number_format($totL,2); ?></td>
          <td class="text-end text-success">-₹<?php echo number_format($totD,2); ?></td>
          <td class="text-end">₹<?php echo number_format($totP,2); ?></td>
          <td class="text-end text-danger">₹<?php echo number_format($totB,2); ?></td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<script>
function toggleDetail(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = el.style.display === 'none' ? '' : 'none';
}
function loadStudents(classId) {
    const sel = document.getElementById('studentSelect');
    sel.innerHTML = '<option>Loading…</option>';
    if (!classId) { sel.innerHTML = '<option value="">Select class first</option>'; return; }
    fetch('<?php echo url('fees/studentsByClass'); ?>?class_id=' + classId)
        .then(r => r.json())
        .then(students => {
            sel.innerHTML = '<option value="">— Select Student —</option>';
            students.forEach(s => {
                const o = document.createElement('option');
                o.value = s.id; o.textContent = s.name;
                sel.appendChild(o);
            });
        });
}
</script>

<?php elseif ($studentId): ?>
<div class="alert alert-info">No month data found for this student. Fee collection data will appear here once payments are recorded.</div>
<?php else: ?>
<div class="alert alert-secondary">Select a student above to view their month-wise fee status.</div>
<?php endif; ?>
