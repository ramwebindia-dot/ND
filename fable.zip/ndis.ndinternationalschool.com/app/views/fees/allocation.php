<div class="page-header">
    <h4><i class="fas fa-tags"></i> Fee Allocation</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#allocationModal">
        <i class="fas fa-plus me-1"></i>Add Allocation
    </button>
</div>

<div class="alert alert-info mb-3">
    <i class="fas fa-info-circle me-1"></i>
    Set fixed fees per class and fee type. These amounts auto-fill during fee collection.
</div>

<!-- Filter by class -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('fees/allocation'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1">Filter by Class</label>
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $class['id']) ? 'selected' : ''; ?>>
                            <?php echo e($class['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-filter me-1"></i>Filter</button>
                <a href="<?php echo url('fees/allocation'); ?>" class="btn btn-outline-secondary ms-1">Clear</a>
            </div>
        </form>
    </div>
</div>

<!-- Allocation Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Class</th>
                        <th>Fee Type</th>
                        <th>Fixed Amount</th>
                        <th>Mandatory</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($allocations)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-tags fa-2x mb-2 d-block opacity-50"></i>
                            No fee allocations found. Click "Add Allocation" to get started.
                        </td></tr>
                    <?php else: ?>
                        <?php foreach ($allocations as $i => $a): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><span class="badge bg-primary"><?php echo e($a['class_name'] ?? '-'); ?></span></td>
                            <td><?php echo e($a['category_name'] ?? '-'); ?></td>
                            <td><strong class="text-success"><?php echo formatCurrency($a['amount']); ?></strong></td>
                            <td>
                                <?php if ($a['is_mandatory'] ?? 0): ?>
                                    <span class="badge badge-success-custom">Mandatory</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Optional</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-info edit-allocation"
                                    data-id="<?php echo $a['id']; ?>"
                                    data-class="<?php echo $a['class_id']; ?>"
                                    data-category="<?php echo $a['fee_category_id']; ?>"
                                    data-amount="<?php echo $a['amount']; ?>"
                                    title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" action="<?php echo url('fees/deleteAllocation'); ?>" class="d-inline" onsubmit="return confirm('Delete this allocation?')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Allocation Modal -->
<div class="modal fade" id="allocationModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('fees/saveAllocation'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="alloc_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title" id="allocModalLabel">Add Fee Allocation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" id="alloc_class" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>"><?php echo e($class['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fee Type <span class="text-danger">*</span></label>
                        <select name="fee_category_id" id="alloc_category" class="form-select" required>
                            <option value="">Select Fee Type</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo e($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">
                            <a href="<?php echo url('fees/heads'); ?>">Manage fee types</a>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fixed Amount <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">₹</span>
                            <input type="number" name="amount" id="alloc_amount" class="form-control" step="0.01" min="0" required placeholder="0.00">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Allocation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-allocation').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('alloc_id').value = this.dataset.id;
        document.getElementById('alloc_class').value = this.dataset.class;
        document.getElementById('alloc_category').value = this.dataset.category;
        document.getElementById('alloc_amount').value = this.dataset.amount;
        document.getElementById('allocModalLabel').textContent = 'Edit Fee Allocation';
        new bootstrap.Modal(document.getElementById('allocationModal')).show();
    });
});
document.getElementById('allocationModal').addEventListener('hidden.bs.modal', function() {
    document.getElementById('alloc_id').value = '';
    document.getElementById('alloc_class').value = '';
    document.getElementById('alloc_category').value = '';
    document.getElementById('alloc_amount').value = '';
    document.getElementById('allocModalLabel').textContent = 'Add Fee Allocation';
});
</script>
