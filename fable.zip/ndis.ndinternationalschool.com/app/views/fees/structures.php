<?php $pageTitle = 'Fee Structure'; ?>
<div class="page-header">
    <h4><i class="fas fa-table"></i> Fee Structure</h4>
    <?php if (Permission::check('fees.manage')): ?>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#structureModal" onclick="resetForm()">
        <i class="fas fa-plus"></i> Add Structure
    </button>
    <?php endif; ?>
</div>

<!-- Session Filter -->
<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="get" action="fees/structures" class="row g-2 align-items-center">
            <div class="col-auto">
                <label class="col-form-label fw-semibold">Session:</label>
            </div>
            <div class="col-auto">
                <select name="session_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Class</th>
                    <th>Fee Head</th>
                    <th>Type</th>
                    <th>Frequency</th>
                    <th class="text-end">Amount (&#8377;)</th>
                    <?php if (Permission::check('fees.manage')): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php $lastClass = ''; foreach ($structures as $s): ?>
            <?php if ($s['class_name'] !== $lastClass): ?>
            <tr class="table-secondary"><td colspan="6"><strong><?= e($s['class_name']) ?></strong></td></tr>
            <?php $lastClass = $s['class_name']; endif; ?>
            <tr>
                <td class="ps-4 text-muted small"><?= e($s['class_name']) ?></td>
                <td><?= e($s['head_name']) ?></td>
                <td><span class="badge bg-light text-dark border small"><?= e($s['head_type']) ?></span></td>
                <td><?= e($s['frequency']) ?></td>
                <td class="text-end fw-semibold">&#8377;<?= number_format((float)$s['amount'], 2) ?></td>
                <?php if (Permission::check('fees.manage')): ?>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editStructure(<?= htmlspecialchars(json_encode($s), ENT_QUOTES) ?>)">
                        <i class="fas fa-edit"></i>
                    </button>
                    <form method="post" action="fees/deleteStructure" class="d-inline" onsubmit="return confirm('Delete this structure?')">
                        <?= CSRF::field() ?>
                        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($structures)): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No fee structures defined for this session.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if (Permission::check('fees.manage')): ?>
<div class="modal fade" id="structureModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="fees/saveStructure">
            <?= CSRF::field() ?>
            <input type="hidden" name="session_id" value="<?= (int)$sessId ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="structModalTitle">Add Fee Structure</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="structId">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" id="structClass" class="form-select" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fee Head <span class="text-danger">*</span></label>
                        <select name="fee_category_id" id="structHead" class="form-select" required>
                            <option value="">-- Select Fee Head --</option>
                            <?php foreach ($heads as $h): ?>
                            <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Amount (&#8377;) <span class="text-danger">*</span></label>
                        <input type="number" name="amount" id="structAmount" class="form-control" step="0.01" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Frequency</label>
                        <select name="frequency" id="structFreq" class="form-select">
                            <option value="Monthly">Monthly</option>
                            <option value="Quarterly">Quarterly</option>
                            <option value="Half Yearly">Half Yearly</option>
                            <option value="Yearly">Yearly (One-time)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
function resetForm(){
    document.getElementById('structId').value='';
    document.getElementById('structClass').value='';
    document.getElementById('structHead').value='';
    document.getElementById('structAmount').value='';
    document.getElementById('structFreq').value='Monthly';
    document.getElementById('structModalTitle').textContent='Add Fee Structure';
}
function editStructure(s){
    document.getElementById('structId').value=s.id;
    document.getElementById('structClass').value=s.class_id;
    document.getElementById('structHead').value=s.fee_category_id;
    document.getElementById('structAmount').value=s.amount;
    document.getElementById('structFreq').value=s.frequency;
    document.getElementById('structModalTitle').textContent='Edit Fee Structure';
    new bootstrap.Modal(document.getElementById('structureModal')).show();
}
</script>
<?php endif; ?>
