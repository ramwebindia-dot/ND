<?php $pageTitle = 'Refund Report'; ?>
<div class="page-header">
    <h4><i class="fas fa-undo"></i> Refund Report</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/reports" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="card shadow-sm mb-3 d-print-none">
    <div class="card-body py-2">
        <form method="get" action="fees/reportRefunds" class="row g-2 align-items-center">
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">View</button></div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Class</th>
                    <th class="text-end">Amount</th>
                    <th>Reason</th>
                    <th>Mode</th>
                    <th>Date</th>
                    <th>Approved By</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $i => $r): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= e($r['student_name']) ?> <small class="text-muted">(<?= e($r['admission_number']) ?>)</small></td>
                <td class="small"><?= e($r['class_name']) ?></td>
                <td class="text-end fw-semibold">&#8377;<?= number_format((float)$r['amount'],2) ?></td>
                <td class="small"><?= e($r['reason'] ?? '-') ?></td>
                <td class="small"><?= e($r['refund_method'] ?? 'Cash') ?></td>
                <td class="small"><?= $r['processed_at'] ? date('d/m/Y',strtotime($r['processed_at'])) : '-' ?></td>
                <td class="small"><?= e($r['approved_by_name'] ?? '-') ?></td>
                <td class="text-center">
                    <?php $rsc = ($r['status']==='Processed'?'success':($r['status']==='Approved'?'info':($r['status']==='Rejected'?'danger':'warning'))); ?>
                    <span class="badge bg-<?= $rsc ?>">
                        <?= e($r['status'] ?? 'Pending') ?>
                    </span>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($data)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No refunds found.</td></tr>
            <?php endif; ?>
            </tbody>
            <?php if (!empty($data)): ?>
            <tfoot class="table-light">
                <tr>
                    <th colspan="3" class="text-end">Total Refunded:</th>
                    <th class="text-end">&#8377;<?= number_format(array_sum(array_map(fn($r)=>(float)($r['amount']??0), array_filter($data,fn($r)=>($r['status']??'')==='Processed'))),2) ?></th>
                    <th colspan="5"></th>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
