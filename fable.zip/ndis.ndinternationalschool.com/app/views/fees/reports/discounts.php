<?php $pageTitle = 'Discount Report'; ?>
<div class="page-header">
    <h4><i class="fas fa-percent"></i> Fee Discount Report</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/reports" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="card shadow-sm mb-3 d-print-none">
    <div class="card-body py-2">
        <form method="get" action="fees/reportDiscounts" class="row g-2 align-items-center">
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">View</button></div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Class</th>
                    <th>Type</th>
                    <th>Fee Head</th>
                    <th class="text-end">Value</th>
                    <th>Reason</th>
                    <th>Valid</th>
                    <th>Approved By</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $i => $d): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= e($d['student_name']) ?> <small class="text-muted">(<?= e($d['admission_number']) ?>)</small></td>
                <td class="small"><?= e($d['class_name']) ?></td>
                <td><span class="badge bg-info text-dark small"><?= e($d['discount_type']) ?></span></td>
                <td class="small"><?= $d['fee_category_id'] ? e($d['head_name']) : '<span class="text-muted">All</span>' ?></td>
                <td class="text-end fw-semibold">
                    <?= $d['discount_type']==='Percentage' ? number_format((float)$d['discount_value'],2).'%' : '&#8377;'.number_format((float)$d['discount_value'],2) ?>
                </td>
                <td class="small"><?= e($d['reason'] ?? '-') ?></td>
                <td class="small">
                    <?= $d['valid_from'] ? date('d/m/Y',strtotime($d['valid_from'])) : '-' ?>
                    <?= $d['valid_until'] ? ' to '.date('d/m/Y',strtotime($d['valid_until'])) : '' ?>
                </td>
                <td class="small"><?= e($d['approved_by_name'] ?? '-') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($data)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No discounts found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
