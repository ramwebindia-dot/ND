<?php $pageTitle = 'Fee Reports'; ?>
<div class="page-header">
    <h4><i class="fas fa-chart-bar"></i> Fee Reports</h4>
    <a href="fees" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body text-center py-4">
                <i class="fas fa-calendar-day fa-3x text-primary mb-3"></i>
                <h5>Daily Collection Report</h5>
                <p class="text-muted small">View all payments collected on a specific date with payment mode summary.</p>
                <a href="fees/reportDaily?date=<?= date('Y-m-d') ?>&session_id=<?= $sessionId ?>" class="btn btn-primary btn-sm">View Report</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body text-center py-4">
                <i class="fas fa-calendar-alt fa-3x text-info mb-3"></i>
                <h5>Monthly Fee Report</h5>
                <p class="text-muted small">Month-wise fee collection by student and fee head.</p>
                <a href="fees/reportMonthly?month_year=<?= date('Y-m') ?>&session_id=<?= $sessionId ?>" class="btn btn-info btn-sm">View Report</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body text-center py-4">
                <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                <h5>Outstanding Report</h5>
                <p class="text-muted small">List of students with pending fee dues, class-wise.</p>
                <a href="fees/reportOutstanding?session_id=<?= $sessionId ?>" class="btn btn-danger btn-sm">View Report</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body text-center py-4">
                <i class="fas fa-percent fa-3x text-success mb-3"></i>
                <h5>Discount Report</h5>
                <p class="text-muted small">All active discounts granted to students this session.</p>
                <a href="fees/reportDiscounts?session_id=<?= $sessionId ?>" class="btn btn-success btn-sm">View Report</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body text-center py-4">
                <i class="fas fa-undo fa-3x text-warning mb-3"></i>
                <h5>Refund Report</h5>
                <p class="text-muted small">All refunds processed or pending for this session.</p>
                <a href="fees/reportRefunds?session_id=<?= $sessionId ?>" class="btn btn-warning btn-sm">View Report</a>
            </div>
        </div>
    </div>
</div>
