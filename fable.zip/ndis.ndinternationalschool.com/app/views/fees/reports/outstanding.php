<?php $pageTitle = 'Outstanding Fee Report'; ?>
<div class="page-header">
    <h4><i class="fas fa-exclamation-triangle"></i> Outstanding Fee Report</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/reports" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="card shadow-sm mb-3 d-print-none">
    <div class="card-body py-2">
        <form method="get" action="fees/reportOutstanding" class="row g-2 align-items-center">
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="class_id" class="form-select form-select-sm">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $classId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">View</button></div>
        </form>
    </div>
</div>

<?php
$grandDue = array_sum(array_column($data,'total_due'));
$grandPaid = array_sum(array_column($data,'total_paid'));
$grandOut = array_sum(array_column($data,'outstanding'));
?>
<div class="row g-3 mb-3">
    <div class="col-md-3 col-6">
        <div class="card border-0 bg-info text-white shadow-sm text-center p-3">
            <div class="small">Total Students</div>
            <h4 class="mb-0"><?= count($data) ?></h4>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 bg-primary text-white shadow-sm text-center p-3">
            <div class="small">Total Billed</div>
            <h5 class="mb-0">&#8377;<?= number_format($grandDue,2) ?></h5>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 bg-success text-white shadow-sm text-center p-3">
            <div class="small">Total Paid</div>
            <h5 class="mb-0">&#8377;<?= number_format($grandPaid,2) ?></h5>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="card border-0 bg-danger text-white shadow-sm text-center p-3">
            <div class="small">Total Outstanding</div>
            <h5 class="mb-0">&#8377;<?= number_format($grandOut,2) ?></h5>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Adm. No.</th>
                    <th>Class</th>
                    <th class="text-end">Total Due</th>
                    <th class="text-end">Paid</th>
                    <th class="text-end text-danger">Outstanding</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $i => $row): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= e($row['student_name']) ?></td>
                <td class="small"><?= e($row['admission_number']) ?></td>
                <td class="small"><?= e($row['class_name']) ?><?= $row['section_name']?' - '.e($row['section_name']):'' ?></td>
                <td class="text-end">&#8377;<?= number_format((float)$row['total_due'],2) ?></td>
                <td class="text-end text-success">&#8377;<?= number_format((float)$row['total_paid'],2) ?></td>
                <td class="text-end text-danger fw-bold">&#8377;<?= number_format((float)$row['outstanding'],2) ?></td>
                <td>
                    <a href="fees/collect?student_id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-success d-print-none">
                        <i class="fas fa-rupee-sign"></i> Collect
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($data)): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">No outstanding fees found.</td></tr>
            <?php endif; ?>
            </tbody>
            <tfoot class="table-light">
                <tr>
                    <th colspan="4" class="text-end">Total:</th>
                    <th class="text-end">&#8377;<?= number_format($grandDue,2) ?></th>
                    <th class="text-end text-success">&#8377;<?= number_format($grandPaid,2) ?></th>
                    <th class="text-end text-danger">&#8377;<?= number_format($grandOut,2) ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
