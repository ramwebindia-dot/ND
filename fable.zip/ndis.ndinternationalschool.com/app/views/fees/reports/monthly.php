<?php $pageTitle = 'Monthly Fee Report'; ?>
<div class="page-header">
    <h4><i class="fas fa-calendar-alt"></i> Monthly Fee Report</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/reports" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="card shadow-sm mb-3 d-print-none">
    <div class="card-body py-2">
        <form method="get" action="fees/reportMonthly" class="row g-2 align-items-center">
            <div class="col-md-2">
                <input type="month" name="month_year" class="form-control form-control-sm" value="<?= e($monthYear) ?>">
            </div>
            <div class="col-md-3">
                <select name="class_id" class="form-select form-select-sm">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $classId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">View</button></div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header"><strong>Fee Collection — <?= date('F Y', strtotime($monthYear.'-01')) ?></strong></div>
    <div class="card-body p-0">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Class</th>
                    <th>Fee Head</th>
                    <th class="text-end">Charged</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Late Fee</th>
                    <th class="text-end">Paid</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($data)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No fee data for this month.</td></tr>
            <?php endif; ?>
            <?php foreach ($data as $i => $row): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= e($row['student_name']) ?> <small class="text-muted">(<?= e($row['admission_number']) ?>)</small></td>
                <td class="small"><?= e($row['class_name']) ?></td>
                <td class="small"><?= e($row['head_name'] ?? 'General') ?></td>
                <td class="text-end small">&#8377;<?= number_format((float)$row['charged'],2) ?></td>
                <td class="text-end small text-success"><?= $row['discount']>0?'-&#8377;'.number_format((float)$row['discount'],2):'-' ?></td>
                <td class="text-end small text-danger"><?= $row['late_fee']>0?'+&#8377;'.number_format((float)$row['late_fee'],2):'-' ?></td>
                <td class="text-end small fw-semibold">&#8377;<?= number_format((float)$row['paid'],2) ?></td>
                <td class="text-center">
                    <?php $msc = ($row['status']==='Paid'?'success':($row['status']==='Partial'?'warning':($row['status']==='Advance'?'info':'danger'))); ?>
                    <span class="badge bg-<?= $msc ?> small">
                        <?= e($row['status'] ?? 'Pending') ?>
                    </span>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <?php if (!empty($data)): ?>
            <tfoot class="table-light">
                <tr>
                    <th colspan="4" class="text-end">Total:</th>
                    <th class="text-end">&#8377;<?= number_format(array_sum(array_column($data,'charged')),2) ?></th>
                    <th class="text-end text-success">-&#8377;<?= number_format(array_sum(array_column($data,'discount')),2) ?></th>
                    <th class="text-end text-danger">+&#8377;<?= number_format(array_sum(array_column($data,'late_fee')),2) ?></th>
                    <th class="text-end fw-bold">&#8377;<?= number_format(array_sum(array_column($data,'paid')),2) ?></th>
                    <th></th>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>
