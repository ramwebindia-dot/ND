<?php $pageTitle = 'Daily Collection Report'; ?>
<div class="page-header">
    <h4><i class="fas fa-calendar-day"></i> Daily Collection Report</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/reports" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
</div>

<!-- Filter -->
<div class="card shadow-sm mb-3 d-print-none">
    <div class="card-body py-2">
        <form method="get" action="fees/reportDaily" class="row g-2 align-items-center">
            <div class="col-md-3">
                <input type="date" name="date" class="form-control form-control-sm" value="<?= e($date) ?>">
            </div>
            <div class="col-md-3">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">View</button></div>
        </form>
    </div>
</div>

<?php $receipts = $data['receipts']; $summary = $data['summary']; ?>

<!-- Summary -->
<div class="row g-3 mb-3">
    <?php $grandTotal = array_sum(array_column($summary,'total')); ?>
    <div class="col-md-3">
        <div class="card border-0 bg-success text-white shadow-sm text-center p-3">
            <div class="small">Total Collection</div>
            <h4 class="mb-0">&#8377;<?= number_format($grandTotal,2) ?></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 bg-info text-white shadow-sm text-center p-3">
            <div class="small">Total Receipts</div>
            <h4 class="mb-0"><?= count($receipts) ?></h4>
        </div>
    </div>
    <?php foreach ($summary as $sm): ?>
    <div class="col-md-3">
        <div class="card border shadow-sm text-center p-3">
            <div class="small text-muted"><?= e($sm['payment_method']) ?></div>
            <div class="fw-semibold">&#8377;<?= number_format($sm['total'],2) ?> <span class="text-muted small">(<?= $sm['cnt'] ?>)</span></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<div class="card shadow-sm">
    <div class="card-header"><strong>Collection on <?= date('d F Y', strtotime($date)) ?></strong></div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Receipt No.</th>
                    <th>Students</th>
                    <th>Mode</th>
                    <th class="text-end">Amount</th>
                    <th>Collected By</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($receipts)): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No collection recorded for this date.</td></tr>
            <?php endif; ?>
            <?php foreach ($receipts as $i => $r): ?>
            <tr class="<?= $r['status']==='Cancelled'?'table-secondary text-muted':'' ?>">
                <td><?= $i+1 ?></td>
                <td><a href="fees/receipt?id=<?= $r['id'] ?>" class="fw-semibold"><?= e($r['receipt_number']) ?></a></td>
                <td class="small"><?= e($r['student_names']) ?></td>
                <td><?= e($r['payment_method']) ?></td>
                <td class="text-end fw-semibold">&#8377;<?= number_format((float)$r['total_amount'],2) ?></td>
                <td class="small"><?= e($r['collected_by_name'] ?? '') ?></td>
                <td><span class="badge bg-<?= $r['status']==='Active'?'success':'danger' ?>"><?= e($r['status']) ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot class="table-light">
                <tr>
                    <th colspan="4" class="text-end">Grand Total:</th>
                    <th class="text-end">&#8377;<?= number_format($grandTotal,2) ?></th>
                    <th colspan="2"></th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
