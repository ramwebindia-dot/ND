<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-balance-scale"></i> Fee Reconciliation</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('fees/reconciliation'); ?>" class="mb-3">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'] ?? ''; ?>">
    <button class="btn btn-primary-custom">
        <i class="fas fa-play me-1"></i>Run Reconciliation Now
    </button>
</form>

<?php if ($result): ?>
<div class="card mb-3 border-<?php echo $result['status'] === 'OK' ? 'success' : 'danger'; ?>">
    <div class="card-header bg-<?php echo $result['status'] === 'OK' ? 'success' : 'danger'; ?> text-white">
        <strong><i class="fas fa-<?php echo $result['status'] === 'OK' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
        <?php echo $result['status'] === 'OK' ? 'Reconciliation Passed — Items match Transaction Headers' : 'MISMATCH — Items total does not match Transaction Headers total'; ?></strong>
        <div class="small mt-1 opacity-75">Checks: SUM(fee_payment_items.paid_amount) = SUM(fee_payment_transactions.total_amount)</div>
    </div>
    <div class="card-body">
        <div class="row">
            <?php
            $items = [
                ['Total Charged (Items)',   $result['total_charged'],      'info'],
                ['Total Paid (Items)',      $result['total_paid'],         'success'],
                ['Total Discounts',        $result['total_discount'],     'warning'],
                ['Late Fees',              $result['total_late_fee'],     'secondary'],
                ['Total Refunds',          $result['total_refund'],       'danger'],
                ['Outstanding Balance',    $result['calc_outstanding'],   'primary'],
                ['Txn Headers Total',      $result['ledger_outstanding'], 'dark'],
                ['Items vs Headers Diff',  $result['mismatch'],           $result['mismatch'] > 0 ? 'danger' : 'success'],
            ];
            foreach ($items as [$label, $val, $col]):
            ?>
            <div class="col-md-3 mb-2">
                <div class="card border-<?php echo $col; ?> text-center">
                    <div class="card-body py-2">
                        <small class="text-muted"><?php echo $label; ?></small>
                        <div class="fw-bold"><?php echo formatCurrency($val); ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h6 class="mb-0">Reconciliation History</h6></div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Date</th><th>Run By</th><th class="text-end">Outstanding Balance</th><th class="text-end">Txn Headers Total</th><th class="text-end">Items vs Headers Diff</th><th>Status</th></tr>
            </thead>
            <tbody>
            <?php foreach ($history as $h): ?>
            <tr class="<?php echo $h['status'] === 'Mismatch' ? 'table-danger' : ''; ?>">
                <td><?php echo formatDate($h['run_date']); ?></td>
                <td><?php echo e($h['run_by_name'] ?? 'System'); ?></td>
                <td class="text-end"><?php echo formatCurrency($h['calc_outstanding']); ?></td>
                <td class="text-end"><?php echo formatCurrency($h['ledger_outstanding']); ?></td>
                <td class="text-end <?php echo $h['mismatch'] > 0 ? 'text-danger fw-bold' : ''; ?>">
                    <?php echo $h['mismatch'] > 0 ? formatCurrency($h['mismatch']) : '—'; ?>
                </td>
                <td><span class="badge bg-<?php echo $h['status'] === 'OK' ? 'success' : 'danger'; ?>"><?php echo $h['status']; ?></span></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($history)): ?>
            <tr><td colspan="6" class="text-center text-muted py-3">No reconciliation runs yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
