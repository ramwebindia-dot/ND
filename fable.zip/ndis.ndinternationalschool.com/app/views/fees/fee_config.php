<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-cog"></i> Fee Configuration</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row">
<div class="col-lg-7">
<div class="card mb-4">
    <div class="card-header"><h6 class="mb-0">Fee Module Settings</h6></div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('fees/saveFeeConfig'); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

            <?php
            $checks = [
                'fee_allow_advance_payment'    => ['Allow Advance Payments', 'Parents can pay fees for future months'],
                'fee_allow_skip_older_dues'    => ['Allow Skipping Older Dues', 'Allow payment for newer months when older months are pending'],
                'fee_auto_allocate'            => ['Auto-Allocate to Oldest Dues', 'Automatically distribute payment to oldest pending dues first'],
                'fee_enable_late_fees'         => ['Enable Late Fees', 'Apply late fee rules to overdue payments'],
                'fee_enable_transport'         => ['Enable Transport Fees', 'Show transport fee options during collection'],
                'fee_receipt_reset_per_session'=> ['Reset Receipt Numbering Per Session', 'Receipt numbers are unique within each academic session only'],
                'fee_require_payment_confirm'  => ['Require Payment Confirmation', 'Show preview screen before saving payment'],
                'fee_require_cancel_reason'    => ['Require Cancellation Reason', 'Mandatory reason when cancelling a receipt'],
                'fee_warn_older_dues'          => ['Warn on Older Pending Dues', 'Alert cashier if older months are unpaid when collecting newer months'],
            ];
            foreach ($checks as $key => [$label, $desc]):
                $val = $settings[$key] ?? '0';
            ?>
            <div class="mb-3 d-flex justify-content-between align-items-start">
                <div>
                    <div class="fw-semibold"><?php echo $label; ?></div>
                    <small class="text-muted"><?php echo $desc; ?></small>
                </div>
                <div class="form-check form-switch ms-3">
                    <input class="form-check-input" type="checkbox" name="<?php echo $key; ?>"
                           id="<?php echo $key; ?>" <?php echo $val === '1' ? 'checked' : ''; ?>>
                </div>
            </div>
            <?php endforeach; ?>

            <hr>
            <button type="submit" class="btn btn-primary-custom">
                <i class="fas fa-save me-1"></i>Save Configuration
            </button>
        </form>
    </div>
</div>
</div>

<div class="col-lg-5">
<div class="card">
    <div class="card-header"><h6 class="mb-0"><i class="fas fa-lock me-2"></i>Session Locking</h6></div>
    <div class="card-body">
        <p class="text-muted small">Locked sessions become read-only. No fee modifications, receipts, cancellations or refunds are allowed.</p>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead class="table-light">
                    <tr><th>Session</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                <?php foreach ($sessions as $sess): ?>
                <tr>
                    <td><?php echo e($sess['name']); ?></td>
                    <td>
                        <?php if ($sess['is_fee_locked']): ?>
                            <span class="badge bg-danger"><i class="fas fa-lock me-1"></i>Locked</span>
                        <?php else: ?>
                            <span class="badge bg-success"><i class="fas fa-unlock me-1"></i>Open</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($sess['is_fee_locked']): ?>
                        <form method="POST" action="<?php echo url('fees/unlockSession'); ?>" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="session_id" value="<?php echo $sess['id']; ?>">
                            <button class="btn btn-xs btn-warning" onclick="return confirm('Unlock this session?')">
                                <i class="fas fa-unlock"></i> Unlock
                            </button>
                        </form>
                        <?php else: ?>
                        <form method="POST" action="<?php echo url('fees/lockSession'); ?>" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="session_id" value="<?php echo $sess['id']; ?>">
                            <button class="btn btn-xs btn-danger" onclick="return confirm('Lock this session? No fee changes will be allowed.')">
                                <i class="fas fa-lock"></i> Lock
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>
<style>.btn-xs{padding:.15rem .4rem;font-size:.7rem}</style>
