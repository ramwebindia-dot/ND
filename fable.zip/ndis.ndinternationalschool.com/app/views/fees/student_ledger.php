<div class="page-header">
    <h4><i class="fas fa-book-open"></i> Student Fee Ledger</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<div class="card mb-3">
  <div class="card-body">
    <form method="GET" action="<?php echo url('fees/studentLedger'); ?>" class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Class</label>
        <select id="classFilter" class="form-select" onchange="loadStudents(this.value)">
          <option value="">Select Class</option>
          <?php foreach ($classes as $cls): ?>
            <option value="<?php echo $cls['id']; ?>"><?php echo e($cls['name']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-5">
        <label class="form-label">Student</label>
        <select name="student_id" id="studentSelect" class="form-select">
          <option value="">Select class first</option>
          <?php if ($student): ?>
            <option value="<?php echo $student['id']; ?>" selected>
              <?php echo e(trim($student['first_name'].' '.($student['last_name']??'')).' ('.$student['admission_number'].')'); ?>
            </option>
          <?php endif; ?>
        </select>
      </div>
      <div class="col-md-3">
        <button type="submit" class="btn btn-primary-custom w-100">
          <i class="fas fa-search me-1"></i>View Ledger
        </button>
      </div>
    </form>
  </div>
</div>

<?php if ($student && !empty($ledger)): ?>
<div class="row mb-3">
  <div class="col-md-6">
    <div class="alert alert-light border mb-0">
      <strong><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></strong>
      <span class="text-muted ms-2"><?php echo e($student['admission_number']); ?></span>
      <span class="badge bg-secondary ms-2"><?php echo e($student['class_name']??''); ?></span>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-center <?php echo $outstanding > 0 ? 'bg-danger text-white' : 'bg-success text-white'; ?>">
      <div class="card-body py-2">
        <small class="d-block">Total Outstanding</small>
        <strong class="fs-5"><?php echo formatCurrency($outstanding ?? 0); ?></strong>
      </div>
    </div>
  </div>
  <div class="col-md-3 text-end d-flex align-items-center justify-content-end gap-2">
    <?php if (($outstanding ?? 0) > 0): ?>
    <a href="<?php echo url('fees/collect?student_id='.$student['id']); ?>" class="btn btn-primary-custom btn-sm">
      <i class="fas fa-rupee-sign me-1"></i>Collect Now
    </a>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between">
    <h6 class="mb-0">Immutable Fee Ledger</h6>
    <button onclick="window.print()" class="btn btn-sm btn-outline-secondary no-print">
      <i class="fas fa-print me-1"></i>Print
    </button>
  </div>
  <div class="table-responsive">
    <table class="table table-sm table-bordered mb-0">
      <thead class="table-light">
        <tr>
          <th>#</th><th>Date</th><th>Type</th><th>Fee Category</th>
          <th>Month</th><th>Description</th>
          <th class="text-end text-danger">Debit<br><small class="fw-normal">(charges/late fee)</small></th>
          <th class="text-end text-success">Credit<br><small class="fw-normal">(payment/discount)</small></th>
          <th class="text-end">Balance</th>
        </tr>
      </thead>
      <tbody>
      <?php
      $i = 1; $runningBalance = 0;
      $typeColors = [
          'Charge'       => 'danger',   'Payment'      => 'success',
          'Discount'     => 'success',  'LateFee'      => 'warning',
          'Refund'       => 'info',     'Adjustment'   => 'secondary',
          'Cancellation' => 'dark',
      ];
      foreach ($ledger as $entry):
          $amt     = (float)$entry['amount'];
          $color   = $typeColors[$entry['entry_type']] ?? 'secondary';
          // positive amount = debit (increases outstanding), negative = credit (reduces outstanding)
          $isDebit = $amt > 0;
          $display = abs($amt);
          $runningBalance += $amt; // running balance: positive = owe money
          $dt = new DateTime($entry['created_at']);
      ?>
        <tr class="<?php echo ($entry['entry_type'] === 'Payment' && $amt < 0 && abs($amt) < $display) ? 'table-warning' : ''; ?>">
          <td class="text-muted small"><?php echo $i++; ?></td>
          <td class="small"><?php echo $dt->format('d/m/Y'); ?></td>
          <td><span class="badge bg-<?php echo $color; ?>"><?php echo e($entry['entry_type']); ?></span></td>
          <td class="small"><?php echo e($entry['category_name'] ?? '—'); ?></td>
          <td class="small text-muted">
            <?php if (!empty($entry['month_year'])):
                $ml = DateTime::createFromFormat('Y-m', $entry['month_year']);
                echo $ml ? $ml->format('M Y') : $entry['month_year'];
            else: echo '—'; endif; ?>
          </td>
          <td class="small"><?php echo e($entry['description'] ?? ''); ?></td>
          <td class="text-end text-danger fw-semibold">
            <?php echo $isDebit ? '₹'.number_format($display,2) : '—'; ?>
          </td>
          <td class="text-end text-success fw-semibold">
            <?php echo !$isDebit ? '₹'.number_format($display,2) : '—'; ?>
          </td>
          <td class="text-end fw-bold <?php echo $runningBalance > 0.004 ? 'text-danger' : 'text-success'; ?>">
            ₹<?php echo number_format(abs($runningBalance), 2); ?>
            <?php echo $runningBalance > 0.004 ? '<small class="fw-normal"> Dr</small>' : ($runningBalance < -0.004 ? '<small class="fw-normal"> Cr</small>' : ''); ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php elseif ($studentId): ?>
<div class="alert alert-info">No ledger entries found. Ledger is populated when payments are collected using the new fee system.</div>
<?php else: ?>
<div class="alert alert-secondary">Select a student to view their fee ledger.</div>
<?php endif; ?>

<script>
function loadStudents(classId) {
    const sel = document.getElementById('studentSelect');
    sel.innerHTML = '<option>Loading…</option>';
    if (!classId) { sel.innerHTML = '<option value="">Select class first</option>'; return; }
    fetch('<?php echo url('fees/studentsByClass'); ?>?class_id=' + classId)
        .then(r => r.json())
        .then(students => {
            sel.innerHTML = '<option value="">— Select Student —</option>';
            students.forEach(s => {
                const o = document.createElement('option');
                o.value = s.id; o.textContent = s.name;
                sel.appendChild(o);
            });
        });
}
</script>
<style>@media print { .no-print { display:none !important; } }</style>
