<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-cash-register"></i> Daily Cash Closing</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row mb-3">
    <div class="col-md-4">
        <div class="card bg-success text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Cash Collected Today</h6>
                <h3 class="mb-0"><?php echo formatCurrency($auto['cash_collected']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-danger text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Cash Refunded</h6>
                <h3 class="mb-0"><?php echo formatCurrency($auto['cash_refunded']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Net Cash</h6>
                <h3 class="mb-0"><?php echo formatCurrency($auto['cash_collected'] - $auto['cash_refunded']); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
<div class="col-lg-5">
<div class="card mb-3">
    <div class="card-header"><h6 class="mb-0">Submit Closing</h6></div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('fees/saveCashClosing'); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="mb-2">
                <label class="form-label small">Date</label>
                <input type="date" name="closing_date" class="form-control form-control-sm"
                       value="<?php echo $date; ?>" required>
            </div>
            <div class="mb-2">
                <label class="form-label small">Cashier</label>
                <select name="cashier_id" class="form-select form-select-sm" required>
                    <?php foreach ($cashiers as $u): ?>
                    <option value="<?php echo $u['id']; ?>"><?php echo e($u['full_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-2">
                <label class="form-label small">Opening Cash (₹)</label>
                <input type="number" name="opening_cash" class="form-control form-control-sm"
                       step="0.01" min="0" value="0" required id="openingCash">
            </div>
            <div class="mb-2">
                <label class="form-label small">Cash Collected (auto-filled)</label>
                <input type="number" name="cash_collected" class="form-control form-control-sm"
                       value="<?php echo $auto['cash_collected']; ?>" step="0.01" id="cashCollected">
            </div>
            <div class="mb-2">
                <label class="form-label small">Cash Refunded</label>
                <input type="number" name="cash_refunded" class="form-control form-control-sm"
                       value="<?php echo $auto['cash_refunded']; ?>" step="0.01" id="cashRefunded">
            </div>
            <div class="mb-2">
                <label class="form-label small">Cash Adjustments (±)</label>
                <input type="number" name="cash_adjustments" class="form-control form-control-sm"
                       value="0" step="0.01" id="cashAdj">
            </div>
            <div class="mb-2">
                <label class="form-label small">Closing Cash (Physical Count)</label>
                <input type="number" name="closing_cash" class="form-control form-control-sm"
                       step="0.01" min="0" value="0" required id="closingCash" oninput="calcDiff()">
            </div>
            <div class="alert py-2 mb-2" id="diffAlert" style="display:none;">
                Difference: <strong id="diffAmt"></strong>
            </div>
            <div class="mb-2">
                <label class="form-label small">Notes</label>
                <textarea name="notes" class="form-control form-control-sm" rows="2"></textarea>
            </div>
            <button type="submit" class="btn btn-primary-custom btn-sm w-100">
                <i class="fas fa-save me-1"></i>Submit Closing
            </button>
        </form>
    </div>
</div>
</div>

<div class="col-lg-7">
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h6 class="mb-0">Closing History</h6>
        <a href="<?php echo url('fees/cashClosing'); ?>" onclick="window.print()" class="btn btn-xs btn-outline-secondary no-print">
            <i class="fas fa-print"></i> Print
        </a>
    </div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Date</th><th>Cashier</th><th class="text-end">Collected</th><th class="text-end">Closing</th><th class="text-end">Diff</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($list as $row): ?>
            <tr class="<?php echo $row['difference'] != 0 ? 'table-warning' : ''; ?>">
                <td><?php echo formatDate($row['closing_date']); ?></td>
                <td><?php echo e($row['cashier_name']); ?></td>
                <td class="text-end"><?php echo formatCurrency($row['cash_collected']); ?></td>
                <td class="text-end"><?php echo formatCurrency($row['closing_cash']); ?></td>
                <td class="text-end <?php echo $row['difference'] != 0 ? 'text-danger fw-bold' : ''; ?>">
                    <?php echo $row['difference'] != 0 ? formatCurrency($row['difference']) : '—'; ?>
                </td>
                <td>
                    <?php
                    $badge = ['Draft' => 'secondary', 'Submitted' => 'warning', 'Approved' => 'success'];
                    echo '<span class="badge bg-' . ($badge[$row['status']] ?? 'secondary') . '">' . $row['status'] . '</span>';
                    ?>
                </td>
                <td>
                    <?php if ($row['status'] === 'Submitted'): ?>
                    <form method="POST" action="<?php echo url('fees/approveCashClosing'); ?>" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <button class="btn btn-xs btn-success">Approve</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($list)): ?>
            <tr><td colspan="7" class="text-center text-muted py-3">No closings recorded yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>

<script>
function calcDiff() {
    const opening   = parseFloat(document.getElementById('openingCash').value)    || 0;
    const collected = parseFloat(document.getElementById('cashCollected').value)  || 0;
    const refunded  = parseFloat(document.getElementById('cashRefunded').value)   || 0;
    const adj       = parseFloat(document.getElementById('cashAdj').value)        || 0;
    const closing   = parseFloat(document.getElementById('closingCash').value)    || 0;
    const expected  = opening + collected - refunded + adj;
    const diff      = closing - expected;
    const el = document.getElementById('diffAlert');
    document.getElementById('diffAmt').textContent = '₹' + diff.toFixed(2);
    el.style.display = '';
    el.className = 'alert py-2 mb-2 ' + (Math.abs(diff) < 0.01 ? 'alert-success' : 'alert-danger');
}
</script>
<style>
.btn-xs{padding:.15rem .4rem;font-size:.7rem}
@media print { .no-print{display:none} }
</style>
