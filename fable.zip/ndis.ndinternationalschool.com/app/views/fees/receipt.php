<?php $pageTitle = 'Fee Receipt #' . e($txn['receipt_number']); ?>
<div class="page-header d-print-none">
    <h4><i class="fas fa-receipt"></i> Receipt</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-primary btn-sm"><i class="fas fa-print"></i> Print</button>
        <a href="fees/receipts" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
        <?php if ($txn['status'] === 'Active' && Permission::check('fees.cancel')): ?>
        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#cancelModal">
            <i class="fas fa-ban"></i> Cancel Receipt
        </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($txn['status'] === 'Cancelled'): ?>
<div class="alert alert-danger d-flex align-items-center">
    <i class="fas fa-ban fa-2x me-3"></i>
    <div>
        <strong>CANCELLED</strong> &mdash; <?= e($txn['cancel_reason']) ?>
        <small class="d-block text-muted">Cancelled at: <?= $txn['cancelled_at'] ?></small>
    </div>
</div>
<?php endif; ?>

<!-- Receipt Print Area -->
<div class="card shadow-sm" id="receiptArea">
    <div class="card-body">
        <!-- School Header -->
        <div class="text-center mb-3 border-bottom pb-3">
            <?php if (!empty($school['school_logo'])): ?>
            <img src="<?= e($school['school_logo']) ?>" height="60" class="mb-2"><br>
            <?php endif; ?>
            <h4 class="mb-0 fw-bold"><?= e($school['school_name'] ?? 'School Name') ?></h4>
            <p class="mb-0 small text-muted"><?= e($school['school_address'] ?? '') ?></p>
            <?php if (!empty($school['school_phone'])): ?>
            <p class="mb-0 small text-muted">Ph: <?= e($school['school_phone']) ?> | <?= e($school['school_email'] ?? '') ?></p>
            <?php endif; ?>
            <h5 class="mt-2 mb-0 text-decoration-underline">FEE RECEIPT</h5>
        </div>

        <!-- Receipt Meta -->
        <div class="row mb-3">
            <div class="col-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><th class="w-40 text-muted fw-normal">Receipt No.</th><td class="fw-bold"><?= e($txn['receipt_number']) ?></td></tr>
                    <tr><th class="text-muted fw-normal">Date</th><td><?= date('d/m/Y', strtotime($txn['payment_date'])) ?></td></tr>
                    <tr><th class="text-muted fw-normal">Mode</th><td><?= e($txn['payment_method']) ?></td></tr>
                    <?php if ($txn['cheque_number']): ?>
                    <tr><th class="text-muted fw-normal">Cheque No.</th><td><?= e($txn['cheque_number']) ?></td></tr>
                    <?php endif; ?>
                    <?php if ($txn['upi_transaction_id']): ?>
                    <tr><th class="text-muted fw-normal">UPI Ref.</th><td><?= e($txn['upi_transaction_id']) ?></td></tr>
                    <?php endif; ?>
                </table>
            </div>
            <div class="col-6 text-end">
                <h2 class="text-success">&#8377;<?= number_format((float)$txn['total_amount'], 2) ?></h2>
                <p class="text-muted small mb-0">Total Paid</p>
                <?php if ($txn['collected_by_name']): ?>
                <p class="text-muted small">Collected by: <?= e($txn['collected_by_name']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Students -->
        <?php foreach ($txn['students'] as $stu): ?>
        <div class="border rounded p-3 mb-3">
            <div class="d-flex justify-content-between mb-2">
                <div>
                    <strong><?= e($stu['student_name']) ?></strong>
                    <span class="badge bg-secondary ms-1"><?= e($stu['admission_number']) ?></span>
                </div>
                <div class="text-muted small"><?= e($stu['class_name']) ?><?= $stu['section_name'] ? ' - '.e($stu['section_name']) : '' ?></div>
            </div>
            <table class="table table-sm mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Month</th>
                        <th>Fee Head</th>
                        <th class="text-end">Charged</th>
                        <th class="text-end">Discount</th>
                        <th class="text-end">Late Fee</th>
                        <th class="text-end">Paid</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($stu['items'] as $item): ?>
                <tr>
                    <td class="small"><?= $item['month_year'] ? date('M Y', strtotime($item['month_year'].'-01')) : '-' ?></td>
                    <td class="small"><?= !empty($item['is_transport'])
                        ? 'Transport' . (!empty($item['transport_fee_type']) ? ' (' . e($item['transport_fee_type']) . ')' : '')
                        : e($item['head_name'] ?? 'Misc') ?></td>
                    <td class="text-end small">&#8377;<?= number_format((float)$item['charged_amount'],2) ?></td>
                    <td class="text-end small text-success"><?= $item['discount_amount']>0 ? '-&#8377;'.number_format((float)$item['discount_amount'],2) : '-' ?></td>
                    <td class="text-end small text-danger"><?= $item['late_fee_amount']>0 ? '+&#8377;'.number_format((float)$item['late_fee_amount'],2) : '-' ?></td>
                    <td class="text-end small fw-semibold">&#8377;<?= number_format((float)$item['paid_amount'],2) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot class="table-light">
                    <tr>
                        <th colspan="5" class="text-end">Student Total:</th>
                        <th class="text-end">&#8377;<?= number_format($stu['total_paid'],2) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endforeach; ?>

        <?php if ($txn['remarks']): ?>
        <p class="text-muted small mb-0"><em>Remarks: <?= e($txn['remarks']) ?></em></p>
        <?php endif; ?>

        <div class="row mt-4 pt-3 border-top">
            <div class="col-6">
                <p class="text-muted small mb-0">Amount in words: <strong><?= e(amountToWords((float)$txn['total_amount'])) ?></strong></p>
            </div>
            <div class="col-6 text-end">
                <div class="mt-4 pt-3 border-top border-secondary" style="display:inline-block;min-width:150px">
                    <small class="text-muted">Authorized Signature</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Cancel Modal -->
<?php if ($txn['status'] === 'Active' && Permission::check('fees.cancel')): ?>
<div class="modal fade" id="cancelModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" action="fees/cancelReceipt">
            <?= CSRF::field() ?>
            <input type="hidden" name="id" value="<?= (int)$txn['id'] ?>">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-ban"></i> Cancel Receipt</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <strong>Warning:</strong> Cancelling this receipt will reverse all associated payments in the ledger. This action cannot be undone.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason for Cancellation <span class="text-danger">*</span></label>
                        <textarea name="reason" class="form-control" rows="3" required placeholder="Reason is mandatory..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this receipt?')">Confirm Cancellation</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<style>
@media print {
    .page-header, .d-print-none, nav, .sidebar, .topbar { display: none !important; }
    .card { border: none !important; box-shadow: none !important; }
    body { padding: 0 !important; margin: 0 !important; }
}
</style>
<?php
function amountToWords(float $amount): string {
    $ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
             'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen',
             'Seventeen','Eighteen','Nineteen'];
    $tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    function numToWord($n, $ones, $tens) {
        if($n < 20) return $ones[$n];
        if($n < 100) return $tens[(int)($n/10)].($n%10?' '.$ones[$n%10]:'');
        return $ones[(int)($n/100)].' Hundred'.($n%100?' '.numToWord($n%100,$ones,$tens):'');
    }
    $n = (int)$amount;
    $p = (int)round(($amount - $n) * 100);
    $words = '';
    if($n >= 10000000) { $words .= numToWord((int)($n/10000000),$ones,$tens).' Crore '; $n %= 10000000; }
    if($n >= 100000)   { $words .= numToWord((int)($n/100000),$ones,$tens).' Lakh '; $n %= 100000; }
    if($n >= 1000)     { $words .= numToWord((int)($n/1000),$ones,$tens).' Thousand '; $n %= 1000; }
    if($n > 0)         { $words .= numToWord($n,$ones,$tens).' '; }
    $words = trim($words) ?: 'Zero';
    $words .= ' Rupees';
    if($p > 0) $words .= ' and '.numToWord($p,$ones,$tens).' Paise';
    return $words.' Only';
}
?>
