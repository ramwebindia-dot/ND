<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-home"></i> Family Fee Dashboard</h4>
    <a href="<?php echo url('fees'); ?>" class="btn btn-outline-primary-custom btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('fees/familyDashboard'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Select Family</label>
                <select name="parent_id" class="form-select" onchange="this.form.submit()">
                    <option value="">— Choose Parent —</option>
                    <?php foreach ($parents as $p): ?>
                    <option value="<?php echo $p['id']; ?>" <?php echo $parentId == $p['id'] ? 'selected' : ''; ?>>
                        <?php echo e($p['father_name'] ?: $p['mother_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<?php if ($parentId && !empty($data)): ?>
<div class="row mb-3">
    <div class="col-md-4">
        <div class="card bg-danger text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Outstanding</h6>
                <h3 class="mb-0"><?php echo formatCurrency($data['grand_total_dues']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Paid (this session)</h6>
                <h3 class="mb-0"><?php echo formatCurrency($data['grand_total_paid']); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Children</h6>
                <h3 class="mb-0"><?php echo count($data['students']); ?></h3>
            </div>
        </div>
    </div>
</div>

<?php foreach ($data['students'] as $st): ?>
<div class="card mb-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div>
            <strong><?php echo e($st['first_name'] . ' ' . $st['last_name']); ?></strong>
            <span class="badge bg-secondary ms-2"><?php echo e($st['class_name'] ?? ''); ?></span>
            <small class="text-muted ms-2"><?php echo e($st['admission_number']); ?></small>
        </div>
        <div class="d-flex align-items-center gap-3">
            <?php if ($st['credit'] > 0): ?>
            <span class="badge bg-success"><i class="fas fa-coins me-1"></i>Credit: <?php echo formatCurrency($st['credit']); ?></span>
            <?php endif; ?>
            <span class="<?php echo $st['outstanding'] > 0 ? 'text-danger fw-bold' : 'text-success'; ?>">
                <?php echo $st['outstanding'] > 0 ? 'Due: ' . formatCurrency($st['outstanding']) : 'No Dues'; ?>
            </span>
            <a href="<?php echo url('fees/collect?student_id=' . $st['id']); ?>" class="btn btn-sm btn-primary-custom">
                <i class="fas fa-rupee-sign me-1"></i>Pay Now
            </a>
        </div>
    </div>
    <div class="card-body py-2">
        <!-- Month Status Mini Grid -->
        <div class="d-flex flex-wrap gap-1 mb-2">
        <?php foreach ($st['month_status'] as $my => $ms): ?>
            <?php
            $colors = ['Pending' => 'danger', 'Partial' => 'warning', 'Paid' => 'success', 'Advance' => 'info'];
            $c = $colors[$ms['status'] ?? 'Pending'] ?? 'secondary';
            $label = date('M', strtotime($my . '-01'));
            ?>
            <span class="badge bg-<?php echo $c; ?> px-2" title="<?php echo $my . ': ' . ($ms['status'] ?? 'Pending'); ?>">
                <?php echo $label; ?>
            </span>
        <?php endforeach; ?>
        </div>
        <!-- Recent Receipts -->
        <?php if (!empty($st['receipts'])): ?>
        <div class="table-responsive">
            <table class="table table-sm table-borderless mb-0">
                <thead><tr class="text-muted small"><th>Receipt</th><th>Date</th><th class="text-end">Amount</th><th>Method</th></tr></thead>
                <tbody>
                <?php foreach (array_slice($st['receipts'], 0, 5) as $r): ?>
                <tr>
                    <td><a href="<?php echo url('fees/receipt?id=' . $r['id']); ?>" target="_blank"><?php echo e($r['receipt_number']); ?></a></td>
                    <td><?php echo formatDate($r['payment_date']); ?></td>
                    <td class="text-end"><?php echo formatCurrency($r['total_amount']); ?></td>
                    <td><?php echo e($r['payment_method']); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<div class="text-end">
    <a href="<?php echo url('fees/familyPayment?parent_id=' . $parentId); ?>" class="btn btn-primary-custom btn-lg">
        <i class="fas fa-users me-2"></i>Combined Family Payment
    </a>
</div>
<?php elseif ($parentId): ?>
<div class="alert alert-info">No active students found for this family.</div>
<?php else: ?>
<div class="alert alert-secondary">Select a family above to view their fee dashboard.</div>
<?php endif; ?>
