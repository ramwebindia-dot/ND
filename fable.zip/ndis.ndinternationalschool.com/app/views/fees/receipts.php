<?php $pageTitle = 'Fee Receipts'; ?>
<div class="page-header">
    <h4><i class="fas fa-receipt"></i> Fee Receipts</h4>
    <a href="fees" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<!-- Filters -->
<div class="card shadow-sm mb-3">
    <div class="card-body py-2">
        <form method="get" action="fees/receipts" class="row g-2">
            <div class="col-md-2">
                <select name="session_id" class="form-select form-select-sm">
                    <?php foreach ($sessions as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $s['id'] == $sessId ? 'selected' : '' ?>><?= e($s['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="text" name="receipt_number" class="form-control form-control-sm" placeholder="Receipt No." value="<?= e($filters['receipt_number']) ?>">
            </div>
            <div class="col-md-2">
                <select name="payment_method" class="form-select form-select-sm">
                    <option value="">All Modes</option>
                    <?php foreach (['Cash','Cheque','DD','NEFT','UPI','Card'] as $pm): ?>
                    <option value="<?= $pm ?>" <?= $filters['payment_method']==$pm?'selected':'' ?>><?= $pm ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Status</option>
                    <option value="Active" <?= $filters['status']==='Active'?'selected':'' ?>>Active</option>
                    <option value="Cancelled" <?= $filters['status']==='Cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-md-2">
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?= e($filters['date_from']) ?>" title="Date From">
            </div>
            <div class="col-md-2">
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?= e($filters['date_to']) ?>" title="Date To">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">Filter</button>
                <a href="fees/receipts" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>Showing <?= count($data) ?> of <?= $total ?> receipts</span>
        <small class="text-muted">Page <?= $page ?> of <?= $total_pages ?></small>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Receipt No.</th>
                    <th>Date</th>
                    <th>Students</th>
                    <th>Class</th>
                    <th>Mode</th>
                    <th class="text-end">Amount</th>
                    <th>Collected By</th>
                    <th class="text-center">Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr class="<?= $r['status']==='Cancelled'?'table-secondary text-muted':'' ?>">
                <td><a href="fees/receipt?id=<?= $r['id'] ?>" class="fw-semibold text-decoration-none"><?= e($r['receipt_number']) ?></a></td>
                <td class="small"><?= date('d/m/Y', strtotime($r['payment_date'])) ?></td>
                <td class="small"><?= e($r['student_names']) ?></td>
                <td class="small"><?= e($r['class_names']) ?></td>
                <td><span class="badge bg-light text-dark border small"><?= e($r['payment_method']) ?></span></td>
                <td class="text-end fw-semibold">&#8377;<?= number_format((float)$r['total_amount'],2) ?></td>
                <td class="small"><?= e($r['collected_by_name'] ?? '') ?></td>
                <td class="text-center">
                    <span class="badge bg-<?= $r['status']==='Active'?'success':'danger' ?>"><?= e($r['status']) ?></span>
                </td>
                <td>
                    <a href="fees/receipt?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($data)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No receipts found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($total_pages > 1): ?>
    <div class="card-footer d-flex justify-content-center">
        <nav><ul class="pagination pagination-sm mb-0">
            <?php for ($i=1; $i<=$total_pages; $i++): ?>
            <li class="page-item <?= $i==$page?'active':'' ?>">
                <a class="page-link" href="?page=<?= $i ?>&session_id=<?= $sessId ?>&<?= http_build_query(array_filter($filters)) ?>"><?= $i ?></a>
            </li>
            <?php endfor; ?>
        </ul></nav>
    </div>
    <?php endif; ?>
</div>
