<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-plus-circle me-2"></i>Assign Homework</h4>
    <a href="<?php echo url('homework'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:700px;">
    <div class="card-body">
        <?php if (empty($isAdmin) && empty($myAssignments)): ?>
        <div class="alert alert-warning mb-0">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Aap kisi bhi class-section ke class teacher assigned nahi hain. Homework dene ke liye admin se apni section assign karwayein.
        </div>
        <?php else: ?>
        <form method="POST" action="<?php echo url('homework/create'); ?>" enctype="multipart/form-data">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required placeholder="Homework title">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Deadline <span class="text-danger">*</span></label>
                    <input type="date" name="deadline" class="form-control" required
                           min="<?php echo date('Y-m-d'); ?>">
                </div>
                <?php if (!empty($isAdmin)): ?>
                <div class="col-md-6">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" class="form-select" id="classSelect" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Section</label>
                    <select name="section_id" class="form-select" id="sectionSelect">
                        <option value="">All sections (whole class)</option>
                    </select>
                    <div class="form-text">Section chuno (ya poori class ke liye chhodo).</div>
                </div>
                <?php else: ?>
                <div class="col-12">
                    <label class="form-label">Your Class &amp; Section <span class="text-danger">*</span></label>
                    <select name="class_section" class="form-select" required>
                        <option value="">Select your class-section</option>
                        <?php foreach (($myAssignments ?? []) as $a): ?>
                        <option value="<?php echo $a['class_id'] . '_' . $a['section_id']; ?>"><?php echo e($a['class_name'] . ' - ' . $a['section_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Aap sirf apni assigned class-section ko homework de sakte hain.</div>
                </div>
                <?php endif; ?>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4"
                              placeholder="Describe the homework (or just attach a file below)..."></textarea>
                    <div class="form-text">Description likho <b>ya</b> file attach karo — kam se kam ek zaroori hai.</div>
                </div>
                <div class="col-12">
                    <label class="form-label">Attachment</label>
                    <input type="file" name="attachment" class="form-control"
                           accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                    <div class="form-text">PDF, Word, or image — max 5 MB. Students &amp; parents can view this file.</div>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check me-2"></i>Assign Homework
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>

<script>
var _hwClassSel = document.getElementById('classSelect');
if (_hwClassSel) {
    _hwClassSel.addEventListener('change', function() {
        const cid = this.value;
        const sel = document.getElementById('sectionSelect');
        sel.innerHTML = '<option value="">Loading…</option>';
        if (!cid) { sel.innerHTML = '<option value="">Select Class first</option>'; return; }
        fetch('<?php echo url("academic/get-sections?class_id="); ?>' + cid)
            .then(r => r.json())
            .then(data => {
                sel.innerHTML = '<option value="">All sections (whole class)</option>';
                data.forEach(s => { sel.innerHTML += `<option value="${s.id}">${s.name}</option>`; });
            })
            .catch(() => { sel.innerHTML = '<option value="">Error loading sections</option>'; });
    });
}
</script>
