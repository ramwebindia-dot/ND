<div class="page-header">
    <h4><i class="fas fa-tasks"></i> Homework</h4>
    <a href="<?php echo url('homework/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Assign Homework</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Deadline</th>
                        <th>Submissions</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($homework)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">No homework found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($homework as $i => $hw): ?>
                        <tr>
                            <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                            <td><strong><?php echo e($hw['title']); ?></strong></td>
                            <td><?php echo e($hw['class_name'] ?? '-'); ?></td>
                            <td><?php echo e($hw['section_name'] ?? 'All'); ?></td>
                            <td>
                                <?php echo formatDate($hw['deadline']); ?>
                                <?php if (strtotime($hw['deadline']) < strtotime('today')): ?>
                                    <span class="badge bg-danger ms-1">Past Due</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo url('homework/submissions?id=' . $hw['id']); ?>" class="btn btn-sm btn-outline-info">
                                    <i class="fas fa-file-alt me-1"></i>View
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo url('homework/edit?id=' . $hw['id']); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></a>
                                <form method="POST" action="<?php echo url('homework/delete'); ?>" class="d-inline" onsubmit="return confirm('Delete this homework?')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $hw['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('homework?page=' . $p); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
