<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Homework</h4>
    <a href="<?php echo url('homework'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('homework/edit?id=' . $hw['id']); ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($hw['title']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" class="form-select" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>" <?php echo $hw['class_id'] == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Subject <span class="text-danger">*</span></label>
                    <input type="number" name="subject_id" class="form-control" value="<?php echo e($hw['subject_id']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Deadline <span class="text-danger">*</span></label>
                    <input type="date" name="deadline" class="form-control" value="<?php echo e($hw['deadline']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Attachment</label>
                    <input type="file" name="attachment" class="form-control">
                    <?php if (!empty($hw['attachment'])): ?>
                        <small class="text-muted">Current: <a href="<?php echo asset($hw['attachment']); ?>" target="_blank">View File</a></small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description <span class="text-danger">*</span></label>
                <textarea name="description" class="form-control" rows="4" required><?php echo e($hw['description']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-check me-1"></i>Update Homework</button>
        </form>
    </div>
</div>
