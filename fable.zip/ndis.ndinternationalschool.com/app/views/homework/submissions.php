﻿<div class="page-header">
    <h4><i class="fas fa-file-alt"></i> Submissions - <?php echo e($hw['title']); ?></h4>
    <a href="<?php echo url('homework'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <strong>Title:</strong> <?php echo e($hw['title']); ?>
            </div>
            <div class="col-md-3">
                <strong>Deadline:</strong> <?php echo formatDate($hw['deadline']); ?>
            </div>
            <div class="col-md-3">
                <strong>Description:</strong> <?php echo e($hw['description'] ?? '-'); ?>
            </div>
            <?php if (!empty($hw['attachment'])): ?>
            <div class="col-md-3">
                <a href="<?php echo asset($hw['attachment']); ?>" target="_blank" class="btn btn-sm btn-outline-info"><i class="fas fa-paperclip me-1"></i>View Attachment</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Adm. No.</th>
                        <th>Submitted At</th>
                        <th>Status</th>
                        <th>Grade</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($submissions)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">No submissions yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($submissions as $i => $sub): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo e(trim($sub['first_name'] . ' ' . ($sub['last_name'] ?? ''))); ?></td>
                            <td><?php echo e($sub['admission_number']); ?></td>
                            <td><?php echo formatDateTime($sub['submitted_at']); ?></td>
                            <td>
                                <span class="badge <?php echo $sub['status'] === 'Graded' ? 'bg-success' : ($sub['status'] === 'Submitted' ? 'bg-info' : 'bg-warning'); ?>">
                                    <?php echo e($sub['status']); ?>
                                </span>
                            </td>
                            <td><?php echo e($sub['grade'] ?? '-'); ?></td>
                            <td>
                                <?php if (!empty($sub['file_path'])): ?>
                                    <a href="<?php echo asset($sub['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-info" title="View File"><i class="fas fa-paperclip"></i></a>
                                <?php endif; ?>
                                <?php if ($sub['status'] !== 'Graded'): ?>
                                <button class="btn btn-sm btn-outline-success grade-btn" data-id="<?php echo $sub['id']; ?>" data-hwid="<?php echo $hw['id']; ?>" data-grade="<?php echo e($sub['grade'] ?? ''); ?>" data-remarks="<?php echo e($sub['teacher_remarks'] ?? ''); ?>" title="Grade"><i class="fas fa-star"></i></button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Grade Modal -->
<div class="modal fade" id="gradeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('homework/gradeSubmission'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="submission_id" id="grade_sub_id">
                <input type="hidden" name="homework_id" id="grade_hw_id">
                <div class="modal-header">
                    <h5 class="modal-title">Grade Submission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Grade <span class="text-danger">*</span></label>
                        <select name="grade" class="form-select" required>
                            <option value="A+">A+</option>
                            <option value="A">A</option>
                            <option value="B+">B+</option>
                            <option value="B">B</option>
                            <option value="C+">C+</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="F">F</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Teacher Remarks</label>
                        <textarea name="teacher_remarks" id="grade_remarks" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Submit Grade</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.grade-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('grade_sub_id').value = this.dataset.id;
        document.getElementById('grade_hw_id').value = this.dataset.hwid;
        document.getElementById('grade_remarks').value = this.dataset.remarks;
        new bootstrap.Modal(document.getElementById('gradeModal')).show();
    });
});
</script>
