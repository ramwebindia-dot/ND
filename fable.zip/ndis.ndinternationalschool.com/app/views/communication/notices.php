<div class="page-header">
    <h4><i class="fas fa-bullhorn"></i> Notice Board</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#noticeModal">
        <i class="fas fa-plus me-1"></i>Post Notice
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Audience</th>
                        <th>Active</th>
                        <th>Posted On</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($notices)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No notices found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($notices as $i => $notice): ?>
                        <tr>
                            <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                            <td><strong><?php echo e($notice['title']); ?></strong></td>
                            <td>
                                <?php foreach (explode(',', $notice['audience'] ?? 'All') as $aud): ?>
                                    <span class="badge bg-info me-1"><?php echo e(trim($aud)); ?></span>
                                <?php endforeach; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $notice['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo $notice['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td><?php echo formatDate($notice['created_at']); ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-info edit-notice" data-id="<?php echo $notice['id']; ?>" data-title="<?php echo e($notice['title']); ?>" data-content="<?php echo e($notice['content'] ?? ''); ?>" data-audience="<?php echo e($notice['audience'] ?? 'All'); ?>" data-active="<?php echo $notice['is_active']; ?>" title="Edit"><i class="fas fa-edit"></i></button>
                                <form method="POST" action="<?php echo url('communication/deleteNotice'); ?>" class="d-inline" onsubmit="return confirm('Delete this notice?')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $notice['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('communication/notices?page=' . $p); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<!-- Add/Edit Notice Modal -->
<div class="modal fade" id="noticeModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('communication/saveNotice'); ?>" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="notice_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title" id="noticeModalLabel">Post Notice</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" id="notice_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Content <span class="text-danger">*</span></label>
                        <textarea name="content" id="notice_content" class="form-control" rows="5" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Audience</label>
                            <input type="text" name="audience" id="notice_audience" class="form-control" placeholder="All, Student, Parent, Teacher" value="All">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Attachment</label>
                            <input type="file" name="attachment" class="form-control">
                        </div>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="is_active" id="notice_active" class="form-check-input" value="1" checked>
                        <label class="form-check-label" for="notice_active">Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Save Notice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-notice').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('notice_id').value = this.dataset.id;
        document.getElementById('notice_title').value = this.dataset.title;
        document.getElementById('notice_content').value = this.dataset.content;
        document.getElementById('notice_audience').value = this.dataset.audience;
        document.getElementById('notice_active').checked = this.dataset.active == 1;
        document.getElementById('noticeModalLabel').textContent = 'Edit Notice';
        new bootstrap.Modal(document.getElementById('noticeModal')).show();
    });
});
</script>