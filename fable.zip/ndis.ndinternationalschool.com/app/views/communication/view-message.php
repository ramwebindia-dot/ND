<div class="page-header">
    <h4><i class="fas fa-envelope-open"></i> View Message</h4>
    <a href="<?php echo url('communication/messages'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-md-6">
                <strong>From:</strong> <?php echo e($message['sender_name'] ?? 'Unknown'); ?><br>
                <strong>To:</strong> <?php echo e($message['receiver_name'] ?? 'Unknown'); ?>
            </div>
            <div class="col-md-6 text-end">
                <strong>Date:</strong> <?php echo formatDateTime($message['created_at']); ?>
            </div>
        </div>
        <h5><?php echo e($message['subject']); ?></h5>
        <hr>
        <div class="message-content">
            <?php echo nl2br(e($message['message'])); ?>
        </div>
    </div>
</div>

<!-- Reply Form -->
<div class="card mt-3">
    <div class="card-header fw-bold"><i class="fas fa-reply me-2"></i>Reply</div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('communication/reply'); ?>">
            <?php echo CSRF::field(); ?>
            <input type="hidden" name="original_id" value="<?php echo $message['id']; ?>">
            <input type="hidden" name="receiver_id" value="<?php echo $message['sender_id']; ?>">
            <input type="hidden" name="subject" value="Re: <?php echo e(addslashes($message['subject'])); ?>">
            <div class="mb-3">
                <label class="form-label">Message</label>
                <textarea name="message" class="form-control" rows="4" required placeholder="Type your reply..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-paper-plane me-1"></i>Send Reply
            </button>
        </form>
    </div>
</div>