<div class="page-header">
    <h4><i class="fas fa-pen"></i> Compose Message</h4>
    <a href="<?php echo url('communication/messages'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('communication/sendMessage'); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="mb-3">
                <label class="form-label">To <span class="text-danger">*</span></label>
                <select name="receiver_id" class="form-select" required>
                    <option value="">Select Recipient</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?php echo $u['id']; ?>"><?php echo e($u['full_name'] . ' (' . ($u['role_name'] ?? 'User') . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Subject <span class="text-danger">*</span></label>
                <input type="text" name="subject" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Message <span class="text-danger">*</span></label>
                <textarea name="message" class="form-control" rows="6" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-paper-plane me-1"></i>Send Message</button>
        </form>
    </div>
</div>