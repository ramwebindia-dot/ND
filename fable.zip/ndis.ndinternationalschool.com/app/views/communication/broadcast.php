<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-broadcast-tower me-2"></i>Broadcast Message</h4>
    <a href="<?php echo url('communication'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row g-3">
<div class="col-md-7">
<div class="card">
    <div class="card-header fw-bold">Send Broadcast</div>
    <div class="card-body">
        <div class="alert alert-info small">
            <i class="fas fa-info-circle me-2"></i>
            A broadcast sends the same message to multiple recipients at once.
            Select either a <strong>Class</strong> (sends to all students in that class with login)
            or a <strong>Role</strong> (sends to all users with that role).
        </div>
        <form method="POST" action="<?php echo url('communication/broadcast'); ?>">
            <?php echo CSRF::field(); ?>
            <div class="mb-3">
                <label class="form-label fw-bold">Target Recipients</label>
                <div class="row g-2">
                    <div class="col-md-6">
                        <label class="form-label small text-muted">By Class (students)</label>
                        <select name="class_id" class="form-select form-select-sm" id="classTarget">
                            <option value="">— None —</option>
                            <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small text-muted">By Role (all users)</label>
                        <select name="target_role" class="form-select form-select-sm" id="roleTarget">
                            <option value="">— None —</option>
                            <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role; ?>"><?php echo $role; ?>s</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-text">Choose one target. If both are selected, Class takes priority.</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Subject <span class="text-danger">*</span></label>
                <input type="text" name="subject" class="form-control" required placeholder="Message subject">
            </div>
            <div class="mb-3">
                <label class="form-label">Message <span class="text-danger">*</span></label>
                <textarea name="message" class="form-control" rows="6" required placeholder="Type your broadcast message here..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary" onclick="return confirm('Send this broadcast?')">
                <i class="fas fa-paper-plane me-2"></i>Send Broadcast
            </button>
        </form>
    </div>
</div>
</div>

<div class="col-md-5">
    <div class="card">
        <div class="card-header fw-bold">Tips</div>
        <div class="card-body">
            <ul class="small text-muted">
                <li>Only users with a login account receive messages</li>
                <li>Each recipient gets an individual message in their inbox</li>
                <li>Large broadcasts (100+ recipients) may take a moment</li>
                <li>Use <strong>Notices</strong> for one-way public announcements — they appear for all</li>
                <li>Use <strong>Broadcast</strong> for private messages that show in inbox</li>
            </ul>
        </div>
    </div>
</div>
</div>

<script>
// Ensure only one target is selected
document.getElementById('classTarget').addEventListener('change', function() {
    if (this.value) document.getElementById('roleTarget').value = '';
});
document.getElementById('roleTarget').addEventListener('change', function() {
    if (this.value) document.getElementById('classTarget').value = '';
});
</script>
