<div class="page-header">
    <h4><i class="fas fa-envelope"></i> Messages</h4>
    <div>
        <a href="<?php echo url('communication/compose'); ?>" class="btn btn-primary-custom"><i class="fas fa-pen me-1"></i>Compose</a>
        <div class="btn-group">
            <a href="<?php echo url('communication/messages?type=inbox'); ?>" class="btn <?php echo $type === 'inbox' ? 'btn-primary-custom' : 'btn-outline-primary-custom'; ?>">Inbox</a>
            <a href="<?php echo url('communication/messages?type=sent'); ?>" class="btn <?php echo $type === 'sent' ? 'btn-primary-custom' : 'btn-outline-primary-custom'; ?>">Sent</a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo $type === 'inbox' ? 'From' : 'To'; ?></th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($messages)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No messages found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($messages as $i => $msg): ?>
                        <tr class="<?php echo empty($msg['is_read']) && $type === 'inbox' ? 'table-warning' : ''; ?>">
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo e($msg['sender_name'] ?? $msg['receiver_name'] ?? '-'); ?></td>
                            <td><strong><?php echo e($msg['subject']); ?></strong></td>
                            <td><?php echo formatDateTime($msg['created_at']); ?></td>
                            <td>
                                <?php if ($type === 'inbox' && empty($msg['is_read'])): ?>
                                    <span class="badge bg-warning text-dark">New</span>
                                <?php elseif (!empty($msg['is_read'])): ?>
                                    <span class="badge bg-secondary">Read</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo url('communication/viewMessage?id=' . $msg['id']); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="fas fa-eye"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>