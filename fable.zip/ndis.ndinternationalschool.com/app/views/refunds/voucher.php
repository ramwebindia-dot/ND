﻿<div class="page-header">
    <h4><i class="fas fa-file-invoice"></i> Refund Voucher</h4>
    <div>
        <button onclick="window.print()" class="btn btn-outline-primary-custom"><i class="fas fa-print me-1"></i>Print</button>
        <a href="<?php echo url('refunds'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="card" id="printArea">
    <div class="card-body">
        <div class="text-center mb-4">
            <h4 class="mb-1">ND International School Dinod</h4>
            <p class="text-muted mb-2">Refund Voucher</p>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <table class="table table-sm table-borderless">
                    <tr><td class="text-muted">Voucher No:</td><td><strong><?php echo e($refund['refund_voucher_number']); ?></strong></td></tr>
                    <tr><td class="text-muted">Refund Date:</td><td><?php echo formatDate($refund['refund_date'] ?? $refund['created_at']); ?></td></tr>
                    <tr><td class="text-muted">Status:</td><td><span class="badge <?php echo $refund['status'] === 'Processed' ? 'bg-success' : 'bg-warning'; ?>"><?php echo e($refund['status']); ?></span></td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <?php if ($student): ?>
                <table class="table table-sm table-borderless">
                    <tr><td class="text-muted">Student:</td><td><strong><?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?></strong></td></tr>
                    <tr><td class="text-muted">Adm. No:</td><td><?php echo e($student['admission_number']); ?></td></tr>
                    <tr><td class="text-muted">Class:</td><td><?php echo e($student['class_name'] ?? '-'); ?></td></tr>
                </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-warning">
                    <tr>
                        <th>Description</th>
                        <th>Refund Method</th>
                        <th class="text-end">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($refund['reason'] ?? 'Fee Refund'); ?></td>
                        <td><?php echo e($refund['refund_method'] ?? '-'); ?></td>
                        <td class="text-end"><strong><?php echo formatCurrency($refund['amount']); ?></strong></td>
                    </tr>
                    <?php if (!empty($refund['deduction'])): ?>
                    <tr>
                        <td>Deduction</td>
                        <td>-</td>
                        <td class="text-end text-danger">- <?php echo formatCurrency($refund['deduction']); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="text-end"><strong>Net Refund</strong></td>
                        <td class="text-end"><strong><?php echo formatCurrency($refund['amount'] - ($refund['deduction'] ?? 0)); ?></strong></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($collection): ?>
        <div class="mt-3">
            <small class="text-muted">Original Receipt: <strong><?php echo e($collection['receipt_number']); ?></strong> | Paid: <?php echo formatCurrency($collection['paid_amount']); ?> on <?php echo formatDate($collection['payment_date']); ?></small>
        </div>
        <?php endif; ?>

        <div class="row mt-4">
            <div class="col-4 text-center">
                <div class="border-top pt-2 mt-4">Prepared By</div>
            </div>
            <div class="col-4 text-center">
                <div class="border-top pt-2 mt-4">Approved By</div>
            </div>
            <div class="col-4 text-center">
                <div class="border-top pt-2 mt-4">Received By</div>
            </div>
        </div>
    </div>
</div>
