﻿<div class="page-header">
    <h4><i class="fas fa-check-circle"></i> Approve Refund</h4>
    <a href="<?php echo url('refunds'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<?php if ($student): ?>
<div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <strong>Student:</strong> <?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?><br>
                <strong>Adm. No:</strong> <?php echo e($student['admission_number']); ?>
            </div>
            <div class="col-md-4">
                <strong>Class:</strong> <?php echo e($student['class_name'] ?? '-'); ?><br>
                <strong>Refund Amount:</strong> <span class="text-danger fw-bold"><?php echo formatCurrency($refund['amount']); ?></span>
            </div>
            <div class="col-md-4">
                <strong>Voucher No:</strong> <?php echo e($refund['refund_voucher_number']); ?><br>
                <strong>Reason:</strong> <?php echo e($refund['reason'] ?? '-'); ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('refunds/approve?id=' . $refund['id']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

            <div class="mb-3">
                <label class="form-label">Refund Method <span class="text-danger">*</span></label>
                <select name="refund_method" class="form-select" required id="refundMethod">
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cheque">Cheque</option>
                </select>
            </div>

            <div class="mb-3" id="bankAccountDiv" style="display:none;">
                <label class="form-label">Bank Account <span class="text-danger">*</span></label>
                <select name="bank_account_id" class="form-select" id="bankAccountId">
                    <option value="">Select Bank Account</option>
                    <?php foreach ($banks as $bank): ?>
                        <option value="<?php echo $bank['id']; ?>"><?php echo e($bank['bank_name'] . ' - ' . ($bank['account_number'] ?? '')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Warning:</strong> Approving this refund will deduct <?php echo formatCurrency($refund['amount']); ?> from the selected ledger. This action cannot be undone.
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success"><i class="fas fa-check me-1"></i>Approve & Process Refund</button>
                <a href="<?php echo url('refunds/reject?id=' . $refund['id']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to reject this refund?')"><i class="fas fa-times me-1"></i>Reject Refund</a>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('refundMethod').addEventListener('change', function() {
    var bankDiv = document.getElementById('bankAccountDiv');
    var bankSelect = document.getElementById('bankAccountId');
    if (this.value === 'Bank Transfer' || this.value === 'Cheque') {
        bankDiv.style.display = 'block';
        bankSelect.required = true;
    } else {
        bankDiv.style.display = 'none';
        bankSelect.required = false;
        bankSelect.value = '';
    }
});
</script>
