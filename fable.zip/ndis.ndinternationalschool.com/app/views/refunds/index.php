﻿<div class="page-header"><h4><i class="fas fa-undo"></i> Fee Refunds</h4><a href="<?php echo url('refunds/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Process Refund</a></div>
<div class="card"><div class="card-body"><div class="table-responsive"><table class="table table-hover">
<thead><tr><th>Voucher #</th><th>Student</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
<tbody><?php if (empty($refunds)): ?><tr><td colspan="7" class="text-center text-muted py-3">No refunds found.</td></tr>
<?php else: foreach ($refunds as $r): ?>
<tr><td><strong><?php echo e($r['refund_voucher_number']); ?></strong></td><td><?php echo e(trim($r['first_name'] . ' ' . ($r['last_name'] ?? ''))); ?></td>
<td><?php echo formatCurrency($r['amount']); ?></td><td><?php echo e($r['refund_method'] ?? '-'); ?></td>
<td><span class="badge <?php echo $r['status'] === 'Processed' ? 'badge-success-custom' : ($r['status'] === 'Pending' ? 'badge-warning-custom' : 'badge-danger-custom'); ?>"><?php echo e($r['status']); ?></span></td>
<td><?php echo formatDateTime($r['created_at']); ?></td>
<td><a href="<?php echo url('refunds/voucher?id=' . $r['id']); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-print"></i></a>
<?php if ($r['status'] === 'Pending'): ?>
<a href="<?php echo url('refunds/approve?id='.$r['id']); ?>" class="btn btn-sm btn-outline-success" title="Approve &amp; Pay"><i class="fas fa-check"></i></a>
<form method="POST" action="<?php echo url('refunds/credit-to-balance'); ?>" class="d-inline" onsubmit="return confirm('Credit to student balance?')">
    <?php echo CSRF::field(); ?><input type="hidden" name="id" value="<?php echo $r['id']; ?>">
    <button class="btn btn-sm btn-outline-info" title="Credit to Balance"><i class="fas fa-wallet"></i></button>
</form>
<form method="POST" action="<?php echo url('refunds/reject'); ?>" class="d-inline" onsubmit="return confirm('Reject this refund?')">
    <?php echo CSRF::field(); ?><input type="hidden" name="id" value="<?php echo $r['id']; ?>">
    <button class="btn btn-sm btn-outline-danger" title="Reject"><i class="fas fa-times"></i></button>
</form>
<?php endif; ?></td></tr>
<?php endforeach; endif; ?></tbody></table></div></div></div>
