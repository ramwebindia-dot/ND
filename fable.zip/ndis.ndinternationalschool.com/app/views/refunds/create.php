﻿<div class="page-header"><h4><i class="fas fa-plus-circle"></i> Process Refund</h4><a href="<?php echo url('refunds'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a></div>
<form method="POST" action="<?php echo url('refunds/create'); ?>" id="refundForm"><input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
<?php if (!empty($collection)): ?><input type="hidden" name="fee_collection_id" value="<?php echo $collection['id']; ?>"><?php endif; ?>

<div class="row">
    <div class="col-md-4 mb-3">
        <label class="form-label">Class *</label>
        <select id="refundClassFilter" class="form-select" <?php echo !empty($student) ? '' : 'required'; ?> <?php echo !empty($student) ? 'disabled' : ''; ?>>
            <option value="">Select Class</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?php echo $class['id']; ?>" <?php echo (!empty($student) && ($student['class_id'] ?? '') == $class['id']) ? 'selected' : ''; ?>>
                    <?php echo e($class['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-4 mb-3">
        <label class="form-label">Student *</label>
        <select name="student_id" id="refundStudentSelect" class="form-select" required <?php echo !empty($student) ? 'disabled' : ''; ?>>
            <option value="">— Select Class First —</option>
            <?php if (!empty($student)): ?>
                <option value="<?php echo $student['id']; ?>" selected>
                    <?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? '')) . ' (' . ($student['admission_number'] ?? '') . ')'); ?>
                </option>
            <?php endif; ?>
        </select>
        <div class="form-text" id="refundStudentLoadStatus"></div>
        <?php if (!empty($student)): ?>
            <!-- Student was pre-selected (came from a fee collection record) so the
                 disabled select above won't submit; mirror its value here. -->
            <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
        <?php endif; ?>
    </div>
    <div class="col-md-4 mb-3"><label class="form-label">Refund Voucher Number *</label><input type="text" name="refund_voucher_number" class="form-control" required placeholder="Enter voucher number (manual)"></div>
</div>
<div class="row">
    <div class="col-md-4 mb-3"><label class="form-label">Amount *</label><input type="number" name="amount" class="form-control" step="0.01" required value="<?php echo $collection['paid_amount'] ?? ''; ?>"></div>
    <div class="col-md-4 mb-3"><label class="form-label">Refund Method *</label><select name="refund_method" class="form-select" required><option>Cash</option><option>Bank Transfer</option><option>Cheque</option></select></div>
    <div class="col-md-4 mb-3"><label class="form-label">Bank Account</label><select name="bank_account_id" class="form-select"><option value="">Select Bank</option><?php foreach ($banks as $b): ?><option value="<?php echo $b['id']; ?>"><?php echo e($b['bank_name']); ?></option><?php endforeach; ?></select></div>
</div>
<div class="row">
    <div class="col-md-3 mb-3"><label class="form-label">Status</label><select name="status" class="form-select"><option>Pending</option><option>Processed</option></select></div>
</div>
<div class="mb-3"><label class="form-label">Reason</label><textarea name="reason" class="form-control" rows="3" required></textarea></div>
<button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Process Refund</button>
</form>

<?php if (empty($student)): ?>
<script>
(function() {
    const studentsApiUrl = '<?php echo url('fees/studentsByClass'); ?>';
    const classFilter = document.getElementById('refundClassFilter');
    const studentSelect = document.getElementById('refundStudentSelect');
    const statusEl = document.getElementById('refundStudentLoadStatus');

    classFilter.addEventListener('change', function() {
        const classId = this.value;
        studentSelect.innerHTML = '<option value="">— Loading... —</option>';
        statusEl.textContent = '';

        if (!classId) {
            studentSelect.innerHTML = '<option value="">— Select Class First —</option>';
            return;
        }

        fetch(studentsApiUrl + '?class_id=' + encodeURIComponent(classId))
            .then(function(res) { return res.json(); })
            .then(function(students) {
                if (!Array.isArray(students) || students.length === 0) {
                    studentSelect.innerHTML = '<option value="">— No students in this class —</option>';
                    statusEl.textContent = 'No active students found for this class.';
                    return;
                }
                let opts = '<option value="">— Select Student —</option>';
                students.forEach(function(s) {
                    opts += '<option value="' + s.id + '">' + s.name + '</option>';
                });
                studentSelect.innerHTML = opts;
                statusEl.textContent = students.length + ' student(s) loaded.';
            })
            .catch(function() {
                studentSelect.innerHTML = '<option value="">— Select Class First —</option>';
                statusEl.textContent = 'Could not load students. Please try again.';
            });
    });
})();
</script>
<?php endif; ?>
