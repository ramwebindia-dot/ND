<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-key"></i> Permissions - <?php echo e($role['name'] ?? ''); ?></h4>
    <a href="<?php echo url('roles'); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="fas fa-arrow-left"></i> Back to Roles
    </a>
</div>

<form method="POST" action="<?php echo url('roles/permissions?id=' . ($role['id'] ?? '')); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token ?? ''; ?>">

    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-shield-alt me-2"></i>Manage Permissions for: <strong><?php echo e($role['name'] ?? ''); ?></strong></span>
            <div>
                <button type="button" class="btn btn-sm btn-outline-primary" onclick="checkAll(true)">Select All</button>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="checkAll(false)">Deselect All</button>
            </div>
        </div>
        <div class="card-body">
            <?php if (!empty($allPermissions)): ?>
            <?php foreach ($allPermissions as $module => $moduleData): ?>
            <?php
                // $moduleData = ['label' => 'Module Label', 'permissions' => [['key' => 'x.y', 'label' => 'Label'], ...]]
                $moduleLabel = is_array($moduleData) ? ($moduleData['label'] ?? ucfirst($module)) : ucfirst($module);
                $modulePerms = is_array($moduleData) && isset($moduleData['permissions']) ? $moduleData['permissions'] : [];
            ?>
            <div class="card mb-3">
                <div class="card-header bg-light">
                    <div class="d-flex align-items-center">
                        <?php
                        $moduleChecked = true;
                        foreach ($modulePerms as $perm) {
                            $permKey = is_array($perm) ? ($perm['key'] ?? '') : (string)$perm;
                            if (!in_array($permKey, $currentPermissions ?? [])) {
                                $moduleChecked = false;
                                break;
                            }
                        }
                        ?>
                        <input type="checkbox" class="form-check-input me-2 module-check"
                            data-module="<?php echo e($module); ?>"
                            id="module_<?php echo e($module); ?>"
                            <?php echo $moduleChecked ? 'checked' : ''; ?>>
                        <label class="form-check-label fw-bold" for="module_<?php echo e($module); ?>">
                            <?php echo e($moduleLabel); ?>
                        </label>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($modulePerms as $perm): ?>
                        <?php
                            $permKey   = is_array($perm) ? ($perm['key']   ?? '') : (string)$perm;
                            $permLabel = is_array($perm) ? ($perm['label'] ?? ucfirst($permKey)) : ucfirst((string)$perm);
                        ?>
                        <div class="col-md-3 col-sm-4 col-6 mb-2">
                            <div class="form-check">
                                <input type="checkbox" name="permissions[]"
                                    value="<?php echo e($permKey); ?>"
                                    class="form-check-input permission-check permission-<?php echo e($module); ?>"
                                    id="perm_<?php echo e(str_replace('.', '_', $permKey)); ?>"
                                    <?php echo in_array($permKey, $currentPermissions ?? []) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="perm_<?php echo e(str_replace('.', '_', $permKey)); ?>">
                                    <?php echo e($permLabel); ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <p class="text-muted text-center">No permissions defined in the system.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="text-end mb-3">
        <a href="<?php echo url('roles'); ?>" class="btn btn-secondary me-2">Cancel</a>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save me-1"></i> Save Permissions
        </button>
    </div>
</form>

<script>
function checkAll(state) {
    document.querySelectorAll('.permission-check').forEach(cb => cb.checked = state);
    document.querySelectorAll('.module-check').forEach(cb => cb.checked = state);
}
document.querySelectorAll('.module-check').forEach(function(moduleCb) {
    moduleCb.addEventListener('change', function() {
        var module = this.getAttribute('data-module');
        document.querySelectorAll('.permission-' + module).forEach(function(cb) {
            cb.checked = moduleCb.checked;
        });
    });
});
</script>
