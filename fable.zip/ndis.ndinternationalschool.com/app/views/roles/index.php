<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-shield"></i> Role & Permission Management</h4>
    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#createRoleModal">
        <i class="fas fa-plus"></i> Add Role
    </button>
</div>

<div class="card">
    <div class="card-body">
        <?php if (!empty($roles)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Role Name</th>
                        <th>Description</th>
                        <th>Users</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($roles as $i => $role): ?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><span class="badge bg-primary"><?php echo e($role['name']); ?></span></td>
                        <td><?php echo e($role['description'] ?? '-'); ?></td>
                        <td><span class="badge bg-secondary"><?php echo $role['user_count'] ?? 0; ?></span></td>
                        <td>
                            <a href="<?php echo url('roles/permissions?id=' . $role['id']); ?>" class="btn btn-sm btn-info" title="Manage Permissions">
                                <i class="fas fa-key"></i> Permissions
                            </a>
                            <button class="btn btn-sm btn-warning" onclick="editRole(<?php echo $role['id']; ?>, '<?php echo e($role['name']); ?>', '<?php echo e($role['description'] ?? ''); ?>')" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <?php if (($role['user_count'] ?? 0) == 0): ?>
                            <form method="POST" action="<?php echo url('roles/delete'); ?>" class="d-inline"
                                  onsubmit="return confirm('Delete role &quot;<?php echo e(addslashes($role['name'])); ?>&quot;?')">
                                <?php echo CSRF::field(); ?>
                                <input type="hidden" name="id" value="<?php echo $role['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php else: ?>
                            <button class="btn btn-sm btn-outline-danger" disabled title="Has users — cannot delete">
                                <i class="fas fa-trash"></i>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-user-shield fa-3x text-muted mb-3"></i>
            <p class="text-muted">No roles found. Create your first role.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Create Role Modal -->
<div class="modal fade" id="createRoleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('roles/create'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Role Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required maxlength="50">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Create Role</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Role Modal -->
<div class="modal fade" id="editRoleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('roles/update'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="edit_role_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Role</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Role Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="edit_role_name" class="form-control" required maxlength="50">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="edit_role_description" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Update Role</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editRole(id, name, description) {
    document.getElementById('edit_role_id').value = id;
    document.getElementById('edit_role_name').value = name;
    document.getElementById('edit_role_description').value = description;
    new bootstrap.Modal(document.getElementById('editRoleModal')).show();
}
</script>
