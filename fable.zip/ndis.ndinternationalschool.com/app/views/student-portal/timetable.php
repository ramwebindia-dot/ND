<div class="page-header">
    <h4><i class="fas fa-clock"></i> My Timetable</h4>
</div>

<?php
$days = ['Monday' => 1, 'Tuesday' => 2, 'Wednesday' => 3, 'Thursday' => 4, 'Friday' => 5, 'Saturday' => 6];
$periods = [];
foreach ($timetable ?? [] as $t) {
    $periods[$t['period_number']] = true;
}
$periodNumbers = array_keys($periods);
sort($periodNumbers, SORT_NUMERIC);
?>

<?php if (!empty($timetable)): ?>
<div class="card">
    <div class="card-header"><i class="fas fa-table me-2"></i>Weekly Schedule</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Day / Period</th>
                        <?php foreach ($periodNumbers as $p): ?>
                        <th class="text-center">Period <?php echo $p; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($days as $dayName => $dayNum): ?>
                    <tr>
                        <td><strong><?php echo $dayName; ?></strong></td>
                        <?php foreach ($periodNumbers as $p): ?>
                        <td class="text-center">
                            <?php
                            $found = null;
                            foreach ($timetable as $t) {
                                if ($t['day_of_week'] == $dayNum && $t['period_number'] == $p) {
                                    $found = $t;
                                    break;
                                }
                            }
                            ?>
                            <?php if ($found): ?>
                                <small><strong><?php echo e($found['subject_name']); ?></strong></small><br>
                                <small class="text-muted"><?php echo e($found['teacher_name']); ?></small>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="fas fa-clock fa-3x mb-3"></i>
        <p>No timetable available for your class.</p>
    </div>
</div>
<?php endif; ?>
