<div class="page-header">
    <h4><i class="fas fa-folder-open"></i> Learning Materials</h4>
</div>

<?php if (!empty($materials)): ?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Subject</th>
                        <th>Description</th>
                        <th>Uploaded By</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($materials as $mat): ?>
                    <tr>
                        <td><strong><?php echo e($mat['title']); ?></strong></td>
                        <td><?php echo e($mat['subject_name'] ?? '-'); ?></td>
                        <td><?php echo e(substr($mat['description'] ?? '', 0, 80)); ?><?php echo strlen($mat['description'] ?? '') > 80 ? '...' : ''; ?></td>
                        <td><?php echo e($mat['uploaded_by_name'] ?? '-'); ?></td>
                        <td><?php echo formatDate($mat['created_at']); ?></td>
                        <td>
                            <?php if (!empty($mat['file_path'])): ?>
                            <a href="<?php echo url('materials/download?id=' . $mat['id']); ?>" class="btn btn-sm btn-outline-primary-custom" target="_blank">
                                <i class="fas fa-download"></i> Download
                            </a>
                            <?php else: ?>
                            <span class="text-muted">No file</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="fas fa-folder-open fa-3x mb-3"></i>
        <p>No learning materials available yet.</p>
    </div>
</div>
<?php endif; ?>
