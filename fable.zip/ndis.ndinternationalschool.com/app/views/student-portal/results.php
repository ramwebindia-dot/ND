<div class="page-header">
    <h4><i class="fas fa-poll"></i> My Results</h4>
</div>

<?php if (!empty($marks)): ?>
<?php
$currentExam = '';
$examTotal = 0; $examMax = 0;
?>
<div class="card">
    <div class="card-header"><i class="fas fa-chart-bar me-2"></i>Exam Results</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Exam</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Marks Obtained</th>
                        <th>Total Marks</th>
                        <th>Percentage</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($marks as $mark): ?>
                    <tr>
                        <td><?php echo e($mark['exam_name']); ?></td>
                        <td><span class="badge bg-info"><?php echo e($mark['exam_type']); ?></span></td>
                        <td><?php echo e($mark['subject_name']); ?></td>
                        <td><strong><?php echo e($mark['marks_obtained']); ?></strong></td>
                        <td><?php echo e($mark['total_marks']); ?></td>
                        <td>
                            <?php
                            $pct = $mark['total_marks'] > 0 ? round(($mark['marks_obtained'] / $mark['total_marks']) * 100, 1) : 0;
                            $badgeClass = $pct >= 75 ? 'bg-success' : ($pct >= 50 ? 'bg-warning text-dark' : 'bg-danger');
                            ?>
                            <span class="badge <?php echo $badgeClass; ?>"><?php echo $pct; ?>%</span>
                        </td>
                        <td><span class="badge bg-primary"><?php echo e($mark['grade'] ?? '-'); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="fas fa-poll fa-3x mb-3"></i>
        <p>No exam results available yet.</p>
    </div>
</div>
<?php endif; ?>
