<div class="page-header">
    <h4><i class="fas fa-tasks me-2"></i>My Homework</h4>
</div>

<?php if (!empty($homework)): ?>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Subject</th>
                        <th>Title</th>
                        <th>Deadline</th>
                        <th>Attachment</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($homework as $hw):
                        $isPastDue = strtotime($hw['deadline']) < time();
                        $submitted = in_array($hw['submission_status'] ?? '', ['Submitted','Graded']);
                    ?>
                    <tr>
                        <td><?php echo e($hw['subject_name']); ?></td>
                        <td>
                            <strong><?php echo e($hw['title']); ?></strong>
                            <?php if (!empty($hw['description'])): ?>
                            <div class="text-muted small"><?php echo e(substr($hw['description'],0,60)); ?><?php echo strlen($hw['description'])>60?'…':''; ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo $isPastDue && !$submitted ? 'bg-danger' : 'bg-info'; ?>">
                                <?php echo formatDate($hw['deadline']); ?>
                            </span>
                            <?php if ($isPastDue && !$submitted): ?>
                            <div class="small text-danger">Overdue</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($hw['attachment'])): ?>
                            <a href="<?php echo asset($hw['attachment']); ?>" target="_blank" class="btn btn-xs btn-outline-info btn-sm">
                                <i class="fas fa-paperclip me-1"></i>View
                            </a>
                            <?php else: ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($hw['submission_status'] === 'Graded'): ?>
                                <span class="badge bg-success">Graded</span>
                                <?php if (!empty($hw['grade'])): ?>
                                <span class="badge bg-primary ms-1">Grade: <?php echo e($hw['grade']); ?></span>
                                <?php endif; ?>
                            <?php elseif ($hw['submission_status'] === 'Submitted'): ?>
                                <span class="badge bg-info">Submitted</span>
                                <div class="small text-muted"><?php echo formatDate($hw['submitted_at']); ?></div>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$submitted): ?>
                            <button class="btn btn-sm btn-primary" type="button"
                                    onclick="openSubmitModal(<?php echo $hw['id']; ?>, '<?php echo e(addslashes($hw['title'])); ?>')">
                                <i class="fas fa-upload me-1"></i>Submit
                            </button>
                            <?php else: ?>
                            <span class="text-muted small"><i class="fas fa-check text-success"></i> Done</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Submit Modal -->
<div class="modal fade" id="submitModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('homework/submit'); ?>" enctype="multipart/form-data">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="homework_id" id="submit_hw_id">
                <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-upload me-2"></i>Submit Homework</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted mb-3" id="submit_hw_title"></p>
                    <div class="mb-3">
                        <label class="form-label">Attach File (PDF / image / doc)</label>
                        <input type="file" name="file" class="form-control"
                               accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.zip">
                        <div class="form-text">Max 5 MB</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Remarks (optional)</label>
                        <textarea name="remarks" class="form-control" rows="3"
                                  placeholder="Any notes for the teacher..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-2"></i>Submit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openSubmitModal(hwId, hwTitle) {
    document.getElementById('submit_hw_id').value = hwId;
    document.getElementById('submit_hw_title').textContent = hwTitle;
    new bootstrap.Modal(document.getElementById('submitModal')).show();
}
</script>

<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="fas fa-tasks fa-3x mb-3 d-block"></i>
        <p>No homework assigned yet.</p>
    </div>
</div>
<?php endif; ?>
