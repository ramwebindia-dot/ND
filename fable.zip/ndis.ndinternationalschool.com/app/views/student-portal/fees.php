<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-rupee-sign"></i> My Fees</h4>
    <div class="text-end">
        <strong>Outstanding:</strong>
        <span class="badge <?php echo ($outstanding ?? 0) > 0 ? 'bg-danger' : 'bg-success'; ?> fs-6">
            <?php echo formatCurrency($outstanding ?? 0); ?>
        </span>
    </div>
</div>

<?php if (!empty($ledger)): ?>
<div class="card">
    <div class="card-header"><i class="fas fa-list me-2"></i>Fee Ledger</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th class="text-end">Debit</th>
                        <th class="text-end">Credit</th>
                        <th class="text-end">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ledger as $entry): ?>
                    <tr>
                        <td><?php echo formatDate($entry['date'] ?? $entry['created_at']); ?></td>
                        <td><?php echo e($entry['description']); ?></td>
                        <td class="text-end text-danger"><?php echo !empty($entry['debit']) ? formatCurrency($entry['debit']) : '-'; ?></td>
                        <td class="text-end text-success"><?php echo !empty($entry['credit']) ? formatCurrency($entry['credit']) : '-'; ?></td>
                        <td class="text-end"><strong><?php echo formatCurrency($entry['balance'] ?? 0); ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-5">
        <i class="fas fa-rupee-sign fa-3x mb-3"></i>
        <p>No fee records found.</p>
    </div>
</div>
<?php endif; ?>
