<div class="page-header">
    <h4><i class="fas fa-clipboard-check"></i> My Attendance</h4>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('student-portal/attendance'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Month</label>
                <select name="month" class="form-select">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                    <option value="<?php echo str_pad($m, 2, '0', STR_PAD_LEFT); ?>" <?php echo $month == str_pad($m, 2, '0', STR_PAD_LEFT) ? 'selected' : ''; ?>>
                        <?php echo date('F', mktime(0, 0, 0, $m, 1)); ?>
                    </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Year</label>
                <select name="year" class="form-select">
                    <?php for ($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                    <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<?php
$present = 0; $absent = 0; $late = 0; $total = count($attendance ?? []);
foreach ($attendance ?? [] as $a) {
    if ($a['status'] === 'Present') $present++;
    elseif ($a['status'] === 'Absent') $absent++;
    elseif ($a['status'] === 'Late') $late++;
}
$percentage = $total > 0 ? round(($present / $total) * 100, 1) : 0;
?>

<div class="row mb-3">
    <div class="col-md-3">
        <div class="card text-white bg-success text-center">
            <div class="card-body"><h6>Present</h6><h3><?php echo $present; ?></h3></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger text-center">
            <div class="card-body"><h6>Absent</h6><h3><?php echo $absent; ?></h3></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning text-center">
            <div class="card-body"><h6>Late</h6><h3><?php echo $late; ?></h3></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white" style="background-color: var(--primary-color);">
            <div class="card-body text-center"><h6>Attendance %</h6><h3><?php echo $percentage; ?>%</h3></div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><i class="fas fa-calendar me-2"></i>Attendance for <?php echo date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?></div>
    <div class="card-body">
        <?php if (!empty($attendance)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance as $a): ?>
                    <tr>
                        <td><?php echo formatDate($a['date']); ?></td>
                        <td>
                            <?php if ($a['status'] === 'Present'): ?>
                                <span class="badge bg-success">Present</span>
                            <?php elseif ($a['status'] === 'Absent'): ?>
                                <span class="badge bg-danger">Absent</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Late</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($a['remarks'] ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p class="text-muted text-center mb-0">No attendance records found for this period.</p>
        <?php endif; ?>
    </div>
</div>
