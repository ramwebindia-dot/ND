<div class="page-header">
    <h4><i class="fas fa-user-graduate me-2"></i>Student Dashboard</h4>
</div>

<div class="row g-3 mb-3">
<!-- Profile Card -->
<div class="col-lg-3">
    <div class="card mb-3">
        <div class="card-body text-center">
            <?php if (!empty($student['photo'])): ?>
            <img src="<?php echo asset($student['photo']); ?>" class="rounded-circle mb-2" width="80" height="80" style="object-fit:cover;">
            <?php else: ?>
            <i class="fas fa-user-circle fa-4x text-muted mb-2 d-block"></i>
            <?php endif; ?>
            <h6 class="mb-1 fw-bold"><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></h6>
            <div class="text-muted small">Adm: <?php echo e($student['admission_number']??'—'); ?></div>
            <div class="text-muted small"><?php echo e($student['class_name']??''); ?> <?php echo isset($student['section_name']) ? '| '.$student['section_name'] : ''; ?></div>
            <div class="text-muted small">Roll: <?php echo e($student['roll_number']??'—'); ?></div>
        </div>
    </div>
    <!-- Quick Links -->
    <div class="list-group list-group-flush rounded shadow-sm">
        <a href="<?php echo url('student-portal/fees'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-rupee-sign text-success"></i> My Fees
            <?php if (($outstanding ?? 0) > 0): ?>
            <span class="badge bg-danger ms-auto">Due ₹<?php echo number_format($outstanding,0); ?></span>
            <?php endif; ?>
        </a>
        <a href="<?php echo url('student-portal/homework'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-tasks text-warning"></i> Homework
            <span class="badge bg-warning text-dark ms-auto"><?php echo count($homework??[]); ?></span>
        </a>
        <a href="<?php echo url('student-portal/results'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-file-alt text-primary"></i> Results
        </a>
        <a href="<?php echo url('student-portal/timetable'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-clock text-info"></i> Timetable
        </a>
        <a href="<?php echo url('student-portal/attendance'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-clipboard-check text-secondary"></i> Attendance
        </a>
        <a href="<?php echo url('student-portal/materials'); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
            <i class="fas fa-folder-open text-orange" style="color:#fd7e14;"></i> Study Materials
        </a>
    </div>
</div>

<!-- Main Content -->
<div class="col-lg-9">
    <!-- Stat Cards -->
    <div class="row g-3 mb-3">
        <div class="col-md-3">
            <div class="card text-center border-<?php echo ($outstanding??0)>0?'danger':'success'; ?>">
                <div class="card-body py-2">
                    <div class="fw-bold <?php echo ($outstanding??0)>0?'text-danger':'text-success'; ?>">₹<?php echo number_format($outstanding??0,0); ?></div>
                    <div class="small text-muted">Outstanding Fee</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-warning">
                <div class="card-body py-2">
                    <div class="fw-bold text-warning"><?php echo count($homework??[]); ?></div>
                    <div class="small text-muted">Pending Homework</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-primary">
                <div class="card-body py-2">
                    <div class="fw-bold text-primary"><?php echo count($exams??[]); ?></div>
                    <div class="small text-muted">Upcoming Exams</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center border-info">
                <div class="card-body py-2">
                    <div class="fw-bold text-info"><?php echo count($notices??[]); ?></div>
                    <div class="small text-muted">Active Notices</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <!-- Homework -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold"><i class="fas fa-tasks me-2 text-warning"></i>Pending Homework</span>
                    <a href="<?php echo url('student-portal/homework'); ?>" class="btn btn-sm btn-outline-warning">View All</a>
                </div>
                <div class="list-group list-group-flush">
                    <?php if (empty($homework)): ?>
                    <div class="list-group-item text-muted text-center py-3">No pending homework.</div>
                    <?php else: ?>
                    <?php foreach (array_slice($homework, 0, 4) as $hw): ?>
                    <div class="list-group-item">
                        <div class="fw-medium"><?php echo e($hw['title']); ?></div>
                        <div class="small text-muted"><?php echo e($hw['subject_name']); ?> · Due: <?php echo formatDate($hw['deadline']); ?>
                            <?php if (strtotime($hw['deadline']) < strtotime('today')): ?>
                            <span class="badge bg-danger ms-1">Overdue</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Upcoming Exams -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold"><i class="fas fa-file-alt me-2 text-primary"></i>Upcoming Exams</span>
                    <a href="<?php echo url('student-portal/results'); ?>" class="btn btn-sm btn-outline-primary">Results</a>
                </div>
                <div class="list-group list-group-flush">
                    <?php if (empty($exams)): ?>
                    <div class="list-group-item text-muted text-center py-3">No upcoming exams.</div>
                    <?php else: ?>
                    <?php foreach ($exams as $ex): ?>
                    <div class="list-group-item">
                        <div class="fw-medium"><?php echo e($ex['name']); ?></div>
                        <div class="small text-muted"><?php echo e($ex['exam_type']??''); ?> · <?php echo formatDate($ex['start_date']); ?>
                            <span class="badge bg-<?php echo $ex['status']==='Ongoing'?'success':'info'; ?> ms-1"><?php echo e($ex['status']); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Notices -->
        <?php if (!empty($notices)): ?>
        <div class="col-12">
            <div class="card">
                <div class="card-header fw-bold"><i class="fas fa-bullhorn me-2 text-danger"></i>Notices</div>
                <div class="list-group list-group-flush">
                    <?php foreach (array_slice($notices, 0, 3) as $n): ?>
                    <div class="list-group-item">
                        <div class="fw-medium"><?php echo e($n['title']); ?></div>
                        <div class="small text-muted"><?php echo e(substr($n['content']??'',0,100)); ?>...</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>
