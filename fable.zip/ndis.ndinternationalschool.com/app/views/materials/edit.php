<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Learning Material</h4>
    <a href="<?php echo url('materials'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('materials/edit?id=' . $material['id']); ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($material['title']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" class="form-select" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>" <?php echo $material['class_id'] == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Subject ID <span class="text-danger">*</span></label>
                    <input type="number" name="subject_id" class="form-control" value="<?php echo e($material['subject_id']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">File</label>
                    <input type="file" name="file_path" class="form-control">
                    <?php if (!empty($material['file_path'])): ?>
                        <small class="text-muted">Current: <a href="<?php echo asset($material['file_path']); ?>" target="_blank">View File</a></small>
                    <?php endif; ?>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Material Type</label>
                    <select name="material_type" class="form-select">
                        <option value="Document" <?php echo ($material['material_type'] ?? 'Document') === 'Document' ? 'selected' : ''; ?>>Document</option>
                        <option value="Video" <?php echo ($material['material_type'] ?? '') === 'Video' ? 'selected' : ''; ?>>Video Link</option>
                        <option value="Presentation" <?php echo ($material['material_type'] ?? '') === 'Presentation' ? 'selected' : ''; ?>>Presentation</option>
                        <option value="Other" <?php echo ($material['material_type'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3"><?php echo e($material['description'] ?? ''); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-check me-1"></i>Update Material</button>
        </form>
    </div>
</div>