<div class="page-header">
    <h4><i class="fas fa-upload"></i> Upload Learning Material</h4>
    <a href="<?php echo url('materials'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('materials/create'); ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" class="form-select" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>"><?php echo e($class['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Subject ID <span class="text-danger">*</span></label>
                    <input type="number" name="subject_id" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">File <span class="text-danger">*</span></label>
                    <input type="file" name="file_path" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Material Type</label>
                    <select name="material_type" class="form-select">
                        <option value="Document">Document</option>
                        <option value="Video">Video Link</option>
                        <option value="Presentation">Presentation</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-check me-1"></i>Upload Material</button>
        </form>
    </div>
</div>