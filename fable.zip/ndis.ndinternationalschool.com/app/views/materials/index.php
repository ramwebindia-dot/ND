<div class="page-header">
    <h4><i class="fas fa-book-reader"></i> Learning Materials</h4>
    <a href="<?php echo url('materials/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Upload Material</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('materials'); ?>" class="row g-2">
            <div class="col-md-4">
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" <?php echo $classId == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <input type="number" name="subject_id" class="form-control" placeholder="Subject ID" value="<?php echo e($subjectId); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>File</th>
                        <th>Uploaded</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($materials)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">No materials found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($materials as $i => $mat): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($mat['title']); ?></strong></td>
                            <td><?php echo e($mat['class_name'] ?? '-'); ?></td>
                            <td><?php echo e($mat['subject_name'] ?? '-'); ?></td>
                            <td>
                                <?php if (!empty($mat['file_path'])): ?>
                                    <a href="<?php echo asset($mat['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-info"><i class="fas fa-download me-1"></i>Download</a>
                                <?php else: ?>
                                    <span class="text-muted">No file</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo formatDate($mat['created_at']); ?></td>
                            <td>
                                <a href="<?php echo url('materials/edit?id=' . $mat['id']); ?>" class="btn btn-sm btn-outline-info" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo url('materials/delete?id=' . $mat['id']); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this material?')" title="Delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
