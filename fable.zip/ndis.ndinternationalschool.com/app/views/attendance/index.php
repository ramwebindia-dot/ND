<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-clipboard-check me-2"></i>Attendance</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('attendance/monthly-report'); ?>" class="btn btn-outline-info btn-sm">
            <i class="fas fa-calendar-alt me-1"></i>Monthly Report
        </a>
    </div>
</div>
<ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link active" href="<?php echo url('attendance'); ?>">Student</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo url('attendance/teacher'); ?>">Teacher</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo url('attendance/report'); ?>">Report</a></li>
</ul>
<div class="card"><div class="card-header d-flex justify-content-between"><h6>Mark Student Attendance</h6><span class="text-muted"><?php echo date('d-m-Y'); ?></span></div>
<div class="card-body">
<form method="POST" action="<?php echo url('attendance/mark'); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <input type="hidden" name="type" value="student">
    <div class="row mb-3">
        <div class="col-md-3"><label class="form-label">Date</label><input type="date" name="attendance_date" class="form-control" value="<?php echo date('Y-m-d'); ?>"></div>
        <div class="col-md-3"><label class="form-label">Class *</label><select name="class_id" class="form-select" required id="classSelect"><option value="">Select</option><?php foreach ($classes as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3"><label class="form-label">Section</label><select name="section_id" class="form-select" id="sectionSelect"><option value="">All</option></select></div>
    </div>
    <div id="studentList"></div>
    <div class="d-flex gap-2 flex-wrap mt-2">
        <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Attendance</button>
        <button type="button" class="btn btn-outline-success" id="bulkMarkBtn" style="display:none"
                onclick="bulkMarkPresent()">
            <i class="fas fa-check-double me-1"></i>Mark All Present
        </button>
        <button type="button" class="btn btn-outline-warning" id="sendSmsBtn" style="display:none"
                onclick="sendAbsentSms()">
            <i class="fas fa-sms me-1"></i>SMS Absentees
        </button>
    </div>
</form>
</div></div>

<script>
document.getElementById('classSelect').addEventListener('change', function() {
    const cid = this.value;
    const sectionSelect = document.getElementById('sectionSelect');
    sectionSelect.innerHTML = '<option value="">All</option>';
    if (!cid) { document.getElementById('studentList').innerHTML = ''; return; }

    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + cid)
        .then(r => r.json())
        .then(data => {
            data.forEach(s => { sectionSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`; });
        })
        .catch(() => {});

    fetch('<?php echo url("attendance/get-students?class_id="); ?>' + cid)
        .then(r => r.json())
        .then(data => {
            let html = '<table class="table table-hover"><thead><tr><th>Roll</th><th>Name</th><th>Status</th></tr></thead><tbody>';
            data.forEach(s => {
                html += `<tr><td>${s.roll_number || '-'}</td><td>${s.first_name} ${s.last_name}</td>
                <td><select name="attendance[${s.id}]" class="form-select form-select-sm" style="width:120px">
                    <option value="Present">Present</option><option value="Absent">Absent</option><option value="Late">Late</option>
                </select></td></tr>`;
            });
            html += '</tbody></table>';
            document.getElementById('studentList').innerHTML = html;
            document.getElementById('bulkMarkBtn').style.display = '';
            document.getElementById('sendSmsBtn').style.display = '';
        });
});

function bulkMarkPresent() {
    if (!confirm('Mark all students as Present?')) return;
    const cid  = document.getElementById('classSelect').value;
    const date = document.querySelector('[name="attendance_date"]').value;
    if (!cid) { alert('Please select a class first.'); return; }
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?php echo url("attendance/bulk-mark-present"); ?>';
    form.innerHTML = `<?php echo CSRF::field(); ?><input name="class_id" value="${cid}"><input name="date" value="${date}">`;
    document.body.appendChild(form);
    form.submit();
}

function sendAbsentSms() {
    if (!confirm('Send SMS to parents of absent students?')) return;
    const cid  = document.getElementById('classSelect').value;
    const date = document.querySelector('[name="attendance_date"]').value;
    if (!cid) { alert('Please select a class first.'); return; }
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?php echo url("attendance/send-absent-sms"); ?>';
    form.innerHTML = `<?php echo CSRF::field(); ?><input name="class_id" value="${cid}"><input name="date" value="${date}">`;
    document.body.appendChild(form);
    form.submit();
}
</script>