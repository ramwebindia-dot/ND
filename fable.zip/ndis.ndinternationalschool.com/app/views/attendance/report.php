<?php
/** @var array $report */
/** @var array $classes */
$type = $type ?? 'student';
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><?php echo e($pageTitle ?? 'Attendance Report'); ?></h1>
    </div>

    <ul class="nav nav-pills mb-3">
        <li class="nav-item">
            <a class="nav-link <?php echo $type === 'student' ? 'active' : ''; ?>" href="<?php echo url('attendance/report?type=student'); ?>">Student Report</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $type === 'teacher' ? 'active' : ''; ?>" href="<?php echo url('attendance/report?type=teacher'); ?>">Teacher Report</a>
        </li>
    </ul>

    <div class="card mb-4">
        <div class="card-header">Filter</div>
        <div class="card-body">
            <form method="GET" action="<?php echo url('attendance/report'); ?>" class="row g-3">
                <input type="hidden" name="type" value="<?php echo e($type); ?>">
                <?php if ($type === 'student'): ?>
                <div class="col-md-3">
                    <label class="form-label">Class</label>
                    <select name="class_id" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach ($classes ?? [] as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $c['id']) ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" value="<?php echo e($_GET['from_date'] ?? date('Y-m-01')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" value="<?php echo e($_GET['to_date'] ?? date('Y-m-d')); ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">Generate Report</button>
                </div>
            </form>
        </div>
    </div>

    <?php if (!empty($report)): ?>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <?php if ($type === 'teacher'): ?>
                    <thead class="table-light">
                        <tr><th>Employee ID</th><th>Teacher</th><th>Present</th><th>Absent</th><th>Late</th><th>Half Day</th><th>Total</th><th>%</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($report as $row): ?>
                    <tr>
                        <td><?php echo e($row['employee_id'] ?? '-'); ?></td>
                        <td><?php echo e(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')); ?></td>
                        <td class="text-success"><?php echo $row['present'] ?? 0; ?></td>
                        <td class="text-danger"><?php echo $row['absent'] ?? 0; ?></td>
                        <td class="text-warning"><?php echo $row['late'] ?? 0; ?></td>
                        <td><?php echo $row['half_day'] ?? 0; ?></td>
                        <td><?php echo $row['total'] ?? 0; ?></td>
                        <td><?php $t = $row['total'] ?? 0; $p = $row['present'] ?? 0; echo $t > 0 ? round(($p/$t)*100, 1).'%' : '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <?php else: ?>
                    <thead class="table-light">
                        <tr><th>Student</th><th>Class</th><th>Present</th><th>Absent</th><th>Late</th><th>Total</th><th>%</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($report as $row): ?>
                    <tr>
                        <td><?php echo e(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')); ?></td>
                        <td><?php echo e($row['class_name'] ?? '-'); ?></td>
                        <td class="text-success"><?php echo $row['present'] ?? 0; ?></td>
                        <td class="text-danger"><?php echo $row['absent'] ?? 0; ?></td>
                        <td class="text-warning"><?php echo $row['late'] ?? 0; ?></td>
                        <td><?php echo $row['total'] ?? 0; ?></td>
                        <td><?php $t = $row['total'] ?? 0; $p = $row['present'] ?? 0; echo $t > 0 ? round(($p/$t)*100, 1).'%' : '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">Select filters and click Generate Report.</div>
    <?php endif; ?>
</div>
