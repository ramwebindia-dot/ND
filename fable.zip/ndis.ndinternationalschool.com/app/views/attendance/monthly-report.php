<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calendar-alt me-2"></i>Monthly Attendance Report</h4>
    <?php if (!empty($report)): ?>
    <button onclick="window.print()" class="btn btn-outline-primary btn-sm no-print">
        <i class="fas fa-print me-1"></i>Print
    </button>
    <?php endif; ?>
</div>

<div class="card mb-3 no-print">
    <div class="card-body">
        <form method="GET" action="<?php echo url('attendance/monthly-report'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select form-select-sm" required>
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo $classId==$c['id']?'selected':''; ?>><?php echo e($c['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Month</label>
                <input type="month" name="month" value="<?php echo e($month); ?>" class="form-control form-control-sm" required>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">Generate</button>
            </div>
        </form>
    </div>
</div>

<?php if (!empty($report)): ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-bold">
            Report for <?php echo date('F Y', strtotime($month.'-01')); ?>
            | Working Days: <strong><?php echo $workingDays; ?></strong>
        </span>
        <a href="<?php echo url('attendance/monthly-report?class_id='.$classId.'&month='.$month.'&export=csv'); ?>" class="btn btn-success btn-sm no-print">
            <i class="fas fa-download me-1"></i>Export CSV
        </a>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-bordered table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Student Name</th>
                    <th>Roll</th>
                    <th class="text-success">Present</th>
                    <th class="text-danger">Absent</th>
                    <th class="text-warning">Late</th>
                    <th>Total</th>
                    <th>%</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($report as $i => $r):
                $pct = $r['total_days'] > 0 ? round($r['present'] / $r['total_days'] * 100) : 0;
                $color = $pct >= 75 ? 'success' : ($pct >= 60 ? 'warning' : 'danger');
            ?>
            <tr>
                <td><?php echo $i+1; ?></td>
                <td><?php echo e($r['name']); ?></td>
                <td><?php echo e($r['roll_number']??'—'); ?></td>
                <td class="text-success fw-bold"><?php echo $r['present']; ?></td>
                <td class="text-danger fw-bold"><?php echo $r['absent']; ?></td>
                <td class="text-warning fw-bold"><?php echo $r['late']; ?></td>
                <td><?php echo $r['total_days']; ?></td>
                <td>
                    <span class="badge bg-<?php echo $color; ?>"><?php echo $pct; ?>%</span>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
@media print {
    .no-print { display:none!important; }
    .sidebar,.navbar,.main-footer { display:none!important; }
    body { background:white!important; }
}
</style>
<?php endif; ?>
