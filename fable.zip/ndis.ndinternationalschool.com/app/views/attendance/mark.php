<?php /** @var array $classes, $sections, $students, $existingAttendance, $selectedClass, $selectedSection, $date */ ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><?php echo e($pageTitle ?? 'Mark Attendance'); ?></h1>
    </div>
    <div class="card mb-4">
        <div class="card-header">Select Class &amp; Date</div>
        <div class="card-body">
            <form method="GET" action="<?php echo url('attendance/mark'); ?>" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Class</label>
                    <select name="class_id" class="form-select" onchange="this.form.submit()">
                        <option value="">Select Class</option>
                        <?php foreach ($classes ?? [] as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo ($selectedClass ?? 0) == $c['id'] ? 'selected' : ''; ?>>
                            <?php echo e($c['name'] ?? ''); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?php echo e($date ?? date('Y-m-d')); ?>" onchange="this.form.submit()">
                </div>
            </form>
        </div>
    </div>
    <?php if (!empty($students)): ?>
    <div class="card">
        <div class="card-header">Mark Attendance - <?php echo count($students); ?> Students</div>
        <div class="card-body p-0">
            <form method="POST" action="<?php echo url('attendance/mark'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="class_id" value="<?php echo e($selectedClass ?? ''); ?>">
                <input type="hidden" name="date" value="<?php echo e($date ?? date('Y-m-d')); ?>">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr><th>#</th><th>Student</th><th>Roll No</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($students as $i => $stu): ?>
                        <?php $existing = $existingAttendance[$stu['id']] ?? 'Present'; ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo e(($stu['first_name'] ?? '') . ' ' . ($stu['last_name'] ?? '')); ?></td>
                            <td><?php echo e($stu['roll_number'] ?? '-'); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <?php foreach (['Present', 'Absent', 'Late', 'Leave'] as $status): ?>
                                    <input type="radio" class="btn-check" name="attendance[<?php echo $stu['id']; ?>]"
                                        id="att_<?php echo $stu['id'] . '_' . $status; ?>"
                                        value="<?php echo $status; ?>" <?php echo $existing === $status ? 'checked' : ''; ?>>
                                    <label class="btn btn-outline-<?php echo $status === 'Present' ? 'success' : ($status === 'Absent' ? 'danger' : ($status === 'Late' ? 'warning' : 'info')); ?>"
                                        for="att_<?php echo $stu['id'] . '_' . $status; ?>"><?php echo $status; ?></label>
                                    <?php endforeach; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="p-3">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i> Save Attendance</button>
                </div>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">Select a class to mark attendance.</div>
    <?php endif; ?>
</div>
