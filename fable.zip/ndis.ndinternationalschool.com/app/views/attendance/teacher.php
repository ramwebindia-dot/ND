<?php /** @var array $teachers, $existingAttendance */ ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><?php echo e($pageTitle ?? 'Teacher Attendance'); ?></h1>
    </div>

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between">
            <h6 class="mb-0">Mark Teacher Attendance</h6>
            <span class="text-muted"><?php echo e($date ?? date('Y-m-d')); ?></span>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo url('attendance/teacher'); ?>" class="row g-3 mb-3">
                <div class="col-md-3">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?php echo e($date ?? date('Y-m-d')); ?>" onchange="this.form.submit()">
                </div>
            </form>

            <?php if (empty($teachers)): ?>
                <p class="text-muted">No active teachers found.</p>
            <?php else: ?>
            <form method="POST" action="<?php echo url('attendance/teacher'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="date" value="<?php echo e($date ?? date('Y-m-d')); ?>">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>Employee ID</th><th>Name</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($teachers as $t): ?>
                            <?php $current = $existingAttendance[$t['id']] ?? 'Present'; ?>
                            <tr>
                                <td><?php echo e($t['employee_id'] ?? '-'); ?></td>
                                <td><?php echo e(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? '')); ?></td>
                                <td>
                                    <select name="attendance[<?php echo (int) $t['id']; ?>]" class="form-select form-select-sm" style="width:140px">
                                        <option value="Present" <?php echo $current === 'Present' ? 'selected' : ''; ?>>Present</option>
                                        <option value="Absent" <?php echo $current === 'Absent' ? 'selected' : ''; ?>>Absent</option>
                                        <option value="Late" <?php echo $current === 'Late' ? 'selected' : ''; ?>>Late</option>
                                        <option value="Half Day" <?php echo $current === 'Half Day' ? 'selected' : ''; ?>>Half Day</option>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Attendance</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
