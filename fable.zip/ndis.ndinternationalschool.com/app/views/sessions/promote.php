<?php /** @var array $sessions, $students, $activeSession */ ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><?php echo e($pageTitle ?? 'Promote Students'); ?></h1>
        <a href="<?php echo url('sessions'); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back
        </a>
    </div>
    <div class="card">
        <div class="card-body">
            <?php if (empty($sessions)): ?>
                <div class="alert alert-warning">No sessions available. Please create at least two sessions.</div>
            <?php else: ?>
            <form method="POST" action="<?php echo url('sessions/promote'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">From Session</label>
                        <select name="from_session_id" class="form-select" required>
                            <?php foreach ($sessions as $s): ?>
                            <option value="<?php echo $s['id']; ?>" <?php echo (($activeSession['id'] ?? 0) == $s['id']) ? 'selected' : ''; ?>>
                                <?php echo e($s['name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">To Session</label>
                        <select name="to_session_id" class="form-select" required>
                            <?php foreach ($sessions as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if (!empty($students)): ?>
                <div class="mb-3">
                    <label class="form-label">Select Students to Promote</label>
                    <div class="mb-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.querySelectorAll('[name=\"student_ids[]\"]').forEach(c=>c.checked=true)">Select All</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.querySelectorAll('[name=\"student_ids[]\"]').forEach(c=>c.checked=false)">Deselect All</button>
                    </div>
                    <div class="table-responsive" style="max-height:400px;overflow-y:auto;">
                        <table class="table table-sm table-hover">
                            <thead><tr><th>Select</th><th>Name</th><th>Class</th></tr></thead>
                            <tbody>
                            <?php foreach ($students as $stu): ?>
                            <tr>
                                <td><input type="checkbox" name="student_ids[]" value="<?php echo $stu['id']; ?>" class="form-check-input"></td>
                                <td><?php echo e(($stu['first_name'] ?? '') . ' ' . ($stu['last_name'] ?? '')); ?></td>
                                <td><?php echo e($stu['class_id'] ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-level-up-alt me-1"></i> Promote Students
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
