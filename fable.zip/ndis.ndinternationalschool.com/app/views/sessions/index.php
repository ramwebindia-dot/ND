<div class="page-header">
    <h4><i class="fas fa-calendar-alt"></i> Academic Sessions</h4>
    <a href="<?php echo url('sessions/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>New Session</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Session Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sessions)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No academic sessions found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($sessions as $i => $session): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($session['name']); ?></strong></td>
                            <td><?php echo formatDate($session['start_date']); ?></td>
                            <td><?php echo formatDate($session['end_date']); ?></td>
                            <td>
                                <?php if ($session['is_active']): ?>
                                    <span class="badge badge-success-custom">Active</span>
                                <?php elseif ($session['is_archived']): ?>
                                    <span class="badge badge-secondary-custom">Archived</span>
                                <?php else: ?>
                                    <span class="badge badge-info-custom">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$session['is_active'] && !$session['is_archived']): ?>
                                    <form method="POST" action="<?php echo url('sessions/activate'); ?>" class="d-inline" onsubmit="return confirm('Activate this session? This will deactivate the current active session.')">
                                        <?php echo CSRF::field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $session['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Activate</button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($session['is_active'] && !$session['is_archived']): ?>
                                    <form method="POST" action="<?php echo url('sessions/archive'); ?>" class="d-inline" onsubmit="return confirm('Archive this session? This action cannot be undone.')">
                                        <?php echo CSRF::field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $session['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-warning"><i class="fas fa-archive"></i> Archive</button>
                                    </form>
                                    <a href="<?php echo url('sessions/promote'); ?>" class="btn btn-sm btn-info"><i class="fas fa-arrow-up"></i> Promote</a>
                                <?php endif; ?>
                                <a href="<?php echo url('sessions/edit?id=' . $session['id']); ?>" class="btn btn-sm btn-outline-primary-custom"><i class="fas fa-edit"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
