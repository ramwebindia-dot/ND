<div class="page-header">
    <h4><i class="fas fa-plus-circle"></i> <?php echo isset($session) ? 'Edit' : 'Create'; ?> Academic Session</h4>
    <a href="<?php echo url('sessions'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('sessions/create'); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <?php if (!empty($session['id'])): ?>
                <input type="hidden" name="id" value="<?php echo e($session['id']); ?>">
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Session Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($session['name'] ?? ''); ?>" required placeholder="e.g., 2025-2026">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Start Date <span class="text-danger">*</span></label>
                    <input type="date" name="start_date" class="form-control" value="<?php echo e($session['start_date'] ?? ''); ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">End Date <span class="text-danger">*</span></label>
                    <input type="date" name="end_date" class="form-control" value="<?php echo e($session['end_date'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?php echo e($session['description'] ?? ''); ?></textarea>
                </div>
            </div>

            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Session</button>
        </form>
    </div>
</div>
