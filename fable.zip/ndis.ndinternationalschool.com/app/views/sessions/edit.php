<?php /** @var array $session */ ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3"><?php echo e($pageTitle ?? 'Edit Session'); ?></h1>
        <a href="<?php echo url('sessions'); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back
        </a>
    </div>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo url('sessions/edit?id=' . ($session['id'] ?? '')); ?>">
                <?php echo CSRF::field(); ?>
                <div class="mb-3">
                    <label class="form-label">Session Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($session['name'] ?? ''); ?>" required>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Start Date <span class="text-danger">*</span></label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo e($session['start_date'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">End Date <span class="text-danger">*</span></label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo e($session['end_date'] ?? ''); ?>" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Session
                </button>
            </form>
        </div>
    </div>
</div>
