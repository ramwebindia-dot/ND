<div class="page-header">
    <h4><i class="fas fa-tags"></i> Book Categories</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#catModal">
        <i class="fas fa-plus me-1"></i>Add Category
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                        <tr><td colspan="4" class="text-center text-muted py-3">No categories found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($categories as $i => $cat): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($cat['name']); ?></strong></td>
                            <td><?php echo e($cat['description'] ?? '-'); ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-info edit-lcat" data-id="<?php echo $cat['id']; ?>" data-name="<?php echo e($cat['name']); ?>" data-desc="<?php echo e($cat['description'] ?? ''); ?>" title="Edit"><i class="fas fa-edit"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Category Modal -->
<div class="modal fade" id="catModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('library/saveCategory'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="lcat_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title" id="catModalLabel">Add Book Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Category Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="lcat_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="lcat_desc" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Save Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-lcat').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('lcat_id').value = this.dataset.id;
        document.getElementById('lcat_name').value = this.dataset.name;
        document.getElementById('lcat_desc').value = this.dataset.desc;
        document.getElementById('catModalLabel').textContent = 'Edit Book Category';
        new bootstrap.Modal(document.getElementById('catModal')).show();
    });
});
</script>
