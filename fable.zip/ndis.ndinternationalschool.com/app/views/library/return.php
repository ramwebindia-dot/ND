<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-undo me-2"></i>Return Book</h4>
    <a href="<?php echo url('library/issued'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<?php
$dueDate     = strtotime($issue['due_date']);
$today       = strtotime('today');
$daysOverdue = max(0, (int)(($today - $dueDate) / 86400));
$finePerDay  = 2; // ₹2/day default — can come from settings
$calcFine    = $daysOverdue * $finePerDay;
?>

<div class="card mb-3">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-4">
                <div class="text-muted small">Book</div>
                <strong><?php echo e($book['title'] ?? '—'); ?></strong><br>
                <span class="text-muted small"><?php echo e($book['author'] ?? ''); ?></span>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Student</div>
                <?php if ($student): ?>
                <strong><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></strong><br>
                <span class="text-muted small">Adm: <?php echo e($student['admission_number']??'—'); ?></span>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="text-muted small">Dates</div>
                <div>Issued: <?php echo formatDate($issue['issue_date']); ?></div>
                <div>Due: <?php echo formatDate($issue['due_date']); ?>
                    <?php if ($daysOverdue > 0): ?>
                    <span class="badge bg-danger ms-1"><?php echo $daysOverdue; ?> days overdue</span>
                    <?php else: ?>
                    <span class="badge bg-success ms-1">On time</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($daysOverdue > 0): ?>
<div class="alert alert-warning">
    <i class="fas fa-exclamation-triangle me-2"></i>
    This book is <strong><?php echo $daysOverdue; ?> day(s)</strong> overdue.
    Suggested fine: <strong>₹<?php echo $calcFine; ?></strong> (₹<?php echo $finePerDay; ?>/day)
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header fw-bold">Process Return</div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('library/return-book?id='.$issue['id']); ?>">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Return Date</label>
                    <input type="date" name="return_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Fine Amount (₹)</label>
                    <input type="number" name="fine_amount" class="form-control" step="0.50" min="0"
                           value="<?php echo $calcFine; ?>" id="fineInput">
                    <div class="form-text">Auto-calculated at ₹<?php echo $finePerDay; ?>/day. Adjust if needed.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Condition on Return</label>
                    <select name="condition" class="form-select">
                        <option value="Good">Good</option>
                        <option value="Damaged">Damaged</option>
                        <option value="Lost">Lost</option>
                    </select>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-check me-2"></i>Return Book<?php echo $calcFine > 0 ? " & Collect Fine" : ""; ?>
                </button>
            </div>
        </form>
    </div>
</div>
