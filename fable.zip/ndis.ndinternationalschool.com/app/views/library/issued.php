<div class="page-header">
    <h4><i class="fas fa-book-open"></i> Issued Books</h4>
    <div>
        <a href="<?php echo url('library/issue'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Issue New</a>
        <a href="<?php echo url('library/overdue'); ?>" class="btn btn-outline-danger"><i class="fas fa-exclamation-triangle me-1"></i>Overdue</a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Book Title</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($issued)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">No issued books found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($issued as $i => $issue): ?>
                        <tr>
                            <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                            <td><strong><?php echo e($issue['book_title'] ?? $issue['title'] ?? '-'); ?></strong></td>
                            <td><?php echo e(($issue['student_first_name'] ?? $issue['first_name'] ?? '') . ' ' . ($issue['student_last_name'] ?? $issue['last_name'] ?? '')); ?></td>
                            <td><?php echo formatDate($issue['issue_date']); ?></td>
                            <td>
                                <?php echo formatDate($issue['due_date']); ?>
                                <?php if ($issue['return_date'] === null && strtotime($issue['due_date']) < strtotime('today')): ?>
                                    <span class="badge bg-danger ms-1">Overdue</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($issue['return_date']): ?>
                                    <span class="badge bg-success">Returned</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Issued</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$issue['return_date']): ?>
                                <a href="<?php echo url('library/returnBook?id=' . $issue['id']); ?>" class="btn btn-sm btn-outline-success" title="Return"><i class="fas fa-undo"></i> Return</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('library/issued?page=' . $p); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
