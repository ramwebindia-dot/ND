<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-exclamation-triangle text-danger me-2"></i>Overdue Books</h4>
    <div class="d-flex gap-2">
        <?php if (!empty($overdue)): ?>
        <form method="POST" action="<?php echo url('library/send-overdue-reminders'); ?>" class="d-inline">
            <?php echo CSRF::field(); ?>
            <button type="submit" class="btn btn-warning btn-sm"
                    onclick="return confirm('Send SMS reminders to all <?php echo count($overdue); ?> overdue borrowers?')">
                <i class="fas fa-sms me-1"></i>Send SMS Reminders
            </button>
        </form>
        <?php endif; ?>
        <a href="<?php echo url('library/issued'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Book Title</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Days Overdue</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($overdue)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">No overdue books.</td></tr>
                    <?php else: ?>
                        <?php foreach ($overdue as $i => $item): ?>
                        <tr class="table-danger">
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($item['book_title'] ?? $item['title'] ?? '-'); ?></strong></td>
                            <td><?php echo e(($item['student_first_name'] ?? $item['first_name'] ?? '') . ' ' . ($item['student_last_name'] ?? $item['last_name'] ?? '')); ?></td>
                            <td><?php echo formatDate($item['issue_date']); ?></td>
                            <td><?php echo formatDate($item['due_date']); ?></td>
                            <td>
                                <span class="badge bg-danger">
                                    <?php echo (int)((strtotime('today') - strtotime($item['due_date'])) / 86400); ?> days
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo url('library/returnBook?id=' . $item['id']); ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-undo me-1"></i>Return</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
