<div class="page-header">
    <h4><i class="fas fa-book"></i> Library - Book Catalog</h4>
    <div>
        <a href="<?php echo url('library/categories'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-tags me-1"></i>Categories</a>
        <a href="<?php echo url('library/issue'); ?>" class="btn btn-primary-custom"><i class="fas fa-hand-holding me-1"></i>Issue Book</a>
        <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#bookModal">
            <i class="fas fa-plus me-1"></i>Add Book
        </button>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('library'); ?>" class="row g-2">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control" placeholder="Search by title, author, ISBN..." value="<?php echo e($search); ?>">
            </div>
            <div class="col-md-3">
                <select name="category_id" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo $categoryId == $cat['id'] ? 'selected' : ''; ?>><?php echo e($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Category</th>
                        <th>Total</th>
                        <th>Available</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($books)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">No books found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($books as $i => $book): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($book['title']); ?></strong></td>
                            <td><?php echo e($book['author'] ?? '-'); ?></td>
                            <td><?php echo e($book['isbn'] ?? '-'); ?></td>
                            <td><?php echo e($book['category_name'] ?? '-'); ?></td>
                            <td><?php echo e($book['total_quantity'] ?? 0); ?></td>
                            <td>
                                <span class="badge <?php echo ($book['available_quantity'] ?? 0) > 0 ? 'bg-success' : 'bg-danger'; ?>">
                                    <?php echo e($book['available_quantity'] ?? 0); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-info edit-book" data-id="<?php echo $book['id']; ?>" data-title="<?php echo e($book['title']); ?>" data-author="<?php echo e($book['author'] ?? ''); ?>" data-isbn="<?php echo e($book['isbn'] ?? ''); ?>" data-category="<?php echo $book['category_id'] ?? ''; ?>" data-total="<?php echo $book['total_quantity'] ?? 0; ?>" data-publisher="<?php echo e($book['publisher'] ?? ''); ?>" title="Edit"><i class="fas fa-edit"></i></button>
                                <a href="<?php echo url('library/deleteBook?id=' . $book['id']); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this book?')" title="Delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Book Modal -->
<div class="modal fade" id="bookModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('library/saveBook'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="book_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title" id="bookModalLabel">Add Book</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="book_title" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Author <span class="text-danger">*</span></label>
                            <input type="text" name="author" id="book_author" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">ISBN</label>
                            <input type="text" name="isbn" id="book_isbn" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Publisher</label>
                            <input type="text" name="publisher" id="book_publisher" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" id="book_category" class="form-select">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo e($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Total Quantity <span class="text-danger">*</span></label>
                            <input type="number" name="total_quantity" id="book_total" class="form-control" min="0" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Edition</label>
                            <input type="text" name="edition" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Publication Year</label>
                            <input type="number" name="publication_year" class="form-control" min="1900" max="2099">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Save Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-book').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('book_id').value = this.dataset.id;
        document.getElementById('book_title').value = this.dataset.title;
        document.getElementById('book_author').value = this.dataset.author;
        document.getElementById('book_isbn').value = this.dataset.isbn;
        document.getElementById('book_publisher').value = this.dataset.publisher;
        document.getElementById('book_category').value = this.dataset.category;
        document.getElementById('book_total').value = this.dataset.total;
        document.getElementById('bookModalLabel').textContent = 'Edit Book';
        new bootstrap.Modal(document.getElementById('bookModal')).show();
    });
});
</script>
