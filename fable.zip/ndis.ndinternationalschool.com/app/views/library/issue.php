﻿<div class="page-header">
    <h4><i class="fas fa-hand-holding"></i> Issue Book</h4>
    <a href="<?php echo url('library'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('library/issue'); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Book <span class="text-danger">*</span></label>
                    <select name="book_id" class="form-select" required>
                        <option value="">Select Book</option>
                        <?php foreach ($books as $book): ?>
                            <option value="<?php echo $book['id']; ?>"><?php echo e($book['title'] . ' by ' . ($book['author'] ?? 'Unknown') . ' (Available: ' . $book['available_quantity'] . ')'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Student <span class="text-danger">*</span></label>
                    <select name="student_id" class="form-select" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo e($s['admission_number'] . ' - ' . trim($s['first_name'] . ' ' . ($s['last_name'] ?? ''))); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Issue Date <span class="text-danger">*</span></label>
                    <input type="date" name="issue_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Due Date <span class="text-danger">*</span></label>
                    <input type="date" name="due_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+15 days')); ?>" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-check me-1"></i>Issue Book</button>
        </form>
    </div>
</div>
