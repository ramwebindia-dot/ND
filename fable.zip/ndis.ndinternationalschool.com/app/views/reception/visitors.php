<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-id-badge me-2"></i>Visitor Log / Gate Pass</h4>
    <div>
        <a href="<?php echo url('reception'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Reception</a>
        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addVis"><i class="fas fa-plus me-1"></i>Check In Visitor</button>
    </div>
</div>

<div class="card"><div class="card-body p-0"><div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light"><tr>
            <th>Visitor</th><th>Phone</th><th>To Meet</th><th>Purpose</th><th>Persons</th><th>In</th><th>Out</th><th></th>
        </tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">No visitors logged.</td></tr>
        <?php else: foreach ($rows as $r): ?>
            <tr class="<?php echo $r['out_time'] ? '' : 'table-warning'; ?>">
                <td class="fw-medium"><?php echo e($r['visitor_name']); ?></td>
                <td><?php echo e($r['phone'] ?: '-'); ?></td>
                <td><?php echo e($r['whom_to_meet'] ?: '-'); ?></td>
                <td><small><?php echo e($r['purpose'] ?: '-'); ?></small></td>
                <td class="text-center"><?php echo (int)($r['no_of_persons'] ?: 1); ?></td>
                <td><small><?php echo $r['in_time'] ? date('d-m h:i A', strtotime($r['in_time'])) : '-'; ?></small></td>
                <td><small><?php echo $r['out_time'] ? date('d-m h:i A', strtotime($r['out_time'])) : '<span class="badge bg-warning text-dark">Inside</span>'; ?></small></td>
                <td>
                    <?php if (!$r['out_time']): ?>
                    <form method="post" action="<?php echo url('reception/visitor-out'); ?>" class="d-inline">
                        <?php echo CSRF::field(); ?><input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="fas fa-sign-out-alt me-1"></i>Out</button>
                    </form>
                    <?php else: ?><span class="text-muted small">Done</span><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="addVis"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/visitors'); ?>">
        <?php echo CSRF::field(); ?>
        <div class="modal-header"><h5 class="modal-title">Check In Visitor</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-md-6"><label class="form-label">Visitor Name <span class="text-danger">*</span></label><input type="text" name="visitor_name" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Whom to Meet</label><input type="text" name="whom_to_meet" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">No. of Persons</label><input type="number" name="no_of_persons" class="form-control" value="1" min="1"></div>
            <div class="col-md-6"><label class="form-label">ID Proof</label><input type="text" name="id_proof" class="form-control" placeholder="Aadhaar / DL no."></div>
            <div class="col-12"><label class="form-label">Purpose</label><input type="text" name="purpose" class="form-control"></div>
            <div class="col-12"><label class="form-label">Remarks</label><textarea name="remarks" class="form-control" rows="2"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-success">Check In</button></div>
    </form>
</div></div></div>
