<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-phone me-2"></i>Phone Call Log</h4>
    <div>
        <a href="<?php echo url('reception'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Reception</a>
        <button class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#addCall"><i class="fas fa-plus me-1"></i>Log Call</button>
    </div>
</div>

<div class="card"><div class="card-body p-0"><div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light"><tr>
            <th>Date</th><th>Caller</th><th>Phone</th><th>Direction</th><th>Purpose</th><th>Remarks</th>
        </tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No calls logged.</td></tr>
        <?php else: foreach ($rows as $r): ?>
            <tr>
                <td><small><?php echo formatDate($r['call_date']); ?></small></td>
                <td class="fw-medium"><?php echo e($r['caller_name']); ?></td>
                <td><?php echo e($r['phone'] ?: '-'); ?></td>
                <td><span class="badge bg-<?php echo $r['direction']==='Incoming'?'success':'primary'; ?>"><?php echo e($r['direction']); ?></span></td>
                <td><small><?php echo e($r['purpose'] ?: '-'); ?></small></td>
                <td><small><?php echo e($r['remarks'] ?: '-'); ?></small></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="addCall"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/calls'); ?>">
        <?php echo CSRF::field(); ?>
        <div class="modal-header"><h5 class="modal-title">Log Phone Call</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-md-6"><label class="form-label">Date</label><input type="date" name="call_date" class="form-control" value="<?php echo date('Y-m-d'); ?>"></div>
            <div class="col-md-6"><label class="form-label">Direction</label><select name="direction" class="form-select"><option>Incoming</option><option>Outgoing</option></select></div>
            <div class="col-md-6"><label class="form-label">Caller Name <span class="text-danger">*</span></label><input type="text" name="caller_name" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
            <div class="col-12"><label class="form-label">Purpose</label><input type="text" name="purpose" class="form-control"></div>
            <div class="col-12"><label class="form-label">Remarks</label><textarea name="remarks" class="form-control" rows="2"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-info text-white">Save</button></div>
    </form>
</div></div></div>
