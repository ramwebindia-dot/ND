<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-comment-dots me-2"></i>Complaints / Queries</h4>
    <div>
        <a href="<?php echo url('reception'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Reception</a>
        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#addComp"><i class="fas fa-plus me-1"></i>New Complaint</button>
    </div>
</div>

<div class="card"><div class="card-body p-0"><div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light"><tr>
            <th>Date</th><th>Name</th><th>Phone</th><th>Subject</th><th>Status</th><th></th>
        </tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No complaints.</td></tr>
        <?php else: foreach ($rows as $r):
            $badge = ['Open'=>'danger','In Progress'=>'warning text-dark','Resolved'=>'success'][$r['status']] ?? 'secondary'; ?>
            <tr>
                <td><small><?php echo formatDate($r['complaint_date']); ?></small></td>
                <td class="fw-medium"><?php echo e($r['complainant_name']); ?></td>
                <td><?php echo e($r['phone'] ?: '-'); ?></td>
                <td><?php echo e($r['subject']); ?><?php if ($r['details']): ?><br><small class="text-muted"><?php echo e($r['details']); ?></small><?php endif; ?></td>
                <td><span class="badge bg-<?php echo $badge; ?>"><?php echo e($r['status']); ?></span>
                    <?php if ($r['status']==='Resolved' && $r['resolution']): ?><br><small class="text-success"><?php echo e($r['resolution']); ?></small><?php endif; ?></td>
                <td><button class="btn btn-sm btn-outline-primary"
                        onclick='editComp(<?php echo json_encode(["id"=>$r["id"],"status"=>$r["status"],"resolution"=>$r["resolution"]]); ?>)'>
                    <i class="fas fa-edit"></i></button></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="addComp"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/complaints'); ?>">
        <?php echo CSRF::field(); ?>
        <div class="modal-header"><h5 class="modal-title">New Complaint / Query</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-md-6"><label class="form-label">Date</label><input type="date" name="complaint_date" class="form-control" value="<?php echo date('Y-m-d'); ?>"></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
            <div class="col-12"><label class="form-label">Name <span class="text-danger">*</span></label><input type="text" name="complainant_name" class="form-control" required></div>
            <div class="col-12"><label class="form-label">Subject <span class="text-danger">*</span></label><input type="text" name="subject" class="form-control" required></div>
            <div class="col-12"><label class="form-label">Details</label><textarea name="details" class="form-control" rows="3"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger">Save</button></div>
    </form>
</div></div></div>

<div class="modal fade" id="editComp"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/resolve-complaint'); ?>">
        <?php echo CSRF::field(); ?>
        <input type="hidden" name="id" id="cmId">
        <div class="modal-header"><h5 class="modal-title">Update Complaint</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-12"><label class="form-label">Status</label><select name="status" id="cmStatus" class="form-select"><option>Open</option><option>In Progress</option><option>Resolved</option></select></div>
            <div class="col-12"><label class="form-label">Resolution / Note</label><textarea name="resolution" id="cmRes" class="form-control" rows="3"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary-custom">Update</button></div>
    </form>
</div></div></div>

<script>
function editComp(d){
    document.getElementById('cmId').value = d.id;
    document.getElementById('cmStatus').value = d.status;
    document.getElementById('cmRes').value = d.resolution || '';
    new bootstrap.Modal(document.getElementById('editComp')).show();
}
</script>
