<div class="page-header">
    <h4><i class="fas fa-concierge-bell me-2"></i>Reception / Front Desk</h4>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <a href="<?php echo url('reception/enquiries'); ?>" class="text-decoration-none">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="stat-value text-primary"><?php echo (int)$stats['open_enquiries']; ?></div>
                <div class="text-muted small">Open Enquiries</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?php echo url('reception/visitors'); ?>" class="text-decoration-none">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="stat-value text-success"><?php echo (int)$stats['inside_visitors']; ?></div>
                <div class="text-muted small">Visitors Inside (today: <?php echo (int)$stats['today_visitors']; ?>)</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?php echo url('reception/calls'); ?>" class="text-decoration-none">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="stat-value text-info"><?php echo (int)$stats['today_calls']; ?></div>
                <div class="text-muted small">Calls Today</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-3 col-6">
        <a href="<?php echo url('reception/complaints'); ?>" class="text-decoration-none">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="stat-value text-danger"><?php echo (int)$stats['open_complaints']; ?></div>
                <div class="text-muted small">Open Complaints</div>
            </div></div>
        </a>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-3 col-6"><a href="<?php echo url('reception/enquiries'); ?>" class="btn btn-outline-primary w-100 py-3"><i class="fas fa-user-plus d-block mb-2 fs-4"></i>Admission Enquiry</a></div>
    <div class="col-md-3 col-6"><a href="<?php echo url('reception/visitors'); ?>" class="btn btn-outline-success w-100 py-3"><i class="fas fa-id-badge d-block mb-2 fs-4"></i>Visitor / Gate Pass</a></div>
    <div class="col-md-3 col-6"><a href="<?php echo url('reception/calls'); ?>" class="btn btn-outline-info w-100 py-3"><i class="fas fa-phone d-block mb-2 fs-4"></i>Phone Call Log</a></div>
    <div class="col-md-3 col-6"><a href="<?php echo url('reception/complaints'); ?>" class="btn btn-outline-danger w-100 py-3"><i class="fas fa-comment-dots d-block mb-2 fs-4"></i>Complaint / Query</a></div>
</div>
