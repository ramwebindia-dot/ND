<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-plus me-2"></i>Admission Enquiries</h4>
    <div>
        <a href="<?php echo url('reception'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Reception</a>
        <button class="btn btn-primary-custom btn-sm" data-bs-toggle="modal" data-bs-target="#addEnq"><i class="fas fa-plus me-1"></i>New Enquiry</button>
    </div>
</div>

<div class="card"><div class="card-body p-0"><div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
        <thead class="table-light"><tr>
            <th>Date</th><th>Parent</th><th>Student</th><th>Class</th><th>Phone</th><th>Source</th><th>Follow-up</th><th>Status</th><th></th>
        </tr></thead>
        <tbody>
        <?php if (empty($rows)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No enquiries yet.</td></tr>
        <?php else: foreach ($rows as $r):
            $badge = ['Open'=>'warning text-dark','Contacted'=>'info text-dark','Converted'=>'success','Lost'=>'secondary'][$r['status']] ?? 'secondary'; ?>
            <tr>
                <td><small><?php echo formatDate($r['enquiry_date']); ?></small></td>
                <td class="fw-medium"><?php echo e($r['parent_name']); ?></td>
                <td><?php echo e($r['student_name'] ?: '-'); ?></td>
                <td><?php echo e($r['class_interested'] ?: '-'); ?></td>
                <td><?php echo e($r['phone']); ?></td>
                <td><small><?php echo e($r['source']); ?></small></td>
                <td><small><?php echo $r['follow_up_date'] ? formatDate($r['follow_up_date']) : '-'; ?></small></td>
                <td><span class="badge bg-<?php echo $badge; ?>"><?php echo e($r['status']); ?></span></td>
                <td><button class="btn btn-sm btn-outline-primary"
                        onclick='editEnq(<?php echo json_encode(["id"=>$r["id"],"status"=>$r["status"],"follow_up_date"=>$r["follow_up_date"],"remarks"=>$r["remarks"]]); ?>)'>
                    <i class="fas fa-edit"></i></button></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div></div></div>

<!-- Add Enquiry -->
<div class="modal fade" id="addEnq"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/enquiries'); ?>">
        <?php echo CSRF::field(); ?>
        <div class="modal-header"><h5 class="modal-title">New Admission Enquiry</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-md-6"><label class="form-label">Date</label><input type="date" name="enquiry_date" class="form-control" value="<?php echo date('Y-m-d'); ?>"></div>
            <div class="col-md-6"><label class="form-label">Source</label><select name="source" class="form-select"><option>Walk-in</option><option>Phone</option><option>Online</option><option>Reference</option><option>Other</option></select></div>
            <div class="col-md-6"><label class="form-label">Parent Name <span class="text-danger">*</span></label><input type="text" name="parent_name" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Phone <span class="text-danger">*</span></label><input type="text" name="phone" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Student Name</label><input type="text" name="student_name" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Class Interested</label><input type="text" name="class_interested" class="form-control" placeholder="e.g. Class 1"></div>
            <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Follow-up Date</label><input type="date" name="follow_up_date" class="form-control"></div>
            <div class="col-12"><label class="form-label">Remarks</label><textarea name="remarks" class="form-control" rows="2"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary-custom">Save Enquiry</button></div>
    </form>
</div></div></div>

<!-- Update status -->
<div class="modal fade" id="editEnq"><div class="modal-dialog"><div class="modal-content">
    <form method="post" action="<?php echo url('reception/update-enquiry'); ?>">
        <?php echo CSRF::field(); ?>
        <input type="hidden" name="id" id="eqId">
        <div class="modal-header"><h5 class="modal-title">Update Enquiry</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
            <div class="col-md-6"><label class="form-label">Status</label><select name="status" id="eqStatus" class="form-select"><option>Open</option><option>Contacted</option><option>Converted</option><option>Lost</option></select></div>
            <div class="col-md-6"><label class="form-label">Follow-up Date</label><input type="date" name="follow_up_date" id="eqFollow" class="form-control"></div>
            <div class="col-12"><label class="form-label">Remarks</label><textarea name="remarks" id="eqRemarks" class="form-control" rows="2"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary-custom">Update</button></div>
    </form>
</div></div></div>

<script>
function editEnq(d){
    document.getElementById('eqId').value = d.id;
    document.getElementById('eqStatus').value = d.status;
    document.getElementById('eqFollow').value = d.follow_up_date || '';
    document.getElementById('eqRemarks').value = d.remarks || '';
    new bootstrap.Modal(document.getElementById('editEnq')).show();
}
</script>
