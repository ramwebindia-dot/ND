<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-user me-2"></i>Teacher Profile</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('teachers/edit?id=' . $teacher['id']); ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-edit me-1"></i>Edit
        </a>
        <a href="<?php echo url('teachers'); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>
</div>

<div class="row">
    <!-- Left column -->
    <div class="col-lg-4">
        <!-- Photo & Status -->
        <div class="card mb-3">
            <div class="card-body text-center">
                <?php if (!empty($teacher['photo'])): ?>
                <img src="<?php echo asset($teacher['photo']); ?>" class="rounded-circle mb-3" width="100" height="100" style="object-fit:cover;" alt="">
                <?php else: ?>
                <i class="fas fa-user-circle fa-5x text-muted mb-3 d-block"></i>
                <?php endif; ?>
                <h5 class="mb-1"><?php echo e(trim(($teacher['first_name'] ?? '') . ' ' . ($teacher['last_name'] ?? ''))); ?></h5>
                <p class="text-muted mb-2">
                    <small>Emp: <strong><?php echo e($teacher['employee_id'] ?? '-'); ?></strong></small>
                </p>
                <span class="badge bg-<?php echo $teacher['status'] === 'Active' ? 'success' : 'danger'; ?>">
                    <?php echo e($teacher['status']); ?>
                </span>
                <?php if (!empty($teacher['department_name'])): ?>
                <div class="mt-2"><span class="badge bg-info text-dark"><?php echo e($teacher['department_name']); ?></span></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Personal Details -->
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-id-card me-2"></i>Details</div>
            <div class="card-body p-0">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted ps-3">Gender</td><td><?php echo e($teacher['gender'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">DOB</td><td><?php echo formatDate($teacher['dob'] ?? ''); ?></td></tr>
                    <tr><td class="text-muted ps-3">Phone</td><td><?php echo e($teacher['phone'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Email</td><td><?php echo e($teacher['email'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Qualification</td><td><?php echo e($teacher['qualification'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Experience</td><td><?php echo e($teacher['experience_years'] ?? '0'); ?> yrs</td></tr>
                    <tr><td class="text-muted ps-3">Joined</td><td><?php echo formatDate($teacher['join_date'] ?? ''); ?></td></tr>
                    <tr><td class="text-muted ps-3">Salary</td><td>₹<?php echo number_format($teacher['salary'] ?? 0, 0); ?></td></tr>
                </table>
            </div>
        </div>

        <!-- Login Account -->
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-key me-2"></i>Login Account</div>
            <div class="card-body">
                <?php if ($teacher['user_id']): ?>
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge bg-<?php echo $teacher['login_active'] ? 'success' : 'danger'; ?>">
                        <?php echo $teacher['login_active'] ? 'Active' : 'Disabled'; ?>
                    </span>
                    <small class="text-muted"><?php echo e($teacher['login_email'] ?? ''); ?></small>
                </div>
                <!-- Reset Password -->
                <form method="POST" action="<?php echo url('teachers/reset-teacher-password'); ?>" class="mb-2">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="teacher_id" value="<?php echo $teacher['id']; ?>">
                    <div class="input-group input-group-sm">
                        <input type="password" name="password" class="form-control" placeholder="New password" minlength="6">
                        <button type="submit" class="btn btn-warning" onclick="return confirm('Reset password?')">
                            <i class="fas fa-key me-1"></i>Reset
                        </button>
                    </div>
                </form>
                <!-- Remove Login -->
                <form method="POST" action="<?php echo url('teachers/delete-login'); ?>" class="d-inline"
                      onsubmit="return confirm('Remove login account? Teacher will not be able to login.')">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="teacher_id" value="<?php echo $teacher['id']; ?>">
                    <button type="submit" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-user-times me-1"></i>Remove Login
                    </button>
                </form>
                <?php else: ?>
                <p class="text-muted small mb-3">No login account. Create one so this teacher can log in.</p>
                <form method="POST" action="<?php echo url('teachers/create-login'); ?>">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="teacher_id" value="<?php echo $teacher['id']; ?>">
                    <div class="mb-2">
                        <input type="email" name="email" class="form-control form-control-sm" placeholder="Email / Username" required>
                    </div>
                    <div class="mb-2">
                        <input type="password" name="password" class="form-control form-control-sm" placeholder="Password (min 6 chars)" required minlength="6">
                    </div>
                    <button type="submit" class="btn btn-success btn-sm w-100">
                        <i class="fas fa-user-plus me-1"></i>Create Login
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right column -->
    <div class="col-lg-8">
        <!-- Leave History -->
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="fw-bold"><i class="fas fa-calendar-times me-2"></i>Leave History</span>
                <a href="<?php echo url('teachers/leave'); ?>" class="btn btn-sm btn-outline-primary">Manage Leaves</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($leaves)): ?>
                <p class="text-muted text-center py-3">No leave history.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead class="table-light">
                            <tr><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($leaves as $l):
                            $days = max(1, (int)((strtotime($l['to_date']) - strtotime($l['from_date'])) / 86400) + 1);
                            $s = $l['status'];
                        ?>
                        <tr>
                            <td><?php echo e($l['leave_type']); ?></td>
                            <td><?php echo formatDate($l['from_date']); ?></td>
                            <td><?php echo formatDate($l['to_date']); ?></td>
                            <td><?php echo $days; ?></td>
                            <td>
                                <span class="badge bg-<?php echo $s === 'Approved' ? 'success' : ($s === 'Rejected' ? 'danger' : 'warning text-dark'); ?>">
                                    <?php echo e($s); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Bank Details -->
        <?php if (!empty($teacher['bank_account_number'])): ?>
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-university me-2"></i>Bank Details</div>
            <div class="card-body p-0">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted ps-3" width="150">Bank</td><td><?php echo e($teacher['bank_name'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Account No.</td><td><?php echo e($teacher['bank_account_number']); ?></td></tr>
                    <tr><td class="text-muted ps-3">IFSC</td><td><?php echo e($teacher['bank_ifsc'] ?? '—'); ?></td></tr>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Address -->
        <?php if (!empty($teacher['address'])): ?>
        <div class="card">
            <div class="card-header fw-bold"><i class="fas fa-map-marker-alt me-2"></i>Address</div>
            <div class="card-body">
                <p class="mb-0"><?php echo nl2br(e($teacher['address'])); ?>,
                <?php echo e(implode(', ', array_filter([$teacher['city'] ?? null, $teacher['state'] ?? null, $teacher['pincode'] ?? null]))); ?>
                </p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
