<div class="page-header">
    <h4><i class="fas fa-building me-2"></i>Edit Department</h4>
</div>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header fw-bold">Department Details</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('teachers/edit-department?id=' . $dept['id']); ?>">
                    <?php echo CSRF::field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Department Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($dept['name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Head Teacher</label>
                        <select name="head_teacher_id" class="form-select">
                            <option value="">None</option>
                            <?php foreach ($teachers ?? [] as $t): ?>
                            <option value="<?php echo $t['id']; ?>" <?php echo $dept['head_teacher_id'] == $t['id'] ? 'selected' : ''; ?>>
                                <?php echo e(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? '')); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                        <a href="<?php echo url('teachers/departments'); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
