<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calendar-times me-2"></i>My Leave Applications</h4>
    <a href="<?php echo url('teachers/my-dashboard'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Dashboard</a>
</div>

<!-- Leave Balance Cards -->
<?php if (!empty($defaultMap)): ?>
<div class="row g-2 mb-4">
    <?php foreach ($defaultMap as $lt => $alloc):
        $used = $usedMap[$lt] ?? 0;
        $remaining = $alloc - $used;
        $color = $remaining <= 0 ? 'danger' : ($remaining <= 3 ? 'warning' : 'success');
    ?>
    <div class="col-6 col-md-2">
        <div class="card border-<?php echo $color; ?> text-center">
            <div class="card-body py-2 px-1">
                <div class="fs-4 fw-bold text-<?php echo $color; ?>"><?php echo max(0,$remaining); ?></div>
                <div class="small text-muted"><?php echo $lt; ?></div>
                <div class="small text-muted"><?php echo $used; ?>/<?php echo $alloc; ?> used</div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="row g-3">
<div class="col-md-5">
    <div class="card">
        <div class="card-header fw-bold">Apply for Leave</div>
        <div class="card-body">
            <form method="POST" action="<?php echo url('teachers/my-leave'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="mb-3">
                    <label class="form-label">Leave Type <span class="text-danger">*</span></label>
                    <select name="leave_type" class="form-select" required>
                        <option value="">Select type</option>
                        <option value="Casual">Casual Leave (CL)</option>
                        <option value="Sick">Sick Leave (SL)</option>
                        <option value="Earned">Earned Leave (EL)</option>
                        <option value="Maternity">Maternity Leave</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col">
                        <label class="form-label">From <span class="text-danger">*</span></label>
                        <input type="date" name="from_date" class="form-control" required>
                    </div>
                    <div class="col">
                        <label class="form-label">To <span class="text-danger">*</span></label>
                        <input type="date" name="to_date" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Reason <span class="text-danger">*</span></label>
                    <textarea name="reason" class="form-control" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-paper-plane me-2"></i>Submit Application
                </button>
            </form>
        </div>
    </div>
</div>

<div class="col-md-7">
    <div class="card">
        <div class="card-header fw-bold">Leave History</div>
        <div class="card-body p-0">
            <?php if (empty($leaves)): ?>
            <p class="text-muted text-center py-4">No leave records.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($leaves as $l):
                        $days = max(1, (int)((strtotime($l['to_date']) - strtotime($l['from_date'])) / 86400) + 1);
                        $s = $l['status'];
                    ?>
                    <tr>
                        <td><?php echo e($l['leave_type']); ?></td>
                        <td><?php echo formatDate($l['from_date']); ?></td>
                        <td><?php echo formatDate($l['to_date']); ?></td>
                        <td><?php echo $days; ?></td>
                        <td>
                            <span class="badge bg-<?php echo $s==='Approved'?'success':($s==='Rejected'?'danger':'warning text-dark'); ?>">
                                <?php echo e($s); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
