<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-clipboard-check me-2"></i>My Attendance</h4>
    <a href="<?php echo url('teachers/my-dashboard'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Dashboard</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('teachers/my-attendance'); ?>" class="row g-2 align-items-end">
            <div class="col-auto">
                <label class="form-label">Month</label>
                <input type="month" name="month" value="<?php echo e($month); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">View</button>
            </div>
        </form>
    </div>
</div>

<?php
$present = count(array_filter($records, fn($r) => $r['status'] === 'Present'));
$absent  = count(array_filter($records, fn($r) => $r['status'] === 'Absent'));
$leave   = count(array_filter($records, fn($r) => $r['status'] === 'On Leave'));
$total   = count($records);
?>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card text-center border-success">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-success"><?php echo $present; ?></div>
                <div class="small text-muted">Present</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center border-danger">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-danger"><?php echo $absent; ?></div>
                <div class="small text-muted">Absent</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center border-warning">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold text-warning"><?php echo $leave; ?></div>
                <div class="small text-muted">On Leave</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body py-2">
                <div class="fs-3 fw-bold"><?php echo $total ? round($present/$total*100) : 0; ?>%</div>
                <div class="small text-muted">Attendance %</div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if (empty($records)): ?>
        <p class="text-muted text-center py-4">No attendance records for this month.</p>
        <?php else: ?>
        <table class="table table-sm table-hover mb-0">
            <thead class="table-light">
                <tr><th>Date</th><th>Day</th><th>Status</th><th>Note</th></tr>
            </thead>
            <tbody>
            <?php foreach ($records as $r): $s=$r['status']; ?>
            <tr>
                <td><?php echo formatDate($r['date']); ?></td>
                <td><?php echo date('l', strtotime($r['date'])); ?></td>
                <td>
                    <span class="badge bg-<?php echo $s==='Present'?'success':($s==='Absent'?'danger':($s==='On Leave'?'warning text-dark':'secondary')); ?>">
                        <?php echo e($s); ?>
                    </span>
                </td>
                <td class="text-muted small"><?php echo e($r['note']??''); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
