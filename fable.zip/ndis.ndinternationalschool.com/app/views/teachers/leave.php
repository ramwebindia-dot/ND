<?php /** @var array $teachers, $leaves */ ?>
<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calendar-times me-2"></i>Teacher Leave Management</h4>
    <a href="<?php echo url('teachers'); ?>" class="btn btn-secondary btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back to Teachers
    </a>
</div>

<!-- Leave Balance Summary -->
<?php if (!empty($teachers)): ?>
<div class="card mb-4">
    <div class="card-header fw-bold"><i class="fas fa-chart-bar me-2"></i>Leave Balance — <?php echo date('Y'); ?></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Teacher</th>
                        <?php foreach (array_keys($defaultMap ?? ['Casual'=>12,'Sick'=>10,'Earned'=>15]) as $lt): ?>
                        <th class="text-center"><?php echo $lt; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($teachers as $t):
                    $tid = $t['id'];
                ?>
                <tr>
                    <td><?php echo e(trim(($t['first_name']??'').' '.($t['last_name']??''))); ?> <small class="text-muted">(<?php echo e($t['employee_id']??''); ?>)</small></td>
                    <?php foreach ($defaultMap ?? [] as $lt => $alloc):
                        $used = $usedMap[$tid][$lt] ?? 0;
                        $remaining = $alloc - $used;
                        $pct = $alloc > 0 ? min(100, round($used/$alloc*100)) : 0;
                        $color = $remaining <= 0 ? 'danger' : ($remaining <= 3 ? 'warning' : 'success');
                    ?>
                    <td class="text-center">
                        <span class="badge bg-<?php echo $color; ?>" title="<?php echo $used; ?> used / <?php echo $alloc; ?> total">
                            <?php echo $remaining; ?>/<?php echo $alloc; ?>
                        </span>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="px-3 pb-2 pt-1 text-muted small">
            <span class="badge bg-success">●</span> Remaining &nbsp;
            <span class="badge bg-warning text-dark">●</span> ≤3 left &nbsp;
            <span class="badge bg-danger">●</span> Exhausted
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <!-- Apply for Leave -->
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header fw-bold"><i class="fas fa-plus-circle me-2"></i>Apply for Leave</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('teachers/leave'); ?>">
                    <?php echo CSRF::field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Teacher <span class="text-danger">*</span></label>
                        <select name="teacher_id" class="form-select" required>
                            <option value="">Select Teacher</option>
                            <?php foreach ($teachers ?? [] as $t): ?>
                            <option value="<?php echo $t['id']; ?>">
                                <?php echo e(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? '')); ?>
                                (<?php echo e($t['employee_id'] ?? ''); ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Leave Type <span class="text-danger">*</span></label>
                        <select name="leave_type" class="form-select" required>
                            <option value="Casual">Casual Leave</option>
                            <option value="Sick">Sick Leave</option>
                            <option value="Earned">Earned Leave</option>
                            <option value="Maternity">Maternity Leave</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col">
                            <label class="form-label">From Date <span class="text-danger">*</span></label>
                            <input type="date" name="from_date" class="form-control" required max="<?php echo date('Y-m-d', strtotime('+1 year')); ?>">
                        </div>
                        <div class="col">
                            <label class="form-label">To Date <span class="text-danger">*</span></label>
                            <input type="date" name="to_date" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <textarea name="reason" class="form-control" rows="3" placeholder="Reason for leave..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane me-2"></i>Submit Request
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Leave Applications -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header fw-bold">
                <i class="fas fa-list me-2"></i>Leave Applications
                <span class="badge bg-warning ms-2"><?php echo count(array_filter($leaves ?? [], fn($l) => $l['status'] === 'Pending')); ?> Pending</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($leaves)): ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-calendar-check fa-2x mb-2 d-block"></i>No leave applications found.
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Teacher</th>
                                <th>Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Days</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($leaves as $l):
                            $days = (int)((strtotime($l['to_date']) - strtotime($l['from_date'])) / 86400) + 1;
                            $status = $l['status'] ?? 'Pending';
                        ?>
                        <tr>
                            <td>
                                <div class="fw-medium"><?php echo e($l['teacher_name'] ?? 'Unknown'); ?></div>
                                <small class="text-muted"><?php echo e($l['employee_id'] ?? ''); ?></small>
                            </td>
                            <td><?php echo e($l['leave_type']); ?></td>
                            <td><?php echo formatDate($l['from_date']); ?></td>
                            <td><?php echo formatDate($l['to_date']); ?></td>
                            <td><span class="badge bg-secondary"><?php echo $days; ?></span></td>
                            <td>
                                <span class="badge bg-<?php echo $status === 'Approved' ? 'success' : ($status === 'Rejected' ? 'danger' : 'warning text-dark'); ?>">
                                    <?php echo e($status); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($status === 'Pending'): ?>
                                <div class="d-flex gap-1">
                                    <!-- Approve -->
                                    <form method="POST" action="<?php echo url('teachers/approve-leave'); ?>" class="d-inline">
                                        <?php echo CSRF::field(); ?>
                                        <input type="hidden" name="leave_id" value="<?php echo $l['id']; ?>">
                                        <button type="submit" class="btn btn-success btn-sm" title="Approve"
                                                onclick="return confirm('Approve this leave request?')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>
                                    <!-- Reject -->
                                    <button type="button" class="btn btn-danger btn-sm" title="Reject"
                                            onclick="rejectLeave(<?php echo $l['id']; ?>)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <?php else: ?>
                                <small class="text-muted">
                                    <?php echo $l['approved_at'] ? formatDate($l['approved_at']) : '-'; ?>
                                </small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('teachers/reject-leave'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Reject Leave</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="leave_id" id="rejectLeaveId">
                    <div class="mb-3">
                        <label class="form-label">Reason for rejection (optional)</label>
                        <textarea name="reject_reason" class="form-control" rows="3" placeholder="Enter reason..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger btn-sm">Reject Leave</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function rejectLeave(id) {
    document.getElementById('rejectLeaveId').value = id;
    new bootstrap.Modal(document.getElementById('rejectModal')).show();
}
</script>
