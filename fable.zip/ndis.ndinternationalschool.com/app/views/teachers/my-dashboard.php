<div class="page-header">
    <h4><i class="fas fa-tachometer-alt me-2"></i>My Dashboard</h4>
</div>

<div class="row g-3">
<!-- Profile Card -->
<div class="col-lg-4">
    <div class="card mb-3">
        <div class="card-body text-center">
            <?php if (!empty($teacher['photo'])): ?>
            <img src="<?php echo asset($teacher['photo']); ?>" class="rounded-circle mb-3" width="90" height="90" style="object-fit:cover;">
            <?php else: ?>
            <i class="fas fa-user-circle fa-4x text-muted mb-3 d-block"></i>
            <?php endif; ?>
            <h5 class="mb-1"><?php echo e(trim($teacher['first_name'].' '.($teacher['last_name']??''))); ?></h5>
            <div class="text-muted small mb-1">Emp. ID: <?php echo e($teacher['employee_id']??'—'); ?></div>
            <div class="text-muted small mb-2"><?php echo e($teacher['department_name']??'—'); ?></div>
            <span class="badge bg-<?php echo $teacher['status']==='Active'?'success':'danger'; ?>"><?php echo e($teacher['status']); ?></span>
        </div>
    </div>
    <div class="card mb-3">
        <div class="card-header fw-bold">Quick Info</div>
        <div class="card-body p-0">
            <table class="table table-sm table-borderless mb-0">
                <tr><td class="text-muted ps-3">Phone</td><td><?php echo e($teacher['phone']??'—'); ?></td></tr>
                <tr><td class="text-muted ps-3">Email</td><td><?php echo e($teacher['email']??'—'); ?></td></tr>
                <tr><td class="text-muted ps-3">Joined</td><td><?php echo formatDate($teacher['join_date']??''); ?></td></tr>
                <tr><td class="text-muted ps-3">Qualification</td><td><?php echo e($teacher['qualification']??'—'); ?></td></tr>
            </table>
        </div>
    </div>
    <div class="d-grid gap-2">
        <a href="<?php echo url('teachers/my-salary'); ?>" class="btn btn-outline-success btn-sm"><i class="fas fa-rupee-sign me-2"></i>My Salary Slips</a>
        <a href="<?php echo url('teachers/my-attendance'); ?>" class="btn btn-outline-info btn-sm"><i class="fas fa-clipboard-check me-2"></i>My Attendance</a>
        <a href="<?php echo url('teachers/my-leave'); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-calendar-times me-2"></i>My Leave</a>
    </div>
</div>

<div class="col-lg-8">
    <!-- Today's Timetable -->
    <div class="card mb-3">
        <div class="card-header fw-bold"><i class="fas fa-clock me-2"></i>Today's Schedule (<?php echo date('l'); ?>)</div>
        <div class="card-body p-0">
            <?php if (empty($timetable)): ?>
            <p class="text-muted text-center py-3">No classes today.</p>
            <?php else: ?>
            <table class="table table-sm table-hover mb-0">
                <thead class="table-light"><tr><th>Time</th><th>Subject</th><th>Class</th></tr></thead>
                <tbody>
                <?php foreach ($timetable as $t): ?>
                <tr>
                    <td><?php echo e(substr($t['start_time'],0,5)); ?> – <?php echo e(substr($t['end_time'],0,5)); ?></td>
                    <td><?php echo e($t['subject_name']); ?></td>
                    <td><?php echo e($t['class_section']); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recent Leaves -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold"><i class="fas fa-calendar-times me-2"></i>Recent Leaves</span>
            <a href="<?php echo url('teachers/my-leave'); ?>" class="btn btn-sm btn-outline-primary">Apply Leave</a>
        </div>
        <div class="card-body p-0">
            <?php if (empty($leaves)): ?>
            <p class="text-muted text-center py-3">No leave records.</p>
            <?php else: ?>
            <table class="table table-sm mb-0">
                <thead class="table-light"><tr><th>Type</th><th>From</th><th>To</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach (array_slice($leaves, 0, 5) as $l): $s=$l['status']; ?>
                <tr>
                    <td><?php echo e($l['leave_type']); ?></td>
                    <td><?php echo formatDate($l['from_date']); ?></td>
                    <td><?php echo formatDate($l['to_date']); ?></td>
                    <td><span class="badge bg-<?php echo $s==='Approved'?'success':($s==='Rejected'?'danger':'warning text-dark'); ?>"><?php echo e($s); ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
