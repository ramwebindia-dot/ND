<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-rupee-sign me-2"></i>My Salary Slips</h4>
    <a href="<?php echo url('teachers/my-dashboard'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Dashboard</a>
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if (empty($salaries)): ?>
        <p class="text-muted text-center py-4">No salary records found.</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Month</th><th>Basic</th><th>Allowances</th><th>Deductions</th><th>Net Pay</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                <?php foreach ($salaries as $s):
                    $net = ($s['net_salary'] ?? 0);
                    $st  = $s['status'] ?? 'Pending';
                ?>
                <tr>
                    <td><?php echo e($s['salary_month'] ?? '—'); ?></td>
                    <td>₹<?php echo number_format($s['basic_salary'] ?? 0, 0); ?></td>
                    <td>₹<?php echo number_format($s['allowances'] ?? 0, 0); ?></td>
                    <td class="text-danger">₹<?php echo number_format($s['deductions'] ?? 0, 0); ?></td>
                    <td class="fw-bold text-success">₹<?php echo number_format($net, 0); ?></td>
                    <td>
                        <span class="badge bg-<?php echo $st==='Paid'?'success':($st==='Processing'?'warning text-dark':'secondary'); ?>">
                            <?php echo e($st); ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?php echo url('payroll/slip?id='.$s['id']); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="fas fa-print me-1"></i>Slip
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
