<?php $departments = $departments ?? []; ?>
<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Teacher</h4>
    <a href="<?php echo url('teachers/profile?id=' . $teacher['id']); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>
<form method="POST" action="<?php echo url('teachers/edit?id=' . $teacher['id']); ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <div class="row">
        <div class="col-lg-8"><div class="card mb-3"><div class="card-header"><h6>Personal Information</h6></div><div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" value="<?php echo e($teacher['first_name']); ?>" required></div>
                <div class="col-md-4 mb-3"><label class="form-label">Last Name</label><input type="text" name="last_name" class="form-control" value="<?php echo e($teacher['last_name'] ?? ''); ?>"></div>
                <div class="col-md-4 mb-3"><label class="form-label">Gender</label><select name="gender" class="form-select"><option value="Male" <?php echo ($teacher['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option><option value="Female" <?php echo ($teacher['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option></select></div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3"><label class="form-label">Mobile *</label><input type="text" name="mobile" class="form-control" value="<?php echo e($teacher['phone'] ?? ''); ?>" required></div>
                <div class="col-md-4 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo e($teacher['email'] ?? ''); ?>"></div>
                <div class="col-md-4 mb-3"><label class="form-label">Designation</label><input type="text" name="designation" class="form-control" value="<?php echo e($teacher['designation'] ?? ''); ?>"></div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3"><label class="form-label">Qualification</label><input type="text" name="qualification" class="form-control" value="<?php echo e($teacher['qualification'] ?? ''); ?>"></div>
                <div class="col-md-4 mb-3"><label class="form-label">Department</label><select name="department_id" class="form-select"><option value="">Select</option><?php foreach ($departments as $dept): ?><option value="<?php echo $dept['id']; ?>" <?php echo ($teacher['department_id'] ?? '') == $dept['id'] ? 'selected' : ''; ?>><?php echo e($dept['name']); ?></option><?php endforeach; ?></select></div>
                <div class="col-md-4 mb-3"><label class="form-label">Status</label><select name="status" class="form-select"><option value="Active" <?php echo ($teacher['status'] ?? '') === 'Active' ? 'selected' : ''; ?>>Active</option><option value="Inactive" <?php echo ($teacher['status'] ?? '') === 'Inactive' ? 'selected' : ''; ?>>Inactive</option></select></div>
            </div>
        </div></div></div>
        <div class="col-lg-4">
            <div class="card mb-3"><div class="card-header"><h6>Photo</h6></div><div class="card-body text-center">
                <?php if (!empty($teacher['photo'])): ?><img src="<?php echo asset($teacher['photo']); ?>" class="rounded-circle mb-2" width="80" height="80" alt=""><br><?php endif; ?>
                <input type="file" name="photo" class="form-control" accept="image/*">
            </div></div>
            <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-save me-1"></i>Update Teacher</button>
        </div>
    </div>
</form>
