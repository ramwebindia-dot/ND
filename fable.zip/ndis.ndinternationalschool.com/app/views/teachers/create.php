<div class="page-header">
    <h4><i class="fas fa-plus-circle"></i> Add Teacher</h4>
    <a href="<?php echo url('teachers'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('teachers/create'); ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-3">
                <div class="card-header"><h6>Personal Information</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Last Name</label><input type="text" name="last_name" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Gender *</label><select name="gender" class="form-select" required><option value="Male">Male</option><option value="Female">Female</option></select></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">Date of Birth *</label><input type="date" name="date_of_birth" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Mobile *</label><input type="text" name="mobile" class="form-control" maxlength="10" required></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">Qualification</label><input type="text" name="qualification" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Specialization</label><input type="text" name="specialization" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Experience (Years)</label><input type="number" name="experience" class="form-control"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">Department</label><select name="department_id" class="form-select"><option value="">Select</option><?php foreach ($departments as $dept): ?><option value="<?php echo $dept['id']; ?>"><?php echo e($dept['name']); ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Designation</label><input type="text" name="designation" class="form-control" placeholder="e.g., TGT, PGT, PRT"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Joining Date</label><input type="date" name="joining_date" class="form-control" value="<?php echo date('Y-m-d'); ?>"></div>
                    </div>
                    <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card mb-3">
                <div class="card-header"><h6>Photo</h6></div>
                <div class="card-body text-center"><input type="file" name="photo" class="form-control" accept="image/*"></div>
            </div>
            <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-save me-1"></i>Save Teacher</button>
        </div>
    </div>
</form>
