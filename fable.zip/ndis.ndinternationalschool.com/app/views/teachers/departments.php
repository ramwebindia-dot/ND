<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-building me-2"></i>Departments</h4>
    <a href="<?php echo url('teachers'); ?>" class="btn btn-secondary btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back to Teachers
    </a>
</div>

<div class="row">
    <!-- Add Department -->
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header fw-bold"><i class="fas fa-plus me-2"></i>Add Department</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('teachers/departments'); ?>">
                    <?php echo CSRF::field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Department Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Science, Mathematics" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Head Teacher</label>
                        <select name="head_teacher_id" class="form-select">
                            <option value="">None</option>
                            <?php foreach ($teachers ?? [] as $t): ?>
                            <option value="<?php echo $t['id']; ?>">
                                <?php echo e(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? '')); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save me-2"></i>Create Department
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Department List -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header fw-bold"><i class="fas fa-list me-2"></i>All Departments (<?php echo count($departments ?? []); ?>)</div>
            <div class="card-body p-0">
                <?php if (empty($departments)): ?>
                <div class="text-center py-4 text-muted">No departments found. Create one to get started.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Department</th>
                                <th>Head Teacher</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($departments as $i => $d): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td class="fw-medium"><?php echo e($d['name']); ?></td>
                            <td><?php echo $d['head_name'] ? e(trim($d['head_name'])) : '<span class="text-muted">—</span>'; ?></td>
                            <td>
                                <a href="<?php echo url('teachers/edit-department?id=' . $d['id']); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo url('teachers/delete-department'); ?>" class="d-inline"
                                      onsubmit="return confirm('Delete department \'<?php echo e(addslashes($d['name'])); ?>\'? Teachers in this department will be unlinked.')">
                                    <?php echo CSRF::field(); ?>
                                    <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
