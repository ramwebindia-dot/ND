<div class="page-header">
    <h4><i class="fas fa-chalkboard-teacher"></i> Teachers</h4>
    <a href="<?php echo url('teachers/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Add Teacher</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead><tr><th>#</th><th>Emp. No.</th><th>Name</th><th>Department</th><th>Designation</th><th>Mobile</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if (empty($teachers)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">No teachers found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($teachers as $i => $teacher): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($teacher['employee_id'] ?? ''); ?></strong></td>
                            <td><?php echo e(trim($teacher['first_name'] . ' ' . ($teacher['last_name'] ?? ''))); ?></td>
                            <td><?php echo e($teacher['department_name'] ?? '-'); ?></td>
                            <td><?php echo e($teacher['designation'] ?? '-'); ?></td>
                            <td><?php echo e($teacher['phone'] ?? '-'); ?></td>
                            <td><span class="badge <?php echo $teacher['status'] === 'Active' ? 'badge-success-custom' : 'badge-danger-custom'; ?>"><?php echo e($teacher['status']); ?></span></td>
                            <td>
                                <a href="<?php echo url('teachers/profile?id=' . $teacher['id']); ?>" class="btn btn-sm btn-outline-primary-custom"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo url('teachers/edit?id=' . $teacher['id']); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-edit"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
