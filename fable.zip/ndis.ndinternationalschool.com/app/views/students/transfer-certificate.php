<div class="page-header d-flex justify-content-between align-items-center no-print">
    <h4><i class="fas fa-certificate me-2"></i>Transfer Certificate</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('students/profile?id=' . $student['id']); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
        <?php if (!empty($student['transfer_certificate_number'])): ?>
        <button onclick="window.print()" class="btn btn-primary btn-sm">
            <i class="fas fa-print me-1"></i>Print TC
        </button>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($student['transfer_certificate_number'])): ?>
<!-- Issue TC Form -->
<div class="card no-print" style="max-width:500px;">
    <div class="card-header fw-bold text-warning"><i class="fas fa-exclamation-triangle me-2"></i>Issue Transfer Certificate</div>
    <div class="card-body">
        <div class="alert alert-warning small">This will change student status to "Transfer Certificate".</div>
        <table class="table table-sm table-borderless mb-3">
            <tr><td class="text-muted">Student</td><td><strong><?php echo e(trim($student['first_name'].' '.($student['last_name']??''))); ?></strong></td></tr>
            <tr><td class="text-muted">Adm. No.</td><td><?php echo e($student['admission_number']); ?></td></tr>
            <tr><td class="text-muted">Class</td><td><?php echo e($student['class_name']??'—'); ?></td></tr>
        </table>
        <form method="POST" action="<?php echo url('students/transfer-certificate?id='.$student['id']); ?>">
            <?php echo CSRF::field(); ?>
            <div class="mb-3">
                <label class="form-label">TC Number <span class="text-danger">*</span></label>
                <input type="text" name="transfer_certificate_number" class="form-control" required placeholder="e.g. TC-2025-001">
            </div>
            <div class="mb-3">
                <label class="form-label">Reason for Leaving</label>
                <select name="leaving_reason" class="form-select">
                    <option>Family Relocation</option>
                    <option>Admission to Another School</option>
                    <option>Course Completion</option>
                    <option>Other</option>
                </select>
            </div>
            <button type="submit" class="btn btn-warning"
                    onclick="return confirm('Issue TC? This cannot be undone.')">
                <i class="fas fa-certificate me-2"></i>Issue TC
            </button>
        </form>
    </div>
</div>

<?php else: ?>
<!-- Printable TC -->
<?php
$settings = app_settings();
$schoolName = $settings['app_name'] ?? APP_NAME;
$address    = $settings['address']  ?? '';
?>
<div id="tcPrint" style="max-width:700px; margin:auto; border:3px double #333; padding:30px; font-family:serif;">
    <div style="text-align:center; border-bottom:2px solid #333; padding-bottom:12px; margin-bottom:16px;">
        <div style="font-size:22px; font-weight:bold; text-transform:uppercase;"><?php echo htmlspecialchars($schoolName); ?></div>
        <div style="font-size:12px; color:#555;"><?php echo htmlspecialchars($address); ?></div>
        <div style="font-size:18px; font-weight:bold; margin-top:8px; text-decoration:underline; letter-spacing:2px;">TRANSFER CERTIFICATE</div>
        <div style="font-size:13px; margin-top:4px;">TC No: <strong><?php echo e($student['transfer_certificate_number']); ?></strong></div>
    </div>

    <table style="width:100%; border-collapse:collapse; font-size:13px; line-height:2;">
        <?php
        $rows = [
            'Student Name'      => strtoupper(trim($student['first_name'].' '.($student['last_name']??''))),
            'Father\'s Name'    => strtoupper($student['father_name'] ?? '—'),
            'Mother\'s Name'    => strtoupper($student['mother_name'] ?? '—'),
            'Date of Birth'     => !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '—',
            'Admission Number'  => $student['admission_number'] ?? '—',
            'Class Last Studied'=> ($student['class_name'] ?? '—') . (isset($student['section_name']) ? ' ('.$student['section_name'].')' : ''),
            'Academic Session'  => $activeSession['name'] ?? '—',
            'Date of Admission' => !empty($student['admission_date']) ? date('d-m-Y', strtotime($student['admission_date'])) : '—',
            'Date of Leaving'   => date('d-m-Y'),
        ];
        foreach ($rows as $label => $value): ?>
        <tr style="border-bottom:1px dotted #ccc;">
            <td style="color:#555; width:45%; padding:2px 4px;"><?php echo $label; ?></td>
            <td style="font-weight:bold; padding:2px 8px;">: <?php echo htmlspecialchars($value); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div style="margin-top:16px; font-size:12px; color:#555;">
        Certified that the above particulars are correct as per school records.
    </div>

    <table style="width:100%; margin-top:40px;">
        <tr>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:12px;">Class Teacher</div>
            </td>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:12px;">Office Seal</div>
            </td>
            <td style="text-align:center; width:33%;">
                <div style="border-top:1px solid #000; margin-top:30px; padding-top:4px; font-size:12px;">Principal</div>
            </td>
        </tr>
    </table>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar, .main-footer { display:none !important; }
    #tcPrint { border:3px double #000 !important; max-width:100% !important; }
    body { background:white !important; }
}
</style>
<?php endif; ?>
