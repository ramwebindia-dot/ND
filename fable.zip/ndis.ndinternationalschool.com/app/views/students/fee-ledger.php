﻿<div class="page-header">
    <h4><i class="fas fa-rupee-sign"></i> Fee Ledger - <?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?></h4>
    <a href="<?php echo url('students/profile?id=' . $student['id']); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row mb-3">
    <div class="col-md-4">
        <div class="stat-card"><div class="stat-value text-danger"><?php echo formatCurrency($outstanding); ?></div><div class="stat-label">Outstanding Balance</div></div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead><tr><th>Date</th><th>Description</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
                <tbody>
                    <?php if (empty($ledger)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">No transactions found.</td></tr>
                    <?php else: ?>
                        <?php $balance = 0; ?>
                        <?php foreach ($ledger as $entry): ?>
                            <?php
                                $debit = (float)($entry['debit'] ?? 0);
                                $credit = (float)($entry['credit'] ?? 0);
                                $balance += $credit - $debit;
                            ?>
                            <tr>
                                <td><?php echo formatDate($entry['date']); ?></td>
                                <td><?php echo e($entry['description']); ?></td>
                                <td class="text-danger"><?php echo $debit > 0 ? formatCurrency($debit) : '-'; ?></td>
                                <td class="text-success"><?php echo $credit > 0 ? formatCurrency($credit) : '-'; ?></td>
                                <td><strong><?php echo formatCurrency(abs($balance)); ?></strong> <small class="text-muted">(<?php echo $balance >= 0 ? 'Cr' : 'Dr'; ?>)</small></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
