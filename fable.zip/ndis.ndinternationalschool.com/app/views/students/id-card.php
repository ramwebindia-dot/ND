<?php $settings = app_settings(); $schoolName = $settings['app_name'] ?? APP_NAME; ?>

<div class="page-header d-flex justify-content-between align-items-center no-print">
    <h4><i class="fas fa-id-card me-2"></i>Student ID Card</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('students/profile?id='.$student['id']); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
        <button onclick="window.print()" class="btn btn-primary btn-sm">
            <i class="fas fa-print me-1"></i>Print
        </button>
    </div>
</div>

<div class="text-center">
<!-- Front Side -->
<div id="idCardFront" style="display:inline-block; width:320px; border:2px solid #1a5276; border-radius:12px; overflow:hidden; font-family:Arial,sans-serif; vertical-align:top; margin:8px;">
    <!-- Header -->
    <div style="background:linear-gradient(135deg,#1a5276,#2980b9); color:#fff; padding:10px 12px; text-align:center;">
        <div style="font-size:13px; font-weight:bold; text-transform:uppercase;"><?php echo htmlspecialchars($schoolName); ?></div>
        <div style="font-size:9px; opacity:.85;"><?php echo htmlspecialchars($settings['address'] ?? ''); ?></div>
        <div style="font-size:10px; margin-top:2px; letter-spacing:1px; font-weight:bold;">STUDENT IDENTITY CARD</div>
    </div>
    <!-- Body -->
    <div style="padding:12px; background:#fff; display:flex; gap:12px; align-items:flex-start;">
        <div style="flex-shrink:0;">
            <?php if (!empty($student['photo'])): ?>
            <img src="<?php echo asset($student['photo']); ?>" style="width:70px;height:85px;object-fit:cover;border:2px solid #1a5276;border-radius:4px;">
            <?php else: ?>
            <div style="width:70px;height:85px;background:#eaf2ff;border:2px solid #1a5276;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#aaa;">
                <i class="fas fa-user" style="font-size:24px;"></i>
            </div>
            <?php endif; ?>
        </div>
        <div style="font-size:11px; line-height:1.7;">
            <div style="font-size:13px; font-weight:bold; color:#1a5276;"><?php echo htmlspecialchars(trim($student['first_name'].' '.($student['last_name']??''))); ?></div>
            <div><span style="color:#777;">Adm No:</span> <strong><?php echo e($student['admission_number']); ?></strong></div>
            <div><span style="color:#777;">Class:</span> <?php echo e($student['class_name']??'—'); ?> <?php echo isset($student['section_name']) ? '– '.$student['section_name'] : ''; ?></div>
            <div><span style="color:#777;">Roll:</span> <?php echo e($student['roll_number']??'—'); ?></div>
            <div><span style="color:#777;">DOB:</span> <?php echo !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '—'; ?></div>
            <div><span style="color:#777;">Blood:</span> <?php echo e($student['blood_group']??'—'); ?></div>
        </div>
    </div>
    <!-- Footer -->
    <div style="background:#eaf2ff; padding:6px 12px; font-size:9px; display:flex; justify-content:space-between;">
        <span><?php echo e($activeSession['name'] ?? ''); ?></span>
        <span><?php echo e($settings['phone'] ?? ''); ?></span>
    </div>
</div>

<!-- Back Side -->
<div style="display:inline-block; width:320px; border:2px solid #1a5276; border-radius:12px; overflow:hidden; font-family:Arial,sans-serif; vertical-align:top; margin:8px;">
    <div style="background:linear-gradient(135deg,#1a5276,#2980b9); color:#fff; padding:8px 12px; text-align:center; font-size:11px; font-weight:bold;">
        CONTACT INFORMATION
    </div>
    <div style="padding:12px; background:#fff; font-size:11px; line-height:1.8;">
        <div><span style="color:#777;">Father:</span> <?php echo e($student['father_name']??'—'); ?></div>
        <div><span style="color:#777;">Mother:</span> <?php echo e($student['mother_name']??'—'); ?></div>
        <div><span style="color:#777;">Phone:</span> <?php echo e($student['father_phone'] ?? ($student['phone']??'—')); ?></div>
        <div><span style="color:#777;">Address:</span> <?php echo e($student['address']??'—'); ?></div>
    </div>
    <div style="background:#fff3e0; padding:8px 12px; font-size:9px; color:#777; border-top:1px solid #eee;">
        If found, please return to the school. Contact: <?php echo e($settings['phone'] ?? '—'); ?>
    </div>
    <div style="padding:12px; text-align:center;">
        <div style="border-top:1px solid #333; margin-top:28px; padding-top:4px; font-size:10px; display:inline-block; width:120px;">Principal's Signature</div>
    </div>
</div>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar, .main-footer { display:none !important; }
    body { background:white !important; }
    #idCardFront, #idCardFront + div { page-break-inside:avoid; }
}
</style>
