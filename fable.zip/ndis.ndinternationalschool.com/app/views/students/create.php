<div class="page-header">
    <h4><i class="fas fa-plus-circle"></i> Add Student</h4>
    <a href="<?php echo url('students'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<form method="POST" action="<?php echo url('students/create'); ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

    <div class="row">
        <!-- Personal Info -->
        <div class="col-lg-8">
            <div class="card mb-3">
                <div class="card-header"><h6><i class="fas fa-user me-2"></i>Personal Information</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Title</label>
                            <select name="title" class="form-select">
                                <option value="Master">Master</option>
                                <option value="Miss">Miss</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Gender <span class="text-danger">*</span></label>
                            <select name="gender" class="form-select" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">DOB <span class="text-danger">*</span></label>
                            <input type="date" name="date_of_birth" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Aadhaar No.</label>
                            <input type="text" name="aadhaar_number" class="form-control" maxlength="12">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <option>A+</option><option>A-</option><option>B+</option><option>B-</option>
                                <option>AB+</option><option>AB-</option><option>O+</option><option>O-</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Religion</label>
                            <input type="text" name="religion" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Category</label>
                            <select name="category" class="form-select">
                                <option value="">Select</option>
                                <option>General</option><option>OBC</option><option>SC</option><option>ST</option><option>EWS</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Mobile <span class="text-danger">*</span></label>
                            <input type="text" name="mobile" class="form-control" maxlength="10" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Parent Info -->
            <div class="card mb-3">
                <div class="card-header"><h6><i class="fas fa-users me-2"></i>Parent / Guardian Information</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Father's Name <span class="text-danger">*</span></label>
                            <input type="text" name="father_name" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Father's Phone <span class="text-danger">*</span></label>
                            <input type="text" name="father_phone" class="form-control" maxlength="10" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Father's Email</label>
                            <input type="email" name="father_email" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Father's Occupation</label>
                            <input type="text" name="father_occupation" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Mother's Name</label>
                            <input type="text" name="mother_name" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Mother's Phone</label>
                            <input type="text" name="mother_phone" class="form-control" maxlength="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Parent Address</label>
                            <textarea name="parent_address" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic & Photo -->
        <div class="col-lg-4">
            <div class="card mb-3">
                <div class="card-header"><h6><i class="fas fa-graduation-cap me-2"></i>Academic Information</h6></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Admission No. <span class="text-muted small">(optional)</span></label>
                        <input type="text" name="admission_number" class="form-control" placeholder="e.g. 2025-001 — baad mein bhi add kar sakte hain">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Admission Date</label>
                        <input type="date" name="admission_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" class="form-select" required id="classSelect">
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>"><?php echo e($class['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Section</label>
                        <select name="section_id" class="form-select" id="sectionSelect">
                            <option value="">Select Section</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Roll Number</label>
                        <input type="text" name="roll_number" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Previous School</label>
                        <input type="text" name="previous_school" class="form-control">
                    </div>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header"><h6><i class="fas fa-camera me-2"></i>Photo</h6></div>
                <div class="card-body text-center">
                    <input type="file" name="photo" class="form-control" accept="image/*">
                    <small class="text-muted">Max 2MB, JPG/PNG only</small>
                </div>
            </div>

            <button type="submit" class="btn btn-primary-custom w-100 btn-lg"><i class="fas fa-save me-1"></i>Save Student</button>
        </div>
    </div>
</form>

<script>
document.getElementById('classSelect').addEventListener('change', function() {
    const classId = this.value;
    const sectionSelect = document.getElementById('sectionSelect');
    sectionSelect.innerHTML = '<option value="">Loading...</option>';
    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + classId)
        .then(r => r.json())
        .then(data => {
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            data.forEach(s => { sectionSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`; });
        })
        .catch(() => { sectionSelect.innerHTML = '<option value="">Select Section</option>'; });
});
</script>
