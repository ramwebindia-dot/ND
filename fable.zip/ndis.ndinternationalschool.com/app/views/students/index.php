﻿<div class="page-header">
    <h4><i class="fas fa-user-graduate"></i> Students</h4>
    <div>
        <a href="<?php echo url('students/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Add Student</a>
        <a href="<?php echo url('students/import'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-file-import me-1"></i>Import CSV</a>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('students'); ?>" class="row g-2">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Search by name, admission no..." value="<?php echo e($search); ?>">
            </div>
            <div class="col-md-3">
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" <?php echo $classId == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Adm. No.</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Gender</th>
                        <th>Mobile</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">No students found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($students as $i => $student): ?>
                        <tr>
                            <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                            <td><strong><?php echo e($student['admission_number']); ?></strong></td>
                            <td>
                                <?php if (!empty($student['photo'])): ?>
                                    <img src="<?php echo asset($student['photo']); ?>" class="rounded-circle me-2" width="30" height="30" alt="">
                                <?php endif; ?>
                                <?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?>
                            </td>
                            <td><?php echo e($student['class_name'] ?? '-'); ?></td>
                            <td><?php echo e($student['gender'] ?? '-'); ?></td>
                            <td><?php echo e($student['mobile'] ?? '-'); ?></td>
                            <td>
                                <span class="badge <?php echo $student['status'] === 'Active' ? 'badge-success-custom' : ($student['status'] === 'Dropout' ? 'badge-danger-custom' : 'badge-warning-custom'); ?>">
                                    <?php echo e($student['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo url('students/profile?id=' . $student['id']); ?>" class="btn btn-sm btn-outline-primary-custom" title="Profile"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo url('students/edit?id=' . $student['id']); ?>" class="btn btn-sm btn-outline-info" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo url('students/fee-ledger?id=' . $student['id']); ?>" class="btn btn-sm btn-outline-success" title="Fee Ledger"><i class="fas fa-rupee-sign"></i></a>
                                <a href="<?php echo url('students/id-card?id=' . $student['id']); ?>" class="btn btn-sm btn-outline-secondary" title="ID Card"><i class="fas fa-id-card"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('students?page=' . $p . '&search=' . $search . '&class_id=' . $classId); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
