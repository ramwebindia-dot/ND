<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-file-import me-2"></i>Bulk Import Students</h4>
    <a href="<?php echo url('students'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row g-3">
<div class="col-md-7">
<div class="card">
    <div class="card-header fw-bold">Upload CSV File</div>
    <div class="card-body">
        <div class="alert alert-info small">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Required CSV columns:</strong><br>
            <code>first_name, last_name, gender, date_of_birth, class_id, section_id, roll_number, father_name, father_phone, mother_name, address</code><br>
            Optional: <code>email, blood_group, religion, category, admission_number</code>
        </div>
        <form method="POST" action="<?php echo url('students/import'); ?>" enctype="multipart/form-data">
            <?php echo CSRF::field(); ?>
            <div class="mb-3">
                <label class="form-label">CSV File <span class="text-danger">*</span></label>
                <input type="file" name="csv_file" class="form-control" accept=".csv,.txt" required>
                <div class="form-text">Max 500 rows per import. Use UTF-8 encoding.</div>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-upload me-2"></i>Import Students
                </button>
            </div>
        </form>
    </div>
</div>
</div>

<div class="col-md-5">
<div class="card">
    <div class="card-header fw-bold">Download Template</div>
    <div class="card-body">
        <p class="text-muted small">Download a sample CSV file with the correct column headers and example data.</p>
        <a href="<?php echo url('students/import-template'); ?>" class="btn btn-success btn-sm">
            <i class="fas fa-download me-2"></i>Download Sample CSV
        </a>
        <hr>
        <h6 class="fw-bold">Instructions:</h6>
        <ol class="small text-muted">
            <li>Download the sample CSV template</li>
            <li>Fill in student data (do not change column headers)</li>
            <li>Use <code>class_id</code> from your Classes list</li>
            <li>Gender: <code>Male</code> or <code>Female</code></li>
            <li>Date format: <code>YYYY-MM-DD</code></li>
            <li>Upload the file above</li>
        </ol>
    </div>
</div>

<?php if (!empty($importResult)): ?>
<div class="card mt-3">
    <div class="card-header fw-bold">Import Results</div>
    <div class="card-body">
        <div class="d-flex gap-3 mb-3">
            <div class="text-center">
                <div class="fs-4 fw-bold text-success"><?php echo $importResult['imported'] ?? 0; ?></div>
                <div class="small text-muted">Imported</div>
            </div>
            <div class="text-center">
                <div class="fs-4 fw-bold text-danger"><?php echo $importResult['failed'] ?? 0; ?></div>
                <div class="small text-muted">Failed</div>
            </div>
            <div class="text-center">
                <div class="fs-4 fw-bold text-secondary"><?php echo $importResult['skipped'] ?? 0; ?></div>
                <div class="small text-muted">Skipped</div>
            </div>
        </div>
        <?php if (!empty($importResult['errors'])): ?>
        <div class="small text-danger">
            <strong>Errors:</strong>
            <ul class="mb-0 mt-1">
                <?php foreach (array_slice($importResult['errors'], 0, 10) as $err): ?>
                <li><?php echo e($err); ?></li>
                <?php endforeach; ?>
                <?php if (count($importResult['errors']) > 10): ?>
                <li class="text-muted">...and <?php echo count($importResult['errors']) - 10; ?> more</li>
                <?php endif; ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
</div>
</div>
