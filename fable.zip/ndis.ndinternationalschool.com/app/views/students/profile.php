﻿<div class="page-header">
    <h4><i class="fas fa-user"></i> Student Profile</h4>
    <div>
        <a href="<?php echo url('students/edit?id=' . $student['id']); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-edit me-1"></i>Edit</a>
        <a href="<?php echo url('students/fee-ledger?id=' . $student['id']); ?>" class="btn btn-outline-success"><i class="fas fa-rupee-sign me-1"></i>Fee Ledger</a>
        <a href="<?php echo url('students/id-card?id=' . $student['id']); ?>" class="btn btn-outline-secondary"><i class="fas fa-id-card me-1"></i>ID Card</a>
        <a href="<?php echo url('students/transfer-certificate?id=' . $student['id']); ?>" class="btn btn-outline-warning"><i class="fas fa-certificate me-1"></i>TC</a>
        <a href="<?php echo url('students'); ?>" class="btn btn-outline-dark"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-body text-center">
                <?php if (!empty($student['photo'])): ?>
                    <img src="<?php echo asset($student['photo']); ?>" class="rounded-circle mb-3" width="120" height="120" alt="">
                <?php else: ?>
                    <div class="rounded-circle bg-primary-custom text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:120px;height:120px;font-size:48px;">
                        <i class="fas fa-user"></i>
                    </div>
                <?php endif; ?>
                <h5><?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?></h5>
                <p class="text-muted mb-1">Adm. No: <strong><?php echo e($student['admission_number']); ?></strong></p>
                <span class="badge <?php echo $student['status'] === 'Active' ? 'badge-success-custom' : 'badge-warning-custom'; ?>"><?php echo e($student['status']); ?></span>
                <?php if (!empty($outstanding) && $outstanding > 0): ?>
                    <div class="alert alert-warning mt-3 py-2">
                        <small>Outstanding: <strong><?php echo formatCurrency($outstanding); ?></strong></small>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header"><h6>Personal Details</h6></div>
            <div class="card-body">
                <table class="table table-sm table-borderless">
                    <tr><td class="text-muted">Gender</td><td><?php echo e($student['gender'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">DOB</td><td><?php echo formatDate($student['date_of_birth'] ?? ''); ?></td></tr>
                    <tr><td class="text-muted">Blood Group</td><td><?php echo e($student['blood_group'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">Religion</td><td><?php echo e($student['religion'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">Category</td><td><?php echo e($student['category'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">Mobile</td><td><?php echo e($student['mobile'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">Email</td><td><?php echo e($student['email'] ?? '-'); ?></td></tr>
                    <tr><td class="text-muted">Aadhaar</td><td><?php echo e($student['aadhaar_number'] ?? '-'); ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card mb-3">
            <div class="card-header"><h6>Academic Information</h6></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4"><strong>Class:</strong> <?php echo e($student['class_name'] ?? '-'); ?></div>
                    <div class="col-md-4"><strong>Section:</strong> <?php echo e($student['section_name'] ?? '-'); ?></div>
                    <div class="col-md-4"><strong>Roll No:</strong> <?php echo e($student['roll_number'] ?? '-'); ?></div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-4"><strong>Admission Date:</strong> <?php echo formatDate($student['admission_date'] ?? ''); ?></div>
                    <div class="col-md-4"><strong>Previous School:</strong> <?php echo e($student['previous_school'] ?? '-'); ?></div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header"><h6>Parent / Guardian</h6></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Father:</strong> <?php echo e($student['father_name'] ?? '-'); ?><br>
                        <small class="text-muted">Phone: <?php echo e($student['father_phone'] ?? '-'); ?> | Occupation: <?php echo e($student['father_occupation'] ?? '-'); ?></small>
                    </div>
                    <div class="col-md-6">
                        <strong>Mother:</strong> <?php echo e($student['mother_name'] ?? '-'); ?><br>
                        <small class="text-muted">Phone: <?php echo e($student['mother_phone'] ?? '-'); ?></small>
                    </div>
                </div>
                <?php if (!empty($student['address'])): ?>
                <div class="mt-2"><strong>Address:</strong> <?php echo e($student['address']); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
