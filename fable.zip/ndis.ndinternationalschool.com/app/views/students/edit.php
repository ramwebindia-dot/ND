<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Student</h4>
    <a href="<?php echo url('students/profile?id=' . $student['id']); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back to Profile</a>
</div>

<form method="POST" action="<?php echo url('students/edit?id=' . $student['id']); ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-3">
                <div class="card-header"><h6>Personal Information</h6></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2 mb-3"><label class="form-label">Title</label><select name="title" class="form-select"><option value="Master" <?php echo ($student['title'] ?? '') === 'Master' ? 'selected' : ''; ?>>Master</option><option value="Miss" <?php echo ($student['title'] ?? '') === 'Miss' ? 'selected' : ''; ?>>Miss</option></select></div>
                        <div class="col-md-3 mb-3"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" value="<?php echo e($student['first_name']); ?>" required></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Last Name</label><input type="text" name="last_name" class="form-control" value="<?php echo e($student['last_name'] ?? ''); ?>"></div>
                        <div class="col-md-2 mb-3"><label class="form-label">Gender *</label><select name="gender" class="form-select" required><option value="Male" <?php echo ($student['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option><option value="Female" <?php echo ($student['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option><option value="Other" <?php echo ($student['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option></select></div>
                        <div class="col-md-2 mb-3"><label class="form-label">DOB *</label><input type="date" name="date_of_birth" class="form-control" value="<?php echo e($student['dob'] ?? ''); ?>" required></div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3"><label class="form-label">Aadhaar</label><input type="text" name="aadhaar_number" class="form-control" value="<?php echo e($student['aadhaar_number'] ?? ''); ?>" maxlength="12"></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Blood Group</label><select name="blood_group" class="form-select"><option value="">Select</option><?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bg): ?><option <?php echo ($student['blood_group'] ?? '') === $bg ? 'selected' : ''; ?>><?php echo $bg; ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Mobile *</label><input type="text" name="mobile" class="form-control" value="<?php echo e($student['phone'] ?? ''); ?>" maxlength="10" required></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo e($student['email'] ?? ''); ?>"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"><?php echo e($student['address'] ?? ''); ?></textarea></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Religion</label><input type="text" name="religion" class="form-control" value="<?php echo e($student['religion'] ?? ''); ?>"></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Category</label><select name="category" class="form-select"><option value="">Select</option><?php foreach(['General','OBC','SC','ST','EWS'] as $cat): ?><option <?php echo ($student['category'] ?? '') === $cat ? 'selected' : ''; ?>><?php echo $cat; ?></option><?php endforeach; ?></select></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card mb-3">
                <div class="card-header"><h6>Academic</h6></div>
                <div class="card-body">
                    <div class="mb-3"><label class="form-label">Admission No.</label><input type="text" name="admission_number" class="form-control" value="<?php echo e($student['admission_number'] ?? ''); ?>"></div>
                    <div class="mb-3"><label class="form-label">Class</label><select name="class_id" class="form-select"><?php foreach ($classes as $class): ?><option value="<?php echo $class['id']; ?>" <?php echo ($student['class_id'] ?? '') == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option><?php endforeach; ?></select></div>
                    <div class="mb-3"><label class="form-label">Section</label><select name="section_id" class="form-select"><option value="">Select</option><?php foreach ($sections as $sec): ?><option value="<?php echo $sec['id']; ?>" <?php echo ($student['section_id'] ?? '') == $sec['id'] ? 'selected' : ''; ?>><?php echo e($sec['name']); ?></option><?php endforeach; ?></select></div>
                    <div class="mb-3"><label class="form-label">Roll No</label><input type="text" name="roll_number" class="form-control" value="<?php echo e($student['roll_number'] ?? ''); ?>"></div>
                </div>
            </div>
            <div class="card mb-3">
                <div class="card-header"><h6>Photo</h6></div>
                <div class="card-body text-center">
                    <?php if (!empty($student['photo'])): ?><img src="<?php echo asset($student['photo']); ?>" class="rounded-circle mb-2" width="80" height="80" alt=""><br><?php endif; ?>
                    <input type="file" name="photo" class="form-control" accept="image/*">
                </div>
            </div>
            <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-save me-1"></i>Update Student</button>
        </div>
    </div>
</form>
