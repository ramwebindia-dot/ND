<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-search"></i> Audit Log Detail</h4>
    <a href="<?php echo url('audit'); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="fas fa-arrow-left"></i> Back to Logs
    </a>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-info-circle me-2"></i>Log Entry Details</div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 200px;">Log ID</th>
                        <td><?php echo $log['id']; ?></td>
                    </tr>
                    <tr>
                        <th>Module</th>
                        <td><span class="badge bg-secondary"><?php echo e(ucfirst($log['module'])); ?></span></td>
                    </tr>
                    <tr>
                        <th>Action</th>
                        <td><span class="badge bg-info"><?php echo e($log['action']); ?></span></td>
                    </tr>
                    <tr>
                        <th>Record ID</th>
                        <td><?php echo e($log['record_id'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>IP Address</th>
                        <td><?php echo e($log['ip_address'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>User Agent</th>
                        <td><?php echo e($log['user_agent'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Date & Time</th>
                        <td><?php echo formatDateTime($log['created_at']); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <?php if (!empty($log['old_values']) || !empty($log['new_values'])): ?>
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-exchange-alt me-2"></i>Changes</div>
            <div class="card-body">
                <div class="row">
                    <?php if (!empty($log['old_values'])): ?>
                    <div class="col-md-6">
                        <h6 class="text-danger">Old Values</h6>
                        <pre class="bg-light p-3 rounded"><?php echo e(is_string($log['old_values']) ? $log['old_values'] : json_encode(json_decode($log['old_values'], true), JSON_PRETTY_PRINT)); ?></pre>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($log['new_values'])): ?>
                    <div class="col-md-6">
                        <h6 class="text-success">New Values</h6>
                        <pre class="bg-light p-3 rounded"><?php echo e(is_string($log['new_values']) ? $log['new_values'] : json_encode(json_decode($log['new_values'], true), JSON_PRETTY_PRINT)); ?></pre>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><i class="fas fa-user me-2"></i>User Information</div>
            <div class="card-body">
                <?php if ($user): ?>
                <table class="table table-sm">
                    <tr>
                        <th>User ID</th>
                        <td><?php echo $user['id']; ?></td>
                    </tr>
                    <tr>
                        <th>Username</th>
                        <td><?php echo e($user['username']); ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($user['full_name'] ?? $user['username']); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($user['email'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Role</th>
                        <td><span class="badge bg-primary"><?php echo e($user['role_name'] ?? 'N/A'); ?></span></td>
                    </tr>
                </table>
                <?php else: ?>
                <p class="text-muted text-center">System / Unknown User</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
