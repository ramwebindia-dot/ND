<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-history"></i> Audit Logs</h4>
    <a href="<?php echo url('audit/export?' . http_build_query(array_filter($filters))); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('audit'); ?>" class="row g-2 align-items-end">
            <div class="col-md-2">
                <label class="form-label">Module</label>
                <select name="module" class="form-select">
                    <option value="">All Modules</option>
                    <?php foreach ($modules as $m): ?>
                    <option value="<?php echo e($m['module']); ?>" <?php echo ($filters['module'] ?? '') === $m['module'] ? 'selected' : ''; ?>>
                        <?php echo e(ucfirst($m['module'])); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Action</label>
                <select name="action" class="form-select">
                    <option value="">All Actions</option>
                    <option value="create" <?php echo ($filters['action'] ?? '') === 'create' ? 'selected' : ''; ?>>Create</option>
                    <option value="update" <?php echo ($filters['action'] ?? '') === 'update' ? 'selected' : ''; ?>>Update</option>
                    <option value="delete" <?php echo ($filters['action'] ?? '') === 'delete' ? 'selected' : ''; ?>>Delete</option>
                    <option value="login" <?php echo ($filters['action'] ?? '') === 'login' ? 'selected' : ''; ?>>Login</option>
                    <option value="logout" <?php echo ($filters['action'] ?? '') === 'logout' ? 'selected' : ''; ?>>Logout</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">From Date</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($filters['date_from'] ?? ''); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">To Date</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($filters['date_to'] ?? ''); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom w-100"><i class="fas fa-filter"></i> Filter</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo url('audit'); ?>" class="btn btn-outline-secondary w-100"><i class="fas fa-times"></i> Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <?php if (!empty($logs)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Module</th>
                        <th>Action</th>
                        <th>Record ID</th>
                        <th>IP Address</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo $log['id']; ?></td>
                        <td><?php echo e($log['user_name'] ?? 'System'); ?></td>
                        <td><span class="badge bg-secondary"><?php echo e(ucfirst($log['module'])); ?></span></td>
                        <td><span class="badge bg-info"><?php echo e($log['action']); ?></span></td>
                        <td><?php echo e($log['record_id'] ?? '-'); ?></td>
                        <td><?php echo e($log['ip_address'] ?? '-'); ?></td>
                        <td><?php echo formatDateTime($log['created_at']); ?></td>
                        <td>
                            <a href="<?php echo url('audit/detail?id=' . $log['id']); ?>" class="btn btn-sm btn-info" title="View Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if (isset($pagination) && $pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['current_page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('audit?' . http_build_query(array_merge(array_filter($filters), ['page' => $p]))); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-history fa-3x text-muted mb-3"></i>
            <p class="text-muted">No audit logs found matching your criteria.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
