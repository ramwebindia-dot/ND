<div class="page-header">
    <h4><i class="fas fa-arrow-down text-success"></i> Income</h4>
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#incomeModal">
        <i class="fas fa-plus me-1"></i>Record Income
    </button>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('accounting/income'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">From Date</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">To Date</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-filter me-1"></i>Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th class="text-end">Amount</th>
                        <th>Method</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($incomes)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No income records found.</td></tr>
                    <?php else: ?>
                        <?php $totalIncome = 0; ?>
                        <?php foreach ($incomes as $i => $inc): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo e($inc['title']); ?></td>
                            <td><?php echo !empty($inc['category']) ? e($inc['category']) : '-'; ?></td>
                            <td class="text-end text-success fw-bold"><?php echo formatCurrency($inc['amount']); ?></td>
                            <td><span class="badge bg-info"><?php echo e($inc['payment_method'] ?? 'Cash'); ?></span></td>
                            <td><?php echo formatDate($inc['income_date']); ?></td>
                        </tr>
                        <?php $totalIncome += $inc['amount']; ?>
                        <?php endforeach; ?>
                        <tr class="table-warning">
                            <td colspan="3" class="text-end"><strong>Total Income</strong></td>
                            <td class="text-end"><strong><?php echo formatCurrency($totalIncome); ?></strong></td>
                            <td colspan="2"></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Record Income Modal -->
<div class="modal fade" id="incomeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('accounting/saveIncome'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Record Income</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category</label>
                        <input type="text" name="category" class="form-control" placeholder="e.g. Fee Collection, Donation">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Amount <span class="text-danger">*</span></label>
                        <input type="number" name="amount" class="form-control" step="0.01" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Method <span class="text-danger">*</span></label>
                        <select name="payment_method" class="form-select" required id="incomeMethod">
                            <option value="Cash">Cash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Cheque">Cheque</option>
                            <option value="UPI">UPI</option>
                            <option value="Card">Card</option>
                        </select>
                    </div>
                    <div class="mb-3" id="incomeBankDiv" style="display:none;">
                        <label class="form-label">Bank Account <span class="text-danger">*</span></label>
                        <select name="bank_account_id" class="form-select" id="incomeBankId">
                            <option value="">Select Bank</option>
                            <?php foreach ($banks as $bank): ?>
                                <option value="<?php echo $bank['id']; ?>"><?php echo e($bank['bank_name'] . ' - ' . ($bank['account_number'] ?? '')); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Date <span class="text-danger">*</span></label>
                        <input type="date" name="income_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Save Income</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('incomeMethod').addEventListener('change', function() {
    var bankDiv = document.getElementById('incomeBankDiv');
    var bankSelect = document.getElementById('incomeBankId');
    if (this.value !== 'Cash') {
        bankDiv.style.display = 'block';
        bankSelect.required = true;
    } else {
        bankDiv.style.display = 'none';
        bankSelect.required = false;
        bankSelect.value = '';
    }
});
</script>
