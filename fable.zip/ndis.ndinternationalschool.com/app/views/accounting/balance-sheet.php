<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-balance-scale me-2"></i>Balance Sheet</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm no-print"><i class="fas fa-print me-1"></i>Print</button>
        <a href="<?php echo url('accounting'); ?>" class="btn btn-secondary btn-sm no-print"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="card" style="max-width:700px; margin:auto;">
    <div class="card-header text-center">
        <strong><?php echo e($schoolSettings['school_name'] ?? APP_NAME); ?></strong><br>
        <span class="text-muted">Balance Sheet as on <?php echo e($date); ?></span>
    </div>
    <div class="card-body p-0">
        <table class="table table-sm table-bordered mb-0">
            <thead class="table-primary"><tr><th colspan="2">ASSETS</th><th class="text-end">Amount (₹)</th></tr></thead>
            <tbody>
                <tr><td colspan="2">Cash in Hand</td><td class="text-end">₹<?php echo number_format($cashBalance,2); ?></td></tr>
                <tr><td colspan="2">Bank Balance</td><td class="text-end">₹<?php echo number_format($bankBalance,2); ?></td></tr>
                <tr><td colspan="2">Fees Receivable (Outstanding)</td><td class="text-end">₹<?php echo number_format($outstanding,2); ?></td></tr>
                <tr class="table-light fw-bold"><td colspan="2">Total Assets</td><td class="text-end text-primary">₹<?php echo number_format($totalAssets,2); ?></td></tr>
            </tbody>
            <thead class="table-warning"><tr><th colspan="2">LIABILITIES</th><th class="text-end">Amount (₹)</th></tr></thead>
            <tbody>
                <tr><td colspan="2">Salary Payable</td><td class="text-end">₹<?php echo number_format($salaryPayable,2); ?></td></tr>
                <tr class="table-light fw-bold"><td colspan="2">Total Liabilities</td><td class="text-end text-warning">₹<?php echo number_format($salaryPayable,2); ?></td></tr>
            </tbody>
            <thead class="table-success"><tr><th colspan="2">NET EQUITY (Assets − Liabilities)</th><th class="text-end">₹<?php echo number_format($equity,2); ?></th></tr></thead>
        </table>
    </div>
    <div class="card-footer text-center text-muted small">
        Assets must equal Liabilities + Equity. Generated on <?php echo date('d M Y H:i'); ?>.
    </div>
</div>
<style>@media print { .no-print{display:none!important;} .sidebar,.navbar,.main-footer{display:none!important;} }</style>
