<div class="page-header">
    <h4><i class="fas fa-university"></i> Bank Accounts</h4>
    <button type="button" class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#bankModal">
        <i class="fas fa-plus me-1"></i>Add Bank Account
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Bank Name</th>
                        <th>Account Number</th>
                        <th>IFSC Code</th>
                        <th>Account Holder</th>
                        <th class="text-end">Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($banks)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">No bank accounts found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($banks as $i => $bank): ?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><strong><?php echo e($bank['bank_name']); ?></strong></td>
                            <td><?php echo e($bank['account_number'] ?? '-'); ?></td>
                            <td><?php echo e($bank['ifsc_code'] ?? '-'); ?></td>
                            <td><?php echo e($bank['account_holder'] ?? '-'); ?></td>
                            <td class="text-end"><?php echo formatCurrency($bank['balance'] ?? 0); ?></td>
                            <td><span class="badge <?php echo $bank['is_active'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $bank['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                            <td>
                                <button class="btn btn-sm btn-outline-info edit-bank" data-id="<?php echo $bank['id']; ?>" data-name="<?php echo e($bank['bank_name']); ?>" data-acct="<?php echo e($bank['account_number'] ?? ''); ?>" data-ifsc="<?php echo e($bank['ifsc_code'] ?? ''); ?>" data-holder="<?php echo e($bank['account_holder'] ?? ''); ?>" data-balance="<?php echo $bank['balance'] ?? 0; ?>" data-active="<?php echo $bank['is_active']; ?>" title="Edit"><i class="fas fa-edit"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add/Edit Bank Account Modal -->
<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('accounting/saveBankAccount'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="id" id="bank_id" value="">
                <div class="modal-header">
                    <h5 class="modal-title" id="bankModalLabel">Add Bank Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Bank Name <span class="text-danger">*</span></label>
                        <input type="text" name="bank_name" id="bank_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Account Number <span class="text-danger">*</span></label>
                        <input type="text" name="account_number" id="bank_acct" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">IFSC Code</label>
                        <input type="text" name="ifsc_code" id="bank_ifsc" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Account Holder</label>
                        <input type="text" name="account_holder" id="bank_holder" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Opening Balance</label>
                        <input type="number" name="balance" id="bank_balance" class="form-control" step="0.01" value="0">
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="is_active" id="bank_active" class="form-check-input" value="1" checked>
                        <label class="form-check-label" for="bank_active">Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary-custom">Save Account</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-bank').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('bank_id').value = this.dataset.id;
        document.getElementById('bank_name').value = this.dataset.name;
        document.getElementById('bank_acct').value = this.dataset.acct;
        document.getElementById('bank_ifsc').value = this.dataset.ifsc;
        document.getElementById('bank_holder').value = this.dataset.holder;
        document.getElementById('bank_balance').value = this.dataset.balance;
        document.getElementById('bank_active').checked = this.dataset.active == 1;
        document.getElementById('bankModalLabel').textContent = 'Edit Bank Account';
        new bootstrap.Modal(document.getElementById('bankModal')).show();
    });
});
</script>
