<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-book me-2"></i>Journal Entries</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('accounting/profit-loss'); ?>" class="btn btn-outline-info btn-sm"><i class="fas fa-chart-line me-1"></i>P&L</a>
        <a href="<?php echo url('accounting/balance-sheet'); ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-balance-scale me-1"></i>Balance Sheet</a>
        <a href="<?php echo url('accounting'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="row g-3">
<div class="col-lg-4">
<div class="card">
    <div class="card-header fw-bold">New Journal Entry</div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('accounting/journal-entries'); ?>">
            <?php echo CSRF::field(); ?>
            <div class="mb-3">
                <label class="form-label">Date <span class="text-danger">*</span></label>
                <input type="date" name="entry_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Description <span class="text-danger">*</span></label>
                <input type="text" name="description" class="form-control" required placeholder="e.g. Fee collection, Salary paid">
            </div>
            <div class="mb-3">
                <label class="form-label">Debit Account <span class="text-danger">*</span></label>
                <select name="debit_account" class="form-select" required>
                    <option value="">Select account</option>
                    <?php foreach ($accounts as $a): ?>
                    <option value="<?php echo $a; ?>"><?php echo $a; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Credit Account <span class="text-danger">*</span></label>
                <select name="credit_account" class="form-select" required>
                    <option value="">Select account</option>
                    <?php foreach ($accounts as $a): ?>
                    <option value="<?php echo $a; ?>"><?php echo $a; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Amount (₹) <span class="text-danger">*</span></label>
                <input type="number" name="amount" class="form-control" step="0.01" min="0.01" required>
            </div>
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-plus me-2"></i>Record Entry</button>
        </form>
    </div>
</div>
</div>

<div class="col-lg-8">
<div class="card">
    <div class="card-header fw-bold">Recent Journal Entries</div>
    <div class="table-responsive">
        <table class="table table-sm table-hover mb-0">
            <thead class="table-light">
                <tr><th>Date</th><th>Reference</th><th>Description</th><th>Debit</th><th>Credit</th><th class="text-end">Amount</th></tr>
            </thead>
            <tbody>
            <?php if (empty($entries)): ?>
            <tr><td colspan="6" class="text-center text-muted py-3">No journal entries yet.</td></tr>
            <?php else: ?>
            <?php foreach ($entries as $e): ?>
            <tr>
                <td><?php echo formatDate($e['entry_date']); ?></td>
                <td><span class="badge bg-secondary"><?php echo e($e['reference']); ?></span></td>
                <td><?php echo e($e['description']); ?></td>
                <td class="text-danger"><?php echo e($e['debit_account']); ?></td>
                <td class="text-success"><?php echo e($e['credit_account']); ?></td>
                <td class="text-end fw-bold">₹<?php echo number_format($e['amount'],2); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
