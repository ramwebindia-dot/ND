<div class="page-header">
    <h4><i class="fas fa-exchange-alt"></i> All Transactions</h4>
    <a href="<?php echo url('accounting'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Method</th>
                        <th class="text-end">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">No transactions found.</td></tr>
                    <?php else: ?>
                        <?php
                        // Money in: Income, Fee Collection. Money out: Expense, Refund.
                        $creditTypes = ['Income', 'Fee Collection'];
                        ?>
                        <?php foreach ($transactions as $i => $txn): ?>
                        <?php $isCredit = in_array($txn['type'] ?? '', $creditTypes, true); ?>
                        <tr>
                            <td><?php echo ($pagination['page'] - 1) * $pagination['per_page'] + $i + 1; ?></td>
                            <td><?php echo formatDate($txn['transaction_date']); ?></td>
                            <td>
                                <span class="badge <?php echo $isCredit ? 'bg-success' : 'bg-danger'; ?>">
                                    <?php echo e($txn['type'] ?? '-'); ?>
                                </span>
                            </td>
                            <td><?php echo e($txn['description'] ?? '-'); ?></td>
                            <td><?php echo e($txn['payment_method'] ?? '-'); ?></td>
                            <td class="text-end fw-bold <?php echo $isCredit ? 'text-success' : 'text-danger'; ?>">
                                <?php echo ($isCredit ? '+' : '-') . formatCurrency($txn['amount']); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pagination['total_pages'] > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php for ($p = 1; $p <= $pagination['total_pages']; $p++): ?>
                <li class="page-item <?php echo $p == $pagination['page'] ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo url('accounting/transactions?page=' . $p); ?>"><?php echo $p; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
