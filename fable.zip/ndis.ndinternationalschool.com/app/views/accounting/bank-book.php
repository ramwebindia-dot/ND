<div class="page-header">
    <h4><i class="fas fa-university"></i> Bank Book</h4>
    <a href="<?php echo url('accounting'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('accounting/bank-book'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Bank Account <span class="text-danger">*</span></label>
                <select name="bank_id" class="form-select" required>
                    <option value="">Select Bank</option>
                    <?php foreach ($banks as $bank): ?>
                        <option value="<?php echo $bank['id']; ?>" <?php echo $bankId == $bank['id'] ? 'selected' : ''; ?>><?php echo e($bank['bank_name'] . ' - ' . ($bank['account_number'] ?? '')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">From Date</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">To Date</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-filter me-1"></i>Filter</button>
            </div>
        </form>
    </div>
</div>

<?php if ($bankId): ?>
<div class="card mb-3">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <span><strong>Bank Balance:</strong></span>
            <span class="fs-5 fw-bold text-primary"><?php echo formatCurrency($bankBalance); ?></span>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th class="text-end">Credit (In)</th>
                        <th class="text-end">Debit (Out)</th>
                        <th class="text-end">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">No bank entries found for this period.</td></tr>
                    <?php else: ?>
                        <?php foreach ($entries as $entry): ?>
                        <?php
                            $isCredit = ($entry['transaction_type'] ?? '') === 'Credit';
                            $credit = $isCredit ? (float) $entry['amount'] : 0;
                            $debit  = !$isCredit ? (float) $entry['amount'] : 0;
                        ?>
                        <tr>
                            <td><?php echo formatDate($entry['transaction_date']); ?></td>
                            <td><?php echo e($entry['description']); ?></td>
                            <td class="text-end text-success"><?php echo $credit > 0 ? formatCurrency($credit) : '-'; ?></td>
                            <td class="text-end text-danger"><?php echo $debit > 0 ? formatCurrency($debit) : '-'; ?></td>
                            <td class="text-end fw-bold"><?php echo formatCurrency($entry['balance_after']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-4">
        <i class="fas fa-university fa-3x mb-3"></i>
        <p>Please select a bank account to view its book.</p>
    </div>
</div>
<?php endif; ?>
