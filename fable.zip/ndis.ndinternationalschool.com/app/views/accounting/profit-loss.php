<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-chart-line me-2"></i>Profit & Loss Statement</h4>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm no-print"><i class="fas fa-print me-1"></i>Print</button>
        <a href="<?php echo url('accounting'); ?>" class="btn btn-secondary btn-sm no-print"><i class="fas fa-arrow-left me-1"></i>Back</a>
    </div>
</div>

<div class="card mb-3 no-print">
    <div class="card-body">
        <form method="GET" action="<?php echo url('accounting/profit-loss'); ?>" class="row g-2 align-items-end">
            <div class="col-auto">
                <label class="form-label">From</label>
                <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-auto">
                <label class="form-label">To</label>
                <input type="date" name="date_to" value="<?php echo e($dateTo); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm">Generate</button></div>
        </form>
    </div>
</div>

<div class="card" style="max-width:700px; margin:auto;">
    <div class="card-header text-center">
        <strong><?php echo e($schoolSettings['school_name'] ?? APP_NAME); ?></strong><br>
        <span class="text-muted">Profit & Loss Statement — <?php echo date('d M Y', strtotime($dateFrom)); ?> to <?php echo date('d M Y', strtotime($dateTo)); ?></span>
    </div>
    <div class="card-body p-0">
        <table class="table table-sm table-bordered mb-0">
            <thead class="table-success"><tr><th colspan="2">INCOME</th><th class="text-end">Amount (₹)</th></tr></thead>
            <tbody>
                <tr><td colspan="2">Fee Collections</td><td class="text-end">₹<?php echo number_format($feeIncome,2); ?></td></tr>
                <?php foreach ($otherIncome as $o): ?>
                <tr><td colspan="2">&nbsp;&nbsp;<?php echo e($o['category']); ?></td><td class="text-end">₹<?php echo number_format($o['total'],2); ?></td></tr>
                <?php endforeach; ?>
                <tr class="table-light fw-bold"><td colspan="2">Total Income</td><td class="text-end text-success">₹<?php echo number_format($totalIncome,2); ?></td></tr>
            </tbody>
            <thead class="table-danger"><tr><th colspan="2">EXPENSES</th><th class="text-end">Amount (₹)</th></tr></thead>
            <tbody>
                <tr><td colspan="2">Salary Paid</td><td class="text-end">₹<?php echo number_format($salary,2); ?></td></tr>
                <?php foreach ($expenses as $ex): ?>
                <tr><td colspan="2">&nbsp;&nbsp;<?php echo e($ex['category']); ?></td><td class="text-end">₹<?php echo number_format($ex['total'],2); ?></td></tr>
                <?php endforeach; ?>
                <tr class="table-light fw-bold"><td colspan="2">Total Expenses</td><td class="text-end text-danger">₹<?php echo number_format($totalExpenses,2); ?></td></tr>
            </tbody>
            <tfoot>
                <tr class="<?php echo $netProfit >= 0 ? 'table-success' : 'table-danger'; ?> fw-bold">
                    <td colspan="2"><?php echo $netProfit >= 0 ? 'NET SURPLUS' : 'NET DEFICIT'; ?></td>
                    <td class="text-end fs-5">₹<?php echo number_format(abs($netProfit),2); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<style>@media print { .no-print{display:none!important;} .sidebar,.navbar,.main-footer{display:none!important;} }</style>
