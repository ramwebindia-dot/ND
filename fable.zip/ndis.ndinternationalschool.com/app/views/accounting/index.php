<div class="page-header">
    <h4><i class="fas fa-calculator"></i> Cash & Bank Accounting</h4>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h6>Cash Balance</h6>
                <h3><?php echo formatCurrency($cashBalance); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h6>Total Bank Balance</h6>
                <h3><?php echo formatCurrency($totalBankBalance); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white" style="background-color: var(--primary-color);">
            <div class="card-body">
                <h6>Total Balance</h6>
                <h3><?php echo formatCurrency($cashBalance + $totalBankBalance); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-money-bill-wave me-2"></i>Quick Links</div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo url('accounting/cash-book'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-book me-2"></i>Cash Book</a>
                    <a href="<?php echo url('accounting/bank-book'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-university me-2"></i>Bank Book</a>
                    <a href="<?php echo url('accounting/transactions'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-exchange-alt me-2"></i>All Transactions</a>
                    <a href="<?php echo url('accounting/financial-summary'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-chart-pie me-2"></i>Financial Summary</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-plus-circle me-2"></i>Record Transaction</div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo url('accounting/income'); ?>" class="btn btn-success"><i class="fas fa-arrow-down me-2"></i>Record Income</a>
                    <a href="<?php echo url('accounting/expenses'); ?>" class="btn btn-danger"><i class="fas fa-arrow-up me-2"></i>Record Expense</a>
                    <a href="<?php echo url('accounting/bank-accounts'); ?>" class="btn btn-outline-info"><i class="fas fa-university me-2"></i>Manage Bank Accounts</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($banks)): ?>
<div class="card">
    <div class="card-header"><i class="fas fa-university me-2"></i>Bank Accounts</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Bank</th>
                        <th>Account Number</th>
                        <th>IFSC</th>
                        <th class="text-end">Balance</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($banks as $bank): ?>
                    <tr>
                        <td><?php echo e($bank['bank_name']); ?></td>
                        <td><?php echo e($bank['account_number'] ?? '-'); ?></td>
                        <td><?php echo e($bank['ifsc_code'] ?? '-'); ?></td>
                        <td class="text-end"><?php echo formatCurrency($bank['balance'] ?? 0); ?></td>
                        <td><span class="badge <?php echo $bank['is_active'] ? 'bg-success' : 'bg-secondary'; ?>"><?php echo $bank['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
