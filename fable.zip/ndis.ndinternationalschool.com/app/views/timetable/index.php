<div class="page-header"><h4><i class="fas fa-clock"></i> Timetable</h4>
    <a href="<?php echo url('timetable/create'); ?>" class="btn btn-primary-custom"><i class="fas fa-plus me-1"></i>Create Timetable</a>
</div>
<div class="card mb-3"><div class="card-body">
    <form method="GET" action="<?php echo url('timetable'); ?>" class="row g-2 align-items-end">
        <div class="col-md-4">
            <label class="form-label">Class</label>
            <select name="class_id" id="classFilter" class="form-select" onchange="this.form.submit()">
                <option value="">Select Class</option>
                <?php foreach ($classes as $c): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo $selectedClass == $c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Section</label>
            <select name="section_id" id="sectionFilter" class="form-select" onchange="this.form.submit()">
                <option value="">All Sections</option>
                <?php foreach ($sections as $s): ?>
                <option value="<?php echo $s['id']; ?>" <?php echo $selectedSection == $s['id'] ? 'selected' : ''; ?>><?php echo e($s['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>
</div></div>
<div class="card"><div class="card-body">
<?php if (!$selectedClass): ?>
    <p class="text-center text-muted py-3">Select a class above to view its timetable.</p>
<?php elseif (empty($timetable)): ?>
    <p class="text-center text-muted py-3">No timetable entries found. Create one to get started.</p>
<?php else: ?>
<div class="table-responsive"><table class="table table-bordered">
    <thead><tr><th>Day/Period</th>
    <?php for ($p = 1; $p <= 8; $p++): ?><th>Period <?php echo $p; ?></th><?php endfor; ?>
    </tr></thead>
    <tbody>
    <?php foreach (['Monday' => 1, 'Tuesday' => 2, 'Wednesday' => 3, 'Thursday' => 4, 'Friday' => 5, 'Saturday' => 6] as $day => $dayNum): ?>
    <tr><td><strong><?php echo $day; ?></strong></td>
        <?php for ($p = 1; $p <= 8; $p++): ?>
        <td style="min-width:100px;"><?php
            $found = false;
            foreach ($timetable as $t) {
                if ((int)$t['day_of_week'] === $dayNum && $t['period_number'] == $p) {
                    $found = true;
                    echo '<small><strong>' . e($t['subject_name'] ?? '') . '</strong><br>' . e($t['teacher_name'] ?? '') . '</small>';
                    echo '<div class="mt-1 d-flex gap-1">';
                    echo '<button class="btn btn-xs btn-outline-warning" style="padding:.1rem .3rem;font-size:.65rem;" '
                        . 'onclick="editEntry(' . $t['id'] . ',\'' . e(addslashes($t['subject_name'] ?? '')) . '\',\'' . e(addslashes($t['teacher_name'] ?? '')) . '\',' . (int)$t['subject_id'] . ',' . (int)$t['teacher_id'] . ',\'' . $t['start_time'] . '\',\'' . $t['end_time'] . '\')">'
                        . '<i class="fas fa-edit"></i></button>';
                    echo '<form method="POST" action="' . url('timetable/delete') . '" class="d-inline" onsubmit="return confirm(\'Delete this entry?\')">'
                        . CSRF::field()
                        . '<input type="hidden" name="id" value="' . $t['id'] . '">'
                        . '<button type="submit" class="btn btn-xs btn-outline-danger" style="padding:.1rem .3rem;font-size:.65rem;"><i class="fas fa-times"></i></button>'
                        . '</form>';
                    echo '</div>';
                    break;
                }
            }
            if (!$found) echo '<span class="text-muted small">Free</span>';
        ?></td>
        <?php endfor; ?>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table></div>
<?php endif; ?>
</div></div>

<!-- Edit Timetable Entry Modal -->
<div class="modal fade" id="editTimetableModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('timetable/update'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="editTtId">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Timetable Entry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body row g-3">
                    <div class="col-12">
                        <label class="form-label">Subject</label>
                        <select name="subject_id" id="editTtSubject" class="form-select" required>
                            <?php foreach ($subjects ?? [] as $sub): ?>
                            <option value="<?php echo $sub['id']; ?>"><?php echo e($sub['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Teacher</label>
                        <select name="teacher_id" id="editTtTeacher" class="form-select">
                            <option value="">-- No Teacher --</option>
                            <?php foreach ($teachers ?? [] as $tch): ?>
                            <option value="<?php echo $tch['id']; ?>"><?php echo e($tch['first_name'] . ' ' . $tch['last_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label">Start Time</label>
                        <input type="time" name="start_time" id="editTtStart" class="form-control">
                    </div>
                    <div class="col-6">
                        <label class="form-label">End Time</label>
                        <input type="time" name="end_time" id="editTtEnd" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editEntry(id, subject, teacher, subjectId, teacherId, startTime, endTime) {
    document.getElementById('editTtId').value       = id;
    document.getElementById('editTtSubject').value  = subjectId;
    document.getElementById('editTtTeacher').value  = teacherId;
    document.getElementById('editTtStart').value    = startTime;
    document.getElementById('editTtEnd').value      = endTime;
    new bootstrap.Modal(document.getElementById('editTimetableModal')).show();
}
</script>