﻿<div class="page-header"><h4><i class="fas fa-plus-circle"></i> Create Timetable Entry</h4>
    <a href="<?php echo url('timetable'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>
<form method="POST" action="<?php echo url('timetable/create'); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <div class="row">
        <div class="col-md-3 mb-3"><label class="form-label">Class *</label><select name="class_id" class="form-select" id="classSelect" required><option value="">Select Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3 mb-3"><label class="form-label">Section *</label><select name="section_id" class="form-select" id="sectionSelect" required><option value="">Select Class First</option></select></div>
        <div class="col-md-3 mb-3"><label class="form-label">Day *</label><select name="day_of_week" class="form-select" required><?php foreach (['1' => 'Monday', '2' => 'Tuesday', '3' => 'Wednesday', '4' => 'Thursday', '5' => 'Friday', '6' => 'Saturday'] as $num => $name): ?><option value="<?php echo $num; ?>"><?php echo $name; ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3 mb-3"><label class="form-label">Period *</label><input type="number" name="period_number" class="form-control" min="1" max="8" required></div>
    </div>
    <div class="row">
        <div class="col-md-3 mb-3"><label class="form-label">Subject *</label><select name="subject_id" class="form-select" required><?php foreach ($subjects as $s): ?><option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3 mb-3"><label class="form-label">Teacher *</label><select name="teacher_id" class="form-select" required><?php foreach ($teachers as $t): ?><option value="<?php echo $t['id']; ?>"><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3 mb-3"><label class="form-label">Start Time *</label><input type="time" name="start_time" class="form-control" required></div>
        <div class="col-md-3 mb-3"><label class="form-label">End Time *</label><input type="time" name="end_time" class="form-control" required></div>
    </div>
    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Save Entry</button>
</form>

<script>
document.getElementById('classSelect').addEventListener('change', function() {
    const classId = this.value;
    const sectionSelect = document.getElementById('sectionSelect');
    if (!classId) {
        sectionSelect.innerHTML = '<option value="">Select Class First</option>';
        return;
    }
    sectionSelect.innerHTML = '<option value="">Loading...</option>';
    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + classId)
        .then(r => r.json())
        .then(data => {
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            data.forEach(s => { sectionSelect.innerHTML += `<option value="${s.id}">${s.name}</option>`; });
        })
        .catch(() => { sectionSelect.innerHTML = '<option value="">Select Section</option>'; });
});
</script>
