<?php /** @var array $timetable */ ?>
<div class="container">
    <div class="text-center mb-4">
        <h2><?php echo e($schoolName ?? 'School'); ?> - Timetable</h2>
        <p class="text-muted">Printed on: <?php echo date('d M Y'); ?></p>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr class="table-dark">
                    <th>Day / Period</th>
                    <?php for ($p = 1; $p <= 8; $p++): ?>
                    <th>Period <?php echo $p; ?></th>
                    <?php endfor; ?>
                </tr>
            </thead>
            <tbody>
                <?php $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']; ?>
                <?php foreach ($days as $day): ?>
                <tr>
                    <td><strong><?php echo $day; ?></strong></td>
                    <?php for ($p = 1; $p <= 8; $p++): ?>
                    <td class="text-center">
                        <?php $slot = $timetable[$day][$p] ?? null; ?>
                        <?php if ($slot): ?>
                            <small><strong><?php echo e($slot['subject'] ?? '-'); ?></strong><br><?php echo e($slot['teacher'] ?? ''); ?></small>
                        <?php else: ?>&mdash;<?php endif; ?>
                    </td>
                    <?php endfor; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="text-center mt-3">
        <button onclick="window.print()" class="btn btn-primary no-print">
            <i class="fas fa-print me-1"></i> Print
        </button>
    </div>
</div>
