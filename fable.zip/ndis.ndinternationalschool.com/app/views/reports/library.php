<div class="page-header">
    <h4><i class="fas fa-book-open"></i> Library Report</h4>
</div>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white" style="background-color: var(--primary-color);">
            <div class="card-body text-center">
                <h6>Total Books</h6>
                <h3><?php echo $totalBooks; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success text-center">
            <div class="card-body">
                <h6>Available</h6>
                <h3><?php echo $availableBooks; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info text-center">
            <div class="card-body">
                <h6>Currently Issued</h6>
                <h3><?php echo count($issued); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger text-center">
            <div class="card-body">
                <h6>Overdue</h6>
                <h3><?php echo count($overdue); ?></h3>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($overdue)): ?>
<div class="card mb-3">
    <div class="card-header bg-danger text-white"><i class="fas fa-exclamation-triangle me-2"></i>Overdue Books</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Days Overdue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($overdue as $o): ?>
                    <tr>
                        <td><?php echo e($o['book_title'] ?? $o['title'] ?? '-'); ?></td>
                        <td><?php echo e(($o['student_first_name'] ?? '') . ' ' . ($o['student_last_name'] ?? '')); ?></td>
                        <td><?php echo formatDate($o['issue_date']); ?></td>
                        <td><?php echo formatDate($o['due_date']); ?></td>
                        <td><span class="badge bg-danger"><?php echo (int)((time() - strtotime($o['due_date'])) / 86400); ?> days</span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><i class="fas fa-list me-2"></i>Currently Issued Books</div>
    <div class="card-body">
        <?php if (!empty($issued)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($issued as $i): ?>
                    <tr>
                        <td><?php echo e($i['book_title'] ?? $i['title'] ?? '-'); ?></td>
                        <td><?php echo e(($i['student_first_name'] ?? '') . ' ' . ($i['student_last_name'] ?? '')); ?></td>
                        <td><?php echo formatDate($i['issue_date']); ?></td>
                        <td><?php echo formatDate($i['due_date']); ?></td>
                        <td>
                            <?php if (strtotime($i['due_date']) < time()): ?>
                                <span class="badge bg-danger">Overdue</span>
                            <?php else: ?>
                                <span class="badge bg-success">Issued</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p class="text-muted text-center mb-0">No books currently issued.</p>
        <?php endif; ?>
    </div>
</div>
