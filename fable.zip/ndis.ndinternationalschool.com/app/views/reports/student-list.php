﻿<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-graduate"></i> Student List Report</h4>
    <a href="<?php echo url('reports/studentList?export=csv' . ($classId ? '&class_id=' . $classId : '') . '&status=' . $status); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/studentList'); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                    <option value="<?php echo $class['id']; ?>" <?php echo $classId == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="Active" <?php echo $status === 'Active' ? 'selected' : ''; ?>>Active</option>
                    <option value="Inactive" <?php echo $status === 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    <option value="Transfer Certificate" <?php echo $status === 'Transfer Certificate' ? 'selected' : ''; ?>>Transfer Certificate</option>
                    <option value="" <?php echo $status === '' ? 'selected' : ''; ?>>All</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <?php if (!empty($students)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Adm. No.</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Gender</th>
                        <th>Mobile</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($students as $s): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo e($s['admission_number']); ?></td>
                        <td><?php echo e(trim($s['first_name'] . ' ' . ($s['last_name'] ?? ''))); ?></td>
                        <td><?php echo e($s['class_name'] ?? '-'); ?></td>
                        <td><?php echo e($s['section_name'] ?? '-'); ?></td>
                        <td><?php echo e($s['gender']); ?></td>
                        <td><?php echo e($s['mobile'] ?? '-'); ?></td>
                        <td><span class="badge bg-<?php echo $s['status'] === 'Active' ? 'success' : 'secondary'; ?>"><?php echo e($s['status']); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="text-muted">Showing <?php echo count($students); ?> students.</div>
        <?php else: ?>
        <p class="text-muted text-center mb-0">No students found with the selected filters.</p>
        <?php endif; ?>
    </div>
</div>
