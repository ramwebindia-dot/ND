<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calendar-day"></i> <?php echo e($pageTitle); ?></h4>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/dailyCollection'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Date</label>
                <input type="date" name="date" class="form-control" value="<?php echo e($date); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> View</button>
            </div>
        </form>
    </div>
</div>

<?php
$grandTotal = array_sum(array_column($rows, 'total_amount'));
?>
<div class="row mb-3">
    <div class="col-md-3">
        <div class="card bg-success text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Collected</h6>
                <h3 class="mb-0"><?php echo formatCurrency($grandTotal); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Receipts Issued</h6>
                <h3 class="mb-0"><?php echo count($rows); ?></h3>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($methods)): ?>
<div class="card mb-3">
    <div class="card-header"><i class="fas fa-credit-card me-2"></i>By Payment Method</div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Method</th><th class="text-center">Count</th><th class="text-end">Amount</th></tr>
            </thead>
            <tbody>
                <?php foreach ($methods as $m): ?>
                <tr>
                    <td><?php echo e($m['method']); ?></td>
                    <td class="text-center"><?php echo $m['count']; ?></td>
                    <td class="text-end"><strong><?php echo formatCurrency($m['total']); ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><i class="fas fa-list me-2"></i>Receipts for <?php echo date('d M Y', strtotime($date)); ?></div>
    <div class="table-responsive">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>Receipt No.</th>
                    <th>Student(s)</th>
                    <th>Months</th>
                    <th class="text-end">Amount</th>
                    <th>Method</th>
                    <th>Cashier</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <td><strong><?php echo e($r['receipt_number']); ?></strong></td>
                    <td><?php echo e($r['student_names']); ?></td>
                    <td><small class="text-muted"><?php echo e($r['months_paid'] ?? ''); ?></small></td>
                    <td class="text-end"><strong><?php echo formatCurrency($r['total_amount']); ?></strong></td>
                    <td><?php echo e($r['payment_method']); ?></td>
                    <td><small><?php echo e($r['cashier_name'] ?? ''); ?></small></td>
                    <td>
                        <a href="<?php echo url('fees/receipt?txn=' . $r['id']); ?>" class="btn btn-xs btn-outline-primary" target="_blank">
                            <i class="fas fa-print"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($rows)): ?>
                <tr><td colspan="7" class="text-center text-muted py-3">No collections for this date.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<style>.btn-xs{padding:.15rem .4rem;font-size:.7rem}</style>
