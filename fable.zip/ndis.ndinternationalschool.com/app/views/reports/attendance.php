﻿<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-clipboard-check"></i> Attendance Report</h4>
    <a href="<?php echo url('reports/attendanceReport?export=csv&class_id=' . $classId . '&date_from=' . $dateFrom . '&date_to=' . $dateTo); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/attendanceReport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select" required>
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $class): ?>
                    <option value="<?php echo $class['id']; ?>" <?php echo $classId == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Date From</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Date To</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Generate</button>
            </div>
        </form>
    </div>
</div>

<?php if (!empty($report)): ?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Adm. No.</th>
                        <th>Student Name</th>
                        <th class="text-center">Total Days</th>
                        <th class="text-center">Present</th>
                        <th class="text-center">Absent</th>
                        <th class="text-center">Late</th>
                        <th class="text-center">Attendance %</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($report as $row): ?>
                    <?php $pct = $row['total_days'] > 0 ? round(($row['present_days'] / $row['total_days']) * 100, 1) : 0; ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo e($row['admission_number']); ?></td>
                        <td><?php echo e(trim($row['first_name'] . ' ' . ($row['last_name'] ?? ''))); ?></td>
                        <td class="text-center"><?php echo $row['total_days']; ?></td>
                        <td class="text-center text-success"><strong><?php echo $row['present_days']; ?></strong></td>
                        <td class="text-center text-danger"><?php echo $row['absent_days']; ?></td>
                        <td class="text-center text-warning"><?php echo $row['late_days']; ?></td>
                        <td class="text-center">
                            <span class="badge bg-<?php echo $pct >= 75 ? 'success' : ($pct >= 50 ? 'warning text-dark' : 'danger'); ?>">
                                <?php echo $pct; ?>%
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php elseif ($classId): ?>
<div class="card">
    <div class="card-body text-center text-muted py-4">No attendance records found for the selected period.</div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-4"><i class="fas fa-filter me-2"></i>Select a class to generate the attendance report.</div>
</div>
<?php endif; ?>
