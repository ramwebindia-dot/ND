﻿<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-file-alt"></i> Exam Report</h4>
    <?php if (!empty($report)): ?>
    <a href="<?php echo url('reports/examReport?export=csv&exam_id=' . $examId . '&class_id=' . $classId); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
    <?php endif; ?>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/examReport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Exam</label>
                <select name="exam_id" class="form-select" required>
                    <option value="">Select Exam</option>
                    <?php foreach ($exams as $exam): ?>
                    <option value="<?php echo $exam['id']; ?>" <?php echo $examId == $exam['id'] ? 'selected' : ''; ?>><?php echo e($exam['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select" required>
                    <option value="">Select Class</option>
                    <?php foreach ($classes as $class): ?>
                    <option value="<?php echo $class['id']; ?>" <?php echo $classId == $class['id'] ? 'selected' : ''; ?>><?php echo e($class['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Generate</button>
            </div>
        </form>
    </div>
</div>

<?php if (!empty($report)): ?>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Adm. No.</th>
                        <th>Student</th>
                        <th>Subject</th>
                        <th class="text-center">Marks Obtained</th>
                        <th class="text-center">Total Marks</th>
                        <th class="text-center">Percentage</th>
                        <th class="text-center">Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($report as $row): ?>
                    <?php $pct = $row['total_marks'] > 0 ? round(($row['marks_obtained'] / $row['total_marks']) * 100, 1) : 0; ?>
                    <tr>
                        <td><?php echo e($row['admission_number']); ?></td>
                        <td><?php echo e(trim($row['first_name'] . ' ' . ($row['last_name'] ?? ''))); ?></td>
                        <td><?php echo e($row['subject_name']); ?></td>
                        <td class="text-center"><strong><?php echo $row['marks_obtained']; ?></strong></td>
                        <td class="text-center"><?php echo $row['total_marks']; ?></td>
                        <td class="text-center">
                            <span class="badge bg-<?php echo $pct >= 75 ? 'success' : ($pct >= 50 ? 'warning text-dark' : 'danger'); ?>"><?php echo $pct; ?>%</span>
                        </td>
                        <td class="text-center"><span class="badge bg-primary"><?php echo e($row['grade'] ?? '-'); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php elseif ($examId && $classId): ?>
<div class="card">
    <div class="card-body text-center text-muted py-4">No marks found for the selected exam and class.</div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-4"><i class="fas fa-filter me-2"></i>Select an exam and class to generate the report.</div>
</div>
<?php endif; ?>
