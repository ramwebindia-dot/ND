<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calculator"></i> Financial Report</h4>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card text-white bg-success text-center">
            <div class="card-body">
                <h6>Cash Balance</h6>
                <h3><?php echo formatCurrency($cashBalance); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-info text-center">
            <div class="card-body">
                <h6>Total Bank Balance</h6>
                <h3><?php echo formatCurrency($totalBankBalance); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white" style="background-color: var(--primary-color);">
            <div class="card-body text-center">
                <h6>Net Balance</h6>
                <h3><?php echo formatCurrency($cashBalance + $totalBankBalance); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/financialReport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Date From</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Date To</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<?php if (!empty($summary)): ?>
<div class="row">
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header bg-success text-white"><i class="fas fa-arrow-down me-2"></i>Income</div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tbody>
                        <tr>
                            <td>Fee Collected</td>
                            <td class="text-end"><?php echo formatCurrency($summary['fee_collected'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <td>Other Income</td>
                            <td class="text-end"><?php echo formatCurrency($summary['other_income'] ?? 0); ?></td>
                        </tr>
                        <tr class="table-success">
                            <td><strong>Total Income</strong></td>
                            <td class="text-end"><strong><?php echo formatCurrency($summary['total_income'] ?? 0); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header bg-danger text-white"><i class="fas fa-arrow-up me-2"></i>Expenses</div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tbody>
                        <tr>
                            <td>Other Expenses</td>
                            <td class="text-end"><?php echo formatCurrency($summary['other_expenses'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <td>Fee Refunds</td>
                            <td class="text-end"><?php echo formatCurrency($summary['refunds'] ?? 0); ?></td>
                        </tr>
                        <tr class="table-danger">
                            <td><strong>Total Expenses</strong></td>
                            <td class="text-end"><strong><?php echo formatCurrency($summary['total_expenses'] ?? 0); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><i class="fas fa-balance-scale me-2"></i>Net Position</div>
    <div class="card-body">
        <div class="row text-center">
            <div class="col-md-4">
                <h6>Total Income</h6>
                <h4 class="text-success"><?php echo formatCurrency($summary['total_income'] ?? 0); ?></h4>
            </div>
            <div class="col-md-4">
                <h6>Total Expenses</h6>
                <h4 class="text-danger"><?php echo formatCurrency($summary['total_expenses'] ?? 0); ?></h4>
            </div>
            <div class="col-md-4">
                <h6>Net Surplus/Deficit</h6>
                <h4 class="<?php echo ($summary['net_income'] ?? 0) >= 0 ? 'text-success' : 'text-danger'; ?>">
                    <?php echo formatCurrency($summary['net_income'] ?? 0); ?>
                </h4>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-4">No financial data found for the selected period.</div>
</div>
<?php endif; ?>
