﻿<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-chalkboard-teacher"></i> Teacher Report</h4>
    <a href="<?php echo url('reports/teacherReport?export=csv'); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card">
    <div class="card-body">
        <?php if (!empty($teachers)): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Employee No.</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Mobile</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($teachers as $t): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo e($t['employee_id'] ?? '-'); ?></td>
                        <td><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></td>
                        <td><?php echo e($t['department_name'] ?? '-'); ?></td>
                        <td><?php echo e($t['designation'] ?? '-'); ?></td>
                        <td><?php echo e($t['phone'] ?? '-'); ?></td>
                        <td><?php echo e($t['email'] ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="text-muted">Showing <?php echo count($teachers); ?> teachers.</div>
        <?php else: ?>
        <p class="text-muted text-center mb-0">No active teachers found.</p>
        <?php endif; ?>
    </div>
</div>
