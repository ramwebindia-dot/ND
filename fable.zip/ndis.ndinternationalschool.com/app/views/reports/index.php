<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-chart-bar me-2"></i>Reports</h4>
    <div class="btn-group">
        <a href="<?php echo url('reports/export-excel-report?type=students'); ?>" class="btn btn-outline-success btn-sm">
            <i class="fas fa-file-excel me-1"></i>Student Excel
        </a>
        <a href="<?php echo url('reports/export-excel-report?type=fees&from='.date('Y-m-01').'&to='.date('Y-m-d')); ?>" class="btn btn-outline-success btn-sm">
            <i class="fas fa-file-excel me-1"></i>Fee Excel
        </a>
        <a href="<?php echo url('reports/export-excel-report?type=attendance&month='.date('Y-m')); ?>" class="btn btn-outline-success btn-sm">
            <i class="fas fa-file-excel me-1"></i>Attendance Excel
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-user-graduate fa-3x mb-3" style="color: var(--primary-color);"></i>
                <h5>Student List</h5>
                <p class="text-muted">List of all students with class, section, and status details.</p>
                <a href="<?php echo url('reports/studentList'); ?>" class="btn btn-primary-custom">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-clipboard-check fa-3x mb-3 text-success"></i>
                <h5>Attendance Report</h5>
                <p class="text-muted">Student attendance summary by class and date range.</p>
                <a href="<?php echo url('reports/attendanceReport'); ?>" class="btn btn-success">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-rupee-sign fa-3x mb-3 text-warning"></i>
                <h5>Fee Report</h5>
                <p class="text-muted">Fee collection summary with method breakdown.</p>
                <a href="<?php echo url('reports/feeReport'); ?>" class="btn btn-warning text-dark">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-file-alt fa-3x mb-3 text-info"></i>
                <h5>Exam Report</h5>
                <p class="text-muted">Student marks and grades by exam and class.</p>
                <a href="<?php echo url('reports/examReport'); ?>" class="btn btn-info text-white">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-calculator fa-3x mb-3 text-danger"></i>
                <h5>Financial Report</h5>
                <p class="text-muted">Income, expense, cash, and bank balance summary.</p>
                <a href="<?php echo url('reports/financialReport'); ?>" class="btn btn-danger">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-chalkboard-teacher fa-3x mb-3" style="color: #6f42c1;"></i>
                <h5>Teacher Report</h5>
                <p class="text-muted">List of active teachers with department and designation.</p>
                <a href="<?php echo url('reports/teacherReport'); ?>" class="btn" style="background-color: #6f42c1; color: white;">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-book-open fa-3x mb-3" style="color: #20c997;"></i>
                <h5>Library Report</h5>
                <p class="text-muted">Issued books, overdue books, and catalog summary.</p>
                <a href="<?php echo url('reports/libraryReport'); ?>" class="btn" style="background-color: #20c997; color: white;">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
</div>

<h5 class="mt-3 mb-3"><i class="fas fa-rupee-sign me-2"></i>Fee Reports</h5>
<div class="row">
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-calendar-day fa-3x mb-3 text-primary"></i>
                <h5>Daily Collection</h5>
                <p class="text-muted">All receipts collected on a specific date, with method breakdown.</p>
                <a href="<?php echo url('reports/dailyCollection'); ?>" class="btn btn-primary">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-calendar-alt fa-3x mb-3 text-success"></i>
                <h5>Monthly Collection</h5>
                <p class="text-muted">Student-wise fee collection for a selected month.</p>
                <a href="<?php echo url('reports/monthlyCollection'); ?>" class="btn btn-success">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-exclamation-circle fa-3x mb-3 text-danger"></i>
                <h5>Outstanding Fees</h5>
                <p class="text-muted">Students with pending dues, class-wise and total.</p>
                <a href="<?php echo url('reports/outstandingReport'); ?>" class="btn btn-danger">
                    <i class="fas fa-eye"></i> View Report
                </a>
            </div>
        </div>
    </div>
</div>
