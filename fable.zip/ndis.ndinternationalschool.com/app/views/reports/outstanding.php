<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-exclamation-circle"></i> Outstanding Fees Report</h4>
    <a href="<?php echo url('reports/outstandingReport?export=csv' . ($classId ? '&class_id='.$classId : '')); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/outstandingReport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Class</label>
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $cls): ?>
                    <option value="<?php echo $cls['id']; ?>" <?php echo $classId == $cls['id'] ? 'selected' : ''; ?>>
                        <?php echo e($cls['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<?php
$totalOutstanding  = array_sum(array_column($rows, 'outstanding'));
$totalCharged      = array_sum(array_column($rows, 'total_charged'));
$totalPaid         = array_sum(array_column($rows, 'total_paid'));
$totalPartial      = count(array_filter($rows, fn($r) => ($r['partial_months'] ?? 0) > 0));
?>
<div class="row mb-3">
    <div class="col-md-3">
        <div class="card bg-info text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Charged</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalCharged); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Collected</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalPaid); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Outstanding</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalOutstanding); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-secondary text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Students With Dues</h6>
                <h3 class="mb-0"><?php echo count($rows); ?></h3>
            </div>
        </div>
    </div>
</div>
<?php if ($totalPartial > 0): ?>
<div class="alert alert-warning py-2 mb-3">
    <i class="fas fa-adjust me-2"></i>
    <strong><?php echo $totalPartial; ?> student<?php echo $totalPartial > 1 ? 's have' : ' has'; ?> partial payments</strong> — months where only part of the fee was collected. Outstanding balance reflects the unpaid portion.
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><i class="fas fa-list me-2"></i>Outstanding Students</div>
    <div class="table-responsive">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>Adm. No.</th>
                    <th>Student</th>
                    <th>Class</th>
                    <th class="text-end">Charged</th>
                    <th class="text-end">Paid</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Outstanding</th>
                    <th>Last Payment</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                <tr class="<?php echo ($r['partial_months'] ?? 0) > 0 ? 'table-warning' : ''; ?>">
                    <td><small><?php echo e($r['admission_number']); ?></small></td>
                    <td>
                        <?php echo e($r['first_name'] . ' ' . $r['last_name']); ?>
                        <?php if (($r['partial_months'] ?? 0) > 0): ?>
                        <span class="badge bg-warning text-dark ms-1" title="<?php echo $r['partial_months']; ?> month(s) partially paid">
                            <i class="fas fa-adjust me-1"></i>Partial
                        </span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($r['class_name'] ?? ''); ?></td>
                    <td class="text-end"><?php echo formatCurrency($r['total_charged']); ?></td>
                    <td class="text-end"><?php echo formatCurrency($r['total_paid']); ?></td>
                    <td class="text-end text-success"><?php echo $r['total_discount'] > 0 ? formatCurrency($r['total_discount']) : '—'; ?></td>
                    <td class="text-end"><strong class="text-danger"><?php echo formatCurrency($r['outstanding']); ?></strong></td>
                    <td><small class="text-muted"><?php echo !empty($r['last_payment_date']) ? formatDate($r['last_payment_date']) : '—'; ?></small></td>
                    <td class="text-nowrap">
                        <a href="<?php echo url('fees/studentLedger?student_id=' . $r['student_id']); ?>" class="btn btn-xs btn-outline-secondary">Ledger</a>
                        <a href="<?php echo url('fees/collect?student_id=' . $r['student_id']); ?>" class="btn btn-xs btn-outline-primary ms-1">Collect</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($rows)): ?>
                <tr><td colspan="9" class="text-center text-muted py-3">No outstanding dues found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<style>.btn-xs{padding:.15rem .4rem;font-size:.7rem}</style>
