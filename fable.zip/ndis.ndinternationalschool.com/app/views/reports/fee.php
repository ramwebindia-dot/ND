<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-rupee-sign"></i> Fee Collection Report</h4>
    <a href="<?php echo url('reports/feeReport?export=csv&date_from=' . $dateFrom . '&date_to=' . $dateTo); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-file-csv"></i> Export CSV
    </a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/feeReport'); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Date From</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Date To</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="row mb-3">
    <div class="col-md-3">
        <div class="card text-white bg-success text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Collected</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalCollected); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Receipts</h6>
                <h3 class="mb-0"><?php echo $receiptCount; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-danger text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Outstanding</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalOutstanding); ?></h3>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($methodBreakdown)): ?>
<div class="card mb-3">
    <div class="card-header"><i class="fas fa-chart-pie me-2"></i>Payment Method Breakdown</div>
    <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light">
                <tr><th>Method</th><th class="text-center">Count</th><th class="text-end">Total</th></tr>
            </thead>
            <tbody>
                <?php foreach ($methodBreakdown as $mb): ?>
                <tr>
                    <td><?php echo e($mb['payment_method']); ?></td>
                    <td class="text-center"><?php echo $mb['count']; ?></td>
                    <td class="text-end"><strong><?php echo formatCurrency($mb['total']); ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><i class="fas fa-list me-2"></i>Receipts (<?php echo count($collections); ?>)</div>
    <div class="table-responsive">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>Receipt No.</th>
                    <th>Student(s)</th>
                    <th>Fee Types</th>
                    <th class="text-end">Amount</th>
                    <th>Method</th>
                    <th>Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($collections as $c): ?>
                <tr>
                    <td><strong><?php echo e($c['receipt_number']); ?></strong></td>
                    <td><?php echo e($c['student_names']); ?></td>
                    <td><small class="text-muted"><?php echo e($c['fee_types']); ?></small></td>
                    <td class="text-end"><strong><?php echo formatCurrency($c['total_amount']); ?></strong></td>
                    <td><?php echo e($c['payment_method']); ?></td>
                    <td><?php echo formatDate($c['payment_date']); ?></td>
                    <td>
                        <a href="<?php echo url('fees/receipt?txn=' . $c['id']); ?>" class="btn btn-xs btn-outline-primary" target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($collections)): ?>
                <tr><td colspan="7" class="text-center text-muted py-3">No collections found for selected period.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<style>.btn-xs{padding:.15rem .4rem;font-size:.7rem}</style>
