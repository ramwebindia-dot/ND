<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-calendar-alt"></i> Monthly Fee Collection</h4>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('reports/monthlyCollection'); ?>" class="row g-2 align-items-end">
            <div class="col-md-2">
                <label class="form-label">Year</label>
                <select name="year" class="form-select">
                    <?php for ($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                    <option value="<?php echo $y; ?>" <?php echo $y == $year ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Month</label>
                <select name="month" class="form-select">
                    <?php $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
                    foreach ($months as $mi => $mn): ?>
                    <option value="<?php echo $mi+1; ?>" <?php echo ($mi+1) == $month ? 'selected' : ''; ?>><?php echo $mn; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-search"></i> View</button>
            </div>
        </form>
    </div>
</div>

<?php
$totalAmt = array_sum(array_column($rows, 'total_amount'));
$totalDisc = array_sum(array_column($rows, 'total_discount'));
$totalLate = array_sum(array_column($rows, 'total_late_fee'));
?>
<div class="row mb-3">
    <div class="col-md-3">
        <div class="card bg-success text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Collected</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalAmt); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-dark text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Total Discounts</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalDisc); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white text-center">
            <div class="card-body py-2">
                <h6 class="mb-1">Late Fees</h6>
                <h3 class="mb-0"><?php echo formatCurrency($totalLate); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <i class="fas fa-list me-2"></i>
        <?php echo date('F Y', mktime(0,0,0,$month,1,$year)); ?> — <?php echo count($rows); ?> student(s)
    </div>
    <div class="table-responsive">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>Student</th>
                    <th>Class</th>
                    <th>Months</th>
                    <th class="text-end">Charged</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Late Fee</th>
                    <th class="text-end">Paid</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <td>
                        <?php echo e($r['first_name'] . ' ' . $r['last_name']); ?>
                        <br><small class="text-muted"><?php echo e($r['admission_number']); ?></small>
                    </td>
                    <td><?php echo e($r['class_name'] ?? ''); ?></td>
                    <td><small class="text-muted"><?php echo e($r['months_paid'] ?? ''); ?></small></td>
                    <td class="text-end"><?php echo formatCurrency($r['total_charged']); ?></td>
                    <td class="text-end text-success"><?php echo $r['total_discount'] > 0 ? '-'.formatCurrency($r['total_discount']) : '—'; ?></td>
                    <td class="text-end text-danger"><?php echo $r['total_late_fee'] > 0 ? '+'.formatCurrency($r['total_late_fee']) : '—'; ?></td>
                    <td class="text-end"><strong><?php echo formatCurrency($r['total_amount']); ?></strong></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($rows)): ?>
                <tr><td colspan="7" class="text-center text-muted py-3">No collections for this month.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
