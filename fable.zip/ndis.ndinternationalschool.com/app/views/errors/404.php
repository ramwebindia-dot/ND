<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <h1 class="display-1 text-primary-custom">404</h1>
            <h3>Page Not Found</h3>
            <p class="text-muted mb-4">The page you are looking for does not exist or has been moved.</p>
            <a href="<?php echo url('dashboard'); ?>" class="btn btn-primary-custom">
                <i class="fas fa-home me-2"></i>Go to Dashboard
            </a>
        </div>
    </div>
</div>
