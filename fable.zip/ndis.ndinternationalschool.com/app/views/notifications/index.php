<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-bell"></i> Notifications
        <?php if ($unreadCount > 0): ?>
        <span class="badge bg-danger"><?php echo $unreadCount; ?> unread</span>
        <?php endif; ?>
    </h4>
    <?php if ($unreadCount > 0): ?>
    <a href="<?php echo url('notifications/markAllRead'); ?>" class="btn btn-outline-primary btn-sm">
        <i class="fas fa-check-double"></i> Mark All Read
    </a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body">
        <?php if (!empty($notifications)): ?>
        <div class="list-group list-group-flush">
            <?php foreach ($notifications as $notification): ?>
            <div class="list-group-item <?php echo empty($notification['read_at']) ? 'list-group-item-warning' : ''; ?>">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center mb-1">
                            <?php if (empty($notification['read_at'])): ?>
                            <span class="badge bg-primary me-2">New</span>
                            <?php endif; ?>
                            <strong><?php echo e($notification['title'] ?? 'Notification'); ?></strong>
                        </div>
                        <p class="mb-1"><?php echo e($notification['message'] ?? ''); ?></p>
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i><?php echo formatDateTime($notification['created_at']); ?>
                            <?php if (!empty($notification['type'])): ?>
                            &middot; <span class="badge bg-secondary"><?php echo e($notification['type']); ?></span>
                            <?php endif; ?>
                        </small>
                    </div>
                    <div class="ms-3">
                        <?php if (empty($notification['read_at'])): ?>
                        <a href="<?php echo url('notifications/markRead?id=' . $notification['id'] . ($notification['link'] ? '&redirect=' . urlencode($notification['link']) : '')); ?>" class="btn btn-sm btn-outline-primary" title="Mark as Read">
                            <i class="fas fa-check"></i>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($notification['link'])): ?>
                        <a href="<?php echo e($notification['link']); ?>" class="btn btn-sm btn-primary-custom" title="View">
                            <i class="fas fa-external-link-alt"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
            <p class="text-muted">No notifications yet.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
