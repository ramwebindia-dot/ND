﻿<div class="page-header">
    <h4><i class="fas fa-calendar-check"></i> Child Attendance</h4>
    <a href="<?php echo url('parent/childProfile?id=' . $student['id']); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo url('parent/childAttendance'); ?>" class="row g-2 align-items-end">
            <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
            <div class="col-md-3">
                <label class="form-label">Month</label>
                <select name="month" class="form-select">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo str_pad($m, 2, '0', STR_PAD_LEFT); ?>" <?php echo $month == str_pad($m, 2, '0', STR_PAD_LEFT) ? 'selected' : ''; ?>><?php echo date('F', mktime(0,0,0,$m,1)); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Year</label>
                <input type="number" name="year" class="form-control" value="<?php echo e($year); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary-custom"><i class="fas fa-filter me-1"></i>Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h6 class="mb-3"><?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?> - Attendance for <?php echo date('F Y', strtotime("$year-$month-01")); ?></h6>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($attendance)): ?>
                        <tr><td colspan="3" class="text-center text-muted py-3">No attendance records found for this month.</td></tr>
                    <?php else: ?>
                        <?php
                        $present = 0; $absent = 0; $late = 0;
                        ?>
                        <?php foreach ($attendance as $att): ?>
                        <tr>
                            <td><?php echo formatDate($att['date']); ?></td>
                            <td>
                                <span class="badge <?php echo $att['status'] === 'Present' ? 'bg-success' : ($att['status'] === 'Absent' ? 'bg-danger' : 'bg-warning'); ?>">
                                    <?php echo e($att['status']); ?>
                                </span>
                            </td>
                            <td><?php echo e($att['remarks'] ?? '-'); ?></td>
                        </tr>
                        <?php
                        if ($att['status'] === 'Present') $present++;
                        elseif ($att['status'] === 'Absent') $absent++;
                        else $late++;
                        ?>
                        <?php endforeach; ?>
                        <tr class="table-warning">
                            <td colspan="3">
                                <strong>Present: <?php echo $present; ?></strong> |
                                <strong>Absent: <?php echo $absent; ?></strong> |
                                <strong>Late: <?php echo $late; ?></strong> |
                                <strong>Total: <?php echo $present + $absent + $late; ?></strong>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>