﻿<div class="page-header">
    <h4><i class="fas fa-user-graduate"></i> Child Profile</h4>
    <a href="<?php echo url('parent'); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-body text-center">
                <?php if (!empty($student['photo'])): ?>
                    <img src="<?php echo asset($student['photo']); ?>" class="rounded-circle mb-2" width="100" height="100" alt="">
                <?php else: ?>
                    <i class="fas fa-user-circle fa-5x text-muted mb-2"></i>
                <?php endif; ?>
                <h5><?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?></h5>
                <p class="text-muted mb-1"><?php echo e($student['admission_number']); ?></p>
                <span class="badge bg-success"><?php echo e($student['status']); ?></span>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Class:</strong> <?php echo e($student['class_name'] ?? '-'); ?></p>
                        <p><strong>Section:</strong> <?php echo e($student['section_name'] ?? '-'); ?></p>
                        <p><strong>Gender:</strong> <?php echo e($student['gender'] ?? '-'); ?></p>
                        <p><strong>Date of Birth:</strong> <?php echo formatDate($student['date_of_birth'] ?? ''); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Mobile:</strong> <?php echo e($student['mobile'] ?? '-'); ?></p>
                        <p><strong>Email:</strong> <?php echo e($student['email'] ?? '-'); ?></p>
                        <p><strong>Blood Group:</strong> <?php echo e($student['blood_group'] ?? '-'); ?></p>
                        <p><strong>Outstanding Fees:</strong> <span class="text-danger fw-bold"><?php echo formatCurrency($outstanding); ?></span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo url('parent/childAttendance?id=' . $student['id']); ?>" class="btn btn-outline-info"><i class="fas fa-calendar-check me-1"></i>Attendance</a>
            <a href="<?php echo url('parent/childMarks?id=' . $student['id']); ?>" class="btn btn-outline-success"><i class="fas fa-chart-bar me-1"></i>Marks</a>
            <a href="<?php echo url('parent/childFees?id=' . $student['id']); ?>" class="btn btn-outline-warning"><i class="fas fa-rupee-sign me-1"></i>Fees</a>
        </div>
    </div>
</div>