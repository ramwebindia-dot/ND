<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-users me-2"></i>Parent Management</h4>
</div>

<!-- Search -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('parent/manage'); ?>" class="d-flex gap-2">
            <input type="text" name="search" class="form-control" placeholder="Search by father name, phone, email..."
                   value="<?php echo e($search ?? ''); ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            <?php if ($search): ?>
            <a href="<?php echo url('parent/manage'); ?>" class="btn btn-secondary"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-bold">All Parents <span class="badge bg-secondary ms-1"><?php echo $pagination['total'] ?? 0; ?></span></span>
        <small class="text-muted">Parents are created automatically when students are admitted.</small>
    </div>
    <div class="card-body p-0">
        <?php if (empty($parents)): ?>
        <div class="text-center py-5 text-muted">
            <i class="fas fa-users fa-3x mb-3 d-block"></i>
            No parents found<?php echo $search ? " for \"$search\"" : ''; ?>.
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Father / Guardian</th>
                        <th>Phone</th>
                        <th>Children</th>
                        <th>Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($parents as $i => $p): ?>
                <tr>
                    <td><?php echo (($pagination['page'] - 1) * $pagination['per_page']) + $i + 1; ?></td>
                    <td>
                        <div class="fw-medium"><?php echo e($p['father_name'] ?? '—'); ?></div>
                        <?php if ($p['mother_name']): ?>
                        <small class="text-muted">Mother: <?php echo e($p['mother_name']); ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($p['father_phone'] ?? '—'); ?>
                        <?php if ($p['father_email']): ?>
                        <div><small class="text-muted"><?php echo e($p['father_email']); ?></small></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge bg-primary"><?php echo $p['children_count']; ?> child<?php echo $p['children_count'] != 1 ? 'ren' : ''; ?></span>
                    </td>
                    <td>
                        <?php if ($p['user_id']): ?>
                        <span class="badge bg-<?php echo $p['login_active'] ? 'success' : 'warning text-dark'; ?>">
                            <i class="fas fa-check me-1"></i><?php echo $p['login_active'] ? 'Active' : 'Disabled'; ?>
                        </span>
                        <?php else: ?>
                        <span class="badge bg-secondary"><i class="fas fa-times me-1"></i>No Login</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo url('parent/viewParent?id=' . $p['id']); ?>" class="btn btn-sm btn-info" title="View">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?php echo url('parent/edit-parent?id=' . $p['id']); ?>" class="btn btn-sm btn-warning" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if (($pagination['total_pages'] ?? 1) > 1): ?>
        <div class="d-flex justify-content-center p-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php for ($pg = 1; $pg <= $pagination['total_pages']; $pg++): ?>
                    <li class="page-item <?php echo $pg == $pagination['page'] ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $pg; ?>&search=<?php echo urlencode($search ?? ''); ?>"><?php echo $pg; ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
