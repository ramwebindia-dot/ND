﻿<div class="page-header">
    <h4><i class="fas fa-rupee-sign"></i> Child Fees</h4>
    <a href="<?php echo url('parent/childProfile?id=' . $student['id']); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <strong>Student:</strong> <?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?>
            </div>
            <div class="col-md-6 text-end">
                <strong>Outstanding Balance:</strong> <span class="text-danger fw-bold fs-5"><?php echo formatCurrency($outstanding); ?></span>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h6 class="mb-3">Fee Ledger</h6>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th class="text-end">Debit</th>
                        <th class="text-end">Credit</th>
                        <th class="text-end">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($ledger)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">No fee records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($ledger as $entry): ?>
                        <tr>
                            <td><?php echo formatDate($entry['date'] ?? $entry['created_at']); ?></td>
                            <td><?php echo e($entry['description'] ?? '-'); ?></td>
                            <td class="text-end text-danger"><?php echo !empty($entry['debit']) ? formatCurrency($entry['debit']) : '-'; ?></td>
                            <td class="text-end text-success"><?php echo !empty($entry['credit']) ? formatCurrency($entry['credit']) : '-'; ?></td>
                            <td class="text-end fw-bold"><?php echo formatCurrency($entry['balance'] ?? 0); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>