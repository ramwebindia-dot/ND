﻿<div class="page-header">
    <h4><i class="fas fa-home"></i> Parent Dashboard</h4>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card text-white bg-success">
            <div class="card-body text-center">
                <h6>My Children</h6>
                <h3><?php echo count($children); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-primary">
            <div class="card-body text-center">
                <h6>Active Notices</h6>
                <h3><?php echo count($notices); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white" style="background-color: var(--primary-color);">
            <div class="card-body text-center">
                <h6>Parent</h6>
                <h5><?php echo e($parent['first_name'] ?? '' . ' ' . $parent['last_name'] ?? ''); ?></h5>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($children)): ?>
<div class="card mb-3">
    <div class="card-header"><i class="fas fa-user-graduate me-2"></i>My Children</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Adm. No.</th>
                        <th>Class</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($children as $child): ?>
                    <tr>
                        <td><strong><?php echo e(trim($child['first_name'] . ' ' . ($child['last_name'] ?? ''))); ?></strong></td>
                        <td><?php echo e($child['admission_number']); ?></td>
                        <td><?php echo e($child['class_name'] ?? '-'); ?></td>
                        <td><span class="badge bg-success"><?php echo e($child['status']); ?></span></td>
                        <td>
                            <a href="<?php echo url('parent/childProfile?id=' . $child['id']); ?>" class="btn btn-sm btn-outline-primary-custom">Profile</a>
                            <a href="<?php echo url('parent/childAttendance?id=' . $child['id']); ?>" class="btn btn-sm btn-outline-info">Attendance</a>
                            <a href="<?php echo url('parent/childMarks?id=' . $child['id']); ?>" class="btn btn-sm btn-outline-success">Marks</a>
                            <a href="<?php echo url('parent/childFees?id=' . $child['id']); ?>" class="btn btn-sm btn-outline-warning">Fees</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center text-muted py-4">
        <i class="fas fa-user-graduate fa-3x mb-3"></i>
        <p>No children linked to your account. Please contact the school administration.</p>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($notices)): ?>
<div class="card">
    <div class="card-header"><i class="fas fa-bullhorn me-2"></i>Recent Notices</div>
    <div class="card-body">
        <?php foreach (array_slice($notices, 0, 5) as $notice): ?>
        <div class="mb-2 pb-2 border-bottom">
            <strong><?php echo e($notice['title']); ?></strong>
            <small class="text-muted ms-2"><?php echo formatDate($notice['created_at']); ?></small>
            <p class="mb-0 text-muted small"><?php echo e(substr($notice['content'] ?? '', 0, 100)); ?>...</p>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>