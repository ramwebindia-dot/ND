<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-edit me-2"></i>Edit Parent Details</h4>
    <a href="<?php echo url('parent/viewParent?id=' . $parent['id']); ?>" class="btn btn-secondary btn-sm">
        <i class="fas fa-arrow-left me-1"></i>Back
    </a>
</div>

<form method="POST" action="<?php echo url('parent/edit-parent?id=' . $parent['id']); ?>">
    <?php echo CSRF::field(); ?>
    <div class="row g-3">
        <!-- Father -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header fw-bold"><i class="fas fa-male me-2 text-primary"></i>Father Details</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Father Name <span class="text-danger">*</span></label>
                        <input type="text" name="father_name" class="form-control" value="<?php echo e($parent['father_name'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="father_phone" class="form-control" value="<?php echo e($parent['father_phone'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="father_email" class="form-control" value="<?php echo e($parent['father_email'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Occupation</label>
                        <input type="text" name="father_occupation" class="form-control" value="<?php echo e($parent['father_occupation'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Mother -->
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header fw-bold"><i class="fas fa-female me-2 text-danger"></i>Mother Details</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Mother Name</label>
                        <input type="text" name="mother_name" class="form-control" value="<?php echo e($parent['mother_name'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="mother_phone" class="form-control" value="<?php echo e($parent['mother_phone'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="mother_email" class="form-control" value="<?php echo e($parent['mother_email'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Occupation</label>
                        <input type="text" name="mother_occupation" class="form-control" value="<?php echo e($parent['mother_occupation'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Address -->
        <div class="col-12">
            <div class="card">
                <div class="card-header fw-bold"><i class="fas fa-map-marker-alt me-2"></i>Address</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"><?php echo e($parent['address'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">City</label>
                            <input type="text" name="city" class="form-control" value="<?php echo e($parent['city'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">State</label>
                            <input type="text" name="state" class="form-control" value="<?php echo e($parent['state'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Pincode</label>
                            <input type="text" name="pincode" class="form-control" value="<?php echo e($parent['pincode'] ?? ''); ?>" maxlength="10">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-2"></i>Save Changes
            </button>
            <a href="<?php echo url('parent/viewParent?id=' . $parent['id']); ?>" class="btn btn-secondary ms-2">Cancel</a>
        </div>
    </div>
</form>
