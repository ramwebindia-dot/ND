<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-user-friends me-2"></i>Parent Details</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('parent/edit-parent?id=' . $parent['id']); ?>" class="btn btn-warning btn-sm">
            <i class="fas fa-edit me-1"></i>Edit
        </a>
        <a href="<?php echo url('parent/manage'); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>
</div>

<div class="row">
    <!-- Parent Info -->
    <div class="col-md-5">
        <!-- Father -->
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-male me-2 text-primary"></i>Father / Guardian Details</div>
            <div class="card-body p-0">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted ps-3" width="140">Father Name</td><td class="fw-medium"><?php echo e($parent['father_name'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Phone</td><td><?php echo e($parent['father_phone'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Email</td><td><?php echo e($parent['father_email'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Occupation</td><td><?php echo e($parent['father_occupation'] ?? '—'); ?></td></tr>
                </table>
            </div>
        </div>

        <!-- Mother -->
        <?php if ($parent['mother_name']): ?>
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-female me-2 text-danger"></i>Mother Details</div>
            <div class="card-body p-0">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted ps-3" width="140">Mother Name</td><td class="fw-medium"><?php echo e($parent['mother_name']); ?></td></tr>
                    <tr><td class="text-muted ps-3">Phone</td><td><?php echo e($parent['mother_phone'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Email</td><td><?php echo e($parent['mother_email'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted ps-3">Occupation</td><td><?php echo e($parent['mother_occupation'] ?? '—'); ?></td></tr>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Address -->
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-map-marker-alt me-2"></i>Address</div>
            <div class="card-body">
                <p class="mb-0"><?php echo e($parent['address'] ?? '—'); ?>
                <?php echo e(implode(', ', array_filter([$parent['city'] ?? null, $parent['state'] ?? null, $parent['pincode'] ?? null]))); ?>
                </p>
            </div>
        </div>

        <!-- Login Account -->
        <div class="card">
            <div class="card-header fw-bold"><i class="fas fa-key me-2"></i>Login Account</div>
            <div class="card-body">
                <?php if ($parent['user_id']): ?>
                <div class="mb-2">
                    <span class="badge bg-<?php echo $parent['login_active'] ? 'success' : 'danger'; ?>">
                        <?php echo $parent['login_active'] ? 'Active' : 'Disabled'; ?>
                    </span>
                    <span class="ms-2 text-muted small"><?php echo e($parent['login_email'] ?? ''); ?></span>
                </div>
                <form method="POST" action="<?php echo url('parent/delete-login'); ?>"
                      onsubmit="return confirm('Remove login access for this parent?')">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="parent_id" value="<?php echo $parent['id']; ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger">
                        <i class="fas fa-user-minus me-1"></i>Remove Login
                    </button>
                </form>
                <?php else: ?>
                <p class="text-muted small mb-3">No login account. Create one so this parent can access the portal.</p>
                <form method="POST" action="<?php echo url('parent/create-login'); ?>">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="parent_id" value="<?php echo $parent['id']; ?>">
                    <div class="mb-2">
                        <input type="email" name="email" class="form-control form-control-sm"
                               placeholder="Email address" required
                               value="<?php echo e($parent['father_email'] ?? ''); ?>">
                    </div>
                    <div class="mb-2">
                        <input type="password" name="password" class="form-control form-control-sm"
                               placeholder="Password (min 6 chars)" required minlength="6">
                    </div>
                    <button type="submit" class="btn btn-success btn-sm w-100">
                        <i class="fas fa-user-plus me-1"></i>Create Portal Login
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Children -->
    <div class="col-md-7">
        <div class="card">
            <div class="card-header fw-bold">
                <i class="fas fa-child me-2"></i>Children
                <span class="badge bg-primary ms-1"><?php echo count($parent['children'] ?? []); ?></span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($parent['children'])): ?>
                <p class="text-muted text-center py-4">No children linked to this parent.</p>
                <?php else: ?>
                <?php foreach ($parent['children'] as $child): ?>
                <div class="border-bottom p-3 d-flex align-items-start gap-3">
                    <div class="flex-shrink-0">
                        <?php if (!empty($child['photo'])): ?>
                        <img src="<?php echo asset($child['photo']); ?>" class="rounded-circle" width="48" height="48" style="object-fit:cover;">
                        <?php else: ?>
                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;">
                            <i class="fas fa-user-graduate text-muted"></i>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-medium">
                            <?php echo e(trim(($child['first_name'] ?? '') . ' ' . ($child['last_name'] ?? ''))); ?>
                        </div>
                        <div class="text-muted small">
                            Adm: <?php echo e($child['admission_number']); ?> &bull;
                            <?php echo e($child['class_name'] ?? '—'); ?>
                            <?php echo $child['section_name'] ? '(' . e($child['section_name']) . ')' : ''; ?>
                        </div>
                        <span class="badge bg-<?php echo $child['status'] === 'Active' ? 'success' : 'secondary'; ?> mt-1">
                            <?php echo e($child['status']); ?>
                        </span>
                    </div>
                    <div>
                        <a href="<?php echo url('students/profile?id=' . $child['id']); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-eye"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
