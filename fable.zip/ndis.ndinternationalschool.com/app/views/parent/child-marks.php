﻿<div class="page-header">
    <h4><i class="fas fa-chart-bar"></i> Child Marks</h4>
    <a href="<?php echo url('parent/childProfile?id=' . $student['id']); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <h6 class="mb-3"><?php echo e(trim($student['first_name'] . ' ' . ($student['last_name'] ?? ''))); ?> - Exam Results</h6>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Exam</th>
                        <th>Subject</th>
                        <th>Marks Obtained</th>
                        <th>Total Marks</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($marks)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">No exam results found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($marks as $mark): ?>
                        <tr>
                            <td><?php echo e($mark['exam_name']); ?></td>
                            <td><?php echo e($mark['subject_name']); ?></td>
                            <td><strong><?php echo e($mark['marks_obtained']); ?></strong></td>
                            <td><?php echo e($mark['total_marks']); ?></td>
                            <td>
                                <span class="badge bg-info"><?php echo e($mark['grade'] ?? '-'); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>