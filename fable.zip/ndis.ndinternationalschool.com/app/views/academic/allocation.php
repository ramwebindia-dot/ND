﻿<div class="page-header"><h4><i class="fas fa-project-diagram"></i> Subject Allocation</h4>
    <button class="btn btn-primary-custom" data-bs-toggle="modal" data-bs-target="#allocModal"><i class="fas fa-plus me-1"></i>Allocate</button>
</div>
<div class="card"><div class="card-body"><div class="table-responsive"><table class="table table-hover">
    <thead><tr><th>#</th><th>Class</th><th>Subject</th><th>Teacher</th><th>Actions</th></tr></thead>
    <tbody><?php if (empty($allocations)): ?><tr><td colspan="5" class="text-center text-muted">No allocations found.</td></tr>
    <?php else: foreach ($allocations as $i => $alloc): ?>
    <tr><td><?php echo $i+1; ?></td><td><?php echo e($alloc['class_name'] ?? '-'); ?></td><td><?php echo e($alloc['subject_name'] ?? '-'); ?></td><td><?php echo e($alloc['teacher_name'] ?? '-'); ?></td>
    <td><a href="<?php echo url('academic/delete-allocation?id=' . $alloc['id']); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove?')"><i class="fas fa-trash"></i></a></td></tr>
    <?php endforeach; endif; ?></tbody>
</table></div></div></div>
<div class="modal fade" id="allocModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title">Allocate Subject</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <form method="POST" action="<?php echo url('academic/save-allocation'); ?>"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        <div class="mb-3"><label class="form-label">Class *</label><select name="class_id" class="form-select" required><option value="">Select</option><?php foreach ($classes as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option><?php endforeach; ?></select></div>
        <div class="mb-3"><label class="form-label">Subject *</label><select name="subject_id" class="form-select" required><option value="">Select</option><?php foreach ($subjects as $s): ?><option value="<?php echo $s['id']; ?>"><?php echo e($s['name']); ?></option><?php endforeach; ?></select></div>
        <div class="mb-3"><label class="form-label">Teacher *</label><select name="teacher_id" class="form-select" required><option value="">Select</option><?php foreach ($teachers as $t): ?><option value="<?php echo $t['id']; ?>"><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></option><?php endforeach; ?></select></div>
    </div><div class="modal-footer"><button type="submit" class="btn btn-primary-custom">Allocate</button></div></form>
</div></div></div>
