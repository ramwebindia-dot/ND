<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-layer-group me-2"></i>Sections</h4>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#sectionModal">
        <i class="fas fa-plus me-1"></i>Add Section
    </button>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr><th>#</th><th>Section Name</th><th>Class</th><th>Class Teacher</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php
                    $rowNum = 0; $hasSections = false;
                    foreach (($allSections ?? []) as $group) {
                        foreach (($group['sections'] ?? []) as $section) {
                            $hasSections = true; $rowNum++;
                ?>
                <tr>
                    <td><?php echo $rowNum; ?></td>
                    <td class="fw-medium"><?php echo e($section['name']); ?></td>
                    <td><?php echo e($group['class']['name'] ?? '-'); ?></td>
                    <td><?php echo trim($section['class_teacher_name'] ?? '') !== '' ? e($section['class_teacher_name']) : '—'; ?></td>
                    <td>
                        <button class="btn btn-sm btn-outline-warning"
                                onclick="editSection(<?php echo $section['id']; ?>, '<?php echo e(addslashes($section['name'])); ?>', <?php echo $group['class']['id'] ?? 0; ?>, <?php echo $section['class_teacher_id'] ?? 0; ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="POST" action="<?php echo url('academic/delete-section'); ?>" class="d-inline"
                              onsubmit="return confirm('Delete section &quot;<?php echo e(addslashes($section['name'])); ?>&quot;?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $section['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php
                        }
                    }
                    if (!$hasSections): ?>
                <tr><td colspan="5" class="text-center text-muted py-3">No sections found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Section Modal -->
<div class="modal fade" id="sectionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('academic/save-section'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add Section</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Section Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., A, B, C">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Class Teacher</label>
                        <select name="class_teacher_id" class="form-select">
                            <option value="">— None —</option>
                            <?php foreach (($teachers ?? []) as $t): ?>
                            <option value="<?php echo $t['id']; ?>"><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Section Modal -->
<div class="modal fade" id="editSectionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('academic/update-section'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="editSecId">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Section</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" id="editSecClass" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Section Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="editSecName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Class Teacher</label>
                        <select name="class_teacher_id" id="editSecTeacher" class="form-select">
                            <option value="">— None —</option>
                            <?php foreach (($teachers ?? []) as $t): ?>
                            <option value="<?php echo $t['id']; ?>"><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editSection(id, name, classId, teacherId) {
    document.getElementById('editSecId').value = id;
    document.getElementById('editSecName').value = name;
    document.getElementById('editSecClass').value = classId;
    document.getElementById('editSecTeacher').value = teacherId || '';
    new bootstrap.Modal(document.getElementById('editSectionModal')).show();
}
</script>
