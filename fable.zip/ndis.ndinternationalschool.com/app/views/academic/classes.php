<div class="page-header"><h4><i class="fas fa-graduation-cap"></i> Academic Management</h4></div>
<ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link <?php echo ($tab ?? '') === 'classes' || !isset($tab) ? 'active' : ''; ?>" href="<?php echo url('academic/classes'); ?>">Classes</a></li>
    <li class="nav-item"><a class="nav-link <?php echo ($tab ?? '') === 'sections' ? 'active' : ''; ?>" href="<?php echo url('academic/sections'); ?>">Sections</a></li>
    <li class="nav-item"><a class="nav-link <?php echo ($tab ?? '') === 'subjects' ? 'active' : ''; ?>" href="<?php echo url('academic/subjects'); ?>">Subjects</a></li>
    <li class="nav-item"><a class="nav-link <?php echo ($tab ?? '') === 'allocation' ? 'active' : ''; ?>" href="<?php echo url('academic/allocation'); ?>">Allocation</a></li>
</ul>

<!-- Classes Tab -->
<div class="card mb-3">
    <div class="card-header d-flex justify-content-between"><h6>Classes</h6>
        <button class="btn btn-sm btn-primary-custom" data-bs-toggle="modal" data-bs-target="#classModal"><i class="fas fa-plus me-1"></i>Add Class</button>
    </div>
    <div class="card-body"><div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>#</th><th>Name</th><th>Numeric Value</th><th>Session</th><th>Actions</th></tr></thead>
        <tbody>
            <?php if (empty($classes)): ?><tr><td colspan="5" class="text-center text-muted">No classes found.</td></tr>
            <?php else: foreach ($classes as $i => $class): ?>
            <tr><td><?php echo $i+1; ?></td><td><?php echo e($class['name']); ?></td><td><?php echo e($class['numeric_value']); ?></td><td><?php echo e($class['session_name'] ?? '-'); ?></td>
            <td><a href="<?php echo url('academic/edit-class?id=' . $class['id']); ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-edit"></i></a>
            <a href="<?php echo url('academic/delete-class?id=' . $class['id']); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this class?')"><i class="fas fa-trash"></i></a></td></tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table></div></div>
</div>

<!-- Class Modal -->
<div class="modal fade" id="classModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title">Add Class</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <form method="POST" action="<?php echo url('academic/save-class'); ?>"><div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g., Class 1"></div>
        <div class="mb-3"><label class="form-label">Numeric Value *</label><input type="number" name="numeric_value" class="form-control" required></div>
    </div><div class="modal-footer"><button type="submit" class="btn btn-primary-custom">Save</button></div></form>
</div></div></div>
