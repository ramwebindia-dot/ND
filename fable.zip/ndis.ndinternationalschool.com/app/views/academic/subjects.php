<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-book me-2"></i>Subjects</h4>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#subjectModal">
        <i class="fas fa-plus me-1"></i>Add Subject
    </button>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr><th>#</th><th>Name</th><th>Class</th><th>Code</th><th>Type</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($subjects)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">No subjects found.</td></tr>
                <?php else: foreach ($subjects as $i => $s): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td class="fw-medium"><?php echo e($s['name']); ?></td>
                    <td class="text-muted small"><?php echo e($s['class_name'] ?? '—'); ?></td>
                    <td><code><?php echo e($s['code'] ?? '—'); ?></code></td>
                    <td><span class="badge bg-light text-dark border"><?php echo e($s['type'] ?? 'Theory'); ?></span></td>
                    <td>
                        <button class="btn btn-sm btn-outline-warning"
                                onclick="editSubject(<?php echo $s['id']; ?>, '<?php echo e(addslashes($s['name'])); ?>', '<?php echo e(addslashes($s['code'] ?? '')); ?>', '<?php echo e($s['type'] ?? 'Theory'); ?>', <?php echo (int)($s['class_id'] ?? 0); ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="POST" action="<?php echo url('academic/delete-subject'); ?>" class="d-inline"
                              onsubmit="return confirm('Delete subject &quot;<?php echo e(addslashes($s['name'])); ?>&quot;?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Subject Modal -->
<div class="modal fade" id="subjectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('academic/save-subject'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes ?? [] as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="code" class="form-control" placeholder="e.g., MATH101">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="type" class="form-select">
                            <option>Theory</option>
                            <option>Practical</option>
                            <option>Theory+Practical</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Subject Modal -->
<div class="modal fade" id="editSubjectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('academic/update-subject'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="id" id="editSubId">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select name="class_id" id="editSubClass" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes ?? [] as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="editSubName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Code</label>
                        <input type="text" name="code" id="editSubCode" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="type" id="editSubType" class="form-select">
                            <option>Theory</option>
                            <option>Practical</option>
                            <option>Theory+Practical</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editSubject(id, name, code, type, classId) {
    document.getElementById('editSubId').value    = id;
    document.getElementById('editSubName').value  = name;
    document.getElementById('editSubCode').value  = code;
    document.getElementById('editSubClass').value = classId;
    const sel = document.getElementById('editSubType');
    [...sel.options].forEach(o => o.selected = o.value === type);
    new bootstrap.Modal(document.getElementById('editSubjectModal')).show();
}
</script>
