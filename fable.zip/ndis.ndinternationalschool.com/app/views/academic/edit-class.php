﻿<div class="page-header">
    <h4><i class="fas fa-edit"></i> Edit Class</h4>
    <a href="<?php echo url('academic/classes'); ?>" class="btn btn-outline-primary-custom"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo url('academic/edit-class?id=' . $class['id']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Name <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($class['name'] ?? ''); ?>" required placeholder="e.g., Class 1">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Numeric Value <span class="text-danger">*</span></label>
                    <input type="number" name="numeric_value" class="form-control" value="<?php echo e($class['numeric_value'] ?? ''); ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Class Teacher</label>
                    <select name="class_teacher_id" class="form-select">
                        <option value="">Select</option>
                        <?php foreach ($teachers as $t): ?>
                        <option value="<?php echo $t['id']; ?>" <?php echo ($class['class_teacher_id'] ?? '') == $t['id'] ? 'selected' : ''; ?>><?php echo e(trim($t['first_name'] . ' ' . ($t['last_name'] ?? ''))); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save me-1"></i>Update Class</button>
        </form>
    </div>
</div>
