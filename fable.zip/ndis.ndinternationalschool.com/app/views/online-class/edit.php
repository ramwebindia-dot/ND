<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-edit me-2"></i>Edit Online Class</h4>
    <a href="<?php echo url('online-class'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:800px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('online-class/edit?id='.$oc['id']); ?>">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required value="<?php echo e($oc['title']); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Platform</label>
                    <select name="platform" class="form-select">
                        <?php foreach (['Google Meet','Zoom','MS Teams','Other'] as $p): ?>
                        <option value="<?php echo $p; ?>" <?php echo $oc['platform']===$p?'selected':''; ?>><?php echo $p; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php foreach (['Scheduled','Live','Completed','Cancelled'] as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $oc['status']===$s?'selected':''; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Scheduled Date & Time <span class="text-danger">*</span></label>
                    <input type="datetime-local" name="scheduled_at" class="form-control" required
                           value="<?php echo date('Y-m-d\TH:i', strtotime($oc['scheduled_at'])); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Duration (minutes)</label>
                    <select name="duration_mins" class="form-select">
                        <?php foreach ([30,45,60,90,120] as $d): ?>
                        <option value="<?php echo $d; ?>" <?php echo $oc['duration_mins']==$d?'selected':''; ?>><?php echo $d; ?> minutes</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Meeting Link <span class="text-danger">*</span></label>
                    <input type="url" name="meeting_link" class="form-control" required value="<?php echo e($oc['meeting_link']); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Meeting ID</label>
                    <input type="text" name="meeting_id" class="form-control" value="<?php echo e($oc['meeting_id']??''); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Meeting Password</label>
                    <input type="text" name="meeting_password" class="form-control" value="<?php echo e($oc['meeting_password']??''); ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Recording Link <small class="text-muted">(add after class)</small></label>
                    <input type="url" name="recording_link" class="form-control" value="<?php echo e($oc['recording_link']??''); ?>" placeholder="https://...">
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?php echo e($oc['description']??''); ?></textarea>
                </div>
            </div>
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Update</button>
                <a href="<?php echo url('online-class'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
