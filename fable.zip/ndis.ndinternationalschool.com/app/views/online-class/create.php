<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-video me-2"></i>Schedule Online Class</h4>
    <a href="<?php echo url('online-class'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:800px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('online-class/create'); ?>">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Class Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required placeholder="e.g. Mathematics Chapter 5 - Algebra">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Class <span class="text-danger">*</span></label>
                    <select name="class_id" id="classSelect" class="form-select" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $c): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo e($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Section</label>
                    <select name="section_id" id="sectionSelect" class="form-select">
                        <option value="">All Sections</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Subject</label>
                    <select name="subject_id" id="subjectSelect" class="form-select">
                        <option value="">Select Subject</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Teacher <span class="text-danger">*</span></label>
                    <select name="teacher_id" class="form-select" required>
                        <option value="">Select Teacher</option>
                        <?php foreach ($teachers as $t): ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo e(trim(($t['first_name']??'').' '.($t['last_name']??''))); ?> (<?php echo e($t['employee_id']??''); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Platform <span class="text-danger">*</span></label>
                    <select name="platform" class="form-select" id="platformSelect" onchange="updateLinkPlaceholder()">
                        <option value="Google Meet">Google Meet</option>
                        <option value="Zoom">Zoom</option>
                        <option value="MS Teams">MS Teams</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Scheduled Date & Time <span class="text-danger">*</span></label>
                    <input type="datetime-local" name="scheduled_at" class="form-control" required
                           min="<?php echo date('Y-m-d\TH:i'); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Duration (minutes) <span class="text-danger">*</span></label>
                    <select name="duration_mins" class="form-select">
                        <option value="30">30 minutes</option>
                        <option value="45" selected>45 minutes</option>
                        <option value="60">1 hour</option>
                        <option value="90">1.5 hours</option>
                        <option value="120">2 hours</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Meeting Link <span class="text-danger">*</span></label>
                    <input type="url" name="meeting_link" class="form-control" required id="meetingLink"
                           placeholder="https://meet.google.com/xxx-yyyy-zzz">
                    <div class="form-text" id="linkHint">Paste the Google Meet / Zoom / Teams link here</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Meeting ID <small class="text-muted">(optional)</small></label>
                    <input type="text" name="meeting_id" class="form-control" placeholder="e.g. 123 456 7890">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Meeting Password <small class="text-muted">(optional)</small></label>
                    <input type="text" name="meeting_password" class="form-control" placeholder="e.g. abc123">
                </div>
                <div class="col-12">
                    <label class="form-label">Description / Agenda <small class="text-muted">(optional)</small></label>
                    <textarea name="description" class="form-control" rows="3" placeholder="What will be covered in this class..."></textarea>
                </div>
            </div>
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-calendar-plus me-2"></i>Schedule Class</button>
                <a href="<?php echo url('online-class'); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('classSelect').addEventListener('change', function() {
    const cid = this.value;
    const secSel = document.getElementById('sectionSelect');
    const subSel = document.getElementById('subjectSelect');
    secSel.innerHTML = '<option value="">All Sections</option>';
    subSel.innerHTML = '<option value="">Select Subject</option>';
    if (!cid) return;
    fetch('<?php echo url("academic/get-sections?class_id="); ?>' + cid)
        .then(r => r.json()).then(data => {
            data.forEach(s => secSel.innerHTML += `<option value="${s.id}">${s.name}</option>`);
        });
    fetch('<?php echo url("academic/get-subjects?class_id="); ?>' + cid)
        .then(r => r.json()).then(data => {
            data.forEach(s => subSel.innerHTML += `<option value="${s.id}">${s.name}</option>`);
        });
});

function updateLinkPlaceholder() {
    const p = document.getElementById('platformSelect').value;
    const hints = {
        'Google Meet': 'https://meet.google.com/xxx-yyyy-zzz',
        'Zoom':        'https://zoom.us/j/1234567890',
        'MS Teams':    'https://teams.microsoft.com/l/meetup-join/...',
        'Other':       'Paste your meeting link here'
    };
    document.getElementById('meetingLink').placeholder = hints[p] || '';
    document.getElementById('linkHint').textContent = `Paste your ${p} meeting link here`;
}
</script>
