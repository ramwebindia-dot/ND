<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-video me-2"></i><?php echo e($oc['title']); ?></h4>
    <a href="<?php echo url('online-class'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<?php
$statusColor = match($oc['status']) {
    'Live'      => 'success',
    'Scheduled' => 'info',
    'Completed' => 'secondary',
    'Cancelled' => 'danger',
    default     => 'secondary'
};
?>

<div class="row g-3">
    <div class="col-md-8">
        <!-- Class Info -->
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong><i class="fas fa-info-circle me-2"></i>Class Details</strong>
                <span class="badge bg-<?php echo $statusColor; ?> fs-6"><?php echo e($oc['status']); ?></span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6"><strong>Class:</strong> <?php echo e($oc['class_name']); ?><?php echo $oc['section_name'] ? ' - '.$oc['section_name'] : ''; ?></div>
                    <div class="col-md-6"><strong>Subject:</strong> <?php echo e($oc['subject_name'] ?? '—'); ?></div>
                    <div class="col-md-6"><strong>Teacher:</strong> <?php echo e($oc['teacher_name']); ?></div>
                    <div class="col-md-6"><strong>Platform:</strong> <?php echo e($oc['platform']); ?></div>
                    <div class="col-md-6"><strong>Date:</strong> <?php echo date('d M Y', strtotime($oc['scheduled_at'])); ?></div>
                    <div class="col-md-6"><strong>Time:</strong> <?php echo date('h:i A', strtotime($oc['scheduled_at'])); ?></div>
                    <div class="col-md-6"><strong>Duration:</strong> <?php echo $oc['duration_mins']; ?> minutes</div>
                    <?php if ($oc['meeting_id']): ?>
                    <div class="col-md-6"><strong>Meeting ID:</strong> <?php echo e($oc['meeting_id']); ?></div>
                    <?php endif; ?>
                    <?php if ($oc['meeting_password']): ?>
                    <div class="col-md-6"><strong>Password:</strong> <?php echo e($oc['meeting_password']); ?></div>
                    <?php endif; ?>
                    <?php if ($oc['description']): ?>
                    <div class="col-12"><strong>Description:</strong><br><p class="mb-0 text-muted"><?php echo nl2br(e($oc['description'])); ?></p></div>
                    <?php endif; ?>
                </div>
                <div class="mt-3 d-flex gap-2 flex-wrap">
                    <a href="<?php echo e($oc['meeting_link']); ?>" target="_blank" class="btn btn-success">
                        <i class="fas fa-sign-in-alt me-2"></i>Join Class
                    </a>
                    <?php if ($oc['recording_link']): ?>
                    <a href="<?php echo e($oc['recording_link']); ?>" target="_blank" class="btn btn-outline-secondary">
                        <i class="fas fa-play-circle me-2"></i>View Recording
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo url('online-class/edit?id='.$oc['id']); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-edit me-2"></i>Edit
                    </a>
                </div>
            </div>
        </div>

        <!-- Update Status -->
        <?php if ($oc['status'] !== 'Completed' && $oc['status'] !== 'Cancelled'): ?>
        <div class="card mb-3">
            <div class="card-header fw-bold"><i class="fas fa-toggle-on me-2"></i>Update Class Status</div>
            <div class="card-body">
                <div class="d-flex gap-2">
                    <?php if ($oc['status'] === 'Scheduled'): ?>
                    <form method="POST" action="<?php echo url('online-class/update-status'); ?>">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="id" value="<?php echo $oc['id']; ?>">
                        <input type="hidden" name="status" value="Live">
                        <button type="submit" class="btn btn-success"><i class="fas fa-circle me-2"></i>Mark as Live</button>
                    </form>
                    <?php endif; ?>
                    <?php if ($oc['status'] === 'Live'): ?>
                    <form method="POST" action="<?php echo url('online-class/update-status'); ?>">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="id" value="<?php echo $oc['id']; ?>">
                        <input type="hidden" name="status" value="Completed">
                        <button type="submit" class="btn btn-secondary"><i class="fas fa-check me-2"></i>Mark as Completed</button>
                    </form>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo url('online-class/update-status'); ?>">
                        <?php echo CSRF::field(); ?>
                        <input type="hidden" name="id" value="<?php echo $oc['id']; ?>">
                        <input type="hidden" name="status" value="Cancelled">
                        <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Cancel this class?')"><i class="fas fa-times me-2"></i>Cancel</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <!-- Attendance -->
        <div class="card">
            <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                <span><i class="fas fa-clipboard-check me-2"></i>Attendance</span>
                <?php $present = count(array_filter($attendance, fn($a)=>$a['status']==='Present')); ?>
                <span class="badge bg-success"><?php echo $present; ?>/<?php echo count($students); ?></span>
            </div>
            <div class="card-body p-0">
                <form method="POST" action="<?php echo url('online-class/mark-attendance'); ?>">
                    <?php echo CSRF::field(); ?>
                    <input type="hidden" name="online_class_id" value="<?php echo $oc['id']; ?>">
                    <div style="max-height:300px; overflow-y:auto;">
                        <table class="table table-sm mb-0">
                            <?php
                            $markedIds = array_column($attendance, 'student_id');
                            $presentIds = array_column(array_filter($attendance, fn($a)=>$a['status']==='Present'), 'student_id');
                            ?>
                            <?php foreach ($students as $st): ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" name="student_ids[]" value="<?php echo $st['id']; ?>"
                                               class="form-check-input"
                                               id="st<?php echo $st['id']; ?>"
                                               <?php echo in_array($st['id'], $presentIds) ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="st<?php echo $st['id']; ?>">
                                            <?php echo e(trim(($st['first_name']??'').' '.($st['last_name']??''))); ?>
                                            <small class="text-muted d-block"><?php echo e($st['admission_number']); ?></small>
                                        </label>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    <div class="p-2 d-flex gap-1">
                        <button type="button" class="btn btn-xs btn-outline-secondary btn-sm" onclick="toggleAll(true)">All</button>
                        <button type="button" class="btn btn-xs btn-outline-secondary btn-sm" onclick="toggleAll(false)">None</button>
                        <button type="submit" class="btn btn-primary btn-sm ms-auto"><i class="fas fa-save me-1"></i>Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleAll(val) {
    document.querySelectorAll('input[name="student_ids[]"]').forEach(cb => cb.checked = val);
}
</script>
