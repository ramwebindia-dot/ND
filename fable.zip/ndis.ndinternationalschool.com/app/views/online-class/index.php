<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-video me-2"></i>Online Classes</h4>
    <a href="<?php echo url('online-class/create'); ?>" class="btn btn-primary-custom">
        <i class="fas fa-plus me-1"></i>Schedule Class
    </a>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">Class</label>
                <select name="class_id" class="form-select form-select-sm">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo ($filters['classId']==$c['id'])?'selected':''; ?>>
                        <?php echo e($c['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All</option>
                    <?php foreach (['Scheduled','Live','Completed','Cancelled'] as $s): ?>
                    <option value="<?php echo $s; ?>" <?php echo ($filters['status']==$s)?'selected':''; ?>><?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control form-control-sm" value="<?php echo e($filters['dateFrom']); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control form-control-sm" value="<?php echo e($filters['dateTo']); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Stats -->
<?php
$scheduled = count(array_filter($online_classes, fn($c)=>$c['status']==='Scheduled'));
$live      = count(array_filter($online_classes, fn($c)=>$c['status']==='Live'));
$completed = count(array_filter($online_classes, fn($c)=>$c['status']==='Completed'));
?>
<div class="row g-3 mb-3">
    <div class="col-md-3"><div class="card text-center border-info"><div class="card-body py-2"><div class="fs-4 fw-bold text-info"><?php echo $scheduled; ?></div><div class="small text-muted">Scheduled</div></div></div></div>
    <div class="col-md-3"><div class="card text-center border-success"><div class="card-body py-2"><div class="fs-4 fw-bold text-success"><?php echo $live; ?></div><div class="small text-muted">Live Now</div></div></div></div>
    <div class="col-md-3"><div class="card text-center border-secondary"><div class="card-body py-2"><div class="fs-4 fw-bold text-secondary"><?php echo $completed; ?></div><div class="small text-muted">Completed</div></div></div></div>
    <div class="col-md-3"><div class="card text-center border-primary"><div class="card-body py-2"><div class="fs-4 fw-bold text-primary"><?php echo count($online_classes); ?></div><div class="small text-muted">Total</div></div></div></div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Title</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Teacher</th>
                        <th>Scheduled At</th>
                        <th>Duration</th>
                        <th>Platform</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($online_classes)): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">No online classes found.</td></tr>
                <?php else: ?>
                <?php foreach ($online_classes as $oc): ?>
                <?php
$statusColor = match($oc['status']) {
    'Live'      => 'success',
    'Scheduled' => 'info',
    'Completed' => 'secondary',
    'Cancelled' => 'danger',
    default     => 'secondary'
};
$platformIcon = match($oc['platform']) {
    'Zoom'      => 'fas fa-video text-primary',
    'Google Meet'=> 'fab fa-google text-danger',
    'MS Teams'  => 'fab fa-microsoft text-primary',
    default     => 'fas fa-link text-secondary'
};
?>
                <tr>
                    <td>
                        <strong><?php echo e($oc['title']); ?></strong>
                        <?php if ($oc['status'] === 'Live'): ?>
                        <span class="badge bg-success ms-1 blink">● LIVE</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($oc['class_name']); ?><?php echo $oc['section_name'] ? ' - '.$oc['section_name'] : ''; ?></td>
                    <td><?php echo e($oc['subject_name'] ?? '—'); ?></td>
                    <td><?php echo e($oc['teacher_name']); ?></td>
                    <td>
                        <div><?php echo date('d M Y', strtotime($oc['scheduled_at'])); ?></div>
                        <small class="text-muted"><?php echo date('h:i A', strtotime($oc['scheduled_at'])); ?></small>
                    </td>
                    <td><?php echo $oc['duration_mins']; ?> min</td>
                    <td><i class="<?php echo $platformIcon; ?> me-1"></i><?php echo e($oc['platform']); ?></td>
                    <td><span class="badge bg-<?php echo $statusColor; ?>"><?php echo e($oc['status']); ?></span></td>
                    <td>
                        <a href="<?php echo e($oc['meeting_link']); ?>" target="_blank" class="btn btn-sm btn-success" title="Join Class"><i class="fas fa-sign-in-alt"></i></a>
                        <a href="<?php echo url('online-class/show?id='.$oc['id']); ?>" class="btn btn-sm btn-outline-info" title="View"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo url('online-class/edit?id='.$oc['id']); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></a>
                        <form method="POST" action="<?php echo url('online-class/delete'); ?>" class="d-inline" onsubmit="return confirm('Delete this class?')">
                            <?php echo CSRF::field(); ?>
                            <input type="hidden" name="id" value="<?php echo $oc['id']; ?>">
                            <button class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.4} }
.blink { animation: blink 1.2s infinite; }
</style>
