<div class="page-header">
    <h4><i class="fas fa-video me-2"></i>My Online Classes</h4>
</div>

<?php if (empty($classes)): ?>
<div class="card"><div class="card-body text-center text-muted py-5">
    <i class="fas fa-video fa-3x mb-3 d-block"></i>
    <p>No upcoming online classes scheduled.</p>
</div></div>
<?php else: ?>
<div class="row g-3">
<?php foreach ($classes as $oc):
    $statusColor = match($oc['status']) {
        'Live'      => 'success',
        'Scheduled' => 'info',
        default     => 'secondary'
    };
    $isPast = strtotime($oc['scheduled_at']) < time();
    $isLive = $oc['status'] === 'Live';
?>
<div class="col-md-6">
    <div class="card h-100 border-<?php echo $statusColor; ?>">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong><?php echo e($oc['title']); ?></strong>
            <span class="badge bg-<?php echo $statusColor; ?>"><?php echo e($oc['status']); ?><?php echo $isLive?' ●':''; ?></span>
        </div>
        <div class="card-body">
            <div class="row g-2 text-sm">
                <div class="col-6"><i class="fas fa-book text-muted me-1"></i><?php echo e($oc['subject_name'] ?? '—'); ?></div>
                <div class="col-6"><i class="fas fa-chalkboard-teacher text-muted me-1"></i><?php echo e($oc['teacher_name']); ?></div>
                <div class="col-6"><i class="fas fa-calendar text-muted me-1"></i><?php echo date('d M Y', strtotime($oc['scheduled_at'])); ?></div>
                <div class="col-6"><i class="fas fa-clock text-muted me-1"></i><?php echo date('h:i A', strtotime($oc['scheduled_at'])); ?></div>
                <div class="col-6"><i class="fas fa-hourglass text-muted me-1"></i><?php echo $oc['duration_mins']; ?> min</div>
                <div class="col-6"><i class="fas fa-video text-muted me-1"></i><?php echo e($oc['platform']); ?></div>
            </div>
        </div>
        <div class="card-footer">
            <?php if ($isLive || (!$isPast && $oc['status'] === 'Scheduled')): ?>
            <a href="<?php echo e($oc['meeting_link']); ?>" target="_blank" class="btn btn-<?php echo $isLive ? 'success' : 'primary'; ?> btn-sm w-100">
                <i class="fas fa-sign-in-alt me-2"></i><?php echo $isLive ? 'Join Now (LIVE)' : 'Join Class'; ?>
            </a>
            <?php elseif ($oc['recording_link']): ?>
            <a href="<?php echo e($oc['recording_link']); ?>" target="_blank" class="btn btn-outline-secondary btn-sm w-100">
                <i class="fas fa-play-circle me-2"></i>Watch Recording
            </a>
            <?php else: ?>
            <button class="btn btn-outline-secondary btn-sm w-100" disabled>Class Ended</button>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
