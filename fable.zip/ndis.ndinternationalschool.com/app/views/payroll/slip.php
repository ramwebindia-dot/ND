<?php
$monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
$settings   = (new Settings())->getAll();
?>
<div class="page-header d-flex justify-content-between align-items-center no-print">
    <h4><i class="fas fa-file-invoice-dollar me-2"></i>Salary Slip</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('payroll/slip?id=' . $slip['id'] . '&format=pdf'); ?>" class="btn btn-danger btn-sm">
            <i class="fas fa-file-pdf me-1"></i>Download PDF
        </a>
        <button class="btn btn-primary btn-sm" onclick="window.print()">
            <i class="fas fa-print me-1"></i>Print
        </button>
        <a href="<?php echo url('payroll?month=' . $slip['month'] . '&year=' . $slip['year']); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left me-1"></i>Back
        </a>
    </div>
</div>

<div class="card" style="max-width:800px; margin:auto;" id="salarySlip">
    <div class="card-body p-4">
        <!-- Header -->
        <div class="text-center border-bottom pb-3 mb-3">
            <h4 class="mb-0"><?php echo e($settings['app_name'] ?? APP_NAME); ?></h4>
            <p class="text-muted mb-0 small"><?php echo e($settings['address'] ?? ''); ?></p>
            <h5 class="mt-2 mb-0">SALARY SLIP</h5>
            <p class="mb-0"><strong><?php echo $monthNames[$slip['month']]; ?> <?php echo $slip['year']; ?></strong></p>
        </div>

        <!-- Employee Info -->
        <div class="row mb-4">
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted" width="130">Employee Name</td><td><strong><?php echo e($slip['teacher_name']); ?></strong></td></tr>
                    <tr><td class="text-muted">Employee ID</td><td><?php echo e($slip['employee_id']); ?></td></tr>
                    <tr><td class="text-muted">Designation</td><td><?php echo e($slip['designation'] ?? '—'); ?></td></tr>
                    <tr><td class="text-muted">Department</td><td><?php echo e($slip['department_name'] ?? '—'); ?></td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><td class="text-muted" width="130">Pay Period</td><td><?php echo $monthNames[$slip['month']] . ' ' . $slip['year']; ?></td></tr>
                    <tr><td class="text-muted">Working Days</td><td><?php echo $slip['working_days']; ?></td></tr>
                    <tr><td class="text-muted">Present Days</td><td><?php echo $slip['present_days']; ?></td></tr>
                    <tr><td class="text-muted">Status</td>
                        <td><span class="badge bg-<?php echo $slip['status'] === 'Paid' ? 'success' : 'warning text-dark'; ?>">
                            <?php echo e($slip['status']); ?>
                        </span></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Earnings and Deductions -->
        <div class="row">
            <div class="col-md-6">
                <h6 class="bg-light px-2 py-1 rounded">Earnings</h6>
                <table class="table table-sm mb-0">
                    <tr><td>Basic Salary</td><td class="text-end">₹<?php echo number_format($slip['basic_salary'], 2); ?></td></tr>
                    <tr><td>House Rent Allowance (HRA)</td><td class="text-end">₹<?php echo number_format($slip['hra'], 2); ?></td></tr>
                    <tr><td>Dearness Allowance (DA)</td><td class="text-end">₹<?php echo number_format($slip['da'], 2); ?></td></tr>
                    <?php if ($slip['ta'] > 0): ?>
                    <tr><td>Travel Allowance (TA)</td><td class="text-end">₹<?php echo number_format($slip['ta'], 2); ?></td></tr>
                    <?php endif; ?>
                    <?php if ($slip['other_allowance'] > 0): ?>
                    <tr><td>Other Allowance</td><td class="text-end">₹<?php echo number_format($slip['other_allowance'], 2); ?></td></tr>
                    <?php endif; ?>
                    <tr class="fw-bold border-top">
                        <td>Gross Salary</td>
                        <td class="text-end">₹<?php echo number_format($slip['gross_salary'], 2); ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h6 class="bg-light px-2 py-1 rounded">Deductions</h6>
                <table class="table table-sm mb-0">
                    <?php if ($slip['pf_deduction'] > 0): ?>
                    <tr><td>Provident Fund (PF)</td><td class="text-end text-danger">-₹<?php echo number_format($slip['pf_deduction'], 2); ?></td></tr>
                    <?php endif; ?>
                    <?php if ($slip['esi_deduction'] > 0): ?>
                    <tr><td>ESI</td><td class="text-end text-danger">-₹<?php echo number_format($slip['esi_deduction'], 2); ?></td></tr>
                    <?php endif; ?>
                    <?php if ($slip['tds_deduction'] > 0): ?>
                    <tr><td>TDS</td><td class="text-end text-danger">-₹<?php echo number_format($slip['tds_deduction'], 2); ?></td></tr>
                    <?php endif; ?>
                    <?php if ($slip['advance_deduction'] > 0): ?>
                    <tr><td>Advance Deduction</td><td class="text-end text-danger">-₹<?php echo number_format($slip['advance_deduction'], 2); ?></td></tr>
                    <?php endif; ?>
                    <?php if ($slip['other_deduction'] > 0): ?>
                    <tr><td>Other Deductions</td><td class="text-end text-danger">-₹<?php echo number_format($slip['other_deduction'], 2); ?></td></tr>
                    <?php endif; ?>
                    <tr class="fw-bold border-top">
                        <td>Total Deductions</td>
                        <td class="text-end text-danger">-₹<?php echo number_format($slip['total_deductions'], 2); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Net Salary -->
        <div class="bg-primary text-white rounded p-3 mt-3 d-flex justify-content-between align-items-center">
            <div class="fs-5 fw-bold">Net Salary</div>
            <div class="fs-4 fw-bold">₹<?php echo number_format($slip['net_salary'], 2); ?></div>
        </div>

        <?php if ($slip['status'] === 'Paid'): ?>
        <div class="mt-3 text-muted small border-top pt-3">
            <strong>Payment Details:</strong>
            Method: <?php echo e($slip['payment_method']); ?> &bull;
            Date: <?php echo formatDate($slip['payment_date']); ?>
            <?php if ($slip['reference_number']): ?> &bull; Ref: <?php echo e($slip['reference_number']); ?><?php endif; ?>
            <?php if ($slip['remarks']): ?><br>Remarks: <?php echo e($slip['remarks']); ?><?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="mt-4 pt-3 border-top text-center text-muted small">
            This is a computer-generated salary slip. No signature required.
        </div>
    </div>
</div>

<style>
@media print {
    .no-print, .sidebar, .navbar { display: none !important; }
    #salarySlip { max-width: 100% !important; box-shadow: none !important; }
    body { background: white !important; }
}
</style>
