<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-list me-2"></i>Salary Structures</h4>
    <a href="<?php echo url('payroll/set-structure'); ?>" class="btn btn-success btn-sm">
        <i class="fas fa-plus me-1"></i>Add / Update Structure
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if (empty($structures)): ?>
        <div class="text-center py-5 text-muted">
            <i class="fas fa-file-alt fa-3x mb-3 d-block"></i>
            No salary structures defined.
            <div class="mt-3"><a href="<?php echo url('payroll/set-structure'); ?>" class="btn btn-success">Add Structure</a></div>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Employee</th>
                        <th>Dept</th>
                        <th>Basic</th>
                        <th>Allowances</th>
                        <th>Gross</th>
                        <th>Deductions</th>
                        <th>Net</th>
                        <th>From</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($structures as $s): ?>
                <?php $net = $s['gross_salary'] - $s['total_deductions']; ?>
                <tr>
                    <td>
                        <div class="fw-medium"><?php echo e($s['teacher_name']); ?></div>
                        <small class="text-muted"><?php echo e($s['employee_id']); ?></small>
                    </td>
                    <td><small><?php echo e($s['department_name'] ?? '—'); ?></small></td>
                    <td>₹<?php echo number_format($s['basic_salary'], 0); ?></td>
                    <td class="text-success small">
                        HRA: ₹<?php echo number_format($s['hra'], 0); ?><br>
                        DA: ₹<?php echo number_format($s['da'], 0); ?><br>
                        <?php if ($s['ta'] > 0): ?>TA: ₹<?php echo number_format($s['ta'], 0); ?><br><?php endif; ?>
                        <?php if ($s['other_allowance'] > 0): ?>Other: ₹<?php echo number_format($s['other_allowance'], 0); ?><?php endif; ?>
                    </td>
                    <td class="fw-medium">₹<?php echo number_format($s['gross_salary'], 0); ?></td>
                    <td class="text-danger small">
                        PF: ₹<?php echo number_format($s['pf_deduction'], 0); ?><br>
                        <?php if ($s['esi_deduction'] > 0): ?>ESI: ₹<?php echo number_format($s['esi_deduction'], 0); ?><br><?php endif; ?>
                        <?php if ($s['tds_deduction'] > 0): ?>TDS: ₹<?php echo number_format($s['tds_deduction'], 0); ?><?php endif; ?>
                    </td>
                    <td class="fw-bold text-success">₹<?php echo number_format($net, 0); ?></td>
                    <td><small><?php echo formatDate($s['effective_from']); ?></small></td>
                    <td>
                        <a href="<?php echo url('payroll/set-structure?id=' . $s['id']); ?>" class="btn btn-sm btn-warning" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
