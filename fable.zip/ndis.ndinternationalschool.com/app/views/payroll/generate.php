<?php $monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December']; ?>
<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-cogs me-2"></i>Generate Payroll</h4>
    <a href="<?php echo url('payroll'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:500px;">
    <div class="card-header fw-bold">Select Month & Year</div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            Payroll will be generated for all active staff (teaching &amp; non-teaching) who have a salary structure. Already-generated slips will be skipped.
        </div>
        <form method="POST" action="<?php echo url('payroll/generate'); ?>"
              onsubmit="return confirm('Generate payroll for selected month? This cannot be undone.')">
            <?php echo CSRF::field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-medium">Month</label>
                    <select name="month" class="form-select" required>
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo $m == date('n') ? 'selected' : ''; ?>>
                            <?php echo $monthNames[$m]; ?>
                        </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-medium">Year</label>
                    <select name="year" class="form-select" required>
                        <?php for ($y = date('Y'); $y >= date('Y') - 3; $y--): ?>
                        <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success mt-4 w-100">
                <i class="fas fa-cogs me-2"></i>Generate Payroll
            </button>
        </form>
    </div>
</div>
