<?php
$monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
?>
<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h4><i class="fas fa-money-bill-wave me-2"></i>Payroll — <?php echo $monthNames[$month]; ?> <?php echo $year; ?></h4>
    <div class="d-flex gap-2">
        <a href="<?php echo url('payroll/generate'); ?>" class="btn btn-success btn-sm">
            <i class="fas fa-cogs me-1"></i>Generate Payroll
        </a>
        <a href="<?php echo url('payroll/structures'); ?>" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-list me-1"></i>Salary Structures
        </a>
        <a href="<?php echo url('payroll/advances'); ?>" class="btn btn-outline-warning btn-sm">
            <i class="fas fa-hand-holding-usd me-1"></i>Advances
        </a>
        <a href="<?php echo url('payroll/reports'); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-chart-bar me-1"></i>Reports
        </a>
    </div>
</div>

<!-- Month Selector -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('payroll'); ?>" class="d-flex align-items-center gap-3">
            <label class="fw-medium mb-0">Select Month:</label>
            <select name="month" class="form-select form-select-sm" style="width:auto;">
                <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?php echo $m; ?>" <?php echo $m == $month ? 'selected' : ''; ?>>
                    <?php echo $monthNames[$m]; ?>
                </option>
                <?php endfor; ?>
            </select>
            <select name="year" class="form-select form-select-sm" style="width:auto;">
                <?php for ($y = date('Y'); $y >= date('Y') - 3; $y--): ?>
                <option value="<?php echo $y; ?>" <?php echo $y == $year ? 'selected' : ''; ?>><?php echo $y; ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Go</button>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-value"><?php echo $summary['total_teachers'] ?? 0; ?></div>
            <div class="stat-label">Total Slips</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-value text-warning"><?php echo $summary['generated'] ?? 0; ?></div>
            <div class="stat-label">Pending Payment</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-value text-success"><?php echo $summary['paid'] ?? 0; ?></div>
            <div class="stat-label">Paid</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-value">₹<?php echo number_format($summary['total_paid'] ?? 0, 0); ?></div>
            <div class="stat-label">Total Paid Amount</div>
        </div>
    </div>
</div>

<!-- Payroll Table -->
<div class="card">
    <div class="card-header fw-bold">
        <i class="fas fa-table me-2"></i>Salary Slips — <?php echo $monthNames[$month] . ' ' . $year; ?>
    </div>
    <div class="card-body p-0">
        <?php if (empty($payments)): ?>
        <div class="text-center py-5 text-muted">
            <i class="fas fa-file-invoice-dollar fa-3x mb-3 d-block"></i>
            No payroll generated for this month.
            <div class="mt-3">
                <a href="<?php echo url('payroll/generate'); ?>" class="btn btn-success">
                    <i class="fas fa-cogs me-2"></i>Generate Now
                </a>
            </div>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Employee</th>
                        <th>Dept</th>
                        <th>Gross</th>
                        <th>Deductions</th>
                        <th>Net Salary</th>
                        <th>Days</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($payments as $p): ?>
                <tr>
                    <td>
                        <div class="fw-medium"><?php echo e($p['teacher_name']); ?></div>
                        <small class="text-muted"><?php echo e($p['employee_id']); ?></small>
                    </td>
                    <td><small><?php echo e($p['department_name'] ?? '—'); ?></small></td>
                    <td>₹<?php echo number_format($p['gross_salary'], 0); ?></td>
                    <td class="text-danger">-₹<?php echo number_format($p['total_deductions'], 0); ?></td>
                    <td class="fw-bold">₹<?php echo number_format($p['net_salary'], 0); ?></td>
                    <td><?php echo $p['present_days']; ?>/<?php echo $p['working_days']; ?></td>
                    <td>
                        <?php if ($p['status'] === 'Paid'): ?>
                        <span class="badge bg-success">
                            <i class="fas fa-check me-1"></i>Paid
                        </span>
                        <div><small class="text-muted"><?php echo formatDate($p['payment_date'] ?? ''); ?></small></div>
                        <?php elseif ($p['status'] === 'Generated'): ?>
                        <span class="badge bg-warning text-dark">Pending</span>
                        <?php else: ?>
                        <span class="badge bg-danger"><?php echo e($p['status']); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo url('payroll/slip?id=' . $p['id']); ?>" class="btn btn-sm btn-outline-info" title="View Slip">
                            <i class="fas fa-eye"></i>
                        </a>
                        <?php if ($p['status'] === 'Generated'): ?>
                        <button type="button" class="btn btn-sm btn-success" title="Mark Paid"
                                onclick="markPaid(<?php echo $p['id']; ?>, '<?php echo e($p['teacher_name']); ?>', <?php echo $p['net_salary']; ?>)">
                            <i class="fas fa-check"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Mark Paid Modal -->
<div class="modal fade" id="paidModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo url('payroll/mark-paid'); ?>">
                <?php echo CSRF::field(); ?>
                <input type="hidden" name="payment_id" id="paidId">
                <div class="modal-header">
                    <h5 class="modal-title">Mark Salary as Paid</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Teacher: <strong id="paidTeacher"></strong></p>
                    <p>Amount: <strong id="paidAmount"></strong></p>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" class="form-select">
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Cash">Cash</option>
                                <option value="Cheque">Cheque</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Payment Date</label>
                            <input type="date" name="payment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Reference / Transaction Number</label>
                            <input type="text" name="reference_number" class="form-control" placeholder="UTR / Cheque no.">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Remarks</label>
                            <textarea name="remarks" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success"><i class="fas fa-check me-1"></i>Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function markPaid(id, name, amount) {
    document.getElementById('paidId').value = id;
    document.getElementById('paidTeacher').textContent = name;
    document.getElementById('paidAmount').textContent = '₹' + amount.toLocaleString('en-IN');
    new bootstrap.Modal(document.getElementById('paidModal')).show();
}
</script>
