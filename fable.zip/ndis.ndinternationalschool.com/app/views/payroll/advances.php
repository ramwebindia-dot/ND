<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-hand-holding-usd me-2"></i>Salary Advances</h4>
    <a href="<?php echo url('payroll'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back to Payroll</a>
</div>

<div class="row g-4">
    <!-- Form -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header fw-bold">Record New Advance</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('payroll/advances'); ?>">
                    <?php echo CSRF::field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Employee</label>
                        <select name="employee_ref" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php $grp = ''; foreach ($employees as $emp): ?>
                                <?php if ($emp['group'] !== $grp): ?>
                                    <?php if ($grp !== ''): ?></optgroup><?php endif; ?>
                                    <optgroup label="<?php echo e($emp['group']); ?>">
                                    <?php $grp = $emp['group']; ?>
                                <?php endif; ?>
                                <option value="<?php echo e($emp['ref']); ?>">
                                    <?php echo e($emp['name']); ?> (<?php echo e($emp['employee_id']); ?>)
                                </option>
                            <?php endforeach; ?>
                            <?php if ($grp !== ''): ?></optgroup><?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Amount</label>
                        <div class="input-group"><span class="input-group-text">₹</span>
                        <input type="number" name="amount" class="form-control" step="0.01" min="1" required></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Date</label>
                        <input type="date" name="advance_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <textarea name="reason" class="form-control" rows="2" placeholder="Reason for advance"></textarea>
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label">Deduct Month</label>
                            <select name="deduction_month" class="form-select form-select-sm">
                                <option value="">—</option>
                                <?php for ($m=1;$m<=12;$m++): ?>
                                <option value="<?php echo $m; ?>"><?php echo date('M',mktime(0,0,0,$m,1)); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Deduct Year</label>
                            <select name="deduction_year" class="form-select form-select-sm">
                                <option value="">—</option>
                                <?php for ($y=date('Y');$y<=date('Y')+1;$y++): ?>
                                <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success w-100 mt-3">
                        <i class="fas fa-plus me-1"></i>Record Advance
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- List -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header fw-bold">Advance History</div>
            <div class="card-body p-0">
                <?php if (empty($advances)): ?>
                <p class="text-center py-4 text-muted">No advances recorded.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr><th>Employee</th><th>Amount</th><th>Date</th><th>Deduct</th><th>Status</th><th>Reason</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($advances as $a): ?>
                        <tr>
                            <td>
                                <div class="fw-medium"><?php echo e($a['teacher_name']); ?></div>
                                <small class="text-muted"><?php echo e($a['employee_id']); ?></small>
                            </td>
                            <td class="fw-bold">₹<?php echo number_format($a['amount'], 0); ?></td>
                            <td><small><?php echo formatDate($a['advance_date']); ?></small></td>
                            <td>
                                <?php if ($a['deduction_month']): ?>
                                <small><?php echo date('M', mktime(0,0,0,$a['deduction_month'],1)); ?> <?php echo $a['deduction_year']; ?></small>
                                <?php else: ?>
                                <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo $a['status']==='Deducted' ? 'success' : ($a['status']==='Cancelled' ? 'danger' : 'warning text-dark'); ?>">
                                    <?php echo e($a['status']); ?>
                                </span>
                            </td>
                            <td><small><?php echo e($a['reason'] ?? '—'); ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
