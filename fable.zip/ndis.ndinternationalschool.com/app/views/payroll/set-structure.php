<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-edit me-2"></i><?php echo $pageTitle; ?></h4>
    <a href="<?php echo url('payroll/structures'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<div class="card" style="max-width:700px;">
    <div class="card-body">
        <form method="POST" action="<?php echo url('payroll/set-structure'); ?>">
            <?php echo CSRF::field(); ?>
            <div class="mb-3">
                <label class="form-label fw-medium">Employee <span class="text-danger">*</span></label>
                <select name="employee_ref" class="form-select" required <?php echo $existing ? 'disabled' : ''; ?>>
                    <option value="">-- Select Employee --</option>
                    <?php $grp = ''; foreach ($employees as $emp): ?>
                        <?php if ($emp['group'] !== $grp): ?>
                            <?php if ($grp !== ''): ?></optgroup><?php endif; ?>
                            <optgroup label="<?php echo e($emp['group']); ?>">
                            <?php $grp = $emp['group']; ?>
                        <?php endif; ?>
                        <option value="<?php echo e($emp['ref']); ?>" <?php echo ($existingRef === $emp['ref']) ? 'selected' : ''; ?>>
                            <?php echo e($emp['name']); ?> (<?php echo e($emp['employee_id']); ?>)
                        </option>
                    <?php endforeach; ?>
                    <?php if ($grp !== ''): ?></optgroup><?php endif; ?>
                </select>
                <?php if ($existing): ?>
                <input type="hidden" name="employee_ref" value="<?php echo e($existingRef); ?>">
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label fw-medium">Effective From</label>
                <input type="date" name="effective_from" class="form-control"
                       value="<?php echo e($existing['effective_from'] ?? date('Y-m-01')); ?>" required>
                <small class="text-muted">Previous structure will be deactivated.</small>
            </div>

            <h6 class="mt-4 mb-3 text-success border-bottom pb-2"><i class="fas fa-plus-circle me-2"></i>Earnings</h6>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Basic Salary</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="basic_salary" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['basic_salary'] ?? 0; ?>" required oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">HRA</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="hra" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['hra'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">DA</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="da" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['da'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">TA</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="ta" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['ta'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Other Allowance</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="other_allowance" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['other_allowance'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Gross Salary</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="text" id="grossDisplay" class="form-control bg-light fw-bold text-success" readonly>
                    </div>
                </div>
            </div>

            <h6 class="mt-4 mb-3 text-danger border-bottom pb-2"><i class="fas fa-minus-circle me-2"></i>Deductions</h6>
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">PF</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="pf_deduction" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['pf_deduction'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">ESI</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="esi_deduction" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['esi_deduction'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">TDS</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="tds_deduction" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['tds_deduction'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Other</label>
                    <div class="input-group"><span class="input-group-text">₹</span>
                    <input type="number" name="other_deduction" class="form-control" step="0.01" min="0"
                           value="<?php echo $existing['other_deduction'] ?? 0; ?>" oninput="calcNet()">
                    </div>
                </div>
            </div>

            <!-- Net Summary -->
            <div class="card mt-4 bg-light">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted me-3">Gross: <strong id="grossSummary" class="text-success">₹0</strong></span>
                        <span class="text-muted me-3">Deductions: <strong id="deductSummary" class="text-danger">₹0</strong></span>
                    </div>
                    <div class="fs-5 fw-bold">
                        Net Salary: <span id="netSummary" class="text-primary">₹0</span>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save me-2"></i>Save Structure
                </button>
                <a href="<?php echo url('payroll/structures'); ?>" class="btn btn-secondary ms-2">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function calcNet() {
    const g = (n) => parseFloat(document.querySelector(`[name="${n}"]`)?.value || 0);
    const gross = g('basic_salary') + g('hra') + g('da') + g('ta') + g('other_allowance');
    const deductions = g('pf_deduction') + g('esi_deduction') + g('tds_deduction') + g('other_deduction');
    const net = gross - deductions;
    const fmt = (v) => '₹' + v.toLocaleString('en-IN', {minimumFractionDigits: 0});
    document.getElementById('grossDisplay').value = fmt(gross);
    document.getElementById('grossSummary').textContent = fmt(gross);
    document.getElementById('deductSummary').textContent = fmt(deductions);
    document.getElementById('netSummary').textContent = fmt(net);
}
calcNet();
</script>
