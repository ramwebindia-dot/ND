<?php $monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December']; ?>
<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-chart-bar me-2"></i>Payroll Reports</h4>
    <a href="<?php echo url('payroll'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back</a>
</div>

<!-- Year Selector -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo url('payroll/reports'); ?>" class="d-flex align-items-center gap-3">
            <label class="fw-medium mb-0">Year:</label>
            <select name="year" class="form-select form-select-sm" style="width:auto;">
                <?php for ($y = date('Y'); $y >= date('Y') - 4; $y--): ?>
                <option value="<?php echo $y; ?>" <?php echo $y == $year ? 'selected' : ''; ?>><?php echo $y; ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">View</button>
        </form>
    </div>
</div>

<?php if (empty($monthly)): ?>
<div class="alert alert-info">No payroll data found for <?php echo $year; ?>.</div>
<?php else: ?>
<?php
$totalGross = array_sum(array_column($monthly, 'total_gross'));
$totalNet   = array_sum(array_column($monthly, 'total_net'));
$totalPaid  = array_sum(array_column($monthly, 'total_paid'));
?>
<!-- Summary -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-value">₹<?php echo number_format($totalGross, 0); ?></div>
            <div class="stat-label">Total Gross (<?php echo $year; ?>)</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-value">₹<?php echo number_format($totalNet, 0); ?></div>
            <div class="stat-label">Total Net Salary</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card">
            <div class="stat-value text-success">₹<?php echo number_format($totalPaid, 0); ?></div>
            <div class="stat-label">Total Paid</div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header fw-bold">Month-wise Summary — <?php echo $year; ?></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Month</th>
                        <th>Slips</th>
                        <th>Gross</th>
                        <th>Deductions</th>
                        <th>Net</th>
                        <th>Paid</th>
                        <th>Pending</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($monthly as $row): ?>
                <?php $pending = $row['total_net'] - $row['total_paid']; ?>
                <tr>
                    <td class="fw-medium"><?php echo $monthNames[$row['month']] . ' ' . $row['year']; ?></td>
                    <td><?php echo $row['total_slips']; ?></td>
                    <td>₹<?php echo number_format($row['total_gross'], 0); ?></td>
                    <td class="text-danger">₹<?php echo number_format($row['total_deductions'], 0); ?></td>
                    <td class="fw-bold">₹<?php echo number_format($row['total_net'], 0); ?></td>
                    <td class="text-success">₹<?php echo number_format($row['total_paid'], 0); ?></td>
                    <td class="text-warning">₹<?php echo number_format(max(0, $pending), 0); ?></td>
                    <td>
                        <?php if ($row['paid_count'] >= $row['total_slips']): ?>
                        <span class="badge bg-success">Complete</span>
                        <?php elseif ($row['paid_count'] > 0): ?>
                        <span class="badge bg-warning text-dark">Partial</span>
                        <?php else: ?>
                        <span class="badge bg-secondary">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo url('payroll?month=' . $row['month'] . '&year=' . $row['year']); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
