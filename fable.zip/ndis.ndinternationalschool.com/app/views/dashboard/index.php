<div class="page-header">
    <h4><i class="fas fa-tachometer-alt"></i> Dashboard</h4>
    <div>
        <span class="badge badge-primary-custom"><i class="fas fa-calendar-alt me-1"></i>Session: <?php echo e($activeSession['name'] ?? 'Not Set'); ?></span>
    </div>
</div>

<!-- Stats Row -->
<div class="row g-3 mb-4">
    <?php
    $topCards = [
        ['value' => e($stats['total_students']), 'label' => 'Total Students',     'icon' => 'fa-user-graduate',    'color' => 'var(--primary-custom)', 'bg' => 'bg-primary-custom', 'url' => 'students'],
        ['value' => e($stats['total_teachers']), 'label' => 'Total Teachers',     'icon' => 'fa-chalkboard-teacher','color' => 'var(--success)',        'bg' => 'bg-success-custom', 'url' => 'teachers'],
        ['value' => e($stats['attendance_present']) . ' / ' . e($stats['attendance_total']), 'label' => "Today's Attendance", 'icon' => 'fa-clipboard-check', 'color' => 'var(--info)', 'bg' => 'bg-info-custom', 'url' => 'attendance'],
        ['value' => formatCurrency($stats['fee_collections']), 'label' => 'Fee Collected (Today)', 'icon' => 'fa-rupee-sign', 'color' => 'var(--danger)', 'bg' => 'bg-danger-custom', 'url' => 'fees'],
    ];
    foreach ($topCards as $card): ?>
    <div class="col-lg-3 col-md-6">
        <a href="<?php echo url($card['url']); ?>" class="text-decoration-none">
        <div class="stat-card" style="border-left-color:<?php echo $card['color']; ?>; cursor:pointer; transition:box-shadow 0.2s;"
             onmouseover="this.style.boxShadow='0 4px 16px rgba(0,0,0,0.13)'" onmouseout="this.style.boxShadow=''">
            <div class="stat-icon <?php echo $card['bg']; ?>"><i class="fas <?php echo $card['icon']; ?>"></i></div>
            <div class="stat-value"><?php echo $card['value']; ?></div>
            <div class="stat-label"><?php echo $card['label']; ?></div>
        </div>
        </a>
    </div>
    <?php endforeach; ?>
</div>

<!-- Financial Stats Row -->
<div class="row g-3 mb-4">
    <div class="col-lg-3 col-md-6">
        <a href="<?php echo url('fees?tab=outstanding'); ?>" class="text-decoration-none">
        <div class="stat-card" style="border-left-color: var(--warning); cursor:pointer; transition: box-shadow 0.2s;" onmouseover="this.style.boxShadow='0 4px 16px rgba(0,0,0,0.13)'" onmouseout="this.style.boxShadow=''">
            <div class="stat-icon" style="background: rgba(243,156,18,0.12); color: var(--warning);"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-value text-warning"><?php echo formatCurrency($stats['total_outstanding_all']); ?></div>
            <div class="stat-label">Outstanding Fees (All Sessions)
                <small class="d-block text-muted">
                    This year: <?php echo formatCurrency($stats['outstanding_fees']); ?>
                    <?php if ($stats['total_previous_outstanding'] > 0): ?>
                    <br><span class="text-danger">Carry fwd: <?php echo formatCurrency($stats['total_previous_outstanding']); ?></span>
                    <?php endif; ?>
                </small>
            </div>
        </div>
        </a>
    </div>
    <?php if (!empty($stats['previous_outstanding'])): ?>
    <!-- Previous sessions outstanding alert -->
    <div class="col-12">
        <div class="alert alert-danger border-0 py-2 mb-0" style="border-left: 4px solid var(--danger) !important; border-radius:8px;">
            <i class="fas fa-exclamation-circle me-2"></i>
            <strong>Carry Forward Outstanding:</strong>
            <?php foreach ($stats['previous_outstanding'] as $prev): ?>
            <span class="badge bg-danger ms-2"><?php echo e($prev['session_name']); ?>: <?php echo formatCurrency($prev['outstanding']); ?></span>
            <?php endforeach; ?>
            <a href="<?php echo url('fees?tab=outstanding'); ?>" class="ms-3 text-danger fw-bold" style="font-size:13px;">View Details →</a>
        </div>
    </div>
    <?php endif; ?>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: var(--success);">
            <div class="stat-icon bg-success-custom"><i class="fas fa-money-bill-wave"></i></div>
            <div class="stat-value"><?php echo formatCurrency($stats['cash_balance']); ?></div>
            <div class="stat-label">Cash Balance</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: var(--info);">
            <div class="stat-icon bg-info-custom"><i class="fas fa-university"></i></div>
            <div class="stat-value"><?php echo formatCurrency($stats['bank_balance']); ?></div>
            <div class="stat-label">Bank Balance</div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="border-left-color: var(--danger);">
            <div class="stat-icon bg-danger-custom"><i class="fas fa-undo"></i></div>
            <div class="stat-value"><?php echo formatCurrency($stats['refund_total']); ?></div>
            <div class="stat-label">Total Refunds</div>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-chart-line text-primary-custom me-2"></i>Monthly Fee Collection</h6>
            </div>
            <div class="card-body">
                <div class="chart-container">
                    <canvas id="feeChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-chart-pie text-primary-custom me-2"></i>Attendance Overview</h6>
            </div>
            <div class="card-body">
                <div class="chart-container">
                    <canvas id="attendanceChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Notices & Exams Row -->
<div class="row g-3">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-bullhorn text-primary-custom me-2"></i>Recent Notices</h6>
                <a href="<?php echo url('communication'); ?>" class="btn btn-sm btn-outline-primary-custom">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($notices)): ?>
                    <p class="text-muted text-center py-3 mb-0">No notices found.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($notices as $notice): ?>
                            <div class="list-group-item px-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1" style="font-size: 14px;"><?php echo e($notice['title']); ?></h6>
                                        <small class="text-muted"><?php echo Helper::timeAgo($notice['created_at']); ?></small>
                                    </div>
                                    <span class="badge <?php echo $notice['priority'] === 'Urgent' ? 'badge-danger-custom' : ($notice['priority'] === 'High' ? 'badge-warning-custom' : 'badge-secondary-custom'); ?>">
                                        <?php echo e($notice['priority']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h6><i class="fas fa-file-alt text-primary-custom me-2"></i>Upcoming Exams</h6>
                <a href="<?php echo url('exams'); ?>" class="btn btn-sm btn-outline-primary-custom">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($exams)): ?>
                    <p class="text-muted text-center py-3 mb-0">No upcoming exams.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($exams as $exam): ?>
                            <div class="list-group-item px-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1" style="font-size: 14px;"><?php echo e($exam['name']); ?></h6>
                                        <small class="text-muted"><?php echo e($exam['class_name']); ?> | <?php echo formatDate($exam['start_date']); ?></small>
                                    </div>
                                    <span class="badge <?php echo $exam['status'] === 'Ongoing' ? 'badge-success-custom' : 'badge-info-custom'; ?>">
                                        <?php echo e($exam['status']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Chart Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Fee Collection Chart
    <?php if (!empty($feeChartData)): ?>
    const feeLabels = <?php echo json_encode(array_column($feeChartData, 'month')); ?>;
    const feeData = <?php echo json_encode(array_map('floatval', array_column($feeChartData, 'total'))); ?>;
    createBarChart('feeChart', feeLabels, feeData, 'Fee Collection');
    <?php endif; ?>

    // Attendance Doughnut Chart
    const attPresent = <?php echo e($stats['attendance_present']); ?>;
    const attTotal = <?php echo e($stats['attendance_total']); ?>;
    const attAbsent = attTotal - attPresent;
    if (attTotal > 0) {
        createDoughnutChart('attendanceChart', ['Present', 'Absent'], [attPresent, attAbsent]);
    }
});
</script>
