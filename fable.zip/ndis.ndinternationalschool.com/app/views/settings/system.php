<div class="page-header">
    <h4><i class="fas fa-cog"></i> System Settings</h4>
</div>

<form method="POST" action="<?php echo url('settings/system'); ?>">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-calendar-alt me-2"></i>Academic Settings</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Default Academic Session</label>
                        <input type="text" name="default_session" class="form-control" value="<?php echo e($settings['default_session'] ?? ''); ?>" placeholder="e.g., 2025-2026">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Date Format</label>
                        <select name="date_format" class="form-select">
                            <option value="d-m-Y" <?php echo ($settings['date_format'] ?? 'd-m-Y') === 'd-m-Y' ? 'selected' : ''; ?>>DD-MM-YYYY</option>
                            <option value="Y-m-d" <?php echo ($settings['date_format'] ?? '') === 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                            <option value="d/m/Y" <?php echo ($settings['date_format'] ?? '') === 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Currency Symbol</label>
                        <input type="text" name="currency_symbol" class="form-control" value="<?php echo e($settings['currency_symbol'] ?? '₹'); ?>" maxlength="3">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-envelope me-2"></i>Email Settings</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">SMTP Host</label>
                        <input type="text" name="smtp_host" class="form-control" value="<?php echo e($settings['smtp_host'] ?? ''); ?>">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">SMTP Port</label>
                            <input type="text" name="smtp_port" class="form-control" value="<?php echo e($settings['smtp_port'] ?? '587'); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SMTP Security</label>
                            <select name="smtp_security" class="form-select">
                                <option value="tls" <?php echo ($settings['smtp_security'] ?? 'tls') === 'tls' ? 'selected' : ''; ?>>TLS</option>
                                <option value="ssl" <?php echo ($settings['smtp_security'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                <option value="none" <?php echo ($settings['smtp_security'] ?? '') === 'none' ? 'selected' : ''; ?>>None</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">SMTP Username</label>
                        <input type="text" name="smtp_username" class="form-control" value="<?php echo e($settings['smtp_username'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">SMTP Password</label>
                        <input type="password" name="smtp_password" class="form-control" placeholder="Enter new password to change">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">From Email</label>
                        <input type="email" name="from_email" class="form-control" value="<?php echo e($settings['from_email'] ?? ''); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-bell me-2"></i>Notification Settings</div>
                <div class="card-body">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="enable_email_notifications" value="1" <?php echo !empty($settings['enable_email_notifications']) ? 'checked' : ''; ?>>
                        <label class="form-check-label">Enable Email Notifications</label>
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="enable_sms_notifications" value="1" <?php echo !empty($settings['enable_sms_notifications']) ? 'checked' : ''; ?>>
                        <label class="form-check-label">Enable SMS Notifications</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="enable_push_notifications" value="1" <?php echo !empty($settings['enable_push_notifications']) ? 'checked' : ''; ?>>
                        <label class="form-check-label">Enable Push Notifications</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-shield-alt me-2"></i>Security Settings</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Session Timeout (minutes)</label>
                        <input type="number" name="session_timeout" class="form-control" value="<?php echo e($settings['session_timeout'] ?? '30'); ?>" min="5" max="120">
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="force_https" value="1" <?php echo !empty($settings['force_https']) ? 'checked' : ''; ?>>
                        <label class="form-check-label">Force HTTPS</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="maintenance_mode" value="1" <?php echo !empty($settings['maintenance_mode']) ? 'checked' : ''; ?>>
                        <label class="form-check-label">Maintenance Mode</label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary-custom">
        <i class="fas fa-save"></i> Save System Settings
    </button>
</form>
