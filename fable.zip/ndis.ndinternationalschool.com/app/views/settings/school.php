<div class="page-header">
    <h4><i class="fas fa-school"></i> School Settings</h4>
</div>

<form method="POST" action="<?php echo url('settings/school'); ?>" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-info-circle me-2"></i>School Information</div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">School Name</label>
                            <input type="text" name="school_name" class="form-control" value="<?php echo e($settings['school_name'] ?? 'ND International School Dinod'); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">School Code</label>
                            <input type="text" name="school_code" class="form-control" value="<?php echo e($settings['school_code'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Phone</label>
                            <input type="text" name="school_phone" class="form-control" value="<?php echo e($settings['school_phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="school_email" class="form-control" value="<?php echo e($settings['school_email'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <textarea name="school_address" class="form-control" rows="2"><?php echo e($settings['school_address'] ?? ''); ?></textarea>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">City</label>
                            <input type="text" name="school_city" class="form-control" value="<?php echo e($settings['school_city'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">State</label>
                            <input type="text" name="school_state" class="form-control" value="<?php echo e($settings['school_state'] ?? ''); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">PIN Code</label>
                            <input type="text" name="school_pin" class="form-control" value="<?php echo e($settings['school_pin'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Affiliation Number</label>
                            <input type="text" name="affiliation_number" class="form-control" value="<?php echo e($settings['affiliation_number'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Board</label>
                            <input type="text" name="school_board" class="form-control" value="<?php echo e($settings['school_board'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header"><i class="fas fa-image me-2"></i>School Logo</div>
                <div class="card-body text-center">
                    <?php if (!empty($settings['school_logo'])): ?>
                    <img src="<?php echo asset($settings['school_logo']); ?>" alt="School Logo" class="img-thumbnail mb-3" style="max-height: 150px;">
                    <?php else: ?>
                    <div class="bg-light rounded d-flex align-items-center justify-content-center mb-3" style="height: 150px;">
                        <i class="fas fa-school fa-3x text-muted"></i>
                    </div>
                    <?php endif; ?>
                    <input type="file" name="school_logo" class="form-control" accept="image/*">
                    <small class="text-muted">Recommended: 200x200px, PNG/JPG</small>
                </div>
            </div>
            <button type="submit" class="btn btn-primary-custom w-100">
                <i class="fas fa-save"></i> Save Settings
            </button>
        </div>
    </div>
</form>
