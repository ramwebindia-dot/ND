<div class="page-header"><h4><i class="fas fa-sms me-2"></i>SMS Settings</h4></div>

<div class="row g-4">
<div class="col-md-8">
<form method="POST" action="<?php echo url('settings/sms'); ?>">
    <?php echo CSRF::field(); ?>

    <div class="card mb-4">
        <div class="card-header fw-bold">Gateway Configuration</div>
        <div class="card-body">
            <div class="mb-3 d-flex align-items-center gap-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="sms_enabled" value="1" role="switch"
                           id="smsEnabled" <?php echo ($settings['sms_enabled'] ?? 0) ? 'checked' : ''; ?>>
                    <label class="form-check-label fw-medium" for="smsEnabled">Enable SMS</label>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Gateway</label>
                <select name="sms_gateway" class="form-select" id="gatewaySelect" onchange="toggleGateway()">
                    <option value="fast2sms" <?php echo ($settings['sms_gateway'] ?? '') === 'fast2sms' ? 'selected' : ''; ?>>Fast2SMS (Recommended for India)</option>
                    <option value="msg91" <?php echo ($settings['sms_gateway'] ?? '') === 'msg91' ? 'selected' : ''; ?>>MSG91</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Fast2SMS -->
    <div class="card mb-4" id="fast2smsCard">
        <div class="card-header fw-bold">
            <i class="fas fa-bolt me-2 text-warning"></i>Fast2SMS Settings
            <a href="https://www.fast2sms.com/dashboard/credentials" target="_blank" class="btn btn-sm btn-outline-secondary ms-3">
                <i class="fas fa-external-link-alt me-1"></i>Get API Key
            </a>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">API Key</label>
                <div class="input-group">
                    <input type="password" name="sms_fast2sms_api_key" id="f2sKey" class="form-control"
                           value="<?php echo e($settings['sms_fast2sms_api_key'] ?? ''); ?>" placeholder="Your Fast2SMS API Key">
                    <button type="button" class="btn btn-outline-secondary" onclick="togglePass('f2sKey')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Sender ID</label>
                    <input type="text" name="sms_fast2sms_sender_id" class="form-control" maxlength="6"
                           value="<?php echo e($settings['sms_fast2sms_sender_id'] ?? 'NDINTL'); ?>">
                    <small class="text-muted">6 chars, registered in DLT</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">DLT Entity ID</label>
                    <input type="text" name="sms_fast2sms_dlt_entity" class="form-control"
                           value="<?php echo e($settings['sms_fast2sms_dlt_entity'] ?? ''); ?>" placeholder="TRAI DLT Entity ID">
                </div>
            </div>
        </div>
    </div>

    <!-- MSG91 -->
    <div class="card mb-4 d-none" id="msg91Card">
        <div class="card-header fw-bold"><i class="fas fa-comment me-2 text-primary"></i>MSG91 Settings</div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Auth Key</label>
                <div class="input-group">
                    <input type="password" name="sms_msg91_auth_key" id="msg91Key" class="form-control"
                           value="<?php echo e($settings['sms_msg91_auth_key'] ?? ''); ?>">
                    <button type="button" class="btn btn-outline-secondary" onclick="togglePass('msg91Key')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Sender ID</label>
                    <input type="text" name="sms_msg91_sender_id" class="form-control" maxlength="6"
                           value="<?php echo e($settings['sms_msg91_sender_id'] ?? 'NDINTL'); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Template ID</label>
                    <input type="text" name="sms_msg91_template_id" class="form-control"
                           value="<?php echo e($settings['sms_msg91_template_id'] ?? ''); ?>">
                </div>
            </div>
        </div>
    </div>

    <!-- Triggers -->
    <div class="card mb-4">
        <div class="card-header fw-bold">Automatic SMS Triggers</div>
        <div class="card-body">
            <?php
            $triggers = [
                'sms_send_fee_reminder'    => 'Fee payment reminder',
                'sms_send_absence_alert'   => 'Student absence alert to parents',
                'sms_send_result_published'=> 'Exam results published',
                'sms_send_salary_credited' => 'Salary credited to teacher',
            ];
            foreach ($triggers as $key => $label):
            ?>
            <div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" name="<?php echo $key; ?>" value="1"
                       id="<?php echo $key; ?>" <?php echo ($settings[$key] ?? 0) ? 'checked' : ''; ?>>
                <label class="form-check-label" for="<?php echo $key; ?>"><?php echo $label; ?></label>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">
        <i class="fas fa-save me-2"></i>Save SMS Settings
    </button>
</form>
</div>

<!-- Test + Info -->
<div class="col-md-4">
    <div class="card mb-3">
        <div class="card-header fw-bold">Test SMS</div>
        <div class="card-body">
            <form method="POST" action="<?php echo url('settings/test-sms'); ?>">
                <?php echo CSRF::field(); ?>
                <div class="mb-3">
                    <label class="form-label">Mobile Number</label>
                    <input type="text" name="test_phone" class="form-control" placeholder="10-digit mobile" maxlength="10">
                </div>
                <button type="submit" class="btn btn-warning w-100">
                    <i class="fas fa-paper-plane me-2"></i>Send Test SMS
                </button>
            </form>
            <?php if (!($settings['sms_enabled'] ?? 0)): ?>
            <div class="alert alert-warning mt-3 mb-0 small">
                <i class="fas fa-exclamation-triangle me-1"></i>SMS is currently disabled. Enable it above first.
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header fw-bold">Setup Guide</div>
        <div class="card-body small">
            <p><strong>Fast2SMS (Recommended)</strong></p>
            <ol class="ps-3">
                <li>Register at <strong>fast2sms.com</strong></li>
                <li>Add money to wallet (min ₹100)</li>
                <li>Copy API key from Dashboard → Credentials</li>
                <li>Register DLT Entity + Sender ID if using promotional route</li>
                <li>Paste key above and enable SMS</li>
            </ol>
            <hr>
            <p><strong>Pricing</strong></p>
            <ul class="ps-3">
                <li>Fast2SMS: ~₹0.20/SMS</li>
                <li>MSG91: ~₹0.15-0.25/SMS</li>
            </ul>
        </div>
    </div>
</div>
</div>

<script>
function toggleGateway() {
    const g = document.getElementById('gatewaySelect').value;
    document.getElementById('fast2smsCard').classList.toggle('d-none', g !== 'fast2sms');
    document.getElementById('msg91Card').classList.toggle('d-none', g !== 'msg91');
}
function togglePass(id) {
    const el = document.getElementById(id);
    el.type = el.type === 'password' ? 'text' : 'password';
}
toggleGateway();
</script>
