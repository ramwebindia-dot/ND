<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-sliders-h me-2"></i>Fee Configuration</h4>
    <a href="<?php echo url('settings'); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Settings</a>
</div>

<!-- Settings Nav Tabs -->
<ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link" href="<?php echo url('settings/school'); ?>">School</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo url('settings/system'); ?>">System</a></li>
    <li class="nav-item"><a class="nav-link active" href="<?php echo url('settings/fee-config'); ?>">Fee Config</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo url('settings/email'); ?>">Email</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo url('settings/sms'); ?>">SMS</a></li>
</ul>

<div class="card" style="max-width:700px;">
    <div class="card-header fw-bold">Fee & Fine Configuration</div>
    <div class="card-body">
        <form method="POST" action="<?php echo url('settings/fee-config'); ?>">
            <?php echo CSRF::field(); ?>
            <h6 class="text-muted mb-3 border-bottom pb-2">Late Fee Rules</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Late Fee per Day (₹)</label>
                    <input type="number" name="late_fee_per_day" class="form-control" step="0.50" min="0"
                           value="<?php echo e($settings['late_fee_per_day'] ?? 2); ?>">
                    <div class="form-text">Amount charged per overdue day for fees</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Grace Period (days)</label>
                    <input type="number" name="late_fee_grace_days" class="form-control" min="0"
                           value="<?php echo e($settings['late_fee_grace_days'] ?? 0); ?>">
                    <div class="form-text">Days after due date before late fee applies</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Fee Due Day of Month</label>
                    <input type="number" name="fee_due_day_of_month" class="form-control" min="1" max="28"
                           value="<?php echo e($settings['fee_due_day_of_month'] ?? 10); ?>">
                    <div class="form-text">E.g. 10 = fees due by 10th every month</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Advance Fee Months</label>
                    <input type="number" name="advance_fee_months" class="form-control" min="0" max="12"
                           value="<?php echo e($settings['advance_fee_months'] ?? 3); ?>">
                    <div class="form-text">How many months ahead can be paid</div>
                </div>
            </div>
            <h6 class="text-muted mb-3 border-bottom pb-2">Library & Other Fines</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Library Fine per Day (₹)</label>
                    <input type="number" name="library_fine_per_day" class="form-control" step="0.50" min="0"
                           value="<?php echo e($settings['library_fine_per_day'] ?? 2); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Transport Late Fee per Day (₹)</label>
                    <input type="number" name="transport_late_fee_per_day" class="form-control" step="0.50" min="0"
                           value="<?php echo e($settings['transport_late_fee_per_day'] ?? 5); ?>">
                </div>
            </div>
            <h6 class="text-muted mb-3 border-bottom pb-2">Receipt Settings</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Receipt Number Prefix</label>
                    <input type="text" name="fee_receipt_prefix" class="form-control" maxlength="10"
                           value="<?php echo e($settings['fee_receipt_prefix'] ?? 'RCP'); ?>"
                           placeholder="e.g. RCP, RCPT, INV">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Allow Partial Payment</label>
                    <select name="allow_partial_payment" class="form-select">
                        <option value="1" <?php echo ($settings['allow_partial_payment']??'1')=='1'?'selected':''; ?>>Yes</option>
                        <option value="0" <?php echo ($settings['allow_partial_payment']??'1')=='0'?'selected':''; ?>>No (full payment required)</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Fee Configuration</button>
        </form>
    </div>
</div>
