<div class="page-header">
    <h4><i class="fas fa-user-circle"></i> My Profile</h4>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-body text-center">
                <?php if (!empty($user['photo'])): ?>
                <img src="<?php echo asset($user['photo']); ?>" alt="Profile" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
                <?php else: ?>
                <div class="rounded-circle bg-light d-inline-flex align-items-center justify-content-center mb-3" style="width: 120px; height: 120px;">
                    <i class="fas fa-user fa-3x text-muted"></i>
                </div>
                <?php endif; ?>
                <h5><?php echo e($user['full_name'] ?? ''); ?></h5>
                <span class="badge bg-primary"><?php echo e($user['role_name'] ?? $user['role'] ?? ''); ?></span>
                <p class="text-muted mb-0"><?php echo e($user['email'] ?? ''); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-edit me-2"></i>Update Profile</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('settings/profile'); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?php echo e($user['full_name'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e($user['email'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Mobile</label>
                            <input type="text" name="mobile" class="form-control" value="<?php echo e($user['mobile'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Profile Photo</label>
                            <input type="file" name="photo" class="form-control" accept="image/*">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save"></i> Update Profile</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><i class="fas fa-lock me-2"></i>Change Password</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('settings/changePassword'); ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required minlength="6">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" required minlength="6">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-key"></i> Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
