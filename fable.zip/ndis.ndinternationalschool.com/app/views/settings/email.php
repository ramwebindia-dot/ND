<div class="page-header d-flex justify-content-between align-items-center">
    <h4><i class="fas fa-envelope-open-text me-2"></i>Email / SMTP Settings</h4>
</div>

<div class="row">
    <div class="col-md-7">
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-server me-2"></i>SMTP Configuration</div>
            <div class="card-body">
                <form method="POST" action="<?php echo url('settings/email'); ?>">
                    <?php echo CSRF::field(); ?>

                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="smtp_enabled" id="smtpEnabled"
                                   <?php echo ($settings['smtp_enabled'] ?? '0') === '1' ? 'checked' : ''; ?>>
                            <label class="form-check-label fw-bold" for="smtpEnabled">Enable SMTP Email</label>
                        </div>
                        <small class="text-muted">When disabled, emails are only logged (not sent).</small>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">SMTP Host <span class="text-danger">*</span></label>
                            <input type="text" name="smtp_host" class="form-control"
                                   value="<?php echo e($settings['smtp_host'] ?? ''); ?>"
                                   placeholder="e.g. smtp.gmail.com">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Port</label>
                            <input type="number" name="smtp_port" class="form-control"
                                   value="<?php echo e($settings['smtp_port'] ?? '587'); ?>"
                                   placeholder="587">
                        </div>
                    </div>

                    <div class="mb-3 mt-3">
                        <label class="form-label">Encryption</label>
                        <select name="smtp_encryption" class="form-select">
                            <option value="tls" <?php echo ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : ''; ?>>TLS (Recommended, Port 587)</option>
                            <option value="ssl" <?php echo ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL (Port 465)</option>
                            <option value="none" <?php echo ($settings['smtp_encryption'] ?? '') === 'none' ? 'selected' : ''; ?>>None (Port 25)</option>
                        </select>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">SMTP Username</label>
                            <input type="text" name="smtp_username" class="form-control"
                                   value="<?php echo e($settings['smtp_username'] ?? ''); ?>"
                                   placeholder="your@email.com" autocomplete="off">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">SMTP Password</label>
                            <div class="input-group">
                                <input type="password" name="smtp_password" id="smtpPass" class="form-control"
                                       value="<?php echo e($settings['smtp_password'] ?? ''); ?>"
                                       autocomplete="new-password">
                                <button type="button" class="btn btn-outline-secondary"
                                        onclick="var f=document.getElementById('smtpPass');f.type=f.type==='password'?'text':'password';">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <hr class="my-3">
                    <h6 class="text-muted mb-3">Sender Details</h6>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">From Email</label>
                            <input type="email" name="smtp_from_email" class="form-control"
                                   value="<?php echo e($settings['smtp_from_email'] ?? ''); ?>"
                                   placeholder="noreply@school.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">From Name</label>
                            <input type="text" name="smtp_from_name" class="form-control"
                                   value="<?php echo e($settings['smtp_from_name'] ?? APP_NAME); ?>">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Save SMTP Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-5">
        <div class="card mb-3">
            <div class="card-header"><i class="fas fa-paper-plane me-2"></i>Test Email</div>
            <div class="card-body">
                <p class="text-muted small">Send a test email to verify your SMTP configuration is working.</p>
                <form method="POST" action="<?php echo url('settings/test-email'); ?>">
                    <?php echo CSRF::field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Send test to</label>
                        <input type="email" name="test_email" class="form-control"
                               placeholder="recipient@example.com" required
                               value="<?php echo e(Session::get('user_email', '')); ?>">
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-vial me-2"></i>Send Test Email
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><i class="fas fa-lightbulb me-2"></i>Quick Setup Guide</div>
            <div class="card-body small text-muted">
                <p class="fw-bold text-dark">Gmail:</p>
                <ul class="mb-3">
                    <li>Host: <code>smtp.gmail.com</code></li>
                    <li>Port: <code>587</code>, Encryption: <code>TLS</code></li>
                    <li>Use an <a href="https://myaccount.google.com/apppasswords" target="_blank">App Password</a> (not your main Gmail password)</li>
                </ul>
                <p class="fw-bold text-dark">cPanel / Hosting SMTP:</p>
                <ul class="mb-0">
                    <li>Host: <code>mail.yourdomain.com</code></li>
                    <li>Port: <code>465</code>, Encryption: <code>SSL</code></li>
                    <li>Username: full email address</li>
                </ul>
            </div>
        </div>
    </div>
</div>
