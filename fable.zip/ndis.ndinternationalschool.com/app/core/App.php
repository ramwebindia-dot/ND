<?php
/**
 * Application Bootstrap Class
 * Initializes the MVC framework and routes requests
 */
class App
{
    protected Router $router;
    protected string $controller = 'Auth';
    protected string $method = 'index';
    protected array $params = [];

    public function __construct()
    {
        Session::start();
        $this->router = new Router();
    }

    public function run(): void
    {
        $url = $this->parseUrl();
        $this->route($url);
    }

    protected function parseUrl(): array
    {
        if (isset($_GET['url'])) {
            return explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));
        }
        return [];
    }

    protected function route(array $url): void
    {
        // Redirect to login if not authenticated (except for auth routes)
        $publicRoutes = ['auth', 'api'];
        $isPublicRoute = !empty($url) && in_array(strtolower($url[0]), $publicRoutes);

        if (!$isPublicRoute && !Session::isLoggedIn()) {
            redirect('auth/login');
            return;
        }

        // Ensure an active academic session is always available. Previously this was
        // only ever set when a user manually used the session switcher, so any fresh
        // login left Session::get('active_session_id') as null, which every controller
        // silently treated as session_id = 0 -- a value that never matches real data.
        // That made session-scoped stats (e.g. Dashboard "Today's Attendance") look
        // permanently stuck, since the query matched zero rows.
        if (!$isPublicRoute && Session::isLoggedIn() && !Session::get('active_session_id')) {
            $sessionModel = new AcademicSession();
            $activeSessionId = $sessionModel->getActiveSessionId();
            if ($activeSessionId) {
                Session::set('active_session_id', $activeSessionId);
            }
        }

        // Set controller. Hyphenated URL segments map to PascalCase class names
        // (e.g. "online-class" -> "OnlineClass", "question-bank" -> "QuestionBank"),
        // mirroring how method names are derived below.
        if (!empty($url[0])) {
            $base = str_replace('-', '', ucwords(strtolower($url[0]), '-'));
            $controllerName = $base . 'Controller';
            if (file_exists(APP_ROOT . '/app/controllers/' . $controllerName . '.php')) {
                $this->controller = $base;
            } else {
                http_response_code(404);
                $this->show404();
                return;
            }
        } elseif (Session::isLoggedIn()) {
            $role = Session::get('role_name');
            switch ($role) {
                case 'Student':
                    $this->controller = 'StudentPortal';
                    break;
                case 'Parent':
                    $this->controller = 'Parent';
                    break;
                default:
                    $this->controller = 'Dashboard';
                    break;
            }
        } else {
            $this->controller = 'Auth';
        }

        // Instantiate controller
        $controllerClass = $this->controller . 'Controller';
        if (!class_exists($controllerClass)) {
            http_response_code(404);
            $this->show404();
            return;
        }
        $controllerInstance = new $controllerClass();

        // Set method
        if (!empty($url[1])) {
            $methodName = lcfirst(str_replace('-', '', ucwords($url[1], '-')));
            if (method_exists($controllerInstance, $methodName)) {
                $this->method = $methodName;
            } else {
                http_response_code(404);
                $this->show404();
                return;
            }
        }

        // Set parameters
        $this->params = array_slice($url, 2);

        // Check permission
        if (!$isPublicRoute && !$controllerInstance->checkPermission($this->method)) {
            Flash::error('You do not have permission to access this page.');
            redirect('dashboard');
            return;
        }

        // Call controller method
        call_user_func_array([$controllerInstance, $this->method], $this->params);
    }

    protected function show404(): void
    {
        if (Session::isLoggedIn()) {
            View::render('errors/404');
        } else {
            redirect('auth/login');
        }
    }
}
