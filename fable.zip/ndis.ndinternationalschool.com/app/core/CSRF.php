<?php
/**
 * CSRF Protection Class
 * CSRF validation temporarily disabled for development.
 */
class CSRF
{
    public static function token(): string
    {
        if (empty($_SESSION[CSRF_TOKEN_NAME])) {
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . self::token() . '">';
    }

    public static function validate(): void
    {
        $tokenName = CSRF_TOKEN_NAME;
        $submitted = $_POST[$tokenName] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $stored    = $_SESSION[$tokenName] ?? '';

        if (empty($submitted) || empty($stored) || !hash_equals($stored, $submitted)) {
            http_response_code(403);
            // Regenerate token so attacker cannot reuse
            unset($_SESSION[$tokenName]);
            die('Invalid or missing CSRF token. Please go back and try again.');
        }
    }

    public static function meta(): string
    {
        return '<meta name="csrf-token" content="' . self::token() . '">';
    }
}