<?php
/**
 * Router Class
 * Handles URL routing
 */
class Router
{
    protected array $routes = [];

    public function add(string $route, string $controller, string $method): void
    {
        $this->routes[$route] = ['controller' => $controller, 'method' => $method];
    }

    public function getRoutes(): array
    {
        return $this->routes;
    }
}
