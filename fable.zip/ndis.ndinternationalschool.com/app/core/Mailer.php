<?php
/**
 * Simple SMTP Mailer
 * Uses PHP's built-in mail() or SMTP via socket (no external library needed)
 * Settings are pulled from the `settings` table via the Settings model.
 */
class Mailer
{
    private array $config;

    public function __construct()
    {
        $settingsModel = new Settings();
        $this->config = [
            'enabled'    => (bool) $settingsModel->get('smtp_enabled'),
            'host'       => $settingsModel->get('smtp_host') ?? '',
            'port'       => (int) ($settingsModel->get('smtp_port') ?? 587),
            'username'   => $settingsModel->get('smtp_username') ?? '',
            'password'   => $settingsModel->get('smtp_password') ?? '',
            'from_email' => $settingsModel->get('smtp_from_email') ?? '',
            'from_name'  => $settingsModel->get('smtp_from_name') ?? APP_NAME,
            'encryption' => $settingsModel->get('smtp_encryption') ?? 'tls',
        ];
    }

    /**
     * Send an email. Returns true on success, false on failure.
     */
    public function send(string $toEmail, string $toName, string $subject, string $htmlBody): bool
    {
        if (!$this->config['enabled']) {
            error_log("Mailer: SMTP not enabled. Would send to $toEmail: $subject");
            return false;
        }

        if (empty($this->config['host']) || empty($this->config['username'])) {
            error_log("Mailer: SMTP not configured.");
            return false;
        }

        try {
            $socket = $this->openSocket();
            if (!$socket) return false;

            $boundary = '----=_Part_' . md5(uniqid());
            $fromEmail = $this->config['from_email'];
            $fromName  = $this->config['from_name'];

            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <$fromEmail>\r\n";
            $headers .= "To: =?UTF-8?B?" . base64_encode($toName) . "?= <$toEmail>\r\n";
            $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
            $headers .= "X-Mailer: ND-School-ERP\r\n";

            // Use SMTP conversation
            $this->smtpSend($socket, $toEmail, $fromEmail, $headers, $htmlBody);
            fclose($socket);
            return true;
        } catch (Exception $e) {
            error_log("Mailer error: " . $e->getMessage());
            return false;
        }
    }

    private function openSocket()
    {
        $host = $this->config['host'];
        $port = $this->config['port'];
        $enc  = $this->config['encryption'];

        $prefix = ($enc === 'ssl') ? 'ssl://' : '';
        $errno = $errstr = null;
        $socket = @fsockopen($prefix . $host, $port, $errno, $errstr, 10);

        if (!$socket) {
            error_log("Mailer: Cannot connect to SMTP $host:$port — $errstr");
            return false;
        }

        $this->smtpRead($socket); // greeting

        if ($enc === 'tls') {
            $this->smtpCmd($socket, "EHLO " . gethostname());
            $this->smtpCmd($socket, "STARTTLS");
            stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        }

        $this->smtpCmd($socket, "EHLO " . gethostname());
        $this->smtpCmd($socket, "AUTH LOGIN");
        $this->smtpCmd($socket, base64_encode($this->config['username']));
        $this->smtpCmd($socket, base64_encode($this->config['password']));

        return $socket;
    }

    private function smtpSend($socket, string $to, string $from, string $headers, string $body): void
    {
        $this->smtpCmd($socket, "MAIL FROM:<$from>");
        $this->smtpCmd($socket, "RCPT TO:<$to>");
        $this->smtpCmd($socket, "DATA");
        fputs($socket, $headers . "\r\n" . $body . "\r\n.\r\n");
        $this->smtpRead($socket);
        $this->smtpCmd($socket, "QUIT");
    }

    private function smtpCmd($socket, string $cmd): string
    {
        fputs($socket, $cmd . "\r\n");
        return $this->smtpRead($socket);
    }

    private function smtpRead($socket): string
    {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        return $response;
    }

    /**
     * Build a clean HTML email template
     */
    public static function buildTemplate(string $title, string $bodyHtml): string
    {
        $appName = APP_NAME;
        $appUrl  = APP_URL;
        $year    = date('Y');

        return <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<style>
  body { margin:0; padding:0; background:#f4f4f4; font-family:Arial,sans-serif; }
  .wrap { max-width:600px; margin:30px auto; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.1); }
  .header { background:#1565C0; padding:24px 32px; text-align:center; }
  .header h2 { color:#fff; margin:0; font-size:20px; }
  .body { padding:32px; color:#333; font-size:15px; line-height:1.6; }
  .body h3 { color:#1565C0; margin-top:0; }
  .btn { display:inline-block; padding:12px 28px; background:#1565C0; color:#fff !important; text-decoration:none; border-radius:6px; font-weight:bold; margin:16px 0; }
  .footer { background:#f4f4f4; padding:16px 32px; text-align:center; font-size:12px; color:#888; }
  .divider { border:none; border-top:1px solid #eee; margin:20px 0; }
</style>
</head>
<body>
<div class="wrap">
  <div class="header"><h2>{$appName}</h2></div>
  <div class="body">
    <h3>{$title}</h3>
    {$bodyHtml}
  </div>
  <div class="footer">&copy; {$year} {$appName} &mdash; This is an automated email, please do not reply.</div>
</div>
</body>
</html>
HTML;
    }
}
