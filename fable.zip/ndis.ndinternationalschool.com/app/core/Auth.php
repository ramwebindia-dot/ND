<?php
/**
 * Authentication Class
 * Handles user login, logout, and password management
 */
class Auth
{
    public static function attempt(string $email, string $password): array
    {
        $userModel = new User();
        $user = $userModel->findByEmail($email);

        if (!$user) {
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }

        if (!$user['is_active']) {
            return ['success' => false, 'message' => 'Your account has been deactivated.'];
        }

        if (!password_verify($password, $user['password'])) {
            // Log failed attempt
            Audit::log('auth', 'login_failed', null, ['email' => $email]);
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }

        // Login successful
        Session::loginUser($user);

        // Log successful login
        Audit::log('auth', 'login_success', $user['id']);

        return ['success' => true, 'message' => 'Login successful.'];
    }

    public static function logout(): void
    {
        if (Session::isLoggedIn()) {
            Audit::log('auth', 'logout', Session::get('user_id'));
        }
        Session::logout();
    }

    public static function changePassword(int $userId, string $currentPassword, string $newPassword): array
    {
        $userModel = new User();
        $user = $userModel->findById($userId);

        if (!$user || !password_verify($currentPassword, $user['password'])) {
            return ['success' => false, 'message' => 'Current password is incorrect.'];
        }

        $hashed = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        $userModel->update($userId, ['password' => $hashed]);

        Audit::log('auth', 'password_change', $userId);

        return ['success' => true, 'message' => 'Password changed successfully.'];
    }

    public static function resetPassword(int $userId, string $newPassword): bool
    {
        $userModel = new User();
        $hashed = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        $result = $userModel->update($userId, ['password' => $hashed]);

        if ($result) {
            Audit::log('auth', 'password_reset', $userId);
        }

        return $result;
    }

    public static function user(): ?array
    {
        if (!Session::isLoggedIn()) return null;
        return [
            'id' => Session::get('user_id'),
            'name' => Session::get('user_name'),
            'email' => Session::get('user_email'),
            'role_id' => Session::get('role_id'),
            'role_name' => Session::get('role_name'),
        ];
    }

    public static function id(): ?int
    {
        return Session::get('user_id');
    }

    public static function role(): ?string
    {
        return Session::get('role_name');
    }

    public static function hasRole(string $role): bool
    {
        return Session::get('role_name') === $role;
    }

    public static function hasAnyRole(array $roles): bool
    {
        return in_array(Session::get('role_name'), $roles);
    }
}
