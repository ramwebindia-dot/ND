<?php
/**
 * Input Validator Class
 */
class Validator
{
    protected array $errors = [];
    protected array $data = [];

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function validate(): bool
    {
        return empty($this->errors);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getFirstError(): string
    {
        return !empty($this->errors) ? reset($this->errors) : '';
    }

    public function required(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!isset($this->data[$field]) || trim((string)$this->data[$field]) === '') {
            $this->errors[$field] = "$label is required.";
        }
        return $this;
    }

    public function email(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "$label must be a valid email address.";
        }
        return $this;
    }

    public function minLength(string $field, int $length, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && strlen((string)$this->data[$field]) < $length) {
            $this->errors[$field] = "$label must be at least $length characters.";
        }
        return $this;
    }

    public function maxLength(string $field, int $length, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && strlen((string)$this->data[$field]) > $length) {
            $this->errors[$field] = "$label must not exceed $length characters.";
        }
        return $this;
    }

    public function numeric(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && !is_numeric($this->data[$field])) {
            $this->errors[$field] = "$label must be a number.";
        }
        return $this;
    }

    public function min(string $field, float $min, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && (float)$this->data[$field] < $min) {
            $this->errors[$field] = "$label must be at least $min.";
        }
        return $this;
    }

    public function max(string $field, float $max, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && (float)$this->data[$field] > $max) {
            $this->errors[$field] = "$label must not exceed $max.";
        }
        return $this;
    }

    public function date(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field])) {
            $d = DateTime::createFromFormat('Y-m-d', $this->data[$field]);
            if (!$d || $d->format('Y-m-d') !== $this->data[$field]) {
                $this->errors[$field] = "$label must be a valid date.";
            }
        }
        return $this;
    }

    public function inList(string $field, array $list, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && !in_array($this->data[$field], $list)) {
            $this->errors[$field] = "$label must be one of: " . implode(', ', $list);
        }
        return $this;
    }

    public function unique(string $field, string $table, string $column = '', int $excludeId = 0): self
    {
        $column = $column ?: $field;
        $value = $this->data[$field] ?? '';
        if (!empty($value)) {
            $model = new Model();
            $sql = "SELECT COUNT(*) as total FROM $table WHERE $column = :value";
            $params = ['value' => $value];
            if ($excludeId > 0) {
                $sql .= " AND id != :exclude_id";
                $params['exclude_id'] = $excludeId;
            }
            $result = $model->rawOne($sql, $params);
            if ($result && $result['total'] > 0) {
                $label = ucfirst(str_replace('_', ' ', $field));
                $this->errors[$field] = "$label already exists.";
            }
        }
        return $this;
    }

    public function phone(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field]) && !preg_match('/^[0-9+\-\s()]{7,15}$/', $this->data[$field])) {
            $this->errors[$field] = "$label must be a valid phone number.";
        }
        return $this;
    }

    public static function sanitize(string $input): string
    {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    public static function sanitizeArray(array $data): array
    {
        unset($data['csrf_token']);
        return array_map(function ($value) {
            return is_string($value) ? self::sanitize($value) : $value;
        }, $data);
    }
}
