<?php
/**
 * SMS Gateway Integration
 * Supports: Fast2SMS (primary), MSG91 (fallback)
 */
class SMS
{
    private static ?array $config = null;

    private static function config(): array
    {
        if (self::$config !== null) return self::$config;

        $settingsModel = new Settings();
        self::$config = [
            'enabled'   => (bool)$settingsModel->get('sms_enabled', 0),
            'gateway'   => $settingsModel->get('sms_gateway', 'fast2sms'),
            // Fast2SMS
            'f2s_api_key'    => $settingsModel->get('sms_fast2sms_api_key', ''),
            'f2s_sender_id'  => $settingsModel->get('sms_fast2sms_sender_id', 'NDINTL'),
            'f2s_dlt_entity' => $settingsModel->get('sms_fast2sms_dlt_entity', ''),
            // MSG91
            'msg91_auth_key'  => $settingsModel->get('sms_msg91_auth_key', ''),
            'msg91_sender_id' => $settingsModel->get('sms_msg91_sender_id', 'NDINTL'),
            'msg91_template'  => $settingsModel->get('sms_msg91_template_id', ''),
        ];
        return self::$config;
    }

    /**
     * Send SMS to one or more phone numbers.
     * @param string|array $phones  Single phone or array of phones (10-digit Indian mobile)
     * @param string $message       Message text (max 160 chars for 1 unit)
     * @return bool
     */
    public static function send($phones, string $message): bool
    {
        $cfg = self::config();
        if (!$cfg['enabled']) {
            error_log('[SMS] Disabled. Would send to: ' . implode(',', (array)$phones) . ' — ' . $message);
            return false;
        }

        $phones = array_filter(array_map('trim', (array)$phones));
        $phones = array_filter($phones, fn($p) => preg_match('/^[6-9]\d{9}$/', $p));
        if (empty($phones)) return false;

        return match($cfg['gateway']) {
            'msg91'     => self::sendMSG91($phones, $message, $cfg),
            default     => self::sendFast2SMS($phones, $message, $cfg),
        };
    }

    // ── Fast2SMS ──────────────────────────────────────────────────

    private static function sendFast2SMS(array $phones, string $message, array $cfg): bool
    {
        if (empty($cfg['f2s_api_key'])) {
            error_log('[SMS] Fast2SMS API key not set.');
            return false;
        }

        $numbers = implode(',', $phones);
        $payload = json_encode([
            'route'     => 'q',           // Quick SMS (non-DLT transactional)
            'message'   => $message,
            'numbers'   => $numbers,
            'flash'     => 0,
        ]);

        $ch = curl_init('https://www.fast2sms.com/dev/bulkV2');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'authorization: ' . $cfg['f2s_api_key'],
                'Content-Type: application/json',
                'Cache-Control: no-cache',
            ],
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            error_log('[SMS] Fast2SMS HTTP error: ' . $httpCode);
            return false;
        }

        $result = json_decode($response, true);
        if (isset($result['return']) && $result['return'] === true) {
            self::logSent($phones, $message, 'fast2sms', 'success');
            return true;
        }

        error_log('[SMS] Fast2SMS failed: ' . $response);
        self::logSent($phones, $message, 'fast2sms', 'failed', $response);
        return false;
    }

    // ── MSG91 ──────────────────────────────────────────────────────

    private static function sendMSG91(array $phones, string $message, array $cfg): bool
    {
        if (empty($cfg['msg91_auth_key'])) {
            error_log('[SMS] MSG91 auth key not set.');
            return false;
        }

        $receipients = array_map(fn($p) => ['mobiles' => '91' . $p], $phones);
        $payload = json_encode([
            'template_id' => $cfg['msg91_template'],
            'sender'      => $cfg['msg91_sender_id'],
            'short_url'   => '0',
            'mobiles'     => implode(',', array_map(fn($p) => '91'.$p, $phones)),
            'message'     => $message,
        ]);

        $ch = curl_init('https://api.msg91.com/api/v5/flow/');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'authkey: ' . $cfg['msg91_auth_key'],
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT        => 10,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            self::logSent($phones, $message, 'msg91', 'success');
            return true;
        }
        error_log('[SMS] MSG91 failed: ' . $response);
        self::logSent($phones, $message, 'msg91', 'failed', $response);
        return false;
    }

    // ── Helpers ───────────────────────────────────────────────────

    private static function logSent(array $phones, string $message, string $gateway, string $status, string $response = ''): void
    {
        try {
            $model = new Model(); $model->table = 'sms_logs';
            $model->create([
                'phones'   => implode(',', $phones),
                'message'  => $message,
                'gateway'  => $gateway,
                'status'   => $status,
                'response' => substr($response, 0, 500),
                'sent_at'  => date('Y-m-d H:i:s'),
            ]);
        } catch (Throwable) {
            // SMS log table may not exist yet — ignore
        }
    }

    // ── Pre-built school message templates ────────────────────────

    public static function feeReminder(string $phone, string $studentName, float $amount, string $dueDate): bool
    {
        $msg = "Dear Parent, fee of Rs.{$amount} for {$studentName} is due on {$dueDate}. Please pay to avoid late charges. - " . APP_NAME;
        return self::send($phone, $msg);
    }

    public static function feeReceived(string $phone, string $studentName, float $amount, string $receipt): bool
    {
        $msg = "Fee Rs.{$amount} received for {$studentName}. Receipt No: {$receipt}. Thank you. - " . APP_NAME;
        return self::send($phone, $msg);
    }

    public static function absenceAlert(string $phone, string $studentName, string $date): bool
    {
        $msg = "Dear Parent, {$studentName} was marked ABSENT on {$date}. Please contact school if needed. - " . APP_NAME;
        return self::send($phone, $msg);
    }

    public static function examReminder(string $phone, string $studentName, string $examName, string $startDate): bool
    {
        $msg = "Exam Alert: {$examName} starts on {$startDate} for {$studentName}. Best of luck! - " . APP_NAME;
        return self::send($phone, $msg);
    }

    public static function resultPublished(string $phone, string $studentName, string $examName): bool
    {
        $msg = "Results of {$examName} are now available for {$studentName}. Login to parent portal to view. - " . APP_NAME;
        return self::send($phone, $msg);
    }

    public static function salaryCredited(string $phone, string $teacherName, float $amount, string $month): bool
    {
        $msg = "Dear {$teacherName}, your salary of Rs.{$amount} for {$month} has been credited. - " . APP_NAME;
        return self::send($phone, $msg);
    }
}
