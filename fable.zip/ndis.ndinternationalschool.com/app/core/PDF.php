<?php
/**
 * PDF Generation Helper
 *
 * Strategy:
 *   1. If mPDF is installed (vendor/autoload.php exists), uses mPDF.
 *   2. Otherwise, renders an HTML page with print-optimised CSS.
 *      The page auto-triggers window.print() so the user can Save as PDF.
 *
 * Install mPDF (recommended):
 *   composer require mpdf/mpdf
 */
class PDF
{
    private static bool $mpdfAvailable;

    private static function hasMpdf(): bool
    {
        if (!isset(self::$mpdfAvailable)) {
            self::$mpdfAvailable = class_exists('\Mpdf\Mpdf')
                || file_exists(APP_ROOT . '/vendor/autoload.php');
            if (!isset(self::$mpdfAvailable) && file_exists(APP_ROOT . '/vendor/autoload.php')) {
                require_once APP_ROOT . '/vendor/autoload.php';
                self::$mpdfAvailable = class_exists('\Mpdf\Mpdf');
            }
        }
        return self::$mpdfAvailable ?? false;
    }

    /**
     * Output an HTML string as a PDF download.
     * @param string $html     Full HTML content (without <html>/<body> wrapper needed — we add it)
     * @param string $filename Download filename (e.g. "fee-receipt-001.pdf")
     * @param string $title    Page title
     */
    public static function download(string $html, string $filename, string $title = ''): void
    {
        if (self::hasMpdf()) {
            self::downloadMpdf($html, $filename, $title);
        } else {
            self::downloadBrowserPrint($html, $filename, $title);
        }
    }

    // ── mPDF path ──────────────────────────────────────────────────

    private static function downloadMpdf(string $html, string $filename, string $title): void
    {
        $autoload = APP_ROOT . '/vendor/autoload.php';
        if (file_exists($autoload)) require_once $autoload;

        $mpdf = new \Mpdf\Mpdf([
            'margin_left'   => 15,
            'margin_right'  => 15,
            'margin_top'    => 15,
            'margin_bottom' => 15,
            'tempDir'       => sys_get_temp_dir(),
        ]);
        if ($title) $mpdf->SetTitle($title);
        $mpdf->WriteHTML(self::wrapHtml($html, $title));
        $mpdf->Output($filename, 'D');
        exit;
    }

    // ── Browser-print fallback ─────────────────────────────────────

    private static function downloadBrowserPrint(string $html, string $filename, string $title): void
    {
        // Output a self-printing HTML page — user saves as PDF from browser
        echo '<!DOCTYPE html><html lang="en"><head>';
        echo '<meta charset="UTF-8">';
        echo '<title>' . htmlspecialchars($title ?: $filename) . '</title>';
        echo self::printCSS();
        echo '</head><body onload="window.print()">';
        echo $html;
        echo '<script>
            window.onafterprint = function(){ window.close(); };
        </script>';
        echo '</body></html>';
        exit;
    }

    private static function wrapHtml(string $html, string $title): string
    {
        return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>'
            . self::printCSS() . '</head><body>' . $html . '</body></html>';
    }

    private static function printCSS(): string
    {
        return '<style>
            * { box-sizing: border-box; }
            body { font-family: Arial, sans-serif; font-size: 12px; color: #000; background: #fff; margin: 0; padding: 0; }
            table { border-collapse: collapse; width: 100%; }
            th, td { padding: 5px 8px; }
            .no-print { display: none !important; }
            @page { margin: 1cm; }
            @media print {
                body { font-size: 11px; }
                .page-break { page-break-after: always; }
            }
        </style>';
    }

    // ── Document builders ──────────────────────────────────────────

    /**
     * Build HTML for a fee receipt.
     */
    public static function feeReceiptHtml(array $receipt, array $items, array $settings): string
    {
        $schoolName = $settings['app_name'] ?? APP_NAME;
        $address    = $settings['address'] ?? '';
        $phone      = $settings['school_phone'] ?? '';
        $logo       = $settings['school_logo'] ?? '';

        ob_start(); ?>
<div style="border: 2px solid #333; padding: 20px; max-width: 700px; margin: auto;">
    <!-- Header -->
    <table style="margin-bottom:15px;">
        <tr>
            <?php if ($logo): ?>
            <td width="80"><img src="<?php echo APP_URL . '/' . ltrim($logo, '/'); ?>" height="60" alt="Logo"></td>
            <?php endif; ?>
            <td style="text-align:center;">
                <div style="font-size:18px;font-weight:bold;"><?php echo htmlspecialchars($schoolName); ?></div>
                <?php if ($address): ?><div style="font-size:11px;"><?php echo htmlspecialchars($address); ?></div><?php endif; ?>
                <?php if ($phone): ?><div style="font-size:11px;">Phone: <?php echo htmlspecialchars($phone); ?></div><?php endif; ?>
                <div style="font-size:14px;font-weight:bold;margin-top:6px;text-decoration:underline;">FEE RECEIPT</div>
            </td>
            <td width="120" style="text-align:right;vertical-align:top;">
                <div><strong>Receipt #</strong></div>
                <div><?php echo htmlspecialchars($receipt['receipt_number'] ?? '—'); ?></div>
                <div style="margin-top:4px;"><strong>Date</strong></div>
                <div><?php echo htmlspecialchars($receipt['payment_date'] ?? date('d-m-Y')); ?></div>
            </td>
        </tr>
    </table>

    <!-- Student Info -->
    <table style="border: 1px solid #ccc; margin-bottom:12px;">
        <tr>
            <td style="border:1px solid #ccc; padding:5px 10px;" width="30%"><strong>Student Name</strong></td>
            <td style="border:1px solid #ccc; padding:5px 10px;" width="70%"><?php echo htmlspecialchars($receipt['student_name'] ?? ''); ?></td>
        </tr>
        <tr>
            <td style="border:1px solid #ccc; padding:5px 10px;"><strong>Admission No.</strong></td>
            <td style="border:1px solid #ccc; padding:5px 10px;"><?php echo htmlspecialchars($receipt['admission_number'] ?? ''); ?></td>
        </tr>
        <tr>
            <td style="border:1px solid #ccc; padding:5px 10px;"><strong>Class / Section</strong></td>
            <td style="border:1px solid #ccc; padding:5px 10px;"><?php echo htmlspecialchars(($receipt['class_name'] ?? '') . ' ' . ($receipt['section_name'] ?? '')); ?></td>
        </tr>
        <tr>
            <td style="border:1px solid #ccc; padding:5px 10px;"><strong>Payment Mode</strong></td>
            <td style="border:1px solid #ccc; padding:5px 10px;"><?php echo htmlspecialchars($receipt['payment_mode'] ?? 'Cash'); ?></td>
        </tr>
    </table>

    <!-- Fee Items -->
    <table style="border:1px solid #ccc;">
        <thead>
            <tr style="background:#f0f0f0;">
                <th style="border:1px solid #ccc; text-align:left;">#</th>
                <th style="border:1px solid #ccc; text-align:left;">Fee Head</th>
                <th style="border:1px solid #ccc; text-align:right;">Amount</th>
            </tr>
        </thead>
        <tbody>
        <?php $total = 0; foreach ($items as $i => $item): $total += $item['amount']; ?>
            <tr>
                <td style="border:1px solid #ccc;"><?php echo $i + 1; ?></td>
                <td style="border:1px solid #ccc;"><?php echo htmlspecialchars($item['fee_head'] ?? $item['description'] ?? ''); ?></td>
                <td style="border:1px solid #ccc; text-align:right;">₹<?php echo number_format($item['amount'], 2); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr style="font-weight:bold;">
                <td colspan="2" style="border:1px solid #ccc; text-align:right; padding:6px 8px;">Total Paid</td>
                <td style="border:1px solid #ccc; text-align:right; padding:6px 8px;">₹<?php echo number_format($total, 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <?php if (!empty($receipt['remarks'])): ?>
    <p style="margin-top:8px;"><em>Remarks: <?php echo htmlspecialchars($receipt['remarks']); ?></em></p>
    <?php endif; ?>

    <div style="margin-top:30px; text-align:right;">
        <div style="border-top: 1px solid #000; width:180px; display:inline-block; padding-top:4px;">
            Authorized Signature
        </div>
    </div>

    <p style="margin-top:20px; font-size:10px; text-align:center; color:#555;">
        This is a computer-generated receipt. No separate signature required.
    </p>
</div>
        <?php return ob_get_clean();
    }

    /**
     * Build HTML for a salary slip PDF.
     */
    public static function salarySlipHtml(array $slip, array $settings): string
    {
        $schoolName = $settings['app_name'] ?? APP_NAME;
        $monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];

        ob_start(); ?>
<div style="border:2px solid #333; padding:20px; max-width:700px; margin:auto;">
    <div style="text-align:center; border-bottom:2px solid #333; padding-bottom:10px; margin-bottom:15px;">
        <div style="font-size:18px; font-weight:bold;"><?php echo htmlspecialchars($schoolName); ?></div>
        <div style="font-size:14px; font-weight:bold; margin-top:4px;">SALARY SLIP</div>
        <div><?php echo $monthNames[$slip['month']] . ' ' . $slip['year']; ?></div>
    </div>

    <!-- Employee Info -->
    <table style="border-collapse:collapse; width:100%; margin-bottom:15px;">
        <tr>
            <td width="50%" style="vertical-align:top;">
                <table style="width:100%;">
                    <tr><td style="color:#555; width:40%;">Name</td><td><strong><?php echo htmlspecialchars($slip['teacher_name'] ?? ''); ?></strong></td></tr>
                    <tr><td style="color:#555;">Emp ID</td><td><?php echo htmlspecialchars($slip['employee_id'] ?? ''); ?></td></tr>
                    <tr><td style="color:#555;">Designation</td><td><?php echo htmlspecialchars($slip['designation'] ?? '—'); ?></td></tr>
                    <tr><td style="color:#555;">Department</td><td><?php echo htmlspecialchars($slip['department_name'] ?? '—'); ?></td></tr>
                </table>
            </td>
            <td width="50%" style="vertical-align:top;">
                <table style="width:100%;">
                    <tr><td style="color:#555; width:45%;">Pay Period</td><td><?php echo $monthNames[$slip['month']] . ' ' . $slip['year']; ?></td></tr>
                    <tr><td style="color:#555;">Working Days</td><td><?php echo $slip['working_days']; ?></td></tr>
                    <tr><td style="color:#555;">Present Days</td><td><?php echo $slip['present_days']; ?></td></tr>
                    <tr><td style="color:#555;">Payment Date</td><td><?php echo $slip['payment_date'] ?? '—'; ?></td></tr>
                </table>
            </td>
        </tr>
    </table>

    <!-- Earnings / Deductions table -->
    <table style="border-collapse:collapse; width:100%; margin-bottom:15px;">
        <tr style="background:#e8f4e8;">
            <th style="border:1px solid #ccc; padding:5px 8px; text-align:left;">Earnings</th>
            <th style="border:1px solid #ccc; padding:5px 8px; text-align:right;">Amount</th>
            <th style="border:1px solid #ccc; padding:5px 8px; text-align:left;">Deductions</th>
            <th style="border:1px solid #ccc; padding:5px 8px; text-align:right;">Amount</th>
        </tr>
        <?php
        $earnings   = [
            'Basic Salary' => $slip['basic_salary'],
            'HRA'          => $slip['hra'],
            'DA'           => $slip['da'],
        ];
        if ($slip['ta'] > 0)              $earnings['TA']              = $slip['ta'];
        if ($slip['other_allowance'] > 0) $earnings['Other Allowance'] = $slip['other_allowance'];

        $deductions = [];
        if ($slip['pf_deduction'] > 0)    $deductions['PF']              = $slip['pf_deduction'];
        if ($slip['esi_deduction'] > 0)   $deductions['ESI']             = $slip['esi_deduction'];
        if ($slip['tds_deduction'] > 0)   $deductions['TDS']             = $slip['tds_deduction'];
        if ($slip['advance_deduction'] > 0) $deductions['Advance']       = $slip['advance_deduction'];
        if ($slip['other_deduction'] > 0) $deductions['Other']           = $slip['other_deduction'];

        $eArr = array_keys($earnings); $dArr = array_keys($deductions);
        $rows = max(count($eArr), count($dArr));
        for ($r = 0; $r < $rows; $r++):
            $eKey = $eArr[$r] ?? null; $dKey = $dArr[$r] ?? null;
        ?>
        <tr>
            <td style="border:1px solid #ccc; padding:4px 8px;"><?php echo $eKey ?? ''; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:right;"><?php echo $eKey ? '₹' . number_format($earnings[$eKey], 2) : ''; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; color:#c00;"><?php echo $dKey ?? ''; ?></td>
            <td style="border:1px solid #ccc; padding:4px 8px; text-align:right; color:#c00;"><?php echo $dKey ? '-₹' . number_format($deductions[$dKey], 2) : ''; ?></td>
        </tr>
        <?php endfor; ?>
        <tr style="font-weight:bold; background:#f5f5f5;">
            <td style="border:1px solid #ccc; padding:5px 8px;">Gross Salary</td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:right;">₹<?php echo number_format($slip['gross_salary'], 2); ?></td>
            <td style="border:1px solid #ccc; padding:5px 8px; color:#c00;">Total Deductions</td>
            <td style="border:1px solid #ccc; padding:5px 8px; text-align:right; color:#c00;">₹<?php echo number_format($slip['total_deductions'], 2); ?></td>
        </tr>
    </table>

    <!-- Net -->
    <div style="background:#1a5276; color:#fff; padding:10px 16px; display:flex; justify-content:space-between; border-radius:4px;">
        <span style="font-size:16px; font-weight:bold;">Net Salary</span>
        <span style="font-size:18px; font-weight:bold;">₹<?php echo number_format($slip['net_salary'], 2); ?></span>
    </div>

    <p style="margin-top:30px; font-size:10px; text-align:center; color:#777;">
        Computer-generated salary slip. No signature required.
    </p>
</div>
        <?php return ob_get_clean();
    }
}
