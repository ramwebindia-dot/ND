<?php
/**
 * Base Model Class
 * Provides PDO database interaction with prepared statements
 */
class Model
{
    protected PDO $db;
    public string $table = '';
    protected string $primaryKey = 'id';

    public function __construct()
    {
        $this->db = $this->connect();
    }

    protected function connect(): PDO
    {
        static $pdo = null;
        if ($pdo !== null) {
            return $pdo;
        }
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            return $pdo;
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            die("Database connection failed. Please check your configuration.");
        }
    }

    public function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Query failed: $sql - " . $e->getMessage());
            throw $e;
        }
    }

    public function findAll(string $orderBy = '', string $orderDir = 'ASC'): array
    {
        $sql = "SELECT * FROM {$this->table}";
        if ($orderBy) {
            $sql .= " ORDER BY $orderBy $orderDir";
        }
        return $this->query($sql)->fetchAll();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1";
        $result = $this->query($sql, ['id' => $id])->fetch();
        return $result ?: null;
    }

    public function findBy(string $column, $value): ?array
    {
        $sql = "SELECT * FROM {$this->table} WHERE $column = :value LIMIT 1";
        $result = $this->query($sql, ['value' => $value])->fetch();
        return $result ?: null;
    }

    public function findAllBy(string $column, $value, string $orderBy = ''): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE $column = :value";
        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }
        return $this->query($sql, ['value' => $value])->fetchAll();
    }

    public function create(array $data): int
    {
        unset($data['csrf_token'], $data['_token']);
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_map(fn($key) => ":$key", array_keys($data)));
        $sql = "INSERT INTO {$this->table} ($columns) VALUES ($placeholders)";
        $this->query($sql, $data);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        unset($data['csrf_token'], $data['_token']);
        $setClause = implode(', ', array_map(fn($key) => "$key = :$key", array_keys($data)));
        $data['id'] = $id;
        $sql = "UPDATE {$this->table} SET $setClause WHERE {$this->primaryKey} = :id";
        return $this->query($sql, $data)->rowCount() > 0;
    }

    public function delete(int $id): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id";
        return $this->query($sql, ['id' => $id])->rowCount() > 0;
    }

    public function count(string $where = '', array $params = []): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        if ($where) {
            $sql .= " WHERE $where";
        }
        $result = $this->query($sql, $params)->fetch();
        return (int) ($result['total'] ?? 0);
    }

    public function paginate(int $page = 1, int $perPage = 20, string $where = '', array $params = [], string $orderBy = ''): array
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM {$this->table}";
        $countSql = "SELECT COUNT(*) as total FROM {$this->table}";

        if ($where) {
            $sql .= " WHERE $where";
            $countSql .= " WHERE $where";
        }

        $total = (int) $this->query($countSql, $params)->fetch()['total'];

        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }
        $sql .= " LIMIT $perPage OFFSET $offset";

        $data = $this->query($sql, $params)->fetchAll();

        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage),
        ];
    }

    public function raw(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    public function rawOne(string $sql, array $params = []): ?array
    {
        $result = $this->query($sql, $params)->fetch();
        return $result ?: null;
    }

    public function beginTransaction(): void
    {
        $this->db->beginTransaction();
    }

    public function commit(): void
    {
        $this->db->commit();
    }

    public function rollBack(): void
    {
        $this->db->rollBack();
    }

    public function inTransaction(): bool
    {
        return $this->db->inTransaction();
    }

    public function lastInsertId(): int
    {
        return (int) $this->db->lastInsertId();
    }
}
