<?php
/**
 * Secure File Upload Class
 */
class FileUpload
{
    protected array $allowedTypes;
    protected int $maxSize;
    protected string $uploadPath;

    public function __construct(array $allowedTypes = [], int $maxSize = 0, string $uploadPath = '')
    {
        $this->allowedTypes = !empty($allowedTypes) ? $allowedTypes : ALLOWED_FILE_TYPES;
        $this->maxSize = $maxSize > 0 ? $maxSize : MAX_UPLOAD_SIZE;
        $this->uploadPath = !empty($uploadPath) ? $uploadPath : UPLOAD_PATH;
    }

    public function upload(array $file, string $subDir = ''): array
    {
        if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
            return ['success' => false, 'message' => 'No file uploaded.'];
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => $this->getErrorMessage($file['error'])];
        }

        if ($file['size'] > $this->maxSize) {
            $maxMB = round($this->maxSize / 1048576, 1);
            return [
                'success' => false,
                'message' => "File size exceeds the maximum limit of {$maxMB}MB."
            ];
        }

        // Detect MIME type safely
        $mimeType = '';

        if (class_exists('finfo')) {
            try {
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mimeType = $finfo->file($file['tmp_name']);
            } catch (Throwable $e) {
                $mimeType = '';
            }
        }

        if (empty($mimeType) && function_exists('mime_content_type')) {
            $mimeType = mime_content_type($file['tmp_name']);
        }

        // Do NOT fall back to browser-supplied $file['type'] — it is trivially faked

        if (empty($mimeType)) {
            return [
                'success' => false,
                'message' => 'Unable to determine uploaded file type.'
            ];
        }

        if (!in_array($mimeType, $this->allowedTypes, true)) {
            return [
                'success' => false,
                'message' => 'File type not allowed.'
            ];
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fileName = uniqid('', true) . '_' . time() . '.' . $extension;

        $targetDir = rtrim($this->uploadPath, '/');
        if ($subDir !== '') {
            $targetDir .= '/' . trim($subDir, '/');
        }

        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        $targetPath = $targetDir . '/' . $fileName;

        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            return [
                'success' => false,
                'message' => 'Failed to move uploaded file.'
            ];
        }

        $relativePath = ($subDir ? trim($subDir, '/') . '/' : '') . $fileName;

        return [
            'success'   => true,
            'message'   => 'File uploaded successfully.',
            'file_name' => $fileName,
            'file_path' => $relativePath,
            'file_size' => $file['size'],
            'file_type' => $mimeType,
        ];
    }

    public function uploadImage(array $file, string $subDir = 'students'): array
    {
        $this->allowedTypes = ALLOWED_IMAGE_TYPES;
        return $this->upload($file, $subDir);
    }

    public function uploadDocument(array $file, string $subDir = 'documents'): array
    {
        $this->allowedTypes = array_merge(ALLOWED_DOC_TYPES, ALLOWED_IMAGE_TYPES);
        return $this->upload($file, $subDir);
    }

    public static function delete(string $filePath): bool
    {
        $fullPath = rtrim(UPLOAD_PATH, '/') . '/' . ltrim($filePath, '/');

        if (is_file($fullPath)) {
            return unlink($fullPath);
        }

        return false;
    }

    protected function getErrorMessage(int $errorCode): string
    {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'File size exceeds the maximum limit.';
            case UPLOAD_ERR_PARTIAL:
                return 'File was only partially uploaded.';
            case UPLOAD_ERR_NO_FILE:
                return 'No file was uploaded.';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Missing temporary folder.';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Failed to write file to disk.';
            case UPLOAD_ERR_EXTENSION:
                return 'A PHP extension stopped the file upload.';
            default:
                return 'Unknown upload error.';
        }
    }
}