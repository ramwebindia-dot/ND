<?php
/**
 * Permission Management Class
 * Role-based access control
 */
class Permission
{
    /**
     * Permission matrix: role => [permissions]
     * Super Admin has all permissions by default
     */
    protected static array $roleDefaults = [
        'Super Admin' => ['*'],
        'School Admin' => ['search.*', 'dashboard', 'students.*', 'teachers.*', 'staff.*', 'academic.*', 'attendance.*', 'timetable.*', 'exams.*', 'fees.*', 'refunds.*', 'accounting.*', 'payroll.*', 'library.*', 'homework.*', 'materials.*', 'communication.*', 'reports.*', 'transport.*', 'reception.*', 'settings.view', 'roles.view', 'users.*', 'audit.view', 'backup.view', 'onlineclass.*', 'questionbank.*'],
        'Principal' => ['search.*', 'dashboard', 'students.*', 'teachers.*', 'staff.*', 'academic.*', 'attendance.*', 'timetable.*', 'exams.*', 'reports.*', 'communication.*', 'reception.*', 'homework.view', 'materials.view', 'transport.view', 'transport.routeDetails', 'transport.pickupPoints', 'transport.getRoutePickupPoints', 'transport.reports', 'onlineclass.*', 'questionbank.*'],
        'Teacher' => ['search.*', 'dashboard', 'attendance.mark', 'attendance.view', 'attendance.getStudents', 'timetable.view', 'exams.marksEntry', 'exams.view', 'homework.*', 'materials.*', 'students.view', 'communication.view', 'teachers.myDashboard', 'teachers.mySalary', 'teachers.myAttendance', 'teachers.myLeave', 'onlineclass.*', 'questionbank.*'],
        'Accountant' => ['search.*', 'dashboard', 'fees.*', 'refunds.*', 'accounting.*', 'reports.feeReports', 'reports.financialReports', 'students.view', 'students.feeLedger', 'transport.fees', 'transport.collectFee'],
        'Receptionist' => ['search.*', 'dashboard', 'reception.*'],
        'Librarian' => ['search.*', 'dashboard', 'library.*', 'students.view'],
        'Student' => ['search.*', 'dashboard', 'studentportal.*', 'attendance.view', 'exams.viewResults', 'homework.view', 'homework.submit', 'materials.view', 'timetable.view', 'fees.myFees', 'communication.view', 'onlineclass.myClasses'],
        'Parent' => ['search.*', 'dashboard', 'parent.*', 'attendance.view', 'exams.viewResults', 'homework.view', 'timetable.view', 'fees.myFees', 'communication.view'],
    ];

    /**
     * Check permission for the currently logged-in user (session role).
     */
    public static function check(string $permission): bool
    {
        $role = Session::get('role_name') ?? '';
        return self::has($permission, $role);
    }

    /**
     * Check if a role has a specific permission
     */
    public static function has(string $permission, string $role): bool
    {
        // Super Admin has all permissions
        if ($role === 'Super Admin') return true;

        $permissions = self::$roleDefaults[$role] ?? [];

        // Check exact match
        if (in_array($permission, $permissions)) return true;

        // Check wildcard match
        $parts = explode('.', $permission);
        if (count($parts) > 1) {
            $wildcard = $parts[0] . '.*';
            if (in_array($wildcard, $permissions)) return true;
        }

        // Check global wildcard
        if (in_array('*', $permissions)) return true;

        // Check database for custom permissions
        return self::checkDatabasePermission($permission, $role);
    }

    /**
     * Check permission from database (for custom role overrides)
     */
    protected static function checkDatabasePermission(string $permission, string $role): bool
    {
        try {
            $model = new Model();
            $sql = "SELECT rp.permission_name FROM role_permissions rp 
                    JOIN roles r ON rp.role_id = r.id 
                    WHERE r.name = :role AND rp.permission_name = :permission";
            $result = $model->rawOne($sql, ['role' => $role, 'permission' => $permission]);
            return !empty($result);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Get all permissions for a role
     */
    public static function getRolePermissions(string $role): array
    {
        return self::$roleDefaults[$role] ?? [];
    }

    /**
     * Get all available modules for permission assignment
     */
    public static function getModules(): array
    {
        return [
            'transport' => 'Transport',
            'dashboard' => 'Dashboard',
            'students' => 'Student Management',
            'teachers' => 'Teacher Management',
            'staff'    => 'Non-Teaching Staff',
            'academic' => 'Academic Management',
            'attendance' => 'Attendance',
            'timetable' => 'Timetable',
            'exams' => 'Examinations',
            'fees' => 'Fee Management',
            'refunds' => 'Fee Refunds',
            'accounting' => 'Accounting',
            'library' => 'Library',
            'homework' => 'Homework',
            'materials' => 'Learning Materials',
            'communication' => 'Communication',
            'reports' => 'Reports',
            'settings' => 'Settings',
            'roles' => 'Role Management',
            'users' => 'User Management',
            'audit' => 'Audit Logs',
            'backup' => 'Backup',
            'onlineclass' => 'Online Classes',
            'questionbank' => 'Question Bank',
        ];
    }

    /**
     * Get permission actions for a module
     */
    public static function getActions(string $module): array
    {
        $actions = [
            'view', 'create', 'edit', 'delete',
        ];
        if ($module === 'attendance') $actions = array_merge($actions, ['mark']);
        if ($module === 'exams') $actions = array_merge($actions, ['marksEntry', 'viewResults']);
        if ($module === 'fees') $actions = array_merge($actions, [
            'collect', 'myFees', 'cancel_receipt', 'process_refund', 'modify_discount',
            'family_payment', 'view_ledger', 'late_fee_rules', 'lock_session', 'unlock_session',
            'reverse_payment', 'config', 'approve_cash_closing',
        ]);
        if ($module === 'homework') $actions = array_merge($actions, ['submit']);
        if ($module === 'reports') $actions = array_merge($actions, ['feeReports', 'financialReports', 'attendanceReports', 'examReports']);
        return $actions;
    }

    /**
     * Get all available permissions grouped by module
     */
    public static function getAllPermissions(): array
    {
        $modules = self::getModules();
        $allPerms = [];
        foreach ($modules as $key => $label) {
            $actions = self::getActions($key);
            $allPerms[$key] = ['label' => $label, 'permissions' => []];
            foreach ($actions as $action) {
                $allPerms[$key]['permissions'][] = ['key' => "$key.$action", 'label' => ucfirst(str_replace('_', ' ', $action))];
            }
            $allPerms[$key]['permissions'][] = ['key' => "$key.*", 'label' => 'All ' . $label];
        }
        return $allPerms;
    }

    /**
     * Get sidebar menu items based on role
     */
    public static function getSidebarMenu(string $role): array
    {
        $menu = [];

        if (self::has('dashboard', $role)) {
            $menu[] = ['title' => 'Dashboard', 'url' => 'dashboard', 'icon' => 'fas fa-tachometer-alt'];
        }

        // Academic
        $academicSubmenu = [];
        if (self::has('academic.*', $role) || self::has('sessions.*', $role)) {
            $academicSubmenu[] = ['title' => 'Sessions', 'url' => 'sessions', 'icon' => 'fas fa-calendar-alt'];
        }
        if (self::has('academic.*', $role)) {
            $academicSubmenu[] = ['title' => 'Classes', 'url' => 'academic/classes', 'icon' => 'fas fa-chalkboard'];
            $academicSubmenu[] = ['title' => 'Sections', 'url' => 'academic/sections', 'icon' => 'fas fa-layer-group'];
            $academicSubmenu[] = ['title' => 'Subjects', 'url' => 'academic/subjects', 'icon' => 'fas fa-book'];
            $academicSubmenu[] = ['title' => 'Subject Allocation', 'url' => 'academic/allocation', 'icon' => 'fas fa-project-diagram'];
        }
        if (!empty($academicSubmenu)) {
            $menu[] = ['title' => 'Academic', 'icon' => 'fas fa-graduation-cap', 'submenu' => $academicSubmenu];
        }

        // People
        $peopleSubmenu = [];
        if (self::has('students.view', $role)) {
            $peopleSubmenu[] = ['title' => 'Students', 'url' => 'students',       'icon' => 'fas fa-user-graduate'];
            $peopleSubmenu[] = ['title' => 'Parents',  'url' => 'parent/manage', 'icon' => 'fas fa-user-friends'];
        }
        if (self::has('teachers.view', $role)) {
            $peopleSubmenu[] = ['title' => 'Teachers',         'url' => 'teachers',             'icon' => 'fas fa-chalkboard-teacher'];
            $peopleSubmenu[] = ['title' => 'Departments',      'url' => 'teachers/departments', 'icon' => 'fas fa-building'];
            $peopleSubmenu[] = ['title' => 'Leave Mgmt',       'url' => 'teachers/leave',       'icon' => 'fas fa-calendar-times'];
        }
        if (self::has('staff.view', $role)) {
            $peopleSubmenu[] = ['title' => 'Non-Teaching Staff', 'url' => 'staff', 'icon' => 'fas fa-users-cog'];
        }
        if (!empty($peopleSubmenu)) {
            $menu[] = ['title' => 'People', 'icon' => 'fas fa-users', 'submenu' => $peopleSubmenu];
        }

        // Reception / Front Desk
        if (self::has('reception.view', $role) || self::has('reception.*', $role)) {
            $menu[] = ['title' => 'Reception', 'icon' => 'fas fa-concierge-bell', 'submenu' => [
                ['title' => 'Overview',            'url' => 'reception',            'icon' => 'fas fa-th-large'],
                ['title' => 'Admission Enquiries', 'url' => 'reception/enquiries',  'icon' => 'fas fa-user-plus'],
                ['title' => 'Visitor Log',         'url' => 'reception/visitors',   'icon' => 'fas fa-id-badge'],
                ['title' => 'Phone Call Log',      'url' => 'reception/calls',      'icon' => 'fas fa-phone'],
                ['title' => 'Complaints',          'url' => 'reception/complaints', 'icon' => 'fas fa-comment-dots'],
            ]];
        }

        // Attendance
        if (self::has('attendance.view', $role) || self::has('attendance.mark', $role)) {
            $attSubmenu = [['title' => 'Daily Attendance', 'url' => 'attendance', 'icon' => 'fas fa-clipboard-check']];
            if (self::has('attendance.view', $role) || self::has('attendance.*', $role)) {
                $attSubmenu[] = ['title' => 'Teacher Attendance', 'url' => 'attendance/teacher', 'icon' => 'fas fa-chalkboard-teacher'];
                $attSubmenu[] = ['title' => 'Monthly Report',     'url' => 'attendance/monthly-report', 'icon' => 'fas fa-calendar-alt'];
            }
            $menu[] = ['title' => 'Attendance', 'icon' => 'fas fa-clipboard-check', 'submenu' => $attSubmenu];
        }

        // Timetable
        if (self::has('timetable.view', $role)) {
            $menu[] = ['title' => 'Timetable', 'url' => 'timetable', 'icon' => 'fas fa-clock'];
        }

        // Exams
        if (self::has('exams.view', $role)) {
            $menu[] = ['title' => 'Examinations', 'url' => 'exams', 'icon' => 'fas fa-file-alt'];
        }

        // Finance
        $financeSubmenu = [];
        if (self::has('fees.view', $role) || self::has('fees.*', $role)) {
            $financeSubmenu[] = ['title' => 'Fee Management',     'url' => 'fees',                       'icon' => 'fas fa-rupee-sign'];
            $financeSubmenu[] = ['title' => 'Fee Heads',          'url' => 'fees/heads',                 'icon' => 'fas fa-tags'];
            $financeSubmenu[] = ['title' => 'Fee Structure',      'url' => 'fees/structures',            'icon' => 'fas fa-table'];
            $financeSubmenu[] = ['title' => 'Family Payment',     'url' => 'fees/familyPayment',         'icon' => 'fas fa-users'];
            $financeSubmenu[] = ['title' => 'Month Status',       'url' => 'fees/monthStatus',           'icon' => 'fas fa-calendar-check'];
            $financeSubmenu[] = ['title' => 'Student Ledger',     'url' => 'fees/studentLedger',         'icon' => 'fas fa-book'];
            $financeSubmenu[] = ['title' => 'Additional Charges', 'url' => 'fees/additionalCharges',    'icon' => 'fas fa-plus-circle'];
            $financeSubmenu[] = ['title' => 'Late Fee Rules',     'url' => 'fees/lateFeeRules',         'icon' => 'fas fa-clock'];
            $financeSubmenu[] = ['title' => 'Fee Allocation',     'url' => 'fees/allocation',           'icon' => 'fas fa-tags'];
            $financeSubmenu[] = ['title' => 'Cash Closing',       'url' => 'fees/cashClosing',          'icon' => 'fas fa-cash-register'];
            $financeSubmenu[] = ['title' => 'Bank Reconciliation','url' => 'fees/bankReconciliation',   'icon' => 'fas fa-university'];
            $financeSubmenu[] = ['title' => 'Reconciliation',     'url' => 'fees/reconciliation',       'icon' => 'fas fa-balance-scale'];
            $financeSubmenu[] = ['title' => 'Family Dashboard',   'url' => 'fees/familyDashboard',      'icon' => 'fas fa-home'];
            $financeSubmenu[] = ['title' => 'Fee Config',         'url' => 'fees/feeConfig',            'icon' => 'fas fa-sliders-h'];
        }
        if (self::has('refunds.view', $role) || self::has('refunds.*', $role)) {
            $financeSubmenu[] = ['title' => 'Fee Refunds', 'url' => 'refunds', 'icon' => 'fas fa-undo'];
        }
        if (self::has('accounting.view', $role) || self::has('accounting.*', $role)) {
            $financeSubmenu[] = ['title' => 'Accounting',    'url' => 'accounting',                 'icon' => 'fas fa-calculator'];
            $financeSubmenu[] = ['title' => 'Income',        'url' => 'accounting/income',          'icon' => 'fas fa-arrow-down'];
            $financeSubmenu[] = ['title' => 'Expense',       'url' => 'accounting/expenses',        'icon' => 'fas fa-arrow-up'];
            $financeSubmenu[] = ['title' => 'Cash Book',     'url' => 'accounting/cash-book',       'icon' => 'fas fa-money-bill-wave'];
            $financeSubmenu[] = ['title' => 'Bank Book',     'url' => 'accounting/bank-book',       'icon' => 'fas fa-university'];
            $financeSubmenu[] = ['title' => 'Profit & Loss', 'url' => 'accounting/profit-loss',     'icon' => 'fas fa-chart-line'];
            $financeSubmenu[] = ['title' => 'Balance Sheet', 'url' => 'accounting/balance-sheet',   'icon' => 'fas fa-balance-scale'];
            // Journal Entries menu removed — the system posts all journal/ledger entries
            // automatically (fee, income, expense, payroll, refund). No manual entry needed.
        }
        if (self::has('payroll.view', $role) || self::has('payroll.*', $role)) {
            $financeSubmenu[] = ['title' => 'Payroll',            'url' => 'payroll',               'icon' => 'fas fa-file-invoice-dollar'];
            $financeSubmenu[] = ['title' => 'Salary Structures',  'url' => 'payroll/structures',    'icon' => 'fas fa-list'];
            $financeSubmenu[] = ['title' => 'Advances',           'url' => 'payroll/advances',      'icon' => 'fas fa-hand-holding-usd'];
        }
        if (!empty($financeSubmenu)) {
            $menu[] = ['title' => 'Finance', 'icon' => 'fas fa-money-bill-wave', 'submenu' => $financeSubmenu];
        }

        // Library
        if (self::has('library.view', $role)) {
            $menu[] = ['title' => 'Library', 'url' => 'library', 'icon' => 'fas fa-book-open'];
        }

        // Homework
        if (self::has('homework.view', $role)) {
            $menu[] = ['title' => 'Homework', 'url' => 'homework', 'icon' => 'fas fa-tasks'];
        }

        // Learning Materials
        if (self::has('materials.view', $role)) {
            $menu[] = ['title' => 'Study Materials', 'url' => 'materials', 'icon' => 'fas fa-folder-open'];
        }

        // Online Classes
        if (self::has('onlineclass.*', $role) || self::has('onlineclass.myClasses', $role)) {
            if (self::has('onlineclass.*', $role)) {
                $ocSub = [
                    ['title' => 'All Classes',      'url' => 'online-class',        'icon' => 'fas fa-list'],
                    ['title' => 'Schedule Class',    'url' => 'online-class/create', 'icon' => 'fas fa-calendar-plus'],
                ];
                $menu[] = ['title' => 'Online Classes', 'icon' => 'fas fa-video', 'submenu' => $ocSub];
            } else {
                $menu[] = ['title' => 'Online Classes', 'url' => 'online-class/my-classes', 'icon' => 'fas fa-video'];
            }
        }

        // Question Bank
        if (self::has('questionbank.*', $role)) {
            $qbSub = [
                ['title' => 'Question Bank',   'url' => 'question-bank',                 'icon' => 'fas fa-database'],
                ['title' => 'Question Papers', 'url' => 'question-bank/papers',           'icon' => 'fas fa-file-alt'],
                ['title' => 'Generate Paper',  'url' => 'question-bank/generate-paper',   'icon' => 'fas fa-magic'],
            ];
            $menu[] = ['title' => 'Question Bank', 'icon' => 'fas fa-question-circle', 'submenu' => $qbSub];
        }

        // Communication
        if (self::has('communication.view', $role)) {
            $commSub = [
                ['title' => 'Overview',   'url' => 'communication',           'icon' => 'fas fa-home'],
                ['title' => 'Messages',   'url' => 'communication/messages',  'icon' => 'fas fa-envelope'],
                ['title' => 'Notices',    'url' => 'communication/notices',   'icon' => 'fas fa-bullhorn'],
            ];
            if (self::has('communication.*', $role) || in_array($role, ['Super Admin','School Admin','Principal','Teacher'])) {
                $commSub[] = ['title' => 'Broadcast', 'url' => 'communication/broadcast', 'icon' => 'fas fa-broadcast-tower'];
            }
            $menu[] = ['title' => 'Communication', 'icon' => 'fas fa-envelope', 'submenu' => $commSub];
        }

        // Teacher Self-Portal
        if (self::has('teachers.myDashboard', $role)) {
            $teacherPortalSubmenu = [
                ['title' => 'My Dashboard',  'url' => 'teachers/my-dashboard',  'icon' => 'fas fa-tachometer-alt'],
                ['title' => 'My Salary',     'url' => 'teachers/my-salary',     'icon' => 'fas fa-rupee-sign'],
                ['title' => 'My Attendance', 'url' => 'teachers/my-attendance', 'icon' => 'fas fa-clipboard-check'],
                ['title' => 'My Leave',      'url' => 'teachers/my-leave',      'icon' => 'fas fa-calendar-times'],
            ];
            $menu[] = ['title' => 'My Portal', 'icon' => 'fas fa-user-circle', 'submenu' => $teacherPortalSubmenu];
        }

        // Transport
        if (self::has('transport.*', $role) || self::has('transport.view', $role)) {
            $transportSubmenu = [];
            $transportSubmenu[] = ['title' => 'Overview',          'url' => 'transport',                    'icon' => 'fas fa-tachometer-alt'];
            $transportSubmenu[] = ['title' => 'Pickup Points',     'url' => 'transport/pickup-points',      'icon' => 'fas fa-map-marker-alt'];
            $transportSubmenu[] = ['title' => 'Vehicles',          'url' => 'transport/vehicles',           'icon' => 'fas fa-bus'];
            $transportSubmenu[] = ['title' => 'Routes',            'url' => 'transport/routes',             'icon' => 'fas fa-route'];
            $transportSubmenu[] = ['title' => 'Student Transport', 'url' => 'transport/student-transport',  'icon' => 'fas fa-user-graduate'];
            $transportSubmenu[] = ['title' => 'Transport Fees',    'url' => 'transport/fees',               'icon' => 'fas fa-rupee-sign'];
            $transportSubmenu[] = ['title' => 'Reports',           'url' => 'transport/reports',            'icon' => 'fas fa-chart-bar'];
            $menu[] = ['title' => 'Transport', 'icon' => 'fas fa-bus-alt', 'submenu' => $transportSubmenu];
        } elseif (self::has('transport.fees', $role) || self::has('transport.collectFee', $role)) {
            $menu[] = ['title' => 'Transport Fees', 'url' => 'transport/fees', 'icon' => 'fas fa-bus'];
        }

        // Reports
        if (self::has('reports.*', $role)) {
            $reportsSubmenu = [
                ['title' => 'All Reports',         'url' => 'reports',                      'icon' => 'fas fa-chart-bar'],
                ['title' => 'Daily Collection',    'url' => 'reports/dailyCollection',      'icon' => 'fas fa-calendar-day'],
                ['title' => 'Monthly Collection',  'url' => 'reports/monthlyCollection',    'icon' => 'fas fa-calendar-alt'],
                ['title' => 'Outstanding Fees',    'url' => 'reports/outstandingReport',    'icon' => 'fas fa-exclamation-circle'],
                ['title' => 'Fee Report',          'url' => 'reports/feeReport',            'icon' => 'fas fa-rupee-sign'],
                ['title' => 'Attendance Report',   'url' => 'reports/attendanceReport',     'icon' => 'fas fa-clipboard-check'],
                ['title' => 'Exam Report',         'url' => 'reports/examReport',           'icon' => 'fas fa-file-alt'],
            ];
            $menu[] = ['title' => 'Reports', 'icon' => 'fas fa-chart-bar', 'submenu' => $reportsSubmenu];
        } elseif (self::has('reports.feeReports', $role)) {
            $menu[] = ['title' => 'Fee Reports', 'url' => 'reports/feeReport', 'icon' => 'fas fa-rupee-sign'];
        }

        // Administration (admin only)
        if (in_array($role, ['Super Admin', 'School Admin'])) {
            $adminSubmenu = [];
            $adminSubmenu[] = ['title' => 'Settings',          'url' => 'settings',              'icon' => 'fas fa-cog'];
            $adminSubmenu[] = ['title' => 'Fee Config',         'url' => 'settings/fee-config',   'icon' => 'fas fa-sliders-h'];
            $adminSubmenu[] = ['title' => 'Email / SMTP',       'url' => 'settings/email',        'icon' => 'fas fa-envelope-open-text'];
            $adminSubmenu[] = ['title' => 'Roles & Permissions','url' => 'roles',                 'icon' => 'fas fa-shield-alt'];
            $adminSubmenu[] = ['title' => 'User Accounts',       'url' => 'users',                'icon' => 'fas fa-users-cog'];
            $adminSubmenu[] = ['title' => 'SMS Settings',        'url' => 'settings/sms',         'icon' => 'fas fa-sms'];
            $adminSubmenu[] = ['title' => 'Audit Logs',         'url' => 'audit',           'icon' => 'fas fa-history'];
            $adminSubmenu[] = ['title' => 'Backup',             'url' => 'backup',          'icon' => 'fas fa-database'];
            $menu[] = ['title' => 'Administration', 'icon' => 'fas fa-cogs', 'submenu' => $adminSubmenu];
        }

        return $menu;
    }
}
