<?php
/**
 * NotificationService
 * Central place to fire in-app notifications (and optionally SMS/email) for all key events.
 * Call static methods from controllers after successful operations.
 */
class NotificationService
{
    // ── Fee Events ────────────────────────────────────────────────

    public static function feeCollected(int $studentUserId, string $studentName, float $amount, string $receipt): void
    {
        if (!$studentUserId) return;
        Notification::add(
            $studentUserId,
            'Fee Payment Received',
            "Payment of ₹" . number_format($amount, 2) . " received. Receipt: $receipt.",
            'Fee',
            url('student-portal/fees')
        );
        self::notifyParentsOfStudent($studentUserId,
            'Fee Payment Received',
            "Fee of ₹" . number_format($amount, 2) . " for $studentName received. Receipt: $receipt.",
            'Fee',
            url('parent/childFees')
        );
        // SMS to parent phones
        self::smsParentsOfStudent($studentUserId, function($phone) use ($studentName, $amount, $receipt) {
            SMS::feeReceived($phone, $studentName, $amount, $receipt);
        });
    }

    public static function feeDueReminder(int $studentUserId, string $studentName, float $outstanding): void
    {
        if (!$studentUserId) return;
        Notification::add(
            $studentUserId,
            'Fee Due Reminder',
            "You have an outstanding fee balance of ₹" . number_format($outstanding, 2) . ". Please pay at your earliest.",
            'Fee',
            url('student-portal/fees')
        );
        self::notifyParentsOfStudent($studentUserId,
            'Fee Due Reminder',
            "Outstanding fee for $studentName is ₹" . number_format($outstanding, 2) . ".",
            'Fee',
            url('parent/childFees')
        );
    }

    // ── Attendance Events ─────────────────────────────────────────

    public static function studentMarkedAbsent(int $studentUserId, string $studentName, string $date): void
    {
        if (!$studentUserId) return;
        Notification::add(
            $studentUserId,
            'Attendance: Absent',
            "You were marked Absent on " . date('d-m-Y', strtotime($date)) . ".",
            'Attendance',
            url('student-portal/attendance')
        );
        self::notifyParentsOfStudent($studentUserId,
            'Child Absent Today',
            "$studentName was marked Absent on " . date('d-m-Y', strtotime($date)) . ".",
            'Attendance',
            url('parent/childAttendance')
        );
        // SMS alert
        self::smsParentsOfStudent($studentUserId, function($phone) use ($studentName, $date) {
            SMS::absenceAlert($phone, $studentName, date('d-m-Y', strtotime($date)));
        });
    }

    // ── Homework Events ───────────────────────────────────────────

    public static function homeworkAssigned(array $userIds, string $title, string $dueDate, int $homeworkId): void
    {
        $due = $dueDate ? ' Due: ' . date('d-m-Y', strtotime($dueDate)) . '.' : '';
        foreach (array_unique($userIds) as $uid) {
            if (!$uid) continue;
            Notification::add(
                (int)$uid,
                "New Homework",
                "\"$title\" assigned by your class teacher.$due",
                'Homework',
                url('homework/view?id=' . $homeworkId)
            );
        }
    }

    public static function homeworkGraded(int $studentUserId, string $subject, string $title, string $grade): void
    {
        if (!$studentUserId) return;
        Notification::add(
            $studentUserId,
            "Homework Graded: $subject",
            "Your submission for \"$title\" has been graded. Grade: $grade.",
            'Homework',
            url('student-portal/homework')
        );
    }

    // ── Exam Events ───────────────────────────────────────────────

    public static function examCreated(array $studentUserIds, string $examName, string $startDate): void
    {
        foreach ($studentUserIds as $uid) {
            if (!$uid) continue;
            Notification::add(
                (int)$uid,
                "Exam Scheduled: $examName",
                "Exam \"$examName\" starts on " . date('d-m-Y', strtotime($startDate)) . ". Please prepare.",
                'Exam',
                url('student-portal/results')
            );
        }
    }

    public static function resultsPublished(array $studentUserIds, string $examName): void
    {
        foreach ($studentUserIds as $uid) {
            if (!$uid) continue;
            Notification::add(
                (int)$uid,
                "Results Published: $examName",
                "Results for \"$examName\" are now available. Check your report card.",
                'Exam',
                url('student-portal/results')
            );
        }
    }

    // ── TC / Student Events ───────────────────────────────────────

    public static function tcIssued(int $studentUserId, string $studentName, string $tcNumber): void
    {
        if (!$studentUserId) return;
        Notification::add(
            $studentUserId,
            'Transfer Certificate Issued',
            "TC No. $tcNumber has been issued for $studentName.",
            'Student',
            null
        );
        self::notifyParentsOfStudent($studentUserId,
            'Transfer Certificate Issued',
            "Transfer Certificate (TC No. $tcNumber) has been issued for $studentName.",
            'Student',
            null
        );
    }

    // ── Teacher Leave Events ──────────────────────────────────────

    public static function leaveStatusChanged(int $teacherUserId, string $leaveType, string $fromDate, string $toDate, string $status): void
    {
        if (!$teacherUserId) return;
        $statusText = $status === 'Approved' ? '✓ Approved' : '✗ Rejected';
        Notification::add(
            $teacherUserId,
            "Leave $status",
            "$statusText: Your $leaveType leave (" . date('d-m-Y', strtotime($fromDate)) . " to " . date('d-m-Y', strtotime($toDate)) . ") has been $status.",
            'Leave',
            url('teachers/myLeaves')
        );
    }

    // ── Notice Events ─────────────────────────────────────────────

    public static function noticePublished(array $userIds, string $noticeTitle): void
    {
        foreach ($userIds as $uid) {
            if (!$uid) continue;
            Notification::add(
                (int)$uid,
                'New Notice',
                "A new notice has been published: \"$noticeTitle\".",
                'Notice',
                url('communication/notices')
            );
        }
    }

    // ── Helper: notify parents of a student ──────────────────────

    private static function notifyParentsOfStudent(int $studentUserId, string $title, string $message, string $type, ?string $link): void
    {
        try {
            $sql = "SELECT p.user_id FROM parents p
                    JOIN students s ON s.parent_id = p.id
                    WHERE s.user_id = :uid AND p.user_id IS NOT NULL";
            $model = new Model();
            $parents = $model->raw($sql, ['uid' => $studentUserId]);
            foreach ($parents as $p) {
                if ($p['user_id']) {
                    Notification::add((int)$p['user_id'], $title, $message, $type, $link);
                }
            }
        } catch (Exception $e) {
            error_log("NotificationService::notifyParentsOfStudent error: " . $e->getMessage());
        }
    }

    private static function smsParentsOfStudent(int $studentUserId, callable $fn): void
    {
        try {
            $sql = "SELECT p.father_phone, p.mother_phone FROM parents p
                    JOIN students s ON s.parent_id = p.id
                    WHERE s.user_id = :uid";
            $model = new Model();
            $rows = $model->raw($sql, ['uid' => $studentUserId]);
            foreach ($rows as $row) {
                $phones = array_filter([$row['father_phone'], $row['mother_phone']]);
                foreach ($phones as $phone) {
                    $clean = preg_replace('/\D/', '', $phone);
                    if (preg_match('/^[6-9]\d{9}$/', $clean)) {
                        $fn($clean);
                    }
                }
            }
        } catch (Throwable $e) {
            error_log("NotificationService::smsParentsOfStudent error: " . $e->getMessage());
        }
    }

    /**
     * Get all user IDs for students in a given class/section
     */
    public static function getStudentUserIdsForClass(int $classId, ?int $sectionId = null, int $sessionId = 0): array
    {
        try {
            $model = new Model();
            $where = "s.class_id = :cid AND s.status = 'Active' AND s.user_id IS NOT NULL";
            $params = ['cid' => $classId];
            if ($sectionId) {
                $where .= " AND s.section_id = :sid";
                $params['sid'] = $sectionId;
            }
            if ($sessionId) {
                $where .= " AND s.session_id = :sess";
                $params['sess'] = $sessionId;
            }
            $rows = $model->raw("SELECT user_id FROM students s WHERE $where", $params);
            return array_column($rows, 'user_id');
        } catch (Exception $e) {
            return [];
        }
    }

    /** Parent user IDs for all students in a class (optionally a section). */
    public static function getParentUserIdsForClass(int $classId, ?int $sectionId = null, int $sessionId = 0): array
    {
        try {
            $model = new Model();
            $where = "s.class_id = :cid AND s.status = 'Active' AND p.user_id IS NOT NULL";
            $params = ['cid' => $classId];
            if ($sectionId) { $where .= " AND s.section_id = :sid";  $params['sid']  = $sectionId; }
            if ($sessionId) { $where .= " AND s.session_id = :sess"; $params['sess'] = $sessionId; }
            $rows = $model->raw(
                "SELECT DISTINCT p.user_id FROM students s
                 JOIN parents p ON s.parent_id = p.id WHERE $where",
                $params
            );
            return array_column($rows, 'user_id');
        } catch (Exception $e) {
            return [];
        }
    }
}
