<?php
/**
 * View Class
 * Template rendering engine
 */
class View
{
    /**
     * Render a view with layout
     */
    public static function render(string $view, array $data = [], string $layout = 'main'): void
    {
        // Extract data to variables
        extract($data);

        // Build view path
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            $viewFile = APP_ROOT . '/app/views/errors/404.php';
            if (!file_exists($viewFile)) {
                echo "<h1>404 - View not found: " . e($view) . "</h1>";
                return;
            }
        }

        // Get school settings for layout
        $schoolName = APP_NAME;
        $schoolLogo = asset('img/logo.png');
        try {
            $settingModel = new Settings();
            $schoolSettings = $settingModel->getAll();
            if (isset($schoolSettings['school_name'])) $schoolName = $schoolSettings['school_name'];
            if (!empty($schoolSettings['school_logo'])) $schoolLogo = asset('uploads/' . $schoolSettings['school_logo']);
        } catch (Exception $e) {
            // Use defaults
        }

        // Get active session
        $activeSession = null;
        try {
            $sessionModel = new AcademicSession();
            $activeSession = $sessionModel->getActive();
        } catch (Exception $e) {
            // No active session
        }

        // CSRF token
        $csrfToken = CSRF::token();
        $csrf_token = $csrfToken; // alias for views using snake_case

        // Flash messages
        $flash = Flash::getAll();

        // Current user
        $currentUser = null;
        $currentRole = '';
        if (Session::isLoggedIn()) {
            $currentUser = [
                'id' => Session::get('user_id'),
                'name' => Session::get('user_name'),
                'email' => Session::get('user_email'),
                'role' => Session::get('role_name'),
            ];
            $currentRole = Session::get('role_name');
        }

        // Start output buffering for view content
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        // Load layout
        if ($layout === 'main' && Session::isLoggedIn()) {
            require APP_ROOT . '/app/views/layouts/main.php';
        } elseif ($layout === 'login') {
            require APP_ROOT . '/app/views/layouts/login.php';
        } elseif ($layout === 'print') {
            require APP_ROOT . '/app/views/layouts/print.php';
        } else {
            echo $content;
        }
    }

    /**
     * Render a partial view (no layout)
     */
    public static function partial(string $view, array $data = []): string
    {
        extract($data);
        $viewFile = APP_ROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            ob_start();
            require $viewFile;
            return ob_get_clean();
        }
        return '';
    }
}
