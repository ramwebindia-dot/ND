<?php
/**
 * Base Controller Class
 * All controllers extend this class
 */
class Controller
{
    protected array $data = [];
    protected string $layout = 'main';

    public function __construct()
    {
        // CSRF token validation for POST requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            CSRF::validate();
        }
    }

    protected function view(string $view, array $data = []): void
    {
        $this->data = array_merge($this->data, $data);
        View::render($view, $this->data, $this->layout);
    }

    protected function json(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * IMPORTANT:
     * This method must be PUBLIC because App.php calls:
     * $controllerInstance->checkPermission(...)
     */
    public function checkPermission(string $method): bool
    {
        // Public methods that don't require specific permissions
        $publicMethods = [
            'index',
            'login',
            'logout',
            'forgotPassword',
            'resetPassword'
        ];

        if (in_array($method, $publicMethods, true)) {
            return true;
        }

        if (!Session::isLoggedIn()) {
            return false;
        }

        $roleName = Session::get('role_name');

        $controllerName = (new ReflectionClass($this))->getShortName();
        $controllerName = str_replace('Controller', '', $controllerName);

        $permission = strtolower($controllerName) . '.' . $method;

        // If Permission class doesn't exist, deny access (fail closed)
        if (!class_exists('Permission')) {
            return false;
        }

        return Permission::has($permission, $roleName);
    }

    protected function requireRole(array $roles): void
    {
        $userRole = Session::get('role_name');

        if (!in_array($userRole, $roles, true)) {
            Flash::error('You do not have permission to access this page.');
            redirect('dashboard');
            exit;
        }
    }

    /**
     * HALTING permission guard. Unlike Permission::check() (which only returns a
     * bool), this redirects away if the current role lacks the permission — use it
     * to protect index() pages (index bypasses the router-level permission gate).
     */
    protected function requirePermission(string $permission): void
    {
        if (!Permission::check($permission)) {
            Flash::error('You do not have permission to access this page.');
            redirect('dashboard');
            exit;
        }
    }

    protected function getPost(string $key, $default = null)
    {
        return $_POST[$key] ?? $default;
    }

    protected function getGet(string $key, $default = null)
    {
        return $_GET[$key] ?? $default;
    }

    protected function isPost(): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
    }

    protected function isAjax(): bool
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    /**
     * Require POST method. Redirects back with error if not POST.
     * Use at the start of all delete/destructive actions.
     */
    protected function requirePost(string $redirectTo = 'dashboard'): void
    {
        if (!$this->isPost()) {
            Flash::error('Invalid request method.');
            redirect($redirectTo);
            exit;
        }
    }

    /**
     * Validate POST input. Returns Validator instance.
     * Usage: $v = $this->validateInput($_POST); $v->required('name')->email('email');
     *        if (!$v->validate()) { Flash::error($v->getFirstError()); redirect(...); return; }
     */
    protected function validateInput(array $data): Validator
    {
        return new Validator(Validator::sanitizeArray($data));
    }

    /**
     * Quick validation with auto-redirect on failure.
     * Fields: ['field' => ['required','email','min:6'], ...]
     */
    protected function validateOrFail(array $data, array $rules, string $redirectTo): array
    {
        $v = $this->validateInput($data);
        foreach ($rules as $field => $fieldRules) {
            foreach ((array)$fieldRules as $rule) {
                if ($rule === 'required') $v->required($field);
                elseif ($rule === 'email')  $v->email($field);
                elseif (str_starts_with($rule, 'min:')) $v->minLength($field, (int)substr($rule, 4));
                elseif (str_starts_with($rule, 'max:')) $v->maxLength($field, (int)substr($rule, 4));
                elseif ($rule === 'numeric') $v->numeric($field);
                elseif ($rule === 'phone')   $v->phone($field);
            }
        }
        if (!$v->validate()) {
            Flash::error($v->getFirstError());
            redirect($redirectTo);
            exit;
        }
        return Validator::sanitizeArray($data);
    }
}