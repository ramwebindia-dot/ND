<?php
/**
 * Helper Functions Class
 */
class Helper
{
    /**
     * Generate a random string
     */
    public static function randomString(int $length = 16): string
    {
        return bin2hex(random_bytes(ceil($length / 2)));
    }

    /**
     * Generate admission number
     */
    public static function generateAdmissionNumber(int $sessionId): string
    {
        $prefix = 'ADM';
        $year = date('Y');
        $model = new Model();
        $result = $model->rawOne("SELECT COUNT(*) as total FROM students WHERE session_id = :sid", ['sid' => $sessionId]);
        $count = ($result['total'] ?? 0) + 1;
        return $prefix . $year . str_pad($count, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Generate employee ID
     */
    public static function generateEmployeeId(): string
    {
        $prefix = 'EMP';
        $model = new Model();
        $result = $model->rawOne("SELECT COUNT(*) as total FROM teachers");
        $count = ($result['total'] ?? 0) + 1;
        return $prefix . str_pad($count, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Format number to Indian currency format
     */
    public static function indianCurrency(float $amount): string
    {
        $decimal = number_format($amount, 2, '.', '');
        $parts = explode('.', $decimal);
        $intPart = $parts[0];
        $decPart = $parts[1];

        if (strlen($intPart) > 3) {
            $lastThree = substr($intPart, -3);
            $restUnits = substr($intPart, 0, -3);
            $restUnits = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $restUnits);
            $intPart = $restUnits . ',' . $lastThree;
        }

        return $intPart . '.' . $decPart;
    }

    /**
     * Get day name from number
     */
    public static function getDayName(int $day): string
    {
        $days = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
        return $days[$day] ?? '';
    }

    /**
     * Get month name
     */
    public static function getMonthName(int $month): string
    {
        $months = [1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'];
        return $months[$month] ?? '';
    }

    /**
     * Calculate attendance percentage
     */
    public static function attendancePercentage(int $present, int $total): float
    {
        if ($total == 0) return 0;
        return round(($present / $total) * 100, 2);
    }

    /**
     * Calculate grade from marks
     */
    public static function calculateGrade(float $marks, float $totalMarks): array
    {
        $percentage = $totalMarks > 0 ? ($marks / $totalMarks) * 100 : 0;

        if ($percentage >= 91) return ['grade' => 'A1', 'point' => 10, 'remark' => 'Outstanding'];
        if ($percentage >= 81) return ['grade' => 'A2', 'point' => 9, 'remark' => 'Excellent'];
        if ($percentage >= 71) return ['grade' => 'B1', 'point' => 8, 'remark' => 'Very Good'];
        if ($percentage >= 61) return ['grade' => 'B2', 'point' => 7, 'remark' => 'Good'];
        if ($percentage >= 51) return ['grade' => 'C1', 'point' => 6, 'remark' => 'Above Average'];
        if ($percentage >= 41) return ['grade' => 'C2', 'point' => 5, 'remark' => 'Average'];
        if ($percentage >= 33) return ['grade' => 'D', 'point' => 4, 'remark' => 'Below Average'];
        return ['grade' => 'E', 'point' => 0, 'remark' => 'Fail'];
    }

    /**
     * Truncate text
     */
    public static function truncate(string $text, int $length = 50): string
    {
        if (strlen($text) <= $length) return $text;
        return substr($text, 0, $length) . '...';
    }

    /**
     * Convert array to CSV
     */
    public static function arrayToCsv(array $data, string $filename = 'export.csv'): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        $output = fopen('php://output', 'w');
        if (!empty($data)) {
            fputcsv($output, array_keys($data[0]));
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
        }
        fclose($output);
        exit;
    }

    /**
     * Get time ago string
     */
    public static function timeAgo(string $datetime): string
    {
        $now = new DateTime();
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
        if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
        if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
        if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
        if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
        return 'Just now';
    }

    /**
     * Slug generator
     */
    public static function slug(string $text): string
    {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        return strtolower($text);
    }

    /**
     * Get current academic session ID
     */
    public static function currentSessionId(): ?int
    {
        return Session::get('active_session_id');
    }
}
