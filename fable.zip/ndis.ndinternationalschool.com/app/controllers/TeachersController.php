<?php
class TeachersController extends Controller
{
    // ── Index ──────────────────────────────────────────────────────

    public function index(): void
    {
        $this->requirePermission('teachers.view');
        $teacherModel = new Teacher();
        $page   = (int) $this->getGet('page', 1);
        $search = $this->getGet('search', '');
        $deptId = $this->getGet('dept_id') ? (int)$this->getGet('dept_id') : null;

        $result = $teacherModel->getTeachersWithDept($page, 20, $search, $deptId);
        $deptModel = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');

        $this->view('teachers/index', [
            'pageTitle'   => 'Teachers',
            'teachers'    => $result['data'],
            'pagination'  => $result,
            'departments' => $departments,
            'search'      => $search,
            'deptId'      => $deptId,
        ]);
    }

    // ── Create ─────────────────────────────────────────────────────

    public function create(): void
    {
        $deptModel   = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');
        $roleModel   = new Model(); $roleModel->table = 'roles';
        $teacherRole = $roleModel->findBy('name', 'Teacher');

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            unset($data['csrf_token']);

            // Field mapping
            if (isset($data['date_of_birth']))  { $data['dob']             = $data['date_of_birth'];  unset($data['date_of_birth']); }
            if (isset($data['mobile']))          { $data['phone']           = $data['mobile'];          unset($data['mobile']); }
            if (isset($data['joining_date']))    { $data['join_date']       = $data['joining_date'];    unset($data['joining_date']); }
            if (isset($data['experience']))      { $data['experience_years']= $data['experience'];      unset($data['experience']); }

            $data['last_name']   = $data['last_name'] ?: null;
            $data['employee_id'] = 'EMP' . date('y') . strtoupper(substr(uniqid(), -5));
            $data['status']      = 'Active';

            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'teachers');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            // Separate login account fields from teacher fields
            $createLogin = !empty($data['create_login']);
            $loginEmail  = trim($data['login_email'] ?? '');
            $loginPass   = $data['login_password'] ?? '';
            unset($data['create_login'], $data['login_email'], $data['login_password']);

            $teacherModel = new Teacher();
            $teacherModel->beginTransaction();
            try {
                $teacherId = $teacherModel->create($data);

                // Auto-create user account if requested
                if ($createLogin && $loginEmail && $loginPass && $teacherRole) {
                    $userModel = new User();
                    $userId = $userModel->createUser([
                        'role_id'   => $teacherRole['id'],
                        'email'     => $loginEmail,
                        'password'  => $loginPass,
                        'full_name' => trim(($data['first_name'] ?? '') . ' ' . ($data['last_name'] ?? '')),
                        'phone'     => $data['phone'] ?? null,
                        'is_active' => 1,
                    ]);
                    // Link user_id to teacher
                    $teacherModel->update($teacherId, ['user_id' => $userId, 'email' => $loginEmail]);
                }

                $teacherModel->commit();
                Audit::log('teachers', 'create', $teacherId, $data);
                Flash::success('Teacher added successfully.' . ($createLogin ? ' Login account created.' : ''));
                redirect('teachers');
            } catch (Exception $e) {
                $teacherModel->rollBack();
                Flash::error('Error: ' . $e->getMessage());
            }
        }

        $this->view('teachers/create', [
            'pageTitle'   => 'Add Teacher',
            'departments' => $departments,
        ]);
    }

    // ── Profile ────────────────────────────────────────────────────

    public function profile(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $teacherModel = new Teacher();
        $teacher = $teacherModel->rawOne(
            "SELECT t.*, d.name as department_name, u.email as login_email, u.is_active as login_active
             FROM teachers t
             LEFT JOIN departments d ON t.department_id = d.id
             LEFT JOIN users u ON t.user_id = u.id
             WHERE t.id = :id LIMIT 1",
            ['id' => $id]
        );
        if (!$teacher) { Flash::error('Teacher not found.'); redirect('teachers'); return; }

        // Leaves for this teacher
        $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';
        $leaves = $leaveModel->findAllBy('teacher_id', $id, 'created_at DESC');

        $this->view('teachers/profile', [
            'pageTitle' => 'Teacher Profile',
            'teacher'   => $teacher,
            'leaves'    => $leaves,
        ]);
    }

    // ── Edit ───────────────────────────────────────────────────────

    public function edit(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $teacherModel = new Teacher();
        $teacher = $teacherModel->findById($id);
        if (!$teacher) { Flash::error('Teacher not found.'); redirect('teachers'); return; }

        $deptModel   = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            unset($data['csrf_token']);
            if (isset($data['date_of_birth']))  { $data['dob']              = $data['date_of_birth'];  unset($data['date_of_birth']); }
            if (isset($data['mobile']))          { $data['phone']            = $data['mobile'];          unset($data['mobile']); }
            if (isset($data['joining_date']))    { $data['join_date']        = $data['joining_date'];    unset($data['joining_date']); }
            if (isset($data['experience']))      { $data['experience_years'] = $data['experience'];      unset($data['experience']); }
            $data['last_name'] = $data['last_name'] ?: null;

            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'teachers');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            $teacherModel->update($id, $data);
            Audit::log('teachers', 'update', $id, $data);
            Flash::success('Teacher updated successfully.');
            redirect('teachers/profile?id=' . $id);
        }

        $this->view('teachers/edit', [
            'pageTitle'   => 'Edit Teacher',
            'teacher'     => $teacher,
            'departments' => $departments,
        ]);
    }

    // ── Delete (deactivate) ────────────────────────────────────────

    public function delete(): void
    {
        $this->requirePost('teachers');
        $id = (int) ($this->getPost('id') ?? 0);
        $teacherModel = new Teacher();
        $teacherModel->update($id, ['status' => 'Resigned']);
        Audit::log('teachers', 'delete', $id);
        Flash::success('Teacher deactivated successfully.');
        redirect('teachers');
    }

    // ── Create Login for existing teacher ─────────────────────────

    public function createLogin(): void
    {
        $this->requirePost('teachers');
        $id    = (int) ($this->getPost('teacher_id') ?? 0);
        $email = trim($this->getPost('email', ''));
        $pass  = $this->getPost('password', '');

        if (!$id || !$email || !$pass) {
            Flash::error('Teacher ID, email and password are required.');
            redirect('teachers/profile?id=' . $id);
            return;
        }

        $teacherModel = new Teacher();
        $teacher = $teacherModel->findById($id);
        if (!$teacher) { Flash::error('Teacher not found.'); redirect('teachers'); return; }

        if ($teacher['user_id']) {
            Flash::error('This teacher already has a login account.');
            redirect('teachers/profile?id=' . $id);
            return;
        }

        $roleModel   = new Model(); $roleModel->table = 'roles';
        $teacherRole = $roleModel->findBy('name', 'Teacher');

        $userModel = new User();
        try {
            $userId = $userModel->createUser([
                'role_id'   => $teacherRole['id'],
                'email'     => $email,
                'password'  => $pass,
                'full_name' => trim(($teacher['first_name'] ?? '') . ' ' . ($teacher['last_name'] ?? '')),
                'phone'     => $teacher['phone'] ?? null,
                'is_active' => 1,
            ]);
            $teacherModel->update($id, ['user_id' => $userId, 'email' => $email]);
            Audit::log('teachers', 'create_login', $id, ['email' => $email]);
            Flash::success('Login account created successfully.');
        } catch (Exception $e) {
            Flash::error('Error creating login: ' . $e->getMessage());
        }
        redirect('teachers/profile?id=' . $id);
    }

    public function deleteLogin(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $this->requirePost('teachers');
        $id = (int)$this->getPost('teacher_id');

        $teacherModel = new Teacher();
        $teacher = $teacherModel->findById($id);
        if (!$teacher || !$teacher['user_id']) { Flash::error('No login account found.'); redirect('teachers/profile?id=' . $id); return; }

        $userId = (int)$teacher['user_id'];
        $teacherModel->update($id, ['user_id' => null]);
        (new Model())->query("DELETE FROM users WHERE id = :uid", ['uid' => $userId]);

        Audit::log('teachers', 'delete_login', $id);
        Flash::success('Login account removed.');
        redirect('teachers/profile?id=' . $id);
    }

    public function resetTeacherPassword(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $this->requirePost('teachers');
        $id       = (int)$this->getPost('teacher_id');
        $password = $this->getPost('password', '');
        if (strlen($password) < 6) { Flash::error('Password must be at least 6 characters.'); redirect('teachers/profile?id=' . $id); return; }

        $teacher = (new Teacher())->findById($id);
        if (!$teacher || !$teacher['user_id']) { Flash::error('No login account.'); redirect('teachers/profile?id=' . $id); return; }

        $model = new Model(); $model->table = 'users';
        $model->update((int)$teacher['user_id'], ['password' => password_hash($password, PASSWORD_DEFAULT)]);
        Audit::log('teachers', 'reset_password', $id);
        Flash::success('Password updated.');
        redirect('teachers/profile?id=' . $id);
    }

    // ── Leaves ─────────────────────────────────────────────────────

    public function leave(): void
    {
        if ($this->isPost()) {
            $data = [
                'teacher_id' => (int)$this->getPost('teacher_id'),
                'leave_type' => $this->getPost('leave_type'),
                'from_date'  => $this->getPost('from_date'),
                'to_date'    => $this->getPost('to_date'),
                'reason'     => $this->getPost('reason'),
                'status'     => 'Pending',
            ];
            $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';
            $id = $leaveModel->create($data);
            Audit::log('teachers', 'leave_request', $id, $data);
            Flash::success('Leave request submitted.');
            redirect('teachers/leave');
        }

        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        $leaveModel = new Model();
        $leaves = $leaveModel->raw(
            "SELECT tl.*, CONCAT(t.first_name, ' ', COALESCE(t.last_name, '')) AS teacher_name, t.employee_id
             FROM teacher_leaves tl
             JOIN teachers t ON tl.teacher_id = t.id
             ORDER BY tl.created_at DESC
             LIMIT 100"
        );

        // Leave balance per teacher (current year, approved leaves used)
        $sessionId = Session::get('active_session_id') ?? 0;
        $leaveDefaults = $leaveModel->raw("SELECT leave_type, default_days FROM leave_settings") ?: [];
        $defaultMap = [];
        foreach ($leaveDefaults as $d) { $defaultMap[$d['leave_type']] = (int)$d['default_days']; }
        if (!$defaultMap) {
            $defaultMap = ['Casual'=>12,'Sick'=>10,'Earned'=>15,'Maternity'=>90,'Other'=>5];
        }

        // Used leaves per teacher per type (approved, current calendar year)
        $usedLeaves = $leaveModel->raw(
            "SELECT teacher_id, leave_type,
                    SUM(DATEDIFF(to_date, from_date) + 1) AS used_days
             FROM teacher_leaves
             WHERE status = 'Approved'
               AND YEAR(from_date) = YEAR(CURDATE())
             GROUP BY teacher_id, leave_type"
        ) ?: [];
        $usedMap = [];
        foreach ($usedLeaves as $u) {
            $usedMap[$u['teacher_id']][$u['leave_type']] = (int)$u['used_days'];
        }

        $this->view('teachers/leave', [
            'pageTitle'   => 'Teacher Leaves',
            'teachers'    => $teachers,
            'leaves'      => $leaves,
            'defaultMap'  => $defaultMap,
            'usedMap'     => $usedMap,
        ]);
    }

    public function approveLeave(): void
    {
        $this->requirePost('teachers/leave');
        $id = (int) ($this->getPost('leave_id') ?? 0);

        $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';
        $leave = $leaveModel->findById($id);
        if (!$leave) { Flash::error('Leave not found.'); redirect('teachers/leave'); return; }

        $leaveModel->update($id, [
            'status'      => 'Approved',
            'approved_by' => Session::get('user_id'),
            'approved_at' => date('Y-m-d H:i:s'),
        ]);

        // Notify teacher
        try {
            $teacherModel = new Teacher();
            $teacher = $teacherModel->findById((int)$leave['teacher_id']);
            if ($teacher && $teacher['user_id']) {
                NotificationService::leaveStatusChanged(
                    (int)$teacher['user_id'],
                    $leave['leave_type'],
                    $leave['from_date'],
                    $leave['to_date'],
                    'Approved'
                );
            }
        } catch (Exception $e) { error_log("Leave notify: " . $e->getMessage()); }

        Audit::log('teachers', 'leave_approve', $id);
        Flash::success('Leave approved successfully.');
        redirect('teachers/leave');
    }

    public function rejectLeave(): void
    {
        $this->requirePost('teachers/leave');
        $id     = (int) ($this->getPost('leave_id') ?? 0);
        $reason = trim($this->getPost('reject_reason', ''));

        $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';
        $leave = $leaveModel->findById($id);
        if (!$leave) { Flash::error('Leave not found.'); redirect('teachers/leave'); return; }

        $leaveModel->update($id, [
            'status'      => 'Rejected',
            'approved_by' => Session::get('user_id'),
            'approved_at' => date('Y-m-d H:i:s'),
            'reason'      => $reason ?: $leave['reason'],
        ]);

        // Notify teacher
        try {
            $teacherModel = new Teacher();
            $teacher = $teacherModel->findById((int)$leave['teacher_id']);
            if ($teacher && $teacher['user_id']) {
                NotificationService::leaveStatusChanged(
                    (int)$teacher['user_id'],
                    $leave['leave_type'],
                    $leave['from_date'],
                    $leave['to_date'],
                    'Rejected'
                );
            }
        } catch (Exception $e) { error_log("Leave notify: " . $e->getMessage()); }

        Audit::log('teachers', 'leave_reject', $id);
        Flash::success('Leave rejected.');
        redirect('teachers/leave');
    }

    // ── Department Management ──────────────────────────────────────

    public function departments(): void
    {
        $deptModel   = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->raw(
            "SELECT d.*, CONCAT(t.first_name, ' ', COALESCE(t.last_name,'')) AS head_name
             FROM departments d
             LEFT JOIN teachers t ON d.head_teacher_id = t.id
             ORDER BY d.name"
        );

        if ($this->isPost()) {
            $name = trim(Validator::sanitize($this->getPost('name', '')));
            $headId = $this->getPost('head_teacher_id') ? (int)$this->getPost('head_teacher_id') : null;

            if (!$name) { Flash::error('Department name is required.'); }
            else {
                try {
                    $deptModel->create(['name' => $name, 'head_teacher_id' => $headId]);
                    Audit::log('teachers', 'dept_create', null, ['name' => $name]);
                    Flash::success("Department '$name' created.");
                } catch (Exception $e) {
                    Flash::error('Error: ' . $e->getMessage());
                }
            }
            redirect('teachers/departments');
            return;
        }

        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        $this->view('teachers/departments', [
            'pageTitle'   => 'Departments',
            'departments' => $departments,
            'teachers'    => $teachers,
        ]);
    }

    public function editDepartment(): void
    {
        $id = (int)($this->getGet('id', 0));
        $deptModel = new Model(); $deptModel->table = 'departments';
        $dept = $deptModel->findById($id);
        if (!$dept) { Flash::error('Department not found.'); redirect('teachers/departments'); return; }

        if ($this->isPost()) {
            $name   = trim(Validator::sanitize($this->getPost('name', '')));
            $headId = $this->getPost('head_teacher_id') ? (int)$this->getPost('head_teacher_id') : null;
            $deptModel->update($id, ['name' => $name, 'head_teacher_id' => $headId]);
            Audit::log('teachers', 'dept_update', $id);
            Flash::success('Department updated.');
            redirect('teachers/departments');
            return;
        }

        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();
        $this->view('teachers/edit-department', [
            'pageTitle' => 'Edit Department',
            'dept'      => $dept,
            'teachers'  => $teachers,
        ]);
    }

    public function deleteDepartment(): void
    {
        $this->requirePost('teachers/departments');
        $id = (int)($this->getPost('id') ?? 0);
        $deptModel = new Model(); $deptModel->table = 'departments';
        $deptModel->delete($id);
        Audit::log('teachers', 'dept_delete', $id);
        Flash::success('Department deleted.');
        redirect('teachers/departments');
    }

    // ── Teacher Self-Portal ────────────────────────────────────────────────

    /** My Dashboard — teacher sees their own summary */
    public function myDashboard(): void
    {
        $userId    = Session::get('user_id');
        $teacher   = (new Teacher())->rawOne(
            "SELECT t.*, d.name as department_name FROM teachers t
             LEFT JOIN departments d ON t.department_id = d.id
             WHERE t.user_id = :uid",
            ['uid' => $userId]
        );
        if (!$teacher) { Flash::error('Teacher record not found.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id') ?? 0;
        $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';
        $leaves    = $leaveModel->raw(
            "SELECT * FROM teacher_leaves WHERE teacher_id = :tid ORDER BY from_date DESC LIMIT 10",
            ['tid' => $teacher['id']]
        );

        // Today's timetable
        $dayOfWeek = date('l');
        $timetable = (new Teacher())->raw(
            "SELECT tt.*, s.name as subject_name, CONCAT(c.name,' ',sec.name) as class_section
             FROM timetables tt
             JOIN subjects s ON tt.subject_id = s.id
             JOIN classes c ON tt.class_id = c.id
             LEFT JOIN sections sec ON tt.section_id = sec.id
             WHERE tt.teacher_id = :tid AND tt.day_of_week = :day
             ORDER BY tt.start_time",
            ['tid' => $teacher['id'], 'day' => $dayOfWeek]
        );

        $this->view('teachers/my-dashboard', [
            'pageTitle' => 'My Dashboard',
            'teacher'   => $teacher,
            'leaves'    => $leaves,
            'timetable' => $timetable,
        ]);
    }

    /** My Salary Slips */
    public function mySalary(): void
    {
        $userId  = Session::get('user_id');
        $teacher = (new Teacher())->rawOne("SELECT id FROM teachers WHERE user_id = :uid", ['uid' => $userId]);
        if (!$teacher) { Flash::error('Teacher record not found.'); redirect('dashboard'); return; }

        $salaryModel = new Model(); $salaryModel->table = 'salary_payments';
        $salaries = $salaryModel->raw(
            "SELECT id, net_salary, status, basic_salary,
                    CONCAT(LPAD(month,2,'0'), '/', year) AS salary_month,
                    (hra + da + ta + other_allowance) AS allowances,
                    total_deductions AS deductions
             FROM salary_payments
             WHERE teacher_id = :tid
             ORDER BY year DESC, month DESC",
            ['tid' => $teacher['id']]
        );
        $this->view('teachers/my-salary', ['pageTitle' => 'My Salary Slips', 'salaries' => $salaries, 'teacherId' => $teacher['id']]);
    }

    /** My Attendance */
    public function myAttendance(): void
    {
        $userId  = Session::get('user_id');
        $teacher = (new Teacher())->rawOne("SELECT id FROM teachers WHERE user_id = :uid", ['uid' => $userId]);
        if (!$teacher) { Flash::error('Teacher record not found.'); redirect('dashboard'); return; }

        $month = $this->getGet('month') ?: date('Y-m');
        $attModel = new Model(); $attModel->table = 'teacher_attendance';
        $records = $attModel->raw(
            "SELECT * FROM teacher_attendance WHERE teacher_id = :tid AND DATE_FORMAT(date,'%Y-%m') = :month ORDER BY date",
            ['tid' => $teacher['id'], 'month' => $month]
        );
        $this->view('teachers/my-attendance', [
            'pageTitle'  => 'My Attendance',
            'records'    => $records,
            'month'      => $month,
            'teacherId'  => $teacher['id'],
        ]);
    }

    /** My Leave Applications */
    public function myLeave(): void
    {
        $userId  = Session::get('user_id');
        $teacher = (new Teacher())->rawOne("SELECT id FROM teachers WHERE user_id = :uid", ['uid' => $userId]);
        if (!$teacher) { Flash::error('Teacher record not found.'); redirect('dashboard'); return; }

        $leaveModel = new Model(); $leaveModel->table = 'teacher_leaves';

        if ($this->isPost()) {
            $data = $this->validateOrFail($_POST, [
                'leave_type' => ['required'],
                'from_date'  => ['required'],
                'to_date'    => ['required'],
                'reason'     => ['required'],
            ], 'teachers/my-leave');
            $leaveModel->create([
                'teacher_id' => $teacher['id'],
                'leave_type' => $data['leave_type'],
                'from_date'  => $data['from_date'],
                'to_date'    => $data['to_date'],
                'reason'     => $data['reason'],
                'status'     => 'Pending',
            ]);
            Flash::success('Leave application submitted.');
            redirect('teachers/my-leave');
            return;
        }

        $leaves = $leaveModel->raw(
            "SELECT * FROM teacher_leaves WHERE teacher_id = :tid ORDER BY from_date DESC",
            ['tid' => $teacher['id']]
        );

        // Leave balance for this teacher (current year)
        $settingsModel = new Model();
        $leaveDefaults = $settingsModel->raw("SELECT leave_type, default_days FROM leave_settings") ?: [];
        $defaultMap = [];
        foreach ($leaveDefaults as $d) { $defaultMap[$d['leave_type']] = (int)$d['default_days']; }
        if (!$defaultMap) {
            $defaultMap = ['Casual'=>12,'Sick'=>10,'Earned'=>15,'Maternity'=>90,'Other'=>5];
        }
        $usedLeaves = $leaveModel->raw(
            "SELECT leave_type, SUM(DATEDIFF(to_date, from_date) + 1) AS used_days
             FROM teacher_leaves
             WHERE teacher_id = :tid AND status = 'Approved' AND YEAR(from_date) = YEAR(CURDATE())
             GROUP BY leave_type",
            ['tid' => $teacher['id']]
        ) ?: [];
        $usedMap = [];
        foreach ($usedLeaves as $u) { $usedMap[$u['leave_type']] = (int)$u['used_days']; }

        $this->view('teachers/my-leave', [
            'pageTitle'  => 'My Leave',
            'leaves'     => $leaves,
            'defaultMap' => $defaultMap,
            'usedMap'    => $usedMap,
        ]);
    }
}
