<?php
class TimetableController extends Controller
{
    public function index(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $timetableModel = new Timetable();
        $timetable = [];
        $selectedClass = (int) $this->getGet('class_id', 0);
        $selectedSection = (int) $this->getGet('section_id', 0);
        $sections = $selectedClass ? (new Section())->getByClass($selectedClass) : [];

        if ($selectedClass) {
            $timetable = $timetableModel->getClassTimetable($selectedClass, $selectedSection ?: null, $sessionId ?? 0);
        }
        $subjects = (new Subject())->getAllSubjects();
        $teachers = (new Teacher())->getActiveTeachers();
        $this->view('timetable/index', ['pageTitle' => 'Timetable', 'classes' => $classes, 'sections' => $sections, 'timetable' => $timetable, 'selectedClass' => $selectedClass, 'selectedSection' => $selectedSection, 'subjects' => $subjects, 'teachers' => $teachers]);
    }

    public function create(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $subjectModel = new Subject();
        $subjects = $subjectModel->getAllSubjects();
        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        if ($this->isPost()) {
            $data = ['class_id' => $this->getPost('class_id'), 'section_id' => $this->getPost('section_id') ?: null, 'subject_id' => $this->getPost('subject_id'), 'teacher_id' => $this->getPost('teacher_id'), 'session_id' => $sessionId, 'day_of_week' => (int) $this->getPost('day_of_week'), 'period_number' => $this->getPost('period_number'), 'start_time' => $this->getPost('start_time'), 'end_time' => $this->getPost('end_time'), 'room_number' => $this->getPost('room_number')];

            // Check teacher conflict
            $timetableModel = new Timetable();
            if ($timetableModel->checkConflict((int) $data['teacher_id'], $data['day_of_week'], $data['start_time'], $data['end_time'], $sessionId)) {
                Flash::error('Teacher has a scheduling conflict at this time.');
            } else {
                $timetableModel->create($data);
                Audit::log('timetable', 'create', null, $data);
                Flash::success('Timetable entry created.');
                redirect('timetable?class_id=' . $data['class_id'] . ($data['section_id'] ? '&section_id=' . $data['section_id'] : ''));
                return;
            }
        }
        $this->view('timetable/create', ['pageTitle' => 'Create Timetable', 'classes' => $classes, 'subjects' => $subjects, 'teachers' => $teachers]);
    }

    public function update(): void
    {
        $this->requirePost('timetable');
        $id        = (int)$this->getPost('id');
        $subjectId = (int)$this->getPost('subject_id');
        $teacherId = (int)$this->getPost('teacher_id') ?: null;
        $startTime = $this->getPost('start_time', '');
        $endTime   = $this->getPost('end_time', '');
        if (!$id || !$subjectId) { Flash::error('Missing fields.'); redirect('timetable'); return; }
        $model = new Model(); $model->table = 'timetables';
        $model->update($id, [
            'subject_id' => $subjectId,
            'teacher_id' => $teacherId,
            'start_time' => $startTime,
            'end_time'   => $endTime,
        ]);
        Audit::log('timetable', 'update', $id);
        Flash::success('Timetable entry updated.');
        // Redirect back with same class/section filter
        redirect('timetable' . (isset($_SERVER['HTTP_REFERER']) ? '' : ''));
        redirect('timetable');
    }

    public function delete(): void
    {
        $this->requirePost('timetable');
        $id = (int) ($this->getPost('id') ?? 0);
        (new Timetable())->delete($id);
        Audit::log('timetable', 'delete', $id);
        Flash::success('Timetable entry deleted.');
        redirect('timetable');
    }

    public function print(): void
    {
        $this->layout = 'print';
        $sessionId = Session::get('active_session_id');
        $classId = (int) $this->getGet('class_id', 0);
        $sectionId = (int) $this->getGet('section_id', 0);
        $timetable = (new Timetable())->getClassTimetable($classId, $sectionId ?: null, $sessionId ?? 0);
        $this->view('timetable/print', ['pageTitle' => 'Print Timetable', 'timetable' => $timetable]);
    }
}