<?php
/**
 * Transport Controller
 * Manages school transport: vehicles, routes, pickup points, student assignments, and fees
 */
class TransportController extends Controller
{
    private Transport $transport;

    public function __construct()
    {
        parent::__construct();
        $this->transport = new Transport();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DASHBOARD / OVERVIEW
    // ══════════════════════════════════════════════════════════════════════════

    public function index(): void
    {
        $sessionId = (int) (Session::get('active_session_id') ?? 0);
        $routes    = [];
        $vehicles  = [];
        $stats     = [];

        try { $routes   = $this->transport->getAllRoutes(); }   catch (Exception $e) { error_log('Transport index routes: '   . $e->getMessage()); }
        try { $vehicles = $this->transport->getAllVehicles(); } catch (Exception $e) { error_log('Transport index vehicles: ' . $e->getMessage()); }
        try { $stats    = $this->transport->getTransportFeeStats($sessionId); } catch (Exception $e) { error_log('Transport index stats: ' . $e->getMessage()); }

        $this->view('transport/index', [
            'pageTitle' => 'Transport Management',
            'routes'    => $routes,
            'vehicles'  => $vehicles,
            'stats'     => $stats,
        ]);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // VEHICLES
    // ══════════════════════════════════════════════════════════════════════════

    public function vehicles(): void
    {
        $vehicles = [];
        try { $vehicles = $this->transport->getAllVehicles(); } catch (Exception $e) { error_log('Transport vehicles: ' . $e->getMessage()); Flash::error('Could not load vehicles. Please run the transport SQL migration.'); }

        // Drivers from non_teaching_staff (designation = Driver) for the dropdown
        $drivers = [];
        try { $drivers = (new NonTeachingStaff())->getDrivers(); } catch (Exception $e) {}

        $this->view('transport/vehicles', [
            'pageTitle' => 'Vehicles',
            'vehicles'  => $vehicles,
            'drivers'   => $drivers ?? [],
        ]);
    }

    public function saveVehicle(): void
    {
        if (!$this->isPost()) { redirect('transport/vehicles'); return; }

        $data      = Validator::sanitizeArray($_POST);
        $editingId = !empty($data['id']) ? (int) $data['id'] : 0;
        $addDriverToStaff = !empty($data['add_driver_to_staff']);
        unset($data['add_driver_to_staff']);

        // Check duplicate registration number before hitting the DB constraint
        $existing = $this->transport->getVehicleByNumber($data['vehicle_number'] ?? '');
        if ($existing && (int) $existing['id'] !== $editingId) {
            Flash::error('Registration number "' . ($data['vehicle_number'] ?? '') . '" is already used by another vehicle. Please enter a unique registration number.');
            redirect('transport/vehicles');
            return;
        }

        try {
            $id     = $this->transport->saveVehicle($data);
            $action = $editingId ? 'update_vehicle' : 'create_vehicle';
            Audit::log('transport', $action, (int) $id, $data);
            // Optionally add this driver to the Staff list so it syncs both ways.
            if ($addDriverToStaff && !empty($data['driver_name'])) {
                try { (new NonTeachingStaff())->ensureDriver($data['driver_name'], $data['driver_phone'] ?? null); } catch (Exception $e) {}
            }
            Flash::success('Vehicle saved successfully.');
        } catch (Exception $e) {
            $msg = $e->getMessage();
            if (strpos($msg, '1062') !== false || strpos($msg, 'Duplicate entry') !== false) {
                Flash::error('Registration number "' . ($data['vehicle_number'] ?? '') . '" already exists. Please use a unique number.');
            } else {
                Flash::error('Error saving vehicle: ' . $msg);
            }
        }

        redirect('transport/vehicles');
    }

    public function deleteVehicle(): void
    {
        $this->requirePost('transport/vehicles');
        $id = (int) ($this->getPost('id') ?? 0);
        if (!$id) { redirect('transport/vehicles'); return; }

        try {
            $this->transport->deleteVehicle($id);
            Audit::log('transport', 'delete_vehicle', $id);
            Flash::success('Vehicle deleted successfully.');
        } catch (Exception $e) {
            Flash::error('Cannot delete vehicle — it may be assigned to a route.');
        }

        redirect('transport/vehicles');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ROUTES
    // ══════════════════════════════════════════════════════════════════════════

    public function routes(): void
    {
        $routes   = [];
        $vehicles = [];
        try { $routes   = $this->transport->getAllRoutes(); }   catch (Exception $e) { error_log('Transport routes: '   . $e->getMessage()); Flash::error('Could not load routes. Please run the transport SQL migration.'); }
        try { $vehicles = $this->transport->getAllVehicles(); } catch (Exception $e) { error_log('Transport vehicles: ' . $e->getMessage()); }
        $drivers = [];
        try { $drivers = (new NonTeachingStaff())->getDrivers(); } catch (Exception $e) {}

        $this->view('transport/routes', [
            'pageTitle' => 'Vehicle Routes',
            'routes'    => $routes,
            'vehicles'  => $vehicles,
            'drivers'   => $drivers,
        ]);
    }

    public function saveRoute(): void
    {
        if (!$this->isPost()) { redirect('transport/routes'); return; }

        $data = Validator::sanitizeArray($_POST);
        if (empty($data['vehicle_id'])) $data['vehicle_id'] = null;
        $addDriverToStaff = !empty($data['add_driver_to_staff']);
        unset($data['add_driver_to_staff']);

        try {
            $id = $this->transport->saveRoute($data);
            $action = empty($_POST['id']) ? 'create_route' : 'update_route';
            Audit::log('transport', $action, (int) $id, $data);
            if ($addDriverToStaff && !empty($data['driver_name'])) {
                try { (new NonTeachingStaff())->ensureDriver($data['driver_name'], $data['driver_phone'] ?? null); } catch (Exception $e) {}
            }
            Flash::success('Route saved successfully.');
        } catch (Exception $e) {
            Flash::error('Error saving route: ' . $e->getMessage());
        }

        redirect('transport/routes');
    }

    public function deleteRoute(): void
    {
        $this->requirePost('transport/routes');
        $id = (int) ($this->getPost('id') ?? 0);
        if (!$id) { redirect('transport/routes'); return; }

        try {
            $this->transport->deleteRoute($id);
            Audit::log('transport', 'delete_route', $id);
            Flash::success('Route deleted successfully.');
        } catch (Exception $e) {
            Flash::error('Cannot delete route — students may be assigned to it.');
        }

        redirect('transport/routes');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PICKUP POINTS
    // ══════════════════════════════════════════════════════════════════════════

    public function pickupPoints(): void
    {
        $routeId      = $this->getGet('route_id') ? (int) $this->getGet('route_id') : null;
        $pickupPoints = [];
        $routes       = [];
        try { $pickupPoints = $this->transport->getPickupPoints($routeId); } catch (Exception $e) { error_log('Transport pickupPoints: ' . $e->getMessage()); Flash::error('Could not load pickup points. Please run the transport SQL migration.'); }
        try { $routes       = $this->transport->getAllRoutes(); }            catch (Exception $e) { error_log('Transport routes: '       . $e->getMessage()); }

        $this->view('transport/pickup-points', [
            'pageTitle'    => 'Pickup Points',
            'pickupPoints' => $pickupPoints,
            'routes'       => $routes,
            'filterRoute'  => $routeId,
        ]);
    }

    public function savePickupPoint(): void
    {
        if (!$this->isPost()) { redirect('transport/pickup-points'); return; }

        $data = Validator::sanitizeArray($_POST);

        try {
            $id = $this->transport->savePickupPoint($data);
            $action = empty($_POST['id']) ? 'create_pickup_point' : 'update_pickup_point';
            Audit::log('transport', $action, (int) $id, $data);
            Flash::success('Pickup point saved successfully.');
        } catch (Exception $e) {
            Flash::error('Error saving pickup point: ' . $e->getMessage());
        }

        redirect('transport/pickup-points');
    }

    public function deletePickupPoint(): void
    {
        $this->requirePost('transport/pickup-points');
        $id = (int) ($this->getPost('id') ?? 0);
        if (!$id) { redirect('transport/pickup-points'); return; }

        try {
            $this->transport->deletePickupPoint($id);
            Audit::log('transport', 'delete_pickup_point', $id);
            Flash::success('Pickup point deleted successfully.');
        } catch (Exception $e) {
            Flash::error('Cannot delete pickup point — students may be assigned to it.');
        }

        redirect('transport/pickup-points');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ASSIGN VEHICLE TO ROUTE  (handled in routes via vehicle_id field)
    // ROUTE WISE PICKUP & DROP
    // ══════════════════════════════════════════════════════════════════════════

    public function routeDetails(): void
    {
        $routeId = (int) ($this->getGet('id') ?? 0);
        if (!$routeId) { redirect('transport/routes'); return; }

        $sessionId    = (int) (Session::get('active_session_id') ?? 0);
        $route        = null;
        $pickupPoints = [];
        $students     = [];

        try {
            $data         = $this->transport->getRouteWithPickupPoints($routeId);
            $route        = $data['route'] ?? null;
            $pickupPoints = $data['pickup_points'] ?? [];
        } catch (Exception $e) {
            error_log('Transport routeDetails error (route/pickups): ' . $e->getMessage());
            Flash::error('Could not load route details. Please ensure the transport database tables are set up.');
        }

        if ($route && $sessionId) {
            try {
                $students = $this->transport->getStudentAssignments($sessionId, $routeId);
            } catch (Exception $e) {
                error_log('Transport routeDetails error (students): ' . $e->getMessage());
                $students = [];
            }
        }

        $this->view('transport/route-details', [
            'pageTitle'    => 'Route Details',
            'route'        => $route,
            'pickupPoints' => $pickupPoints,
            'students'     => $students,
        ]);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STUDENT TRANSPORT ASSIGNMENTS
    // ══════════════════════════════════════════════════════════════════════════

    public function studentTransport(): void
    {
        $sessionId   = (int) (Session::get('active_session_id') ?? 0);
        $routeId     = $this->getGet('route_id') ? (int) $this->getGet('route_id') : null;
        $assignments = [];
        $routes      = [];
        $students    = [];

        // Check whether student_transport_assignments table exists
        $tableExists = false;
        try {
            $check = $this->transport->rawOne(
                "SELECT 1 FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_transport_assignments'",
                []
            );
            $tableExists = !empty($check);
        } catch (\Exception $e) { /* ignore */ }

        if (!$tableExists) {
            Flash::error('Student transport table is missing. Please run the SQL migration file <strong>2026_06_21_transport_complete_fix.sql</strong> in phpMyAdmin.');
        } else {
            try {
                $assignments = $this->transport->getStudentAssignments($sessionId, $routeId);
            } catch (\Exception $e) {
                error_log('Transport studentTransport assignments: ' . $e->getMessage());
                Flash::error('Could not load student assignments. DB error: ' . htmlspecialchars($e->getMessage()));
            }
        }

        try { $routes = $this->transport->getAllRoutes(); } catch (\Exception $e) { error_log('Transport studentTransport routes: ' . $e->getMessage()); }
        try {
            $studentModel = new Student();
            $allStudents  = $studentModel->getStudentsWithDetails($sessionId, 1, 1000);
            $students     = $allStudents['data'] ?? [];
        } catch (\Exception $e) { error_log('Transport studentTransport students: ' . $e->getMessage()); }

        $this->view('transport/student-transport', [
            'pageTitle'   => 'Student Transport',
            'assignments' => $assignments,
            'routes'      => $routes,
            'students'    => $students,
            'filterRoute' => $routeId,
            'sessionId'   => $sessionId,
        ]);
    }

    public function saveStudentAssignment(): void
    {
        if (!$this->isPost()) { redirect('transport/student-transport'); return; }

        $data = Validator::sanitizeArray($_POST);
        $data['session_id'] = Session::get('active_session_id') ?? 0;
        if (empty($data['pickup_point_id'])) $data['pickup_point_id'] = null;

        try {
            $id = $this->transport->saveStudentAssignment($data);
            Audit::log('transport', 'assign_student', (int) $id, $data);
            Flash::success('Student transport assignment saved.');
        } catch (Exception $e) {
            Flash::error('Error saving assignment: ' . $e->getMessage());
        }

        redirect('transport/student-transport');
    }

    public function deleteStudentAssignment(): void
    {
        $this->requirePost('transport/student-transport');
        $id = (int) ($this->getPost('id') ?? 0);
        if (!$id) { redirect('transport/student-transport'); return; }

        try {
            $this->transport->deleteStudentAssignment($id);
            Audit::log('transport', 'remove_student_assignment', $id);
            Flash::success('Transport assignment removed.');
        } catch (Exception $e) {
            Flash::error('Error removing assignment.');
        }

        redirect('transport/student-transport');
    }

    public function getRoutePickupPoints(): void
    {
        $routeId = (int) ($this->getGet('route_id') ?? 0);
        $points  = $this->transport->getPickupPoints($routeId);
        $this->json(['points' => $points]);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TRANSPORT FEES
    // ══════════════════════════════════════════════════════════════════════════

    public function fees(): void
    {
        $sessionId = (int) (Session::get('active_session_id') ?? 0);
        $fees      = [];
        $stats     = [];
        $routes    = [];
        $students  = [];

        // Check whether the transport_fees table actually exists before querying it
        $tableExists = false;
        try {
            $check = $this->transport->rawOne(
                "SELECT 1 FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'transport_fees'",
                []
            );
            $tableExists = !empty($check);
        } catch (\Exception $e) { /* ignore */ }

        if (!$tableExists) {
            Flash::error('Transport Fees table is missing. Please run the SQL migration file <strong>2026_06_21_transport_complete_fix.sql</strong> in phpMyAdmin.');
        } else {
            try {
                $fees = $this->transport->getTransportFees($sessionId);
            } catch (\Exception $e) {
                error_log('Transport fees error: ' . $e->getMessage());
                Flash::error('Could not load transport fees. DB error: ' . htmlspecialchars($e->getMessage()));
            }
            try { $stats = $this->transport->getTransportFeeStats($sessionId); } catch (\Exception $e) { error_log('Transport stats: ' . $e->getMessage()); }
        }

        try { $routes = $this->transport->getAllRoutes(); } catch (\Exception $e) { error_log('Transport routes: ' . $e->getMessage()); }
        try {
            $studentModel = new Student();
            $allStudents  = $studentModel->getStudentsWithDetails($sessionId, 1, 1000);
            $students     = $allStudents['data'] ?? [];
        } catch (\Exception $e) { error_log('Transport fees students: ' . $e->getMessage()); }

        // Load fee rates (Dinod / Other / Custom)
        $feeRates   = [];
        $feeRateMap = [];
        try {
            $feeRates = $this->transport->getFeeRates();
            foreach ($feeRates as $fr) { $feeRateMap[$fr['fee_type']] = $fr; }
        } catch (\Exception $e) { error_log('Transport feeRates: ' . $e->getMessage()); }

        $this->view('transport/fees', [
            'pageTitle'   => 'Transport Fees',
            'fees'        => $fees,
            'stats'       => $stats,
            'routes'      => $routes,
            'students'    => $students,
            'sessionId'   => $sessionId,
            'tableExists' => $tableExists,
            'feeRates'    => $feeRates,
            'feeRateMap'  => $feeRateMap,
        ]);
    }

    // ── Fee Rate Settings (Dinod / Other / Custom) ─────────────────────────────

    public function saveFeeRate(): void
    {
        if (!$this->isPost()) { redirect('transport/fees'); return; }

        $data = Validator::sanitizeArray($_POST);

        $validTypes = ['Dinod', 'Other', 'Custom'];
        if (empty($data['fee_type']) || !in_array($data['fee_type'], $validTypes)) {
            Flash::error('Invalid fee type.');
            redirect('transport/fees');
            return;
        }

        try {
            // If no id supplied, check whether a row for this fee_type already exists
            if (empty($data['id'])) {
                $existing = $this->transport->getFeeRateByType($data['fee_type']);
                if ($existing) {
                    $data['id'] = $existing['id'];
                }
            }
            $id = $this->transport->saveFeeRate($data);
            Audit::log('transport', 'save_fee_rate', (int) $id, $data);
            Flash::success('Transport fee rate saved successfully.');
        } catch (Exception $e) {
            Flash::error('Error saving fee rate: ' . $e->getMessage());
        }

        redirect('transport/fees');
    }

    public function deleteFeeRate(): void
    {
        $this->requirePost('transport/fees');
        $id = (int) ($this->getPost('id') ?? 0);
        if (!$id) { redirect('transport/fees'); return; }

        try {
            $this->transport->deleteFeeRate($id);
            Audit::log('transport', 'delete_fee_rate', $id);
            Flash::success('Transport fee rate deleted.');
        } catch (Exception $e) {
            Flash::error('Error deleting fee rate: ' . $e->getMessage());
        }

        redirect('transport/fees');
    }

    // ─────────────────────────────────────────────────────────────────────────

    public function collectFee(): void
    {
        if (!$this->isPost()) { redirect('transport/fees'); return; }

        $data              = Validator::sanitizeArray($_POST);
        $data['session_id']= Session::get('active_session_id') ?? 0;
        $data['collected_by'] = Session::get('user_id');
        if (empty($data['bank_account_id'])) $data['bank_account_id'] = null;

        // Validate and default fee_type
        $validTypes = ['Dinod', 'Other', 'Custom'];
        if (empty($data['fee_type']) || !in_array($data['fee_type'], $validTypes)) {
            $data['fee_type'] = 'Other';
        }

        try {
            $id = $this->transport->collectTransportFee($data);
            Audit::log('transport', 'collect_fee', $id, $data);
            Flash::success('Transport fee collected successfully.');
        } catch (Exception $e) {
            Flash::error('Error collecting fee: ' . $e->getMessage());
        }

        redirect('transport/fees');
    }

    // ══════════════════════════════════════════════════════════════════════════
    // REPORTS
    // ══════════════════════════════════════════════════════════════════════════

    public function reports(): void
    {
        $sessionId    = (int) (Session::get('active_session_id') ?? 0);
        $routeSummary = [];
        $feeReport    = [];
        $unassigned   = [];
        $vehicleReport= [];
        $stats        = [];
        $routes       = [];

        try { $routeSummary  = $this->transport->getRouteSummaryReport($sessionId); } catch (Exception $e) { error_log('Transport reports routeSummary: '  . $e->getMessage()); }
        try { $feeReport     = $this->transport->getTransportFeeReport($sessionId); } catch (Exception $e) { error_log('Transport reports feeReport: '     . $e->getMessage()); }
        try { $unassigned    = $this->transport->getUnassignedStudents($sessionId); } catch (Exception $e) { error_log('Transport reports unassigned: '    . $e->getMessage()); }
        try { $vehicleReport = $this->transport->getVehicleReport(); }               catch (Exception $e) { error_log('Transport reports vehicleReport: '  . $e->getMessage()); }
        try { $stats         = $this->transport->getTransportFeeStats($sessionId); } catch (Exception $e) { error_log('Transport reports stats: '         . $e->getMessage()); }
        try { $routes        = $this->transport->getAllRoutes(); }                   catch (Exception $e) { error_log('Transport reports routes: '         . $e->getMessage()); }

        $this->view('transport/reports', [
            'pageTitle'    => 'Transport Reports',
            'routeSummary' => $routeSummary,
            'feeReport'    => $feeReport,
            'unassigned'   => $unassigned,
            'vehicleReport'=> $vehicleReport,
            'stats'        => $stats,
            'routes'       => $routes,
            'sessionId'    => $sessionId,
        ]);
    }
}
