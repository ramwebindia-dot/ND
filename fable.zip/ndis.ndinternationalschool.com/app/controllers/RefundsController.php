<?php
class RefundsController extends Controller
{
    public function index(): void
    {
        $this->requirePermission('refunds.view');
        $sessionId = Session::get('active_session_id');
        $refundModel = new Refund();
        $page = (int) $this->getGet('page', 1);
        $refunds = $refundModel->getRefunds($sessionId ?? 0, $page, 20);

        $this->view('refunds/index', [
            'pageTitle' => 'Fee Refunds',
            'refunds' => $refunds['data'],
            'pagination' => $refunds
        ]);
    }

    public function create(): void
    {
        if (!Permission::check('refunds.create')) { Flash::error('Permission denied.'); redirect('refunds'); return; }
        $feeCollectionId = (int) ($this->getGet('collection_id') ?? 0);
        $collection = null;
        $student = null;

        if ($feeCollectionId) {
            $fcModel = new Model();
            $fcModel->table = 'fee_collections';
            $collection = $fcModel->findById($feeCollectionId);
            if ($collection) {
                $studentModel = new Student();
                $student = $studentModel->getStudentWithDetails($collection['student_id']);
            }
        }

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $classModel = new ClassModel();
        $classes = $classModel->getBySession(Session::get('active_session_id') ?? 0);

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['session_id'] = Session::get('active_session_id');
            $data['approved_by'] = Session::get('user_id');

            // Validate voucher number uniqueness
            $checkModel = new Model();
            $checkModel->table = 'fee_refunds';
            $existing = $checkModel->findBy('refund_voucher_number', $data['refund_voucher_number']);
            if ($existing) {
                Flash::error('Refund voucher number already exists. Please enter a unique voucher number.');
            } else {
                try {
                    $refundModel = new Refund();
                    $id = $refundModel->processRefund($data);
                    Audit::log('refunds', 'create', $id, $data);
                    Flash::success('Refund processed successfully.');
                    redirect('refunds/voucher?id=' . $id);
                    return;
                } catch (Exception $e) {
                    Flash::error('Error processing refund: ' . $e->getMessage());
                }
            }
        }

        $this->view('refunds/create', [
            'pageTitle' => 'Process Refund',
            'collection' => $collection,
            'student' => $student,
            'banks' => $banks,
            'classes' => $classes,
            'feeCollectionId' => $feeCollectionId
        ]);
    }

    public function voucher(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $refundModel = new Refund();
        $refund = $refundModel->findById($id);
        if (!$refund) { Flash::error('Refund not found.'); redirect('refunds'); return; }

        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($refund['student_id']);

        $fcModel = new Model();
        $fcModel->table = 'fee_collections';
        $collection = $fcModel->findById($refund['fee_collection_id']);

        $this->view('refunds/voucher', [
            'pageTitle' => 'Refund Voucher',
            'refund' => $refund,
            'student' => $student,
            'collection' => $collection
        ]);
    }

    public function approve(): void
    {
        if (!Permission::check('refunds.approve')) { Flash::error('Permission denied.'); redirect('refunds'); return; }
        $id = (int) ($this->getGet('id') ?? 0);
        $refundModel = new Refund();
        $refund = $refundModel->findById($id);
        if (!$refund) { Flash::error('Refund not found.'); redirect('refunds'); return; }
        if ($refund['status'] === 'Processed') { Flash::error('Refund already processed.'); redirect('refunds'); return; }

        if ($this->isPost()) {
            $data = [
                'status' => 'Processed',
                'approved_by' => Session::get('user_id'),
                'refund_method' => $this->getPost('refund_method'),
                'bank_account_id' => $this->getPost('bank_account_id') ?: null,
            ];

            try {
                $refundModel->update($id, $data);

                $accountingModel = new Accounting();
                if ($data['refund_method'] === 'Cash') {
                    $accountingModel->addCashDebit((float)$refund['amount'], 'Refund - Voucher #' . $refund['refund_voucher_number'], date('Y-m-d'), $data['approved_by']);
                } else {
                    $accountingModel->addBankDebit($data['bank_account_id'], (float)$refund['amount'], 'Refund - Voucher #' . $refund['refund_voucher_number'], date('Y-m-d'), $data['approved_by']);
                }

                // Write immutable ledger entry and rebuild month status
                $feeModel = new Fee();
                $feeModel->recordRefundLedger(
                    (int)$refund['student_id'],
                    (int)$refund['session_id'],
                    (float)$refund['amount'],
                    $id,
                    'Refund - Voucher #' . $refund['refund_voucher_number'],
                    (int)$data['approved_by']
                );
                $feeModel->rebuildMonthStatus((int)$refund['student_id'], (int)$refund['session_id']);

                Audit::log('refunds', 'approve', $id, $data);
                Flash::success('Refund approved and processed.');
                redirect('refunds/voucher?id=' . $id);
                return;
            } catch (Exception $e) {
                Flash::error('Error approving refund: ' . $e->getMessage());
            }
        }

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($refund['student_id']);

        $this->view('refunds/approve', [
            'pageTitle' => 'Approve Refund',
            'refund' => $refund,
            'student' => $student,
            'banks' => $banks
        ]);
    }

    public function reject(): void
    {
        if (!Permission::check('refunds.approve')) { Flash::error('Permission denied.'); redirect('refunds'); return; }
        $this->requirePost('refunds');
        $id = (int) ($this->getPost('id') ?? 0);
        $refundModel = new Refund();
        $refund = $refundModel->findById($id);
        if (!$refund) { Flash::error('Refund not found.'); redirect('refunds'); return; }

        $refundModel->update($id, ['status' => 'Rejected']);
        Audit::log('refunds', 'reject', $id);
        Flash::success('Refund rejected.');
        redirect('refunds');
    }

    /** Credit refund amount to student's credit balance instead of cash/bank payout */
    public function creditToBalance(): void
    {
        if (!Permission::check('refunds.approve')) { Flash::error('Permission denied.'); redirect('refunds'); return; }
        $this->requirePost('refunds');
        $id = (int)($this->getPost('id') ?? 0);
        $refundModel = new Refund();
        $refund = $refundModel->findById($id);

        if (!$refund) { Flash::error('Refund not found.'); redirect('refunds'); return; }
        if ($refund['status'] === 'Processed') { Flash::error('Already processed.'); redirect('refunds'); return; }

        // Add to student credit balance
        $feeModel = new Fee();
        $feeModel->addCreditBalance(
            (int)$refund['student_id'],
            (int)$refund['session_id'],
            (float)$refund['amount'],
            'Credit from Refund #' . $refund['refund_voucher_number']
        );

        $refundModel->update($id, [
            'status'       => 'Processed',
            'refund_method'=> 'Credit Balance',
            'approved_by'  => Session::get('user_id'),
        ]);

        Audit::log('refunds', 'credit_to_balance', $id, ['amount' => $refund['amount']]);
        Flash::success('₹' . number_format($refund['amount'], 2) . ' credited to student balance.');
        redirect('refunds');
    }
}
