<?php
class AcademicController extends Controller
{
    public function classes(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getClassesWithDetails($sessionId ?? 0);
        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        $this->view('academic/classes', ['pageTitle' => 'Classes', 'classes' => $classes, 'teachers' => $teachers]);
    }

    /**
     * Handle "Add Class" form submission (POST academic/save-class)
     */
    public function saveClass(): void
    {
        $sessionId = Session::get('active_session_id');

        if ($this->isPost()) {
            $data = ['session_id' => $sessionId, 'name' => $this->getPost('name'), 'numeric_value' => $this->getPost('numeric_value'), 'class_teacher_id' => $this->getPost('class_teacher_id') ?: null];
            $classModel = new ClassModel();
            $classModel->create($data);
            Audit::log('academic', 'class_create', null, $data);
            Flash::success('Class created successfully.');
        }
        redirect('academic/classes');
    }

    /**
     * Edit an existing class (GET shows form, POST saves changes)
     */
    public function editClass(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $classModel = new ClassModel();
        $class = $classModel->findById($id);
        if (!$class) { Flash::error('Class not found.'); redirect('academic/classes'); return; }

        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        if ($this->isPost()) {
            $data = ['name' => $this->getPost('name'), 'numeric_value' => $this->getPost('numeric_value'), 'class_teacher_id' => $this->getPost('class_teacher_id') ?: null];
            $classModel->update($id, $data);
            Audit::log('academic', 'class_update', $id, $data);
            Flash::success('Class updated successfully.');
            redirect('academic/classes');
            return;
        }

        $this->view('academic/edit-class', ['pageTitle' => 'Edit Class', 'class' => $class, 'teachers' => $teachers]);
    }

    public function sections(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $sectionModel = new Section();

        $allSections = [];
        foreach ($classes as $class) {
            $allSections[$class['id']] = ['class' => $class, 'sections' => $sectionModel->getByClass($class['id'])];
        }
        $teachers = (new Teacher())->getActiveTeachers();
        $this->view('academic/sections', ['pageTitle' => 'Sections', 'classes' => $classes, 'allSections' => $allSections, 'teachers' => $teachers]);
    }

    /**
     * Handle "Add Section" form submission (POST academic/save-section)
     */
    public function saveSection(): void
    {
        if ($this->isPost()) {
            $data = ['class_id' => $this->getPost('class_id'), 'name' => $this->getPost('name'), 'capacity' => $this->getPost('capacity', 40), 'class_teacher_id' => $this->getPost('class_teacher_id') ?: null];
            $sectionModel = new Section();
            $sectionModel->create($data);
            Audit::log('academic', 'section_create', null, $data);
            Flash::success('Section created successfully.');
        }
        redirect('academic/sections');
    }

    public function subjects(): void
    {
        $sessionId = Session::get('active_session_id');
        $subjects  = (new Model())->raw(
            "SELECT s.*, c.name AS class_name, cs.class_id AS class_id
             FROM subjects s
             LEFT JOIN class_subjects cs ON cs.subject_id = s.id
             LEFT JOIN classes c ON cs.class_id = c.id
             ORDER BY c.name, s.name"
        );
        $classes = (new ClassModel())->getBySession($sessionId ?? 0);
        $this->view('academic/subjects', ['pageTitle' => 'Subjects', 'subjects' => $subjects, 'classes' => $classes]);
    }

    /**
     * Handle "Add Subject" form submission (POST academic/save-subject)
     */
    public function saveSubject(): void
    {
        if ($this->isPost()) {
            $data = [
                'class_id' => $this->getPost('class_id') ?: null,
                'name'     => $this->getPost('name'),
                'code'     => $this->getPost('code') ?: null,
                'type'     => $this->getPost('type', 'Theory'),
            ];
            $subjectModel = new Subject();
            $subjectModel->create($data);
            Audit::log('academic', 'subject_create', null, $data);
            Flash::success('Subject created successfully.');
        }
        redirect('academic/subjects');
    }

    public function allocation(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $subjectModel = new Subject();
        $subjects = $subjectModel->getAllSubjects();
        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();

        $allocations = (new Model())->raw("SELECT cs.*, c.name as class_name, s.name as subject_name, CONCAT(t.first_name, ' ', t.last_name) as teacher_name FROM class_subjects cs JOIN classes c ON cs.class_id = c.id JOIN subjects s ON cs.subject_id = s.id LEFT JOIN teachers t ON cs.teacher_id = t.id WHERE cs.session_id = :sid ORDER BY c.numeric_value, s.name", ['sid' => $sessionId ?? 0]);

        $this->view('academic/allocation', ['pageTitle' => 'Subject Allocation', 'classes' => $classes, 'subjects' => $subjects, 'teachers' => $teachers, 'allocations' => $allocations]);
    }

    /**
     * Handle "Allocate Subject" form submission (POST academic/save-allocation)
     */
    public function saveAllocation(): void
    {
        $sessionId = Session::get('active_session_id');

        if ($this->isPost()) {
            $data = ['class_id' => $this->getPost('class_id'), 'subject_id' => $this->getPost('subject_id'), 'teacher_id' => $this->getPost('teacher_id') ?: null, 'session_id' => $sessionId, 'is_elective' => (int)$this->getPost('is_elective', 0)];
            $csModel = new Model(); $csModel->table = 'class_subjects';
            $csModel->create($data);
            Audit::log('academic', 'subject_allocation', null, $data);
            Flash::success('Subject allocated successfully.');
        }
        redirect('academic/allocation');
    }

    /**
     * AJAX endpoint: list sections for a given class (used by dependent dropdowns)
     * GET academic/get-sections?class_id=
     */
    public function getSections(): void
    {
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $sectionModel = new Section();
        $sections = $classId ? $sectionModel->getByClass($classId) : [];
        $this->json($sections);
    }

    public function getSubjects(): void
    {
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $subjectModel = new Subject();
        $subjects = $classId
            ? $subjectModel->raw(
                "SELECT DISTINCT s.id, s.name, s.code FROM subjects s
                 JOIN class_subjects cs ON cs.subject_id = s.id
                 WHERE cs.class_id = :cid ORDER BY s.name",
                ['cid' => $classId]
              )
            : [];
        $this->json($subjects);
    }

    public function deleteClass(): void
    {
        $this->requirePost('academic/classes');
        $id = (int) ($this->getPost('id') ?? 0);
        (new ClassModel())->delete($id);
        Audit::log('academic', 'class_delete', $id);
        Flash::success('Class deleted.');
        redirect('academic/classes');
    }

    public function deleteSection(): void
    {
        $this->requirePost('academic/sections');
        $id = (int) ($this->getPost('id') ?? 0);
        (new Section())->delete($id);
        Audit::log('academic', 'section_delete', $id);
        Flash::success('Section deleted.');
        redirect('academic/sections');
    }

    public function updateSection(): void
    {
        $this->requirePost('academic/sections');
        $id      = (int)$this->getPost('id');
        $classId = (int)$this->getPost('class_id');
        $name    = trim($this->getPost('name', ''));
        if (!$id || !$classId || !$name) { Flash::error('Missing fields.'); redirect('academic/sections'); return; }
        $model = new Model(); $model->table = 'sections';
        $model->update($id, ['class_id' => $classId, 'name' => $name, 'class_teacher_id' => $this->getPost('class_teacher_id') ?: null]);
        Audit::log('academic', 'section_update', $id, ['name' => $name]);
        Flash::success('Section updated.');
        redirect('academic/sections');
    }

    public function deleteSubject(): void
    {
        $this->requirePost('academic/subjects');
        $id = (int) ($this->getPost('id') ?? 0);
        (new Subject())->delete($id);
        Audit::log('academic', 'subject_delete', $id);
        Flash::success('Subject deleted.');
        redirect('academic/subjects');
    }

    public function updateSubject(): void
    {
        $this->requirePost('academic/subjects');
        $id      = (int)$this->getPost('id');
        $classId = (int)$this->getPost('class_id');
        $name    = trim($this->getPost('name', ''));
        $code    = trim($this->getPost('code', ''));
        $type    = $this->getPost('type', 'Theory');
        if (!$id || !$classId || !$name) { Flash::error('Missing fields.'); redirect('academic/subjects'); return; }
        $model = new Model(); $model->table = 'subjects';
        $model->update($id, ['class_id' => $classId, 'name' => $name, 'code' => $code ?: null, 'type' => $type]);
        Audit::log('academic', 'subject_update', $id, ['name' => $name]);
        Flash::success('Subject updated.');
        redirect('academic/subjects');
    }

    public function deleteAllocation(): void
    {
        $this->requirePost('academic/allocation');
        $id = (int) ($this->getPost('id') ?? 0);
        $csModel = new Model(); $csModel->table = 'class_subjects';
        $csModel->delete($id);
        Audit::log('academic', 'allocation_delete', $id);
        Flash::success('Allocation removed.');
        redirect('academic/allocation');
    }
}