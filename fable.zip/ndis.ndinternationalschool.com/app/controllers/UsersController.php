<?php
class UsersController extends Controller
{
    // ── List ─────────────────────────────────────────────────────────

    public function index(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);

        $search  = trim($this->getGet('search') ?? '');
        $roleId  = (int)($this->getGet('role_id') ?? 0);
        $page    = max(1, (int)($this->getGet('page') ?? 1));
        $perPage = 20;

        $where  = 'WHERE 1=1';
        $params = [];

        if ($search) {
            $where .= ' AND (u.full_name LIKE :s OR u.email LIKE :s2 OR u.username LIKE :s3)';
            $params['s']  = "%$search%";
            $params['s2'] = "%$search%";
            $params['s3'] = "%$search%";
        }
        if ($roleId) {
            $where .= ' AND u.role_id = :rid';
            $params['rid'] = $roleId;
        }

        $model = new Model();
        $total = (int)$model->rawOne(
            "SELECT COUNT(*) AS cnt FROM users u $where", $params
        )['cnt'];

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $users = $model->raw(
            "SELECT u.*, r.name AS role_name
             FROM users u
             JOIN roles r ON r.id = u.role_id
             $where
             ORDER BY u.full_name ASC
             LIMIT :limit OFFSET :offset",
            $params
        );

        $roles = (new Role())->findAll('name');

        $this->view('users/index', [
            'pageTitle'  => 'User Management',
            'users'      => $users,
            'roles'      => $roles,
            'search'     => $search,
            'roleId'     => $roleId,
            'pagination' => [
                'page'        => $page,
                'per_page'    => $perPage,
                'total'       => $total,
                'total_pages' => max(1, ceil($total / $perPage)),
            ],
        ]);
    }

    // ── Create ────────────────────────────────────────────────────────

    public function create(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);

        $roles = (new Role())->findAll('name');

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);

            // Validate
            $email    = trim($data['email'] ?? '');
            $username = trim($data['username'] ?? '');
            $fullName = trim($data['full_name'] ?? '');
            $password = $this->getPost('password', '');
            $roleId   = (int)($data['role_id'] ?? 0);

            if (!$email || !$fullName || !$password || !$roleId) {
                Flash::error('All required fields must be filled.');
                $this->view('users/create', ['pageTitle' => 'Create User', 'roles' => $roles]);
                return;
            }

            $model = new Model();
            // Check email uniqueness
            $exists = $model->rawOne("SELECT id FROM users WHERE email = :e", ['e' => $email]);
            if ($exists) {
                Flash::error('Email already exists.');
                $this->view('users/create', ['pageTitle' => 'Create User', 'roles' => $roles]);
                return;
            }
            if ($username) {
                $exists2 = $model->rawOne("SELECT id FROM users WHERE username = :u", ['u' => $username]);
                if ($exists2) {
                    Flash::error('Username already taken.');
                    $this->view('users/create', ['pageTitle' => 'Create User', 'roles' => $roles]);
                    return;
                }
            }

            $userModel = new Model(); $userModel->table = 'users';
            $id = $userModel->create([
                'role_id'   => $roleId,
                'username'  => $username ?: null,
                'email'     => $email,
                'password'  => password_hash($password, PASSWORD_DEFAULT),
                'full_name' => $fullName,
                'phone'     => $data['phone'] ?? null,
                'is_active' => 1,
            ]);

            Audit::log('users', 'create', $id, ['email' => $email, 'role_id' => $roleId]);
            Flash::success("User \"$fullName\" created successfully.");
            redirect('users');
            return;
        }

        $this->view('users/create', ['pageTitle' => 'Create User', 'roles' => $roles]);
    }

    // ── Edit ──────────────────────────────────────────────────────────

    public function edit(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);

        $id    = (int)($this->getGet('id') ?? 0);
        $model = new Model();
        $user  = $model->rawOne(
            "SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = :id",
            ['id' => $id]
        );
        if (!$user) { Flash::error('User not found.'); redirect('users'); return; }

        $roles = (new Role())->findAll('name');

        if ($this->isPost()) {
            $data     = Validator::sanitizeArray($_POST);
            $email    = trim($data['email'] ?? '');
            $username = trim($data['username'] ?? '');
            $fullName = trim($data['full_name'] ?? '');
            $roleId   = (int)($data['role_id'] ?? 0);
            $password = $this->getPost('password', '');

            if (!$email || !$fullName || !$roleId) {
                Flash::error('Required fields missing.');
                $this->view('users/edit', ['pageTitle' => 'Edit User', 'user' => $user, 'roles' => $roles]);
                return;
            }

            // Check email unique excluding self
            $dup = $model->rawOne("SELECT id FROM users WHERE email = :e AND id != :id", ['e' => $email, 'id' => $id]);
            if ($dup) { Flash::error('Email already in use.'); $this->view('users/edit', ['pageTitle' => 'Edit User', 'user' => $user, 'roles' => $roles]); return; }

            $update = [
                'role_id'   => $roleId,
                'username'  => $username ?: null,
                'email'     => $email,
                'full_name' => $fullName,
                'phone'     => $data['phone'] ?? null,
            ];
            if ($password) {
                $update['password'] = password_hash($password, PASSWORD_DEFAULT);
            }

            $userModel = new Model(); $userModel->table = 'users';
            $userModel->update($id, $update);

            Audit::log('users', 'update', $id, ['email' => $email]);
            Flash::success('User updated successfully.');
            redirect('users');
            return;
        }

        $this->view('users/edit', ['pageTitle' => 'Edit User', 'user' => $user, 'roles' => $roles]);
    }

    // ── Toggle Active/Inactive ────────────────────────────────────────

    public function toggleActive(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $this->requirePost('users');

        $id        = (int)$this->getPost('id');
        $currentId = (int)Session::get('user_id');

        if ($id === $currentId) { Flash::error('You cannot deactivate your own account.'); redirect('users'); return; }

        $model = new Model(); $model->table = 'users';
        $user  = $model->findById($id);
        if (!$user) { Flash::error('User not found.'); redirect('users'); return; }

        $newStatus = $user['is_active'] ? 0 : 1;
        $model->update($id, ['is_active' => $newStatus]);

        Audit::log('users', $newStatus ? 'activate' : 'deactivate', $id);
        Flash::success('User ' . ($newStatus ? 'activated' : 'deactivated') . ' successfully.');
        redirect('users');
    }

    // ── Reset Password ────────────────────────────────────────────────

    public function resetPassword(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $this->requirePost('users');

        $id       = (int)$this->getPost('id');
        $password = $this->getPost('new_password', '');

        if (strlen($password) < 6) {
            Flash::error('Password must be at least 6 characters.');
            redirect('users/edit?id=' . $id);
            return;
        }

        $model = new Model(); $model->table = 'users';
        $model->update($id, ['password' => password_hash($password, PASSWORD_DEFAULT)]);

        Audit::log('users', 'reset_password', $id);
        Flash::success('Password reset successfully.');
        redirect('users');
    }

    // ── Delete ────────────────────────────────────────────────────────

    public function delete(): void
    {
        $this->requireRole(['Super Admin']);
        $this->requirePost('users');

        $id        = (int)$this->getPost('id');
        $currentId = (int)Session::get('user_id');

        if ($id === $currentId) { Flash::error('You cannot delete your own account.'); redirect('users'); return; }

        $model = new Model(); $model->table = 'users';
        $model->query("DELETE FROM users WHERE id = :id", ['id' => $id]);

        Audit::log('users', 'delete', $id);
        Flash::success('User deleted.');
        redirect('users');
    }
}
