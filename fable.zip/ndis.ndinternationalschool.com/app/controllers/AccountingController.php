<?php
class AccountingController extends Controller
{
    public function index(): void
    {
        $this->requirePermission('accounting.view');
        $accountingModel = new Accounting();
        $cashBalance = $accountingModel->getCashBalance();
        $totalBankBalance = $accountingModel->getTotalBankBalance();

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $this->view('accounting/index', [
            'pageTitle' => 'Cash & Bank Accounting',
            'cashBalance' => $cashBalance,
            'totalBankBalance' => $totalBankBalance,
            'banks' => $banks
        ]);
    }

    public function cashBook(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));
        $accountingModel = new Accounting();
        $entries = $accountingModel->getCashBook($dateFrom, $dateTo);
        $cashBalance = $accountingModel->getCashBalance();

        $this->view('accounting/cash-book', [
            'pageTitle' => 'Cash Book',
            'entries' => $entries,
            'cashBalance' => $cashBalance,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function bankBook(): void
    {
        $bankId = (int) ($this->getGet('bank_id') ?? 0);
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $entries = [];
        $bankBalance = 0;
        if ($bankId) {
            $accountingModel = new Accounting();
            $entries = $accountingModel->getBankBook($bankId, $dateFrom, $dateTo);
            $bankBalance = $accountingModel->getBankBalance($bankId);
        }

        $this->view('accounting/bank-book', [
            'pageTitle' => 'Bank Book',
            'entries' => $entries,
            'banks' => $banks,
            'bankId' => $bankId,
            'bankBalance' => $bankBalance,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function bankAccounts(): void
    {
        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAll('bank_name');

        $this->view('accounting/bank-accounts', [
            'pageTitle' => 'Bank Accounts',
            'banks' => $banks
        ]);
    }

    public function saveBankAccount(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['is_active'] = isset($data['is_active']) ? 1 : 0;

            try {
                $bankModel = new Model();
                $bankModel->table = 'bank_accounts';
                if (!empty($data['id'])) {
                    $bankModel->update((int)$data['id'], $data);
                    Audit::log('accounting', 'update_bank', (int)$data['id'], $data);
                    Flash::success('Bank account updated successfully.');
                } else {
                    $data['balance'] = $data['balance'] ?? 0;
                    $id = $bankModel->create($data);
                    Audit::log('accounting', 'create_bank', $id, $data);
                    Flash::success('Bank account created successfully.');
                }
            } catch (Exception $e) {
                Flash::error('Error saving bank account: ' . $e->getMessage());
            }
        }
        redirect('accounting/bank-accounts');
    }

    public function income(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));
        $accountingModel = new Accounting();
        $incomes = $accountingModel->getIncomeSummary($dateFrom, $dateTo);

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $this->view('accounting/income', [
            'pageTitle' => 'Income',
            'incomes' => $incomes,
            'banks' => $banks,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function saveIncome(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['created_by'] = Session::get('user_id');
            if (empty($data['bank_account_id'])) $data['bank_account_id'] = null;
            if (!isset($data['category']) || $data['category'] === '') $data['category'] = null;

            if (($data['payment_method'] ?? 'Cash') !== 'Cash' && empty($data['bank_account_id'])) {
                Flash::error('Please select a bank account for non-cash income.');
                redirect('accounting/income');
                return;
            }

            try {
                $accountingModel = new Accounting();
                $model = new Model();
                $model->table = 'income';
                $id = $model->create($data);

                // Update cash/bank ledger
                if ($data['payment_method'] === 'Cash') {
                    $accountingModel->addCashCredit((float)$data['amount'], 'Income - ' . $data['title'], $data['income_date'], $data['created_by']);
                } else {
                    $accountingModel->addBankCredit((int)$data['bank_account_id'], (float)$data['amount'], 'Income - ' . $data['title'], $data['income_date'], $data['created_by']);
                }

                // Record in the consolidated transactions log so it shows in
                // Accounting > All Transactions alongside fee collections/refunds.
                $transModel = new Model();
                $transModel->table = 'transactions';
                $transModel->create([
                    'type' => 'Income', 'category' => $data['category'] ?? null, 'reference_id' => $id,
                    'reference_type' => 'income',
                    'amount' => $data['amount'], 'payment_method' => $data['payment_method'],
                    'bank_account_id' => $data['bank_account_id'],
                    'description' => 'Income - ' . $data['title'],
                    'transaction_date' => $data['income_date'], 'created_by' => $data['created_by']
                ]);

                Audit::log('accounting', 'create_income', $id, $data);
                Flash::success('Income recorded successfully.');
            } catch (Exception $e) {
                Flash::error('Error recording income: ' . $e->getMessage());
            }
        }
        redirect('accounting/income');
    }

    public function expenses(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));
        $accountingModel = new Accounting();
        $expenseList = $accountingModel->getExpenseSummary($dateFrom, $dateTo);

        $bankModel = new Model();
        $bankModel->table = 'bank_accounts';
        $banks = $bankModel->findAllBy('is_active', 1);

        $this->view('accounting/expenses', [
            'pageTitle' => 'Expenses',
            'expenses' => $expenseList,
            'banks' => $banks,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function saveExpense(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['created_by'] = Session::get('user_id');
            if (empty($data['bank_account_id'])) $data['bank_account_id'] = null;
            if (!isset($data['category']) || $data['category'] === '') $data['category'] = null;

            if (($data['payment_method'] ?? 'Cash') !== 'Cash' && empty($data['bank_account_id'])) {
                Flash::error('Please select a bank account for non-cash expense.');
                redirect('accounting/expenses');
                return;
            }

            try {
                $accountingModel = new Accounting();
                $model = new Model();
                $model->table = 'expenses';
                $id = $model->create($data);

                // Update cash/bank ledger
                if ($data['payment_method'] === 'Cash') {
                    $accountingModel->addCashDebit((float)$data['amount'], 'Expense - ' . $data['title'], $data['expense_date'], $data['created_by']);
                } else {
                    $accountingModel->addBankDebit((int)$data['bank_account_id'], (float)$data['amount'], 'Expense - ' . $data['title'], $data['expense_date'], $data['created_by']);
                }

                // Record in the consolidated transactions log so it shows in
                // Accounting > All Transactions alongside fee collections/refunds.
                $transModel = new Model();
                $transModel->table = 'transactions';
                $transModel->create([
                    'type' => 'Expense', 'category' => $data['category'] ?? null, 'reference_id' => $id,
                    'reference_type' => 'expense',
                    'amount' => $data['amount'], 'payment_method' => $data['payment_method'],
                    'bank_account_id' => $data['bank_account_id'],
                    'description' => 'Expense - ' . $data['title'],
                    'transaction_date' => $data['expense_date'], 'created_by' => $data['created_by']
                ]);

                Audit::log('accounting', 'create_expense', $id, $data);
                Flash::success('Expense recorded successfully.');
            } catch (Exception $e) {
                Flash::error('Error recording expense: ' . $e->getMessage());
            }
        }
        redirect('accounting/expenses');
    }

    public function transactions(): void
    {
        $page = (int) $this->getGet('page', 1);
        $model = new Model();
        $model->table = 'transactions';
        $transactions = $model->paginate($page, 25, '', [], 'transaction_date DESC');

        $this->view('accounting/transactions', [
            'pageTitle' => 'Transactions',
            'transactions' => $transactions['data'],
            'pagination' => $transactions
        ]);
    }

    public function financialSummary(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));
        $accountingModel = new Accounting();
        $summary = $accountingModel->getFinancialSummary($dateFrom, $dateTo);
        $cashBalance = $accountingModel->getCashBalance();
        $totalBankBalance = $accountingModel->getTotalBankBalance();

        $this->view('accounting/summary', [
            'pageTitle' => 'Financial Summary',
            'summary' => $summary,
            'cashBalance' => $cashBalance,
            'totalBankBalance' => $totalBankBalance,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    /** Journal Entries — double-entry bookkeeping */
    public function journalEntries(): void
    {
        $accountingModel = new Accounting();

        if ($this->isPost()) {
            $data = $this->validateOrFail($_POST, [
                'entry_date'  => ['required'],
                'description' => ['required'],
                'debit_account'  => ['required'],
                'credit_account' => ['required'],
                'amount'      => ['required','numeric'],
            ], 'accounting/journal-entries');

            $ref = 'JE-' . date('Ymd') . '-' . rand(100,999);
            $journalModel = new Model(); $journalModel->table = 'journal_entries';
            $journalModel->create([
                'entry_date'     => $data['entry_date'],
                'reference'      => $ref,
                'description'    => $data['description'],
                'debit_account'  => $data['debit_account'],
                'credit_account' => $data['credit_account'],
                'amount'         => $data['amount'],
                'created_by'     => Session::get('user_id'),
            ]);
            Audit::log('accounting', 'journal_entry', null, ['ref' => $ref]);
            Flash::success('Journal entry recorded: ' . $ref);
            redirect('accounting/journal-entries');
            return;
        }

        $journalModel = new Model(); $journalModel->table = 'journal_entries';
        $entries = $journalModel->raw(
            "SELECT je.*, u.full_name as created_by_name FROM journal_entries je
             LEFT JOIN users u ON je.created_by = u.id ORDER BY je.entry_date DESC, je.id DESC LIMIT 100"
        );

        $accounts = ['Cash','Bank','Fee Income','Transport Fee','Library Fine','Salary Expense',
                     'Rent Expense','Stationery Expense','Miscellaneous Income','Miscellaneous Expense',
                     'Accounts Receivable','Accounts Payable'];

        $this->view('accounting/journal-entries', [
            'pageTitle' => 'Journal Entries',
            'entries'   => $entries,
            'accounts'  => $accounts,
        ]);
    }

    /** Profit & Loss Statement */
    public function profitLoss(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-01-01'));
        $dateTo   = $this->getGet('date_to',   date('Y-12-31'));
        $accModel = new Accounting();

        // Income: fee collections + other income
        $feeIncome = $accModel->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) as total FROM fee_payment_transactions
             WHERE payment_date BETWEEN :f AND :t AND status='Active'",
            ['f' => $dateFrom, 't' => $dateTo]
        )['total'] ?? 0;

        $otherIncome = $accModel->raw(
            "SELECT category, SUM(amount) as total FROM income
             WHERE income_date BETWEEN :f AND :t GROUP BY category ORDER BY total DESC",
            ['f' => $dateFrom, 't' => $dateTo]
        );

        $expenses = $accModel->raw(
            "SELECT category, SUM(amount) as total FROM expenses
             WHERE expense_date BETWEEN :f AND :t GROUP BY category ORDER BY total DESC",
            ['f' => $dateFrom, 't' => $dateTo]
        );

        $salary = $accModel->rawOne(
            "SELECT COALESCE(SUM(net_salary),0) as total FROM salary_payments
             WHERE DATE(created_at) BETWEEN :f AND :t AND status='Paid'",
            ['f' => $dateFrom, 't' => $dateTo]
        )['total'] ?? 0;

        $totalOtherIncome = array_sum(array_column($otherIncome, 'total'));
        $totalExpenses    = array_sum(array_column($expenses, 'total'));
        $totalIncome  = $feeIncome + $totalOtherIncome;
        $totalExpAll  = $totalExpenses + $salary;
        $netProfit    = $totalIncome - $totalExpAll;

        $this->view('accounting/profit-loss', [
            'pageTitle'        => 'Profit & Loss Statement',
            'dateFrom'         => $dateFrom,
            'dateTo'           => $dateTo,
            'feeIncome'        => $feeIncome,
            'otherIncome'      => $otherIncome,
            'totalOtherIncome' => $totalOtherIncome,
            'totalIncome'      => $totalIncome,
            'expenses'         => $expenses,
            'salary'           => $salary,
            'totalExpenses'    => $totalExpAll,
            'netProfit'        => $netProfit,
        ]);
    }

    /** Balance Sheet */
    public function balanceSheet(): void
    {
        $accModel = new Accounting();
        $cashBalance = $accModel->getCashBalance();
        $bankBalance = $accModel->getTotalBankBalance();

        // Outstanding fees = assets (receivable)
        $sessionId = Session::get('active_session_id') ?? 0;
        $feeModel  = new Fee();
        $outstanding = $feeModel->getTotalOutstanding($sessionId);

        $totalAssets = $cashBalance + $bankBalance + $outstanding;

        // Liabilities: salary payable
        $salaryPayable = $accModel->rawOne(
            "SELECT COALESCE(SUM(net_salary),0) as total FROM salary_payments WHERE status='Generated'"
        )['total'] ?? 0;

        $equity = $totalAssets - $salaryPayable;

        $this->view('accounting/balance-sheet', [
            'pageTitle'      => 'Balance Sheet',
            'cashBalance'    => $cashBalance,
            'bankBalance'    => $bankBalance,
            'outstanding'    => $outstanding,
            'totalAssets'    => $totalAssets,
            'salaryPayable'  => $salaryPayable,
            'equity'         => $equity,
            'date'           => date('d M Y'),
        ]);
    }
}
