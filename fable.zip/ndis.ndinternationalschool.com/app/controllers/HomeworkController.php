<?php
class HomeworkController extends Controller
{
    public function index(): void
    {
        $sessionId = Session::get('active_session_id');
        $homeworkModel = new Homework();
        $page = (int) $this->getGet('page', 1);
        $homework = $homeworkModel->getHomeworkWithDetails($sessionId ?? 0, $page, 20);

        $this->view('homework/index', [
            'pageTitle' => 'Homework',
            'homework' => $homework['data'],
            'pagination' => $homework
        ]);
    }

    public function create(): void
    {
        $sess     = (int)(Session::get('active_session_id') ?? 0);
        $roleName = Session::get('role_name');
        $isAdmin  = in_array($roleName, ['Super Admin', 'School Admin', 'Principal'], true);

        // Non-admins can only assign homework to sections where THEY are the class teacher.
        $myTeacherId   = 0;
        $myAssignments = [];
        if (!$isAdmin) {
            $t = (new Teacher())->rawOne("SELECT id FROM teachers WHERE user_id = :uid", ['uid' => Session::get('user_id')]);
            $myTeacherId = isset($t['id']) ? (int)$t['id'] : 0;
            $myAssignments = (new Model())->raw(
                "SELECT sec.id AS section_id, sec.name AS section_name, c.id AS class_id, c.name AS class_name
                 FROM sections sec JOIN classes c ON sec.class_id = c.id
                 WHERE sec.class_teacher_id = :tid AND c.session_id = :sess
                 ORDER BY c.numeric_value, sec.name",
                ['tid' => $myTeacherId, 'sess' => $sess]
            );
        }

        if ($this->isPost()) {
            // Resolve class/section. Teachers submit a combined "classId_sectionId" value.
            $classId   = (int)$this->getPost('class_id', 0);
            $sectionId = $this->getPost('section_id') ? (int)$this->getPost('section_id') : null;
            $tid       = null;
            if (!$isAdmin) {
                $cs        = explode('_', (string)$this->getPost('class_section', ''));
                $classId   = (int)($cs[0] ?? 0);
                $sectionId = !empty($cs[1]) ? (int)$cs[1] : null;
                $tid       = $myTeacherId ?: null;
                // ENFORCE server-side: this must be a section the teacher owns.
                $own = (new Model())->rawOne(
                    "SELECT id FROM sections WHERE id = :sid AND class_id = :cid AND class_teacher_id = :tid",
                    ['sid' => $sectionId ?: 0, 'cid' => $classId, 'tid' => $myTeacherId]
                );
                if (!$own) {
                    Flash::error('You can only assign homework to your own class & section.');
                    redirect('homework/create');
                    return;
                }
            }

            // File attachment -> stored in the `file_path` column
            $filePath = null;
            if (!empty($_FILES['attachment']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['attachment'], 'homework');
                if ($result['success']) $filePath = $result['file_path'];
            }

            $description = trim($this->getPost('description', ''));
            // Homework needs a description OR a file (no subject any more).
            if ($description === '' && !$filePath) {
                Flash::error('Please write a description or attach a file.');
                redirect('homework/create');
                return;
            }

            $hwData = [
                'class_id'    => $classId,
                'section_id'  => $sectionId,
                'session_id'  => $sess,
                'teacher_id'  => $tid,
                'title'       => trim($this->getPost('title', '')),
                'description' => $description ?: null,
                'file_path'   => $filePath,
                'deadline'    => $this->getPost('deadline') ?: null,
            ];

            try {
                $id = (new Homework())->create($hwData);
                Audit::log('homework', 'create', $id, $hwData);

                // Notify BOTH students and parents of that class/section
                try {
                    $userIds = array_merge(
                        NotificationService::getStudentUserIdsForClass($hwData['class_id'], $hwData['section_id'], $sess),
                        NotificationService::getParentUserIdsForClass($hwData['class_id'], $hwData['section_id'], $sess)
                    );
                    NotificationService::homeworkAssigned($userIds, $hwData['title'] ?: 'Homework', $hwData['deadline'] ?? '', $id);
                } catch (Exception $e) { error_log("HW notification: " . $e->getMessage()); }

                Flash::success('Homework assigned. Students & parents notified.');
                redirect('homework');
                return;
            } catch (Exception $e) {
                Flash::error('Error assigning homework: ' . $e->getMessage());
            }
        }

        $classes = $isAdmin ? (new ClassModel())->getBySession($sess) : [];
        $this->view('homework/create', [
            'pageTitle'     => 'Assign Homework',
            'classes'       => $classes,
            'isAdmin'       => $isAdmin,
            'myAssignments' => $myAssignments,
        ]);
    }

    public function edit(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $homeworkModel = new Homework();
        $hw = $homeworkModel->findById($id);
        if (!$hw) { Flash::error('Homework not found.'); redirect('homework'); return; }

        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            if (!empty($_FILES['attachment']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['attachment'], 'homework');
                if ($result['success']) $data['attachment'] = $result['file_path'];
            }
            $homeworkModel->update($id, $data);
            Audit::log('homework', 'update', $id, $data);
            Flash::success('Homework updated successfully.');
            redirect('homework');
            return;
        }

        $this->view('homework/edit', [
            'pageTitle' => 'Edit Homework',
            'hw' => $hw,
            'classes' => $classes
        ]);
    }

    public function delete(): void
    {
        $this->requirePost('homework');
        $id = (int) ($this->getPost('id') ?? 0);
        $homeworkModel = new Homework();
        $homeworkModel->delete($id);
        Audit::log('homework', 'delete', $id);
        Flash::success('Homework deleted successfully.');
        redirect('homework');
    }

    public function submissions(): void
    {
        $hwId = (int) ($this->getGet('id') ?? 0);
        $homeworkModel = new Homework();
        $hw = $homeworkModel->findById($hwId);
        if (!$hw) { Flash::error('Homework not found.'); redirect('homework'); return; }

        $subModel = new Model();
        $subModel->table = 'homework_submissions';
        $submissions = $subModel->raw("SELECT hs.*, s.first_name, s.last_name, s.admission_number
            FROM homework_submissions hs JOIN students s ON hs.student_id = s.id
            WHERE hs.homework_id = :hid ORDER BY hs.submitted_at DESC", ['hid' => $hwId]);

        $this->view('homework/submissions', [
            'pageTitle' => 'Homework Submissions',
            'hw' => $hw,
            'submissions' => $submissions
        ]);
    }

    public function submit(): void
    {
        if ($this->isPost()) {
            $homeworkId = (int) $this->getPost('homework_id');
            $studentId = (int) $this->getPost('student_id');
            $remarks = $this->getPost('remarks');
            $filePath = null;

            if (!empty($_FILES['file']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['file'], 'homework');
                if ($result['success']) $filePath = $result['file_path'];
            }

            try {
                $homeworkModel = new Homework();
                $homeworkModel->submitHomework($homeworkId, $studentId, $filePath, $remarks);
                Flash::success('Homework submitted successfully.');
            } catch (Exception $e) {
                Flash::error('Error submitting homework: ' . $e->getMessage());
            }
        }
        redirect('homework');
    }

    public function gradeSubmission(): void
    {
        if ($this->isPost()) {
            $subId = (int) $this->getPost('submission_id');
            $grade = $this->getPost('grade');
            $teacherRemarks = $this->getPost('teacher_remarks');

            $subModel = new Model();
            $subModel->table = 'homework_submissions';
            $subModel->update($subId, ['grade' => $grade, 'teacher_remarks' => $teacherRemarks, 'status' => 'Graded']);
            Audit::log('homework', 'grade_submission', $subId);
            Flash::success('Submission graded successfully.');
        }
        redirect('homework/submissions?id=' . $this->getPost('homework_id'));
    }
}
