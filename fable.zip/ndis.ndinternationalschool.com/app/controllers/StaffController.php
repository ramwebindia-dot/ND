<?php
class StaffController extends Controller
{
    // ── Index ──────────────────────────────────────────────────────

    public function index(): void
    {
        $this->requirePermission('staff.view');
        $model  = new NonTeachingStaff();
        $page   = (int) $this->getGet('page', 1);
        $search = $this->getGet('search', '');
        $status = $this->getGet('status', '');

        $result = $model->getAllWithDept($page, 20, $search, $status);

        $deptModel = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');

        $this->view('staff/index', [
            'pageTitle'   => 'Non-Teaching Staff',
            'staffList'   => $result['data'],
            'pagination'  => $result,
            'departments' => $departments,
            'search'      => $search,
            'status'      => $status,
        ]);
    }

    // ── Create ─────────────────────────────────────────────────────

    public function create(): void
    {
        $deptModel   = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');

        if ($this->isPost()) {
            CSRF::validate();
            $data = Validator::sanitizeArray($_POST);
            unset($data['csrf_token']);

            if (isset($data['date_of_birth'])) { $data['dob'] = $data['date_of_birth']; unset($data['date_of_birth']); }
            if (isset($data['mobile']))         { $data['phone'] = $data['mobile'];       unset($data['mobile']); }
            if (isset($data['joining_date']))   { $data['join_date'] = $data['joining_date']; unset($data['joining_date']); }

            $data['last_name']   = $data['last_name'] ?: null;
            $data['department_id'] = !empty($data['department_id']) ? (int)$data['department_id'] : null;
            $data['salary']      = !empty($data['salary']) ? (float)$data['salary'] : 0;
            $data['status']      = 'Active';
            $data['employee_id'] = 'NTS' . date('y') . strtoupper(substr(uniqid(), -5));

            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'staff');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            $model = new NonTeachingStaff();
            $id = $model->create($data);
            Audit::log('staff', 'create', $id, $data);
            Flash::success('Staff member added successfully.');
            redirect('staff');
            return;
        }

        $this->view('staff/create', [
            'pageTitle'   => 'Add Staff Member',
            'departments' => $departments,
        ]);
    }

    // ── Profile ────────────────────────────────────────────────────

    public function profile(): void
    {
        $id    = (int) $this->getGet('id', 0);
        $model = new NonTeachingStaff();
        $staff = $model->rawOne(
            "SELECT s.*, d.name AS department_name
             FROM non_teaching_staff s
             LEFT JOIN departments d ON s.department_id = d.id
             WHERE s.id = :id LIMIT 1",
            ['id' => $id]
        );
        if (!$staff) { Flash::error('Staff member not found.'); redirect('staff'); return; }

        $this->view('staff/profile', [
            'pageTitle' => 'Staff Profile',
            'staff'     => $staff,
        ]);
    }

    // ── Edit ───────────────────────────────────────────────────────

    public function edit(): void
    {
        $id    = (int) $this->getGet('id', 0);
        $model = new NonTeachingStaff();
        $staff = $model->findById($id);
        if (!$staff) { Flash::error('Staff member not found.'); redirect('staff'); return; }

        $deptModel   = new Model(); $deptModel->table = 'departments';
        $departments = $deptModel->findAll('name', 'ASC');

        if ($this->isPost()) {
            CSRF::validate();
            $data = Validator::sanitizeArray($_POST);
            unset($data['csrf_token']);

            if (isset($data['date_of_birth'])) { $data['dob'] = $data['date_of_birth']; unset($data['date_of_birth']); }
            if (isset($data['mobile']))         { $data['phone'] = $data['mobile'];       unset($data['mobile']); }
            if (isset($data['joining_date']))   { $data['join_date'] = $data['joining_date']; unset($data['joining_date']); }

            $data['last_name']     = $data['last_name'] ?: null;
            $data['department_id'] = !empty($data['department_id']) ? (int)$data['department_id'] : null;
            $data['salary']        = !empty($data['salary']) ? (float)$data['salary'] : 0;

            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'staff');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            $model->update($id, $data);
            Audit::log('staff', 'update', $id, $data);
            Flash::success('Staff member updated successfully.');
            redirect('staff/profile?id=' . $id);
            return;
        }

        $this->view('staff/edit', [
            'pageTitle'   => 'Edit Staff Member',
            'staff'       => $staff,
            'departments' => $departments,
        ]);
    }

    // ── Delete (soft — mark Resigned) ─────────────────────────────

    public function delete(): void
    {
        $this->requirePost('staff');
        $id    = (int) $this->getPost('id', 0);
        $model = new NonTeachingStaff();
        if (!$model->findById($id)) { Flash::error('Staff member not found.'); redirect('staff'); return; }

        $model->update($id, ['status' => 'Resigned']);
        Audit::log('staff', 'delete', $id);
        Flash::success('Staff member marked as resigned.');
        redirect('staff');
    }
}
