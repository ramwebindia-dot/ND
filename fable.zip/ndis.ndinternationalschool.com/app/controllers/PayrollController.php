<?php
class PayrollController extends Controller
{
    // ── Employee helpers (teaching + non-teaching unified) ─────────

    /**
     * Unified list of payable employees: active teachers + active non-teaching
     * staff. Each entry carries a `ref` ("teacher:5" / "nonteaching:3") used by
     * the forms, plus the resolved name / employee_id for display.
     */
    private function employeeList(): array
    {
        $out = [];
        foreach ((new Teacher())->getActiveTeachers() as $t) {
            $out[] = [
                'ref'         => 'teacher:' . $t['id'],
                'type'        => 'teacher',
                'id'          => (int)$t['id'],
                'name'        => trim($t['first_name'] . ' ' . ($t['last_name'] ?? '')),
                'employee_id' => $t['employee_id'] ?? '',
                'group'       => 'Teaching Staff',
            ];
        }
        foreach ((new NonTeachingStaff())->getActiveStaff() as $s) {
            $out[] = [
                'ref'         => 'nonteaching:' . $s['id'],
                'type'        => 'non_teaching',
                'id'          => (int)$s['id'],
                'name'        => trim($s['first_name'] . ' ' . ($s['last_name'] ?? '')),
                'employee_id' => $s['employee_id'] ?? '',
                'group'       => 'Non-Teaching Staff',
            ];
        }
        return $out;
    }

    /**
     * Parse a form employee ref into [staff_type, teacher_id|null, staff_id|null].
     * Accepts a bare number for backward compatibility (treated as a teacher).
     */
    private function parseEmployeeRef(string $ref): array
    {
        $ref = trim($ref);
        if (strpos($ref, ':') === false) {
            return ['teacher', (int)$ref ?: null, null];
        }
        [$type, $id] = explode(':', $ref, 2);
        if ($type === 'nonteaching') {
            return ['non_teaching', null, (int)$id ?: null];
        }
        return ['teacher', (int)$id ?: null, null];
    }

    /** Build the "ref" for an existing salary row so its option pre-selects. */
    private function refForRow(array $row): string
    {
        return ($row['staff_type'] ?? 'teacher') === 'non_teaching'
            ? 'nonteaching:' . ($row['staff_id'] ?? '')
            : 'teacher:' . ($row['teacher_id'] ?? '');
    }

    /** SELECT expression resolving employee name + code from either table. */
    private function empSelect(): string
    {
        return "COALESCE(NULLIF(TRIM(CONCAT(t.first_name,' ',COALESCE(t.last_name,''))),''),
                         TRIM(CONCAT(nts.first_name,' ',COALESCE(nts.last_name,'')))) AS teacher_name,
                COALESCE(t.employee_id, nts.employee_id) AS employee_id";
    }

    /** JOINs resolving the employee (and department) for a payroll table alias. */
    private function empJoin(string $a): string
    {
        return "LEFT JOIN teachers t ON $a.staff_type = 'teacher' AND $a.teacher_id = t.id
                LEFT JOIN non_teaching_staff nts ON $a.staff_type = 'non_teaching' AND $a.staff_id = nts.id
                LEFT JOIN departments d ON d.id = COALESCE(t.department_id, nts.department_id)";
    }

    // ── Index: Monthly Payroll Overview ───────────────────────────

    public function index(): void
    {
        $this->requirePermission('payroll.view');
        $month = (int)$this->getGet('month', date('n'));
        $year  = (int)$this->getGet('year',  date('Y'));

        $model   = new Model();
        $summary = $model->rawOne(
            "SELECT COUNT(*) as total_teachers,
                    SUM(CASE WHEN sp.status = 'Generated' THEN 1 ELSE 0 END) as generated,
                    SUM(CASE WHEN sp.status = 'Paid' THEN 1 ELSE 0 END) as paid,
                    SUM(CASE WHEN sp.status = 'Paid' THEN sp.net_salary ELSE 0 END) as total_paid,
                    SUM(CASE WHEN sp.status = 'Generated' THEN sp.net_salary ELSE 0 END) as pending_amount
             FROM salary_payments sp
             WHERE sp.month = :m AND sp.year = :y",
            ['m' => $month, 'y' => $year]
        );

        $payments = $model->raw(
            "SELECT sp.*, {$this->empSelect()}, d.name AS department_name
             FROM salary_payments sp
             {$this->empJoin('sp')}
             WHERE sp.month = :m AND sp.year = :y
             ORDER BY teacher_name",
            ['m' => $month, 'y' => $year]
        );

        $this->view('payroll/index', [
            'pageTitle' => 'Payroll Management',
            'month'     => $month,
            'year'      => $year,
            'summary'   => $summary,
            'payments'  => $payments,
        ]);
    }

    // ── Salary Structures ─────────────────────────────────────────

    public function structures(): void
    {
        $model      = new Model();
        $structures = $model->raw(
            "SELECT ss.*, {$this->empSelect()}, d.name AS department_name,
                    (ss.basic_salary + ss.hra + ss.da + ss.ta + ss.other_allowance) AS gross_salary,
                    (ss.pf_deduction + ss.esi_deduction + ss.tds_deduction + ss.other_deduction) AS total_deductions
             FROM salary_structures ss
             {$this->empJoin('ss')}
             WHERE ss.is_active = 1
             ORDER BY teacher_name"
        );

        $this->view('payroll/structures', [
            'pageTitle'  => 'Salary Structures',
            'structures' => $structures,
        ]);
    }

    public function setStructure(): void
    {
        $id      = $this->getGet('id') ? (int)$this->getGet('id') : null;
        $model   = new Model();

        if ($this->isPost()) {
            [$staffType, $teacherId, $staffId] = $this->parseEmployeeRef($this->getPost('employee_ref', ''));
            if (!$teacherId && !$staffId) {
                Flash::error('Please select an employee.');
                redirect('payroll/set-structure');
                return;
            }
            $data = [
                'staff_type'      => $staffType,
                'teacher_id'      => $teacherId,
                'staff_id'        => $staffId,
                'basic_salary'    => (float)$this->getPost('basic_salary', 0),
                'hra'             => (float)$this->getPost('hra', 0),
                'da'              => (float)$this->getPost('da', 0),
                'ta'              => (float)$this->getPost('ta', 0),
                'other_allowance' => (float)$this->getPost('other_allowance', 0),
                'pf_deduction'    => (float)$this->getPost('pf_deduction', 0),
                'esi_deduction'   => (float)$this->getPost('esi_deduction', 0),
                'tds_deduction'   => (float)$this->getPost('tds_deduction', 0),
                'other_deduction' => (float)$this->getPost('other_deduction', 0),
                'effective_from'  => $this->getPost('effective_from', date('Y-m-01')),
                'is_active'       => 1,
            ];

            try {
                // Deactivate any existing active structure for THIS employee.
                $model->query(
                    "UPDATE salary_structures SET is_active = 0
                     WHERE staff_type = :st AND teacher_id <=> :tid AND staff_id <=> :sid",
                    ['st' => $staffType, 'tid' => $teacherId, 'sid' => $staffId]
                );
                $ssModel = new Model(); $ssModel->table = 'salary_structures';
                $newId = $ssModel->create($data);
                Audit::log('payroll', 'set_structure', $newId, $data);
                Flash::success('Salary structure saved successfully.');
            } catch (Exception $e) {
                Flash::error('Error: ' . $e->getMessage());
            }
            redirect('payroll/structures');
            return;
        }

        $existing = $id ? $model->rawOne("SELECT * FROM salary_structures WHERE id = :id", ['id' => $id]) : null;

        $this->view('payroll/set-structure', [
            'pageTitle'   => $id ? 'Edit Salary Structure' : 'Set Salary Structure',
            'employees'   => $this->employeeList(),
            'existing'    => $existing,
            'existingRef' => $existing ? $this->refForRow($existing) : '',
        ]);
    }

    // ── Generate Payroll ──────────────────────────────────────────

    public function generate(): void
    {
        if ($this->isPost()) {
            $month = (int)$this->getPost('month');
            $year  = (int)$this->getPost('year');

            $model      = new Model();
            $employees  = $this->employeeList();
            $generated  = 0;
            $skipped    = 0;
            // Loss-of-pay is opt-in. Default OFF = fixed salary (unchanged behavior).
            // When ON, only EXPLICITLY marked Absent / Half Day records dock pay —
            // never unmarked days, so sparse attendance can't falsely reduce salaries.
            // LOP applies only to teachers (only teacher_attendance exists).
            $lopEnabled = (new Settings())->get('payroll_lop_enabled', '0') === '1';

            foreach ($employees as $emp) {
                $staffType = $emp['type'];
                $teacherId = $staffType === 'teacher'      ? $emp['id'] : null;
                $staffId   = $staffType === 'non_teaching' ? $emp['id'] : null;

                // Already generated?
                $existing = $model->rawOne(
                    "SELECT id FROM salary_payments
                     WHERE staff_type = :st AND teacher_id <=> :tid AND staff_id <=> :sid
                       AND month = :m AND year = :y",
                    ['st' => $staffType, 'tid' => $teacherId, 'sid' => $staffId, 'm' => $month, 'y' => $year]
                );
                if ($existing) { $skipped++; continue; }

                // Active salary structure for this employee.
                $structure = $model->rawOne(
                    "SELECT * FROM salary_structures
                     WHERE staff_type = :st AND teacher_id <=> :tid AND staff_id <=> :sid AND is_active = 1
                     ORDER BY effective_from DESC LIMIT 1",
                    ['st' => $staffType, 'tid' => $teacherId, 'sid' => $staffId]
                );
                if (!$structure) { $skipped++; continue; }

                $gross = $structure['basic_salary'] + $structure['hra'] + $structure['da'] + $structure['ta'] + $structure['other_allowance'];
                $baseDeductions = $structure['pf_deduction'] + $structure['esi_deduction'] + $structure['tds_deduction'] + $structure['other_deduction'];

                // Recover salary advances scheduled for this exact month/year.
                $advRows = $model->raw(
                    "SELECT id, amount FROM salary_advances
                     WHERE staff_type = :st AND teacher_id <=> :tid AND staff_id <=> :sid
                       AND status = 'Pending' AND deduction_month = :m AND deduction_year = :y",
                    ['st' => $staffType, 'tid' => $teacherId, 'sid' => $staffId, 'm' => $month, 'y' => $year]
                );
                $advanceDeduction = 0.0;
                foreach ($advRows as $a) { $advanceDeduction += (float)$a['amount']; }

                // Loss of pay from explicitly-marked absences (teachers only, when enabled).
                $workingDays = 26;
                $absentDays  = 0.0;
                if ($staffType === 'teacher') {
                    $absentDays = (float)($model->rawOne(
                        "SELECT COALESCE(SUM(CASE WHEN status='Absent' THEN 1
                                                  WHEN status='Half Day' THEN 0.5 ELSE 0 END),0) AS days
                         FROM teacher_attendance
                         WHERE teacher_id = :tid AND MONTH(date) = :m AND YEAR(date) = :y",
                        ['tid' => $teacherId, 'm' => $month, 'y' => $year]
                    )['days'] ?? 0);
                }
                $presentDays  = max(0, $workingDays - $absentDays);
                $lopDeduction = ($lopEnabled && $absentDays > 0)
                    ? round(($gross / $workingDays) * $absentDays, 2) : 0.0;

                $totalDeductions = $baseDeductions + $advanceDeduction + $lopDeduction;
                $net = $gross - $totalDeductions;

                $spModel = new Model(); $spModel->table = 'salary_payments';
                $spModel->create([
                    'staff_type'          => $staffType,
                    'teacher_id'          => $teacherId,
                    'staff_id'            => $staffId,
                    'salary_structure_id' => $structure['id'],
                    'month'               => $month,
                    'year'                => $year,
                    'basic_salary'        => $structure['basic_salary'],
                    'hra'                 => $structure['hra'],
                    'da'                  => $structure['da'],
                    'ta'                  => $structure['ta'],
                    'other_allowance'     => $structure['other_allowance'],
                    'gross_salary'        => $gross,
                    'pf_deduction'        => $structure['pf_deduction'],
                    'esi_deduction'       => $structure['esi_deduction'],
                    'tds_deduction'       => $structure['tds_deduction'],
                    'advance_deduction'   => $advanceDeduction,
                    'other_deduction'     => $structure['other_deduction'],
                    'total_deductions'    => $totalDeductions,
                    'net_salary'          => $net,
                    'working_days'        => $workingDays,
                    'present_days'        => $presentDays,
                    'status'              => 'Generated',
                    'generated_by'        => Session::get('user_id'),
                ]);

                // Mark the recovered advances as deducted so they aren't taken again.
                foreach ($advRows as $a) {
                    $model->query("UPDATE salary_advances SET status = 'Deducted' WHERE id = :id", ['id' => $a['id']]);
                }
                $generated++;
            }

            Audit::log('payroll', 'generate', null, ['month' => $month, 'year' => $year, 'generated' => $generated]);
            Flash::success("Payroll generated: $generated slips created, $skipped skipped (already exists or no structure).");
            redirect("payroll?month=$month&year=$year");
            return;
        }

        $this->view('payroll/generate', ['pageTitle' => 'Generate Payroll']);
    }

    // ── View / Edit a single salary slip ──────────────────────────

    public function slip(): void
    {
        $id    = (int)$this->getGet('id', 0);
        $model = new Model();
        $slip  = $model->rawOne(
            "SELECT sp.*, {$this->empSelect()},
                    COALESCE(t.qualification, nts.designation) AS designation,
                    COALESCE(t.phone, nts.phone) AS teacher_phone,
                    COALESCE(t.email, nts.email) AS teacher_email,
                    t.bank_name, t.bank_account_number, t.bank_ifsc,
                    d.name AS department_name
             FROM salary_payments sp
             {$this->empJoin('sp')}
             WHERE sp.id = :id",
            ['id' => $id]
        );
        if (!$slip) { Flash::error('Salary slip not found.'); redirect('payroll'); return; }

        $format = $this->getGet('format', 'html');
        if ($format === 'pdf') {
            $settings = (new Settings())->getAll();
            $html     = PDF::salarySlipHtml($slip, $settings);
            $filename = 'salary-slip-' . ($slip['employee_id'] ?? $id) . '-' . $slip['month'] . '-' . $slip['year'] . '.pdf';
            PDF::download($html, $filename, 'Salary Slip');
            return;
        }

        $this->view('payroll/slip', [
            'pageTitle' => 'Salary Slip',
            'slip'      => $slip,
        ]);
    }

    // ── Mark as Paid ──────────────────────────────────────────────

    public function markPaid(): void
    {
        $this->requirePost('payroll');
        $id = (int)$this->getPost('payment_id', 0);

        $model = new Model(); $model->table = 'salary_payments';
        $slip  = $model->findById($id);
        if (!$slip || $slip['status'] !== 'Generated') {
            Flash::error('Invalid payment or already processed.');
            redirect('payroll');
            return;
        }

        $data = [
            'status'           => 'Paid',
            'payment_method'   => $this->getPost('payment_method', 'Bank Transfer'),
            'payment_date'     => $this->getPost('payment_date', date('Y-m-d')),
            'reference_number' => $this->getPost('reference_number', ''),
            'bank_account_id'  => $this->getPost('bank_account_id') ? (int)$this->getPost('bank_account_id') : null,
            'remarks'          => $this->getPost('remarks', ''),
            'paid_by'          => Session::get('user_id'),
            'paid_at'          => date('Y-m-d H:i:s'),
        ];

        $model->update($id, $data);
        Audit::log('payroll', 'mark_paid', $id, $data);

        // SMS to the employee (teaching or non-teaching).
        $slipModel = new Model();
        $fullSlip  = $slipModel->rawOne(
            "SELECT sp.net_salary, sp.month, sp.year,
                    COALESCE(t.phone, nts.phone) AS phone,
                    {$this->empSelect()}
             FROM salary_payments sp
             {$this->empJoin('sp')}
             WHERE sp.id = :id",
            ['id' => $id]
        );
        if ($fullSlip && !empty($fullSlip['phone'])) {
            $monthNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
            SMS::salaryCredited(
                preg_replace('/\D/', '', $fullSlip['phone']),
                $fullSlip['teacher_name'] ?? '',
                (float)$fullSlip['net_salary'],
                ($monthNames[$fullSlip['month']] ?? '') . ' ' . $fullSlip['year']
            );
        }

        // Auto-post the salary payment into the Cash / Bank book (money going out).
        // No manual journal entry needed — the ledger reflects it automatically.
        try {
            $acc  = new Accounting();
            $net  = (float)($fullSlip['net_salary'] ?? $slip['net_salary'] ?? 0);
            $name = $fullSlip['teacher_name'] ?? ('Payment #' . $id);
            $desc = 'Salary - ' . trim($name) . ' (' . $slip['month'] . '/' . $slip['year'] . ')';
            if ($net > 0) {
                if (($data['payment_method'] ?? 'Cash') === 'Cash') {
                    $acc->addCashDebit($net, $desc, $data['payment_date'], (int)Session::get('user_id'));
                } else {
                    $acc->addBankDebit(
                        $data['bank_account_id'] ? (int)$data['bank_account_id'] : null,
                        $net, $desc, $data['payment_date'], (int)Session::get('user_id')
                    );
                }
            }
        } catch (Exception $e) { error_log('Payroll ledger post: ' . $e->getMessage()); }

        Flash::success('Salary marked as paid.');
        redirect('payroll?month=' . $slip['month'] . '&year=' . $slip['year']);
    }

    // ── Advances ──────────────────────────────────────────────────

    public function advances(): void
    {
        $model    = new Model();
        $advances = $model->raw(
            "SELECT sa.*, {$this->empSelect()}
             FROM salary_advances sa
             {$this->empJoin('sa')}
             ORDER BY sa.advance_date DESC LIMIT 100"
        );

        if ($this->isPost()) {
            [$staffType, $teacherId, $staffId] = $this->parseEmployeeRef($this->getPost('employee_ref', ''));
            if (!$teacherId && !$staffId) {
                Flash::error('Please select an employee.');
                redirect('payroll/advances');
                return;
            }
            $data = [
                'staff_type'       => $staffType,
                'teacher_id'       => $teacherId,
                'staff_id'         => $staffId,
                'amount'           => (float)$this->getPost('amount'),
                'reason'           => $this->getPost('reason', ''),
                'advance_date'     => $this->getPost('advance_date', date('Y-m-d')),
                'deduction_month'  => $this->getPost('deduction_month') ?: null,
                'deduction_year'   => $this->getPost('deduction_year') ?: null,
                'status'           => 'Pending',
                'approved_by'      => Session::get('user_id'),
            ];

            $advModel = new Model(); $advModel->table = 'salary_advances';
            $advModel->create($data);
            Audit::log('payroll', 'advance', null, $data);
            Flash::success('Advance salary recorded.');
            redirect('payroll/advances');
            return;
        }

        $this->view('payroll/advances', [
            'pageTitle' => 'Salary Advances',
            'employees' => $this->employeeList(),
            'advances'  => $advances,
        ]);
    }

    // ── Reports ───────────────────────────────────────────────────

    public function reports(): void
    {
        $year  = (int)$this->getGet('year', date('Y'));
        $model = new Model();

        $monthly = $model->raw(
            "SELECT month, year,
                    SUM(gross_salary) as total_gross,
                    SUM(total_deductions) as total_deductions,
                    SUM(net_salary) as total_net,
                    SUM(CASE WHEN status='Paid' THEN net_salary ELSE 0 END) as total_paid,
                    COUNT(*) as total_slips,
                    SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END) as paid_count
             FROM salary_payments
             WHERE year = :yr
             GROUP BY month, year
             ORDER BY month",
            ['yr' => $year]
        );

        $this->view('payroll/reports', [
            'pageTitle' => 'Payroll Reports',
            'year'      => $year,
            'monthly'   => $monthly,
        ]);
    }
}
