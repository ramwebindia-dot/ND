<?php
class SettingsController extends Controller
{
    public function index(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $this->school();
    }

    public function school(): void
    {
        $settingsModel = new Settings();
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);

            // Handle logo upload
            if (!empty($_FILES['school_logo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['school_logo'], 'documents');
                if ($result['success']) $data['school_logo'] = $result['file_path'];
            }

            try {
                $settingsModel->updateSettings($data);
                Audit::log('settings', 'update_school', null, $data);
                Flash::success('School settings updated successfully.');
            } catch (Exception $e) {
                Flash::error('Error updating settings: ' . $e->getMessage());
            }
        }

        $settings = $settingsModel->getAll();
        $this->view('settings/school', [
            'pageTitle' => 'School Settings',
            'settings' => $settings
        ]);
    }

    public function system(): void
    {
        $settingsModel = new Settings();
        if ($this->isPost()) {
            // Whitelist of allowed system setting keys
            $allowed = [
                'currency_symbol', 'date_format', 'timezone',
                'login_max_attempts', 'login_lockout_minutes',
                'session_lifetime', 'maintenance_mode',
            ];
            $data = [];
            foreach ($allowed as $key) {
                if (isset($_POST[$key])) {
                    $data[$key] = Validator::sanitize($_POST[$key]);
                }
            }
            try {
                $settingsModel->updateSettings($data);
                Audit::log('settings', 'update_system', null, $data);
                Flash::success('System settings updated successfully.');
            } catch (Exception $e) {
                Flash::error('Error updating settings: ' . $e->getMessage());
            }
        }

        $settings = $settingsModel->getAll();
        $this->view('settings/system', [
            'pageTitle' => 'System Settings',
            'settings' => $settings
        ]);
    }

    public function email(): void
    {
        $settingsModel = new Settings();
        if ($this->isPost()) {
            $allowed = [
                'smtp_enabled', 'smtp_host', 'smtp_port',
                'smtp_username', 'smtp_password',
                'smtp_from_email', 'smtp_from_name', 'smtp_encryption',
            ];
            $data = [];
            foreach ($allowed as $key) {
                $data[$key] = Validator::sanitize($_POST[$key] ?? '');
            }
            $data['smtp_enabled'] = isset($_POST['smtp_enabled']) ? '1' : '0';
            try {
                $settingsModel->updateSettings($data);
                Audit::log('settings', 'update_email', null);
                Flash::success('Email/SMTP settings updated successfully.');
            } catch (Exception $e) {
                Flash::error('Error: ' . $e->getMessage());
            }
        }

        $settings = $settingsModel->getAll();
        $this->view('settings/email', [
            'pageTitle' => 'Email / SMTP Settings',
            'settings' => $settings,
        ]);
    }

    public function testEmail(): void
    {
        if (!$this->isPost()) { redirect('settings/email'); return; }

        $toEmail = trim($this->getPost('test_email', ''));
        if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
            Flash::error('Please enter a valid email address.');
            redirect('settings/email');
            return;
        }

        $mailer = new Mailer();
        $body   = Mailer::buildTemplate('Test Email', '<p>This is a test email from <strong>' . e(APP_NAME) . '</strong>. Your SMTP configuration is working correctly!</p>');
        $sent   = $mailer->send($toEmail, $toEmail, 'Test Email - ' . APP_NAME, $body);

        if ($sent) {
            Flash::success("Test email sent to $toEmail successfully.");
        } else {
            Flash::error('Failed to send test email. Check SMTP settings and error.log.');
        }
        redirect('settings/email');
    }

    public function sms(): void
    {
        $settingsModel = new Settings();
        if ($this->isPost()) {
            $allowed = [
                'sms_enabled', 'sms_gateway',
                'sms_fast2sms_api_key', 'sms_fast2sms_sender_id', 'sms_fast2sms_dlt_entity',
                'sms_msg91_auth_key', 'sms_msg91_sender_id', 'sms_msg91_template_id',
                'sms_send_fee_reminder', 'sms_send_absence_alert',
                'sms_send_result_published', 'sms_send_salary_credited',
            ];
            $data = [];
            foreach ($allowed as $key) {
                $data[$key] = Validator::sanitize($_POST[$key] ?? '0');
            }
            $settingsModel->updateSettings($data);
            Audit::log('settings', 'update_sms', null, array_diff_key($data, ['sms_fast2sms_api_key' => 1, 'sms_msg91_auth_key' => 1]));
            Flash::success('SMS settings updated.');
            redirect('settings/sms');
            return;
        }

        $settings = $settingsModel->getAll();
        $this->view('settings/sms', ['pageTitle' => 'SMS Settings', 'settings' => $settings]);
    }

    public function testSMS(): void
    {
        $this->requirePost('settings/sms');
        $phone = preg_replace('/\D/', '', $this->getPost('test_phone', ''));
        if (!preg_match('/^[6-9]\d{9}$/', $phone)) {
            Flash::error('Invalid Indian mobile number. Enter 10-digit number.');
            redirect('settings/sms'); return;
        }
        $sent = SMS::send($phone, 'This is a test SMS from ' . APP_NAME . '. If you received this, SMS is working correctly.');
        if ($sent) {
            Flash::success("Test SMS sent to $phone successfully.");
        } else {
            Flash::error('Failed to send SMS. Check API key and error.log.');
        }
        redirect('settings/sms');
    }

    public function profile(): void
    {
        $userId = Session::get('user_id');
        $userModel = new User();
        $user = $userModel->findById($userId);

        if ($this->isPost()) {
            $data = [
                'full_name' => $this->getPost('full_name'),
                'email' => $this->getPost('email'),
                'mobile' => $this->getPost('mobile'),
            ];

            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'teachers');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            $userModel->update($userId, $data);
            Session::set('full_name', $data['full_name']);
            Audit::log('settings', 'update_profile', $userId, $data);
            Flash::success('Profile updated successfully.');
            redirect('settings/profile');
            return;
        }

        $this->view('settings/profile', [
            'pageTitle' => 'My Profile',
            'user' => $user
        ]);
    }

    /** Fee Configuration — late fee per day, fine rates, etc. */
    public function feeConfig(): void
    {
        $settingsModel = new Settings();
        if ($this->isPost()) {
            $keys = ['late_fee_per_day','late_fee_grace_days','library_fine_per_day',
                     'transport_late_fee_per_day','fee_due_day_of_month','allow_partial_payment',
                     'fee_receipt_prefix','advance_fee_months'];
            $data = [];
            foreach ($keys as $k) {
                $data[$k] = $this->getPost($k, '');
            }
            $settingsModel->updateSettings($data);
            Audit::log('settings', 'fee_config', null, $data);
            Flash::success('Fee configuration updated.');
            redirect('settings/fee-config');
            return;
        }
        $settings = $settingsModel->getAll();
        $this->view('settings/fee-config', ['pageTitle' => 'Fee Configuration', 'settings' => $settings]);
    }

    public function changePassword(): void
    {
        if ($this->isPost()) {
            $currentPassword = $this->getPost('current_password');
            $newPassword = $this->getPost('new_password');
            $confirmPassword = $this->getPost('confirm_password');

            $userId = Session::get('user_id');
            $userModel = new User();
            $user = $userModel->findById($userId);

            if (!$user) {
                Flash::error('User not found. Please log in again.');
                redirect('auth/login');
                return;
            }

            if (!password_verify($currentPassword, $user['password'])) {
                Flash::error('Current password is incorrect.');
            } elseif ($newPassword !== $confirmPassword) {
                Flash::error('New passwords do not match.');
            } elseif (strlen($newPassword) < 6) {
                Flash::error('Password must be at least 6 characters.');
            } else {
                $userModel->update($userId, ['password' => password_hash($newPassword, PASSWORD_DEFAULT)]);
                Audit::log('settings', 'change_password', $userId);
                Flash::success('Password changed successfully.');
            }
        }
        redirect('settings/profile');
    }
}
