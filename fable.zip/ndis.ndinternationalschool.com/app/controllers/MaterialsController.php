<?php
class MaterialsController extends Controller
{
    public function index(): void
    {
        $sessionId = Session::get('active_session_id');
        $materialModel = new Material();
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $subjectId = (int) ($this->getGet('subject_id') ?? 0);
        $materials = $materialModel->getMaterials($sessionId ?? 0, $classId ?: null, $subjectId ?: null);

        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        $this->view('materials/index', [
            'pageTitle' => 'Learning Materials',
            'materials' => $materials,
            'classes' => $classes,
            'classId' => $classId,
            'subjectId' => $subjectId
        ]);
    }

    public function create(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['session_id'] = $sessionId;
            $data['uploaded_by'] = Session::get('user_id');

            // Handle file upload
            if (!empty($_FILES['file_path']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['file_path'], 'documents');
                if ($result['success']) $data['file_path'] = $result['file_path'];
            }

            try {
                $materialModel = new Material();
                $id = $materialModel->create($data);
                Audit::log('materials', 'create', $id, $data);
                Flash::success('Learning material uploaded successfully.');
                redirect('materials');
                return;
            } catch (Exception $e) {
                Flash::error('Error uploading material: ' . $e->getMessage());
            }
        }

        $this->view('materials/create', [
            'pageTitle' => 'Upload Learning Material',
            'classes' => $classes
        ]);
    }

    public function edit(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $materialModel = new Material();
        $material = $materialModel->findById($id);
        if (!$material) { Flash::error('Material not found.'); redirect('materials'); return; }

        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            if (!empty($_FILES['file_path']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['file_path'], 'documents');
                if ($result['success']) $data['file_path'] = $result['file_path'];
            }
            $materialModel->update($id, $data);
            Audit::log('materials', 'update', $id, $data);
            Flash::success('Material updated successfully.');
            redirect('materials');
            return;
        }

        $this->view('materials/edit', [
            'pageTitle' => 'Edit Learning Material',
            'material' => $material,
            'classes' => $classes
        ]);
    }

    public function delete(): void
    {
        $this->requirePost('materials');
        $id = (int) ($this->getPost('id') ?? 0);
        $materialModel = new Material();
        $materialModel->delete($id);
        Audit::log('materials', 'delete', $id);
        Flash::success('Material deleted successfully.');
        redirect('materials');
    }

    public function download(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $materialModel = new Material();
        $material = $materialModel->findById($id);

        if (!$material || empty($material['file_path'])) {
            Flash::error('Material file not found.');
            redirect('materials');
            return;
        }

        $filepath = rtrim(UPLOAD_PATH, '/') . '/' . ltrim($material['file_path'], '/');
        if (!file_exists($filepath)) {
            Flash::error('Material file not found.');
            redirect('materials');
            return;
        }

        Audit::log('materials', 'download', $id);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }
}
