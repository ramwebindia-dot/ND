<?php
/**
 * Session Controller
 */
class SessionsController extends Controller
{
    public function index(): void
    {
        $this->requirePermission('academic.view');
        $sessionModel = new AcademicSession();
        $sessions = $sessionModel->findAll('name', 'DESC');
        $activeSession = $sessionModel->getActive();

        $this->view('sessions/index', [
            'pageTitle' => 'Academic Sessions',
            'sessions' => $sessions,
            'activeSession' => $activeSession,
        ]);
    }

    public function create(): void
    {
        if ($this->isPost()) {
            $data = [
                'name' => trim($this->getPost('name')),
                'start_date' => $this->getPost('start_date'),
                'end_date' => $this->getPost('end_date'),
                'is_active' => (int) $this->getPost('is_active', 0),
                'is_archived' => 0,
            ];

            $validator = new Validator($data);
            $validator->required('name', 'Session Name')->required('start_date', 'Start Date')->required('end_date', 'End Date');

            if (!$validator->validate()) {
                Flash::error($validator->getFirstError());
                redirect('sessions');
                return;
            }

            $sessionModel = new AcademicSession();
            $id = $sessionModel->create($data);

            if ($data['is_active']) {
                $sessionModel->activate($id);
            }

            Audit::log('sessions', 'create', $id, $data);
            Flash::success('Academic session created successfully.');
            redirect('sessions');
        }

        $this->view('sessions/create', ['pageTitle' => 'Create Session']);
    }

    public function edit(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $sessionModel = new AcademicSession();
        $session = $sessionModel->findById($id);

        if (!$session) {
            Flash::error('Session not found.');
            redirect('sessions');
            return;
        }

        if ($this->isPost()) {
            $data = [
                'name' => trim($this->getPost('name')),
                'start_date' => $this->getPost('start_date'),
                'end_date' => $this->getPost('end_date'),
            ];

            $sessionModel->update($id, $data);
            Audit::log('sessions', 'update', $id, $data);
            Flash::success('Session updated successfully.');
            redirect('sessions');
        }

        $this->view('sessions/edit', ['pageTitle' => 'Edit Session', 'session' => $session]);
    }

    public function activate(): void
    {
        $this->requirePost('sessions');
        $id = (int) ($this->getPost('id') ?? 0);
        $sessionModel = new AcademicSession();
        $sessionModel->activate($id);
        Session::set('active_session_id', $id);
        Audit::log('sessions', 'activate', $id);
        Flash::success('Session activated successfully.');
        redirect('sessions');
    }

    public function archive(): void
    {
        $this->requirePost('sessions');
        $id = (int) ($this->getPost('id') ?? 0);
        $sessionModel = new AcademicSession();
        $sessionModel->archive($id);
        Audit::log('sessions', 'archive', $id);
        Flash::success('Session archived successfully.');
        redirect('sessions');
    }

    public function promote(): void
    {
        $sessionModel = new AcademicSession();
        $sessions = $sessionModel->getActiveSessions();

        if ($this->isPost()) {
            $fromSessionId = (int) $this->getPost('from_session_id');
            $toSessionId = (int) $this->getPost('to_session_id');
            $studentIds = $this->getPost('student_ids', []);

            if (empty($studentIds)) {
                Flash::error('Please select students to promote.');
                redirect('sessions/promote');
                return;
            }

            $count = $sessionModel->promoteStudents($fromSessionId, $toSessionId, $studentIds);
            Audit::log('sessions', 'promote', null, ['from' => $fromSessionId, 'to' => $toSessionId, 'count' => $count]);
            Flash::success("$count students promoted successfully.");
            redirect('sessions');
            return;
        }

        $activeSession = $sessionModel->getActive();
        $students = [];
        if ($activeSession) {
            $studentModel = new Student();
            $students = $studentModel->findAllBy('session_id', $activeSession['id'], 'class_id, first_name');
        }

        $this->view('sessions/promote', [
            'pageTitle' => 'Promote Students',
            'sessions' => $sessions,
            'activeSession' => $activeSession,
            'students' => $students,
        ]);
    }
}
