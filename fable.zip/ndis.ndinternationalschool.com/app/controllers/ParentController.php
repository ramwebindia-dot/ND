<?php
class ParentController extends Controller
{
    // ═══════════════════════════════════════════════════════════════
    //  PARENT PORTAL (role = Parent)
    // ═══════════════════════════════════════════════════════════════

    public function index(): void
    {
        $role = Session::get('role_name');
        if ($role === 'Parent') {
            $this->dashboard();
        } else {
            $this->manage();
        }
    }

    public function dashboard(): void
    {
        $userId      = Session::get('user_id');
        $parentModel = new ParentModel();
        $parent      = $parentModel->findBy('user_id', $userId);

        if (!$parent) {
            Flash::error('Parent profile not found. Please contact the administrator.');
            Auth::logout();
            redirect('auth/login');
            return;
        }

        $studentModel = new Student();
        $sessionId    = Session::get('active_session_id');
        $children     = $studentModel->raw(
            "SELECT s.*, c.name as class_name, sec.name as section_name
             FROM students s
             LEFT JOIN classes c ON s.class_id = c.id
             LEFT JOIN sections sec ON s.section_id = sec.id
             WHERE s.parent_id = :pid AND s.session_id = :sid AND s.status = 'Active'",
            ['pid' => $parent['id'], 'sid' => $sessionId ?? 0]
        );

        $commModel = new Communication();
        $notices   = $commModel->getActiveNotices('Parent');

        $this->view('parent/dashboard', [
            'pageTitle' => 'Parent Dashboard',
            'parent'    => $parent,
            'children'  => $children,
            'notices'   => $notices,
        ]);
    }

    /** Verify that logged-in parent owns the given student. Returns parent row or redirects. */
    private function verifyParentOwnsChild(int $studentId): ?array
    {
        if (Session::get('role_name') !== 'Parent') return []; // admins skip check

        $parentModel = new ParentModel();
        $parent      = $parentModel->findBy('user_id', Session::get('user_id'));
        if (!$parent) { Flash::error('Parent profile not found.'); redirect('parent'); return null; }

        $studentModel = new Student();
        $student = $studentModel->findById($studentId);
        if (!$student || (int)$student['parent_id'] !== (int)$parent['id']) {
            Flash::error('Access denied.');
            redirect('parent');
            return null;
        }
        return $parent;
    }

    public function childProfile(): void
    {
        $studentId    = (int)($this->getGet('id') ?? 0);
        if ($this->verifyParentOwnsChild($studentId) === null) return;

        $studentModel = new Student();
        $student      = $studentModel->getStudentWithDetails($studentId);
        if (!$student) { Flash::error('Student not found.'); redirect('parent'); return; }

        $sessionId   = Session::get('active_session_id');
        $outstanding = $studentModel->getOutstandingBalance($studentId, $sessionId ?? 0);

        $this->view('parent/child-profile', [
            'pageTitle'   => 'Child Profile',
            'student'     => $student,
            'outstanding' => $outstanding,
        ]);
    }

    public function childAttendance(): void
    {
        $studentId = (int)($this->getGet('id') ?? 0);
        if ($this->verifyParentOwnsChild($studentId) === null) return;
        $month     = $this->getGet('month', date('m'));
        $year      = $this->getGet('year', date('Y'));

        $attendanceModel = new Attendance();
        $attendance = $attendanceModel->raw(
            "SELECT * FROM student_attendance WHERE student_id = :sid AND MONTH(date) = :month AND YEAR(date) = :year ORDER BY date",
            ['sid' => $studentId, 'month' => $month, 'year' => $year]
        );

        $studentModel = new Student();
        $student      = $studentModel->getStudentWithDetails($studentId);
        if (!$student) { Flash::error('Student not found.'); redirect('dashboard'); return; }

        $this->view('parent/child-attendance', [
            'pageTitle'  => 'Child Attendance',
            'student'    => $student,
            'attendance' => $attendance,
            'month'      => $month,
            'year'       => $year,
        ]);
    }

    public function childMarks(): void
    {
        $studentId = (int)($this->getGet('id') ?? 0);
        if ($this->verifyParentOwnsChild($studentId) === null) return;
        $sessionId = Session::get('active_session_id');

        $markModel = new Mark();
        $marks = $markModel->raw(
            "SELECT m.*, e.name as exam_name, s.name as subject_name
             FROM marks m
             JOIN exams e ON m.exam_id = e.id
             JOIN subjects s ON m.subject_id = s.id
             WHERE m.student_id = :sid AND e.session_id = :sess
             ORDER BY e.start_date, s.name",
            ['sid' => $studentId, 'sess' => $sessionId ?? 0]
        );

        $studentModel = new Student();
        $student      = $studentModel->getStudentWithDetails($studentId);
        if (!$student) { Flash::error('Student not found.'); redirect('dashboard'); return; }

        $this->view('parent/child-marks', [
            'pageTitle' => 'Child Marks',
            'student'   => $student,
            'marks'     => $marks,
        ]);
    }

    public function childFees(): void
    {
        $studentId = (int)($this->getGet('id') ?? 0);
        if ($this->verifyParentOwnsChild($studentId) === null) return;
        $sessionId = Session::get('active_session_id');

        $studentModel = new Student();
        $student      = $studentModel->getStudentWithDetails($studentId);
        if (!$student) { Flash::error('Student not found.'); redirect('dashboard'); return; }
        $ledger       = $studentModel->getStudentFeeLedger($studentId, $sessionId ?? 0);
        $outstanding  = $studentModel->getOutstandingBalance($studentId, $sessionId ?? 0);

        $this->view('parent/child-fees', [
            'pageTitle'   => 'Child Fees',
            'student'     => $student,
            'ledger'      => $ledger,
            'outstanding' => $outstanding,
        ]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  ADMIN SIDE — Parent Management
    // ═══════════════════════════════════════════════════════════════

    public function manage(): void
    {
        $parentModel = new ParentModel();
        $page   = (int)$this->getGet('page', 1);
        $search = $this->getGet('search', '');
        $result = $parentModel->getAllParents($page, 20, $search);

        $this->view('parent/manage', [
            'pageTitle'  => 'Parent Management',
            'parents'    => $result['data'],
            'pagination' => $result,
            'search'     => $search,
        ]);
    }

    public function viewParent(): void
    {
        $id          = (int)($this->getGet('id') ?? 0);
        $parentModel = new ParentModel();
        $parent      = $parentModel->getWithChildren($id);

        if (!$parent) { Flash::error('Parent not found.'); redirect('parent/manage'); return; }

        $this->view('parent/view', [
            'pageTitle' => 'Parent Details',
            'parent'    => $parent,
        ]);
    }

    public function editParent(): void
    {
        $id          = (int)($this->getGet('id') ?? 0);
        $parentModel = new ParentModel();
        $parent      = $parentModel->findById($id);
        if (!$parent) { Flash::error('Parent not found.'); redirect('parent/manage'); return; }

        if ($this->isPost()) {
            $allowed = [
                'father_name','father_phone','father_email','father_occupation',
                'mother_name','mother_phone','mother_email','mother_occupation',
                'guardian_name','guardian_phone','guardian_email','guardian_relation',
                'address','city','state','pincode',
            ];
            $data = [];
            foreach ($allowed as $field) {
                $data[$field] = Validator::sanitize($_POST[$field] ?? '');
            }
            $parentModel->update($id, $data);
            Audit::log('parents', 'update', $id, $data);
            Flash::success('Parent details updated.');
            redirect('parent/viewParent?id=' . $id);
            return;
        }

        $this->view('parent/edit', [
            'pageTitle' => 'Edit Parent',
            'parent'    => $parent,
        ]);
    }

    public function createLogin(): void
    {
        $this->requirePost('parent/manage');

        $parentId = (int)$this->getPost('parent_id');
        $email    = trim($this->getPost('email', ''));
        $pass     = $this->getPost('password', '');

        if (!$parentId || !$email || !$pass) {
            Flash::error('Parent ID, email, and password are required.');
            redirect('parent/viewParent?id=' . $parentId);
            return;
        }

        $parentModel = new ParentModel();
        $parent = $parentModel->findById($parentId);
        if (!$parent) { Flash::error('Parent not found.'); redirect('parent/manage'); return; }

        if ($parent['user_id']) {
            Flash::error('This parent already has a login account.');
            redirect('parent/viewParent?id=' . $parentId);
            return;
        }

        $roleModel  = new Model(); $roleModel->table = 'roles';
        $parentRole = $roleModel->findBy('name', 'Parent');
        if (!$parentRole) {
            Flash::error('Parent role not found. Please create a "Parent" role first.');
            redirect('parent/viewParent?id=' . $parentId);
            return;
        }

        $userModel = new User();
        try {
            $userId = $userModel->createUser([
                'role_id'   => $parentRole['id'],
                'email'     => $email,
                'password'  => $pass,
                'full_name' => $parent['father_name'] ?? 'Parent',
                'phone'     => $parent['father_phone'] ?? null,
                'is_active' => 1,
            ]);
            $parentModel->update($parentId, ['user_id' => $userId]);
            Audit::log('parents', 'create_login', $parentId, ['email' => $email]);
            Flash::success('Login account created successfully for this parent.');
        } catch (Exception $e) {
            Flash::error('Error: ' . $e->getMessage());
        }
        redirect('parent/viewParent?id=' . $parentId);
    }

    public function deleteLogin(): void
    {
        $this->requirePost('parent/manage');
        $parentId = (int)$this->getPost('parent_id');
        $parentModel = new ParentModel();
        $parent = $parentModel->findById($parentId);
        if (!$parent || !$parent['user_id']) { redirect('parent/manage'); return; }

        $userModel = new User();
        $userModel->update((int)$parent['user_id'], ['is_active' => 0]);
        $parentModel->update($parentId, ['user_id' => null]);
        Audit::log('parents', 'delete_login', $parentId);
        Flash::success('Parent login account removed.');
        redirect('parent/viewParent?id=' . $parentId);
    }
}
