<?php
class ExamsController extends Controller
{
    // ── List ──────────────────────────────────────────────────────
    public function index(): void
    {
        $this->requirePermission('exams.view');
        $sessionId = Session::get('active_session_id');
        $examModel = new Exam();
        $exams     = $examModel->getExamsWithClass($sessionId ?? 0);
        $this->view('exams/index', ['pageTitle' => 'Examinations', 'exams' => $exams]);
    }

    // ── Create ────────────────────────────────────────────────────
    public function create(): void
    {
        $sessionId  = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes    = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            $examModel = new Exam();
            $data = [
                'name'        => $this->getPost('name'),
                'exam_type'   => $this->getPost('exam_type', 'Other'),
                'class_id'    => (int)$this->getPost('class_id'),
                'section_id'  => $this->getPost('section_id') ?: null,
                'session_id'  => $sessionId,
                'start_date'  => $this->getPost('start_date'),
                'end_date'    => $this->getPost('end_date'),
                'description' => $this->getPost('description', ''),
                'status'      => $this->getPost('status', 'Upcoming'),
            ];
            $id = $examModel->create($data);

            // Save per-subject schedules
            $this->saveSchedules($id);

            Audit::log('exams', 'create', $id, $data);
            Flash::success('Exam created successfully.');
            redirect('exams/edit?id=' . $id);
            return;
        }

        $subjectModel = new Subject();
        $subjects     = $subjectModel->getAllSubjects();
        $this->view('exams/create', [
            'pageTitle' => 'Create Exam',
            'classes'   => $classes,
            'subjects'  => $subjects,
        ]);
    }

    // ── Edit (exam + schedule) ────────────────────────────────────
    public function edit(): void
    {
        $id        = (int)($this->getGet('id') ?? 0);
        $examModel = new Exam();
        $exam      = $examModel->getExamWithSchedule($id);
        if (!$exam) { Flash::error('Exam not found.'); redirect('exams'); return; }

        $sessionId  = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes    = $classModel->getBySession($sessionId ?? 0);
        $sections   = (new Section())->getByClass((int)$exam['class_id']);

        if ($this->isPost()) {
            $data = [
                'name'        => $this->getPost('name'),
                'exam_type'   => $this->getPost('exam_type', 'Other'),
                'class_id'    => (int)$this->getPost('class_id'),
                'section_id'  => $this->getPost('section_id') ?: null,
                'start_date'  => $this->getPost('start_date'),
                'end_date'    => $this->getPost('end_date'),
                'description' => $this->getPost('description', ''),
                'status'      => $this->getPost('status', 'Upcoming'),
            ];
            $examModel->update($id, $data);

            // Re-save schedules (delete + re-insert)
            $examModel->query("DELETE FROM exam_schedules WHERE exam_id = :eid", ['eid' => $id]);
            $this->saveSchedules($id);

            Audit::log('exams', 'update', $id, $data);
            Flash::success('Exam updated.');
            redirect('exams/edit?id=' . $id);
            return;
        }

        // Subjects for this class
        $subjectModel = new Subject();
        $subjects = $subjectModel->raw(
            "SELECT s.* FROM subjects s
             JOIN class_subjects sa ON sa.subject_id = s.id
             WHERE sa.class_id = :cid AND sa.session_id = :sess
             ORDER BY s.name",
            ['cid' => (int)$exam['class_id'], 'sess' => $sessionId ?? 0]
        );
        if (empty($subjects)) {
            $subjects = $subjectModel->getAllSubjects();
        }

        $this->view('exams/edit', [
            'pageTitle' => 'Edit Exam',
            'exam'      => $exam,
            'classes'   => $classes,
            'sections'  => $sections,
            'subjects'  => $subjects,
        ]);
    }

    // ── Marks Entry ───────────────────────────────────────────────
    public function marksEntry(): void
    {
        $sessionId    = Session::get('active_session_id');
        $examModel    = new Exam();
        $exams        = $examModel->getExamsWithClass($sessionId ?? 0);
        $selectedExam = (int)$this->getGet('exam_id', $this->getPost('exam_id', 0));

        if ($this->isPost() && $selectedExam) {
            $marksData = $this->getPost('marks', []);
            $markModel = new Mark();
            $count     = $markModel->saveBulk($selectedExam, $marksData);
            Audit::log('exams', 'marks_entry', $selectedExam, ['count' => $count]);
            Flash::success("$count marks saved successfully.");
            redirect("exams/marks-entry?exam_id=$selectedExam");
            return;
        }

        $students = [];
        $subjects = [];
        $exam     = null;
        $existingMarks = [];

        if ($selectedExam) {
            $exam = $examModel->getExamWithSchedule($selectedExam);
            if ($exam) {
                $studentModel  = new Student();
                $studentsData  = $studentModel->getStudentsWithDetails(
                    $sessionId ?? 0, 1, 500, '', $exam['class_id'], $exam['section_id'] ?? null
                );
                $students = $studentsData['data'];
                $subjects = $exam['schedules'] ?? [];

                // Load existing marks
                $markModel = new Mark();
                foreach ($students as $s) {
                    $rows = $markModel->getStudentMarks($selectedExam, (int)$s['id']);
                    foreach ($rows as $m) {
                        $existingMarks[$s['id']][$m['subject_id']] = $m['marks_obtained'];
                    }
                }
            }
        }

        $this->view('exams/marks-entry', [
            'pageTitle'     => 'Marks Entry',
            'exams'         => $exams,
            'selectedExam'  => $selectedExam,
            'exam'          => $exam,
            'students'      => $students,
            'subjects'      => $subjects,
            'existingMarks' => $existingMarks,
        ]);
    }

    // ── Report Card ───────────────────────────────────────────────
    public function reportCard(): void
    {
        $sessionId       = Session::get('active_session_id');
        $examModel       = new Exam();
        $exams           = $examModel->getExamsWithClass($sessionId ?? 0);
        $selectedExam    = (int)$this->getGet('exam_id', 0);
        $selectedStudent = (int)$this->getGet('student_id', 0);
        $marks           = [];
        $student         = null;
        $rank            = 0;
        $classStudents   = [];

        if ($selectedExam) {
            // Student search by admission_number or name
            $search = trim($this->getGet('search', ''));
            if ($search && !$selectedStudent) {
                $studentModel = new Student();
                $found = $studentModel->rawOne(
                    "SELECT id FROM students WHERE (admission_number = :s OR first_name LIKE :sl OR last_name LIKE :sl2)
                     AND session_id = :sess LIMIT 1",
                    ['s' => $search, 'sl' => "%$search%", 'sl2' => "%$search%", 'sess' => $sessionId ?? 0]
                );
                if ($found) $selectedStudent = (int)$found['id'];
            }

            if ($selectedStudent) {
                $markModel    = new Mark();
                $marks        = $markModel->getStudentMarks($selectedExam, $selectedStudent);
                $studentModel = new Student();
                $student      = $studentModel->getStudentWithDetails($selectedStudent);
                if ($student) {
                    $rank = $examModel->getStudentRank($selectedExam, $selectedStudent, (int)$student['class_id']);
                }
            }

            // For PDF download
            if ($this->getGet('format') === 'pdf' && $student && !empty($marks)) {
                $this->reportCardPdf($student, $marks, $rank, $exams, $selectedExam);
                return;
            }
        }

        $this->view('exams/report-card', [
            'pageTitle'       => 'Report Card',
            'exams'           => $exams,
            'selectedExam'    => $selectedExam,
            'selectedStudent' => $selectedStudent,
            'marks'           => $marks,
            'student'         => $student,
            'rank'            => $rank,
        ]);
    }

    // ── Class Results (all students) ──────────────────────────────
    public function classResults(): void
    {
        $sessionId    = Session::get('active_session_id');
        $examModel    = new Exam();
        $exams        = $examModel->getExamsWithClass($sessionId ?? 0);
        $selectedExam = (int)$this->getGet('exam_id', 0);
        $results      = [];
        $exam         = null;

        if ($selectedExam) {
            $exam    = $examModel->findById($selectedExam);
            $results = $examModel->getClassResults($selectedExam, (int)($exam['class_id'] ?? 0));
        }

        $this->view('exams/class-results', [
            'pageTitle'    => 'Class Results',
            'exams'        => $exams,
            'selectedExam' => $selectedExam,
            'exam'         => $exam,
            'results'      => $results,
        ]);
    }

    // ── Hall Ticket ───────────────────────────────────────────────
    public function hallTicket(): void
    {
        $selectedExam    = (int)$this->getGet('exam_id', 0);
        $selectedStudent = (int)$this->getGet('student_id', 0);
        $sessionId       = Session::get('active_session_id');
        $examModel       = new Exam();
        $exams           = $examModel->getExamsWithClass($sessionId ?? 0);
        $exam            = null;
        $student         = null;
        $schedules       = [];

        // search by admission number
        $search = trim($this->getGet('search', ''));
        if ($search && !$selectedStudent) {
            $studentModel = new Student();
            $found = $studentModel->rawOne(
                "SELECT id FROM students WHERE admission_number = :s AND session_id = :sess LIMIT 1",
                ['s' => $search, 'sess' => $sessionId ?? 0]
            );
            if ($found) $selectedStudent = (int)$found['id'];
        }

        if ($selectedExam) {
            $exam      = $examModel->getExamWithSchedule($selectedExam);
            $schedules = $exam['schedules'] ?? [];
            if ($selectedStudent) {
                $studentModel = new Student();
                $student      = $studentModel->getStudentWithDetails($selectedStudent);
            }
        }

        if ($this->getGet('format') === 'pdf' && $exam && $student) {
            $this->hallTicketPdf($exam, $student, $schedules, (new Settings())->getAll());
            return;
        }

        $this->view('exams/hall-ticket', [
            'pageTitle'       => 'Hall Ticket',
            'exams'           => $exams,
            'selectedExam'    => $selectedExam,
            'selectedStudent' => $selectedStudent,
            'exam'            => $exam,
            'student'         => $student,
            'schedules'       => $schedules,
            'search'          => $search,
        ]);
    }

    // ── Publish Results ───────────────────────────────────────────
    public function publishResults(): void
    {
        $this->requirePost('exams');
        $examId    = (int)$this->getPost('exam_id', 0);
        $examModel = new Exam();
        $exam      = $examModel->findById($examId);
        if (!$exam) { Flash::error('Exam not found.'); redirect('exams'); return; }

        $examModel->update($examId, ['status' => 'Completed']);

        // Notify students in the class
        $studentModel  = new Student();
        $sessionId     = Session::get('active_session_id');
        $students      = $studentModel->raw(
            "SELECT user_id FROM students WHERE class_id = :cid AND session_id = :sess AND status = 'Active' AND user_id IS NOT NULL",
            ['cid' => $exam['class_id'], 'sess' => $sessionId ?? 0]
        );
        $userIds = array_column($students, 'user_id');
        if ($userIds) {
            NotificationService::resultsPublished($userIds, $exam['name']);
        }

        Audit::log('exams', 'publish_results', $examId);
        Flash::success('Results published and students notified.');
        redirect('exams/class-results?exam_id=' . $examId);
    }

    // ── Delete ────────────────────────────────────────────────────
    public function delete(): void
    {
        $this->requirePost('exams');
        $id = (int)($this->getPost('id') ?? 0);
        (new Exam())->query("DELETE FROM exam_schedules WHERE exam_id = :eid", ['eid' => $id]);
        (new Exam())->delete($id);
        Audit::log('exams', 'delete', $id);
        Flash::success('Exam deleted.');
        redirect('exams');
    }

    // ── AJAX: sections for class ──────────────────────────────────
    public function getSections(): void
    {
        $classId  = (int)$this->getGet('class_id', 0);
        $sections = (new Section())->getByClass($classId);
        header('Content-Type: application/json');
        echo json_encode($sections);
        exit;
    }

    // ── Private helpers ───────────────────────────────────────────

    private function saveSchedules(int $examId): void
    {
        $subjects    = $this->getPost('subjects', []);
        $examDates   = $this->getPost('exam_dates', []);
        $startTimes  = $this->getPost('start_times', []);
        $endTimes    = $this->getPost('end_times', []);
        $totalMarks  = $this->getPost('total_marks', []);
        $passMarks   = $this->getPost('pass_marks', []);

        $schedModel = new Model(); $schedModel->table = 'exam_schedules';
        foreach ($subjects as $i => $subjectId) {
            if (!$subjectId || empty($examDates[$i])) continue;
            $schedModel->create([
                'exam_id'       => $examId,
                'subject_id'    => (int)$subjectId,
                'exam_date'     => $examDates[$i],
                'start_time'    => $startTimes[$i] ?? '09:00',
                'end_time'      => $endTimes[$i]   ?? '12:00',
                'total_marks'   => (float)($totalMarks[$i] ?? 100),
                'passing_marks' => (float)($passMarks[$i]  ?? 33),
            ]);
        }
    }

    private function reportCardPdf(array $student, array $marks, int $rank, array $exams, int $examId): void
    {
        $examName = '';
        foreach ($exams as $e) { if ((int)$e['id'] === $examId) { $examName = $e['name']; break; } }
        $settings = (new Settings())->getAll();

        $totalMax  = array_sum(array_column($marks, 'total_marks'));
        $totalObt  = array_sum(array_column($marks, 'marks_obtained'));
        $pct       = $totalMax > 0 ? round($totalObt / $totalMax * 100, 1) : 0;
        $allPass   = true;
        foreach ($marks as $m) {
            if ((float)$m['marks_obtained'] < (float)($m['passing_marks'] ?? 33)) { $allPass = false; break; }
        }

        ob_start();
        include APP_ROOT . '/app/views/exams/report-card-pdf.php';
        $html = ob_get_clean();
        PDF::download($html, 'report-card-' . ($student['admission_number'] ?? $student['id']) . '.pdf', 'Report Card');
    }

    private function hallTicketPdf(array $exam, array $student, array $schedules, array $settings): void
    {
        ob_start();
        include APP_ROOT . '/app/views/exams/hall-ticket-pdf.php';
        $html = ob_get_clean();
        PDF::download($html, 'hall-ticket-' . ($student['admission_number'] ?? $student['id']) . '.pdf', 'Hall Ticket');
    }
}
