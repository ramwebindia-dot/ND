<?php
class LibraryController extends Controller
{
    public function index(): void
    {
        $libraryModel = new Library();
        $search = $this->getGet('search', '');
        $categoryId = (int) ($this->getGet('category_id') ?? 0);

        if ($search || $categoryId) {
            $where = '1=1';
            $params = [];
            if ($search) {
                $where .= ' AND (b.title LIKE :search OR b.author LIKE :search2 OR b.isbn LIKE :search3)';
                $params['search'] = "%$search%";
                $params['search2'] = "%$search%";
                $params['search3'] = "%$search%";
            }
            if ($categoryId) {
                $where .= ' AND b.category_id = :cid';
                $params['cid'] = $categoryId;
            }
            $books = $libraryModel->raw("SELECT b.*, bc.name as category_name FROM books b LEFT JOIN book_categories bc ON b.category_id = bc.id WHERE $where ORDER BY b.title ASC", $params);
        } else {
            $books = $libraryModel->getBooksWithCategory();
        }

        $catModel = new Model();
        $catModel->table = 'book_categories';
        $categories = $catModel->findAll('name');

        $this->view('library/index', [
            'pageTitle' => 'Library - Book Catalog',
            'books' => $books,
            'categories' => $categories,
            'search' => $search,
            'categoryId' => $categoryId
        ]);
    }

    public function saveBook(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);

            try {
                $libraryModel = new Library();
                if (!empty($data['id'])) {
                    $libraryModel->update((int)$data['id'], $data);
                    Audit::log('library', 'update_book', (int)$data['id'], $data);
                    Flash::success('Book updated successfully.');
                } else {
                    $data['available_quantity'] = $data['total_quantity'] ?? 0;
                    $id = $libraryModel->create($data);
                    Audit::log('library', 'create_book', $id, $data);
                    Flash::success('Book added successfully.');
                }
            } catch (Exception $e) {
                Flash::error('Error saving book: ' . $e->getMessage());
            }
        }
        redirect('library');
    }

    public function deleteBook(): void
    {
        $this->requirePost('library');
        $id = (int) ($this->getPost('id') ?? 0);
        $libraryModel = new Library();
        $libraryModel->delete($id);
        Audit::log('library', 'delete_book', $id);
        Flash::success('Book deleted successfully.');
        redirect('library');
    }

    public function categories(): void
    {
        $catModel = new Model();
        $catModel->table = 'book_categories';
        $categories = $catModel->findAll('name');

        $this->view('library/categories', [
            'pageTitle' => 'Book Categories',
            'categories' => $categories
        ]);
    }

    public function saveCategory(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            try {
                $catModel = new Model();
                $catModel->table = 'book_categories';
                if (!empty($data['id'])) {
                    $catModel->update((int)$data['id'], $data);
                    Audit::log('library', 'update_category', (int)$data['id'], $data);
                    Flash::success('Category updated successfully.');
                } else {
                    $id = $catModel->create($data);
                    Audit::log('library', 'create_category', $id, $data);
                    Flash::success('Category created successfully.');
                }
            } catch (Exception $e) {
                Flash::error('Error saving category: ' . $e->getMessage());
            }
        }
        redirect('library/categories');
    }

    public function issue(): void
    {
        $libraryModel = new Library();
        $books = $libraryModel->raw("SELECT * FROM books WHERE available_quantity > 0 ORDER BY title ASC");

        $studentModel = new Student();
        $sessionId = Session::get('active_session_id');
        $students = $studentModel->raw("SELECT id, first_name, last_name, admission_number FROM students WHERE session_id = :sid AND status = 'Active' ORDER BY first_name", ['sid' => $sessionId ?? 0]);

        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            try {
                $id = $libraryModel->issueBook((int)$data['book_id'], (int)$data['student_id'], $data['issue_date'], $data['due_date'], Session::get('user_id'));
                Audit::log('library', 'issue_book', $id, $data);
                Flash::success('Book issued successfully.');
                redirect('library/issued');
                return;
            } catch (Exception $e) {
                Flash::error('Error issuing book: ' . $e->getMessage());
            }
        }

        $this->view('library/issue', [
            'pageTitle' => 'Issue Book',
            'books' => $books,
            'students' => $students
        ]);
    }

    public function issued(): void
    {
        $libraryModel = new Library();
        $page = (int) $this->getGet('page', 1);
        $issued = $libraryModel->getIssuedBooks($page, 20);

        $this->view('library/issued', [
            'pageTitle' => 'Issued Books',
            'issued' => $issued['data'],
            'pagination' => $issued
        ]);
    }

    public function returnBook(): void
    {
        $issueId = (int) ($this->getGet('id') ?? 0);
        $libraryModel = new Library();

        $issueModel = new Model();
        $issueModel->table = 'book_issues';
        $issue = $issueModel->findById($issueId);
        if (!$issue) { Flash::error('Issue record not found.'); redirect('library/issued'); return; }

        if ($this->isPost()) {
            $fineAmount = (float) ($this->getPost('fine_amount') ?? 0);
            try {
                $libraryModel->returnBook($issueId, $fineAmount);
                Audit::log('library', 'return_book', $issueId, ['fine' => $fineAmount]);
                Flash::success('Book returned successfully.');
                redirect('library/issued');
                return;
            } catch (Exception $e) {
                Flash::error('Error returning book: ' . $e->getMessage());
            }
        }

        $bookModel = new Library();
        $book = $bookModel->findById($issue['book_id']);
        $studentModel = new Student();
        $student = $studentModel->findById($issue['student_id']);

        $this->view('library/return', [
            'pageTitle' => 'Return Book',
            'issue' => $issue,
            'book' => $book,
            'student' => $student
        ]);
    }

    public function overdue(): void
    {
        $libraryModel = new Library();
        $overdue = $libraryModel->getOverdueBooks();

        $this->view('library/overdue', [
            'pageTitle' => 'Overdue Books',
            'overdue' => $overdue
        ]);
    }

    /** Send overdue SMS reminders to all overdue borrowers */
    public function sendOverdueReminders(): void
    {
        $this->requirePost('library/overdue');
        $libraryModel = new Library();
        $overdue = $libraryModel->getOverdueBooks();
        $sent = 0;
        foreach ($overdue as $item) {
            $phone = $item['father_phone'] ?? $item['phone'] ?? null;
            if (!$phone) continue;
            $days  = (int)((strtotime('today') - strtotime($item['due_date'])) / 86400);
            $name  = trim(($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? ''));
            $title = $item['book_title'] ?? $item['title'] ?? 'book';
            $msg   = "Dear Parent, $name has not returned '$title' — $days day(s) overdue. Please return immediately. - " . APP_NAME;
            SMS::send($phone, $msg);
            $sent++;
        }
        Flash::success("Reminder SMS sent to $sent student(s).");
        redirect('library/overdue');
    }

    /** Collect fine for an already-returned book */
    public function collectFine(): void
    {
        $this->requirePost('library/issued');
        $issueId = (int)($this->getPost('issue_id') ?? 0);
        $amount  = (float)($this->getPost('fine_amount') ?? 0);

        $issueModel = new Model(); $issueModel->table = 'book_issues';
        $issueModel->update($issueId, ['fine_paid' => $amount, 'fine_status' => 'Paid']);
        Audit::log('library', 'collect_fine', $issueId, ['amount' => $amount]);
        Flash::success("Fine of ₹$amount collected.");
        redirect('library/issued');
    }
}
