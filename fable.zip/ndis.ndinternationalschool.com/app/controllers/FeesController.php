<?php
/**
 * FeesController — Production-grade Fee Management
 * Ledger-based: all balances computed dynamically, history is immutable.
 */
class FeesController extends Controller
{
    private Fee $fee;
    private int $sessionId;

    public function __construct()
    {
        parent::__construct();
        $this->fee = new Fee();
        $sessM = new Model(); $sessM->table = 'academic_sessions';
        $cur = $sessM->rawOne("SELECT id FROM academic_sessions WHERE is_active = 1 LIMIT 1", []);
        $this->sessionId = $cur ? (int)$cur['id'] : 0;
    }

    // ─────────────────────────────────────────────────────────────
    // DASHBOARD
    // ─────────────────────────────────────────────────────────────

    public function index(): void
    {
        $this->requirePermission('fees.view');
        Permission::check('fees.view');
        if (!$this->sessionId) {
            Flash::error('No active academic session found.');
            redirect('dashboard');
            return;
        }
        $summary  = $this->fee->getDashboardSummary($this->sessionId);
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/index', [
            'summary'  => $summary,
            'sessions' => $sessions,
            'sessionId'=> $this->sessionId,
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    // FEE HEADS
    // ─────────────────────────────────────────────────────────────

    public function heads(): void
    {
        Permission::check('fees.view');
        $heads = $this->fee->getHeads(false);
        $this->view('fees/heads', ['heads' => $heads]);
    }

    public function saveHead(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/heads');
        $id   = (int)$this->getPost('id', 0);
        $name = trim($this->getPost('name', ''));
        if ($name === '') {
            Flash::error('Fee head name is required.');
            redirect('fees/heads');
            return;
        }
        try {
            $headId = $this->fee->saveHead([
                'id'          => $id,
                'name'        => $name,
                'description' => $this->getPost('description', ''),
                'head_type'   => $this->getPost('head_type', 'Custom'),
                'sort_order'  => (int)$this->getPost('sort_order', 0),
                'is_mandatory'=> $this->getPost('is_mandatory', 0),
            ]);
            Audit::log('fees', $id ? 'head_updated' : 'head_created', $headId, ['name' => $name]);
            Flash::success('Fee head saved successfully.');
        } catch (Exception $e) {
            Flash::error('Error: ' . $e->getMessage());
        }
        redirect('fees/heads');
    }

    public function deleteHead(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/heads');
        try {
            $this->fee->deleteHead((int)$this->getPost('id', 0));
            Flash::success('Fee head deactivated.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/heads');
    }

    // ─────────────────────────────────────────────────────────────
    // FEE STRUCTURES
    // ─────────────────────────────────────────────────────────────

    public function structures(): void
    {
        Permission::check('fees.view');
        $sessId     = (int)$this->getGet('session_id', $this->sessionId);
        $structures = $this->fee->getStructures($sessId);
        $classes    = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $heads      = $this->fee->getHeads();
        $sessions   = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/structures', compact('structures','classes','heads','sessions','sessId'));
    }

    public function saveStructure(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/structures');
        $sessId = (int)$this->getPost('session_id', $this->sessionId);
        try {
            $id = $this->fee->saveStructure([
                'id'              => (int)$this->getPost('id', 0),
                'class_id'        => (int)$this->getPost('class_id', 0),
                'session_id'      => $sessId,
                'fee_category_id' => (int)$this->getPost('fee_category_id', 0),
                'amount'          => (float)$this->getPost('amount', 0),
                'frequency'       => $this->getPost('frequency', 'Monthly'),
            ]);
            Audit::log('fees', 'structure_saved', $id, []);
            Flash::success('Fee structure saved.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/structures?session_id=' . $sessId);
    }

    public function deleteStructure(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/structures');
        try {
            $this->fee->deleteStructure((int)$this->getPost('id', 0));
            Flash::success('Fee structure deleted.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/structures');
    }

    // ─────────────────────────────────────────────────────────────
    // COLLECT PAYMENT
    // ─────────────────────────────────────────────────────────────

    public function collect(): void
    {
        Permission::check('fees.collect');
        $studentId = (int)$this->getGet('student_id', 0);
        $classes   = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        if (!$studentId) {
            $this->view('fees/collect', [
                'student' => null, 'classes' => $classes, 'sessionId' => $this->sessionId,
            ]);
            return;
        }
        $student     = $this->loadStudent($studentId);
        $structure   = $this->fee->getClassStructure((int)$student['class_id'], $this->sessionId);
        $months      = $this->fee->getSessionMonths($this->sessionId);
        $monthStatus = $this->fee->getCollectionGrid($studentId, $this->sessionId);
        $discounts   = $this->fee->getStudentDiscounts($studentId, $this->sessionId);
        $additional  = $this->fee->getAdditionalCharges($studentId, $this->sessionId);
        $credit      = $this->fee->getCreditBalance($studentId, $this->sessionId);
        $siblings    = $this->fee->getSiblings($studentId, $this->sessionId);
        $accounts    = (new Model())->raw(
            "SELECT id, account_name, bank_name FROM bank_accounts WHERE is_active=1 ORDER BY account_name"
        );
        $transportRates = $this->fee->getTransportRates();
        $this->view('fees/collect', compact(
            'student','structure','months','monthStatus','discounts',
            'additional','credit','siblings','accounts','classes','studentId','transportRates'
        ) + ['sessionId' => $this->sessionId]);
    }

    public function processPayment(): void
    {
        Permission::check('fees.collect');
        $this->requirePost('fees/collect');

        $rawItems = is_array($_POST['items'] ?? null) ? $_POST['items'] : [];
        $studentId = (int)$this->getPost('student_id', 0);

        if (empty($rawItems)) {
            Flash::error('No fee items selected.');
            redirect('fees/collect?student_id=' . $studentId);
            return;
        }

        $items = [];
        foreach ($rawItems as $raw) {
            if (!is_array($raw)) continue;
            $paid = (float)($raw['paid_amount'] ?? 0);
            if ($paid <= 0) continue;
            // Discount input is permission-gated in the view; always clamp to [0, charged]
            // server-side so a tampered field can never exceed the charge or go negative.
            $charged  = (float)($raw['charged_amount'] ?? 0);
            $discount = max(0.0, min((float)($raw['discount_amount'] ?? 0), $charged));
            $items[] = [
                'student_id'         => (int)($raw['student_id'] ?? 0),
                'fee_category_id'    => !empty($raw['fee_category_id']) ? (int)$raw['fee_category_id'] : null,
                'month_year'         => Validator::sanitize($raw['month_year'] ?? ''),
                'charged_amount'     => $charged,
                'discount_amount'    => $discount,
                'late_fee_amount'    => (float)($raw['late_fee_amount'] ?? 0),
                'late_fee_days'      => (int)($raw['late_fee_days'] ?? 0),
                'paid_amount'        => $paid,
                'is_transport'       => !empty($raw['is_transport']) ? 1 : 0,
                'transport_route_id' => !empty($raw['transport_route_id']) ? (int)$raw['transport_route_id'] : null,
                'transport_fee_type' => !empty($raw['transport_fee_type']) ? Validator::sanitize($raw['transport_fee_type']) : null,
                'remarks'            => Validator::sanitize($raw['remarks'] ?? ''),
            ];
        }

        if (empty($items)) {
            Flash::error('Paid amount must be greater than zero.');
            redirect('fees/collect?student_id=' . $studentId);
            return;
        }

        // Receipt number is entered manually by the cashier. Duplicates are intentionally
        // ALLOWED — siblings paid together on one physical receipt share the same number
        // (the receipt_number index is non-unique by design). Only "required" is enforced.
        $receiptNo = trim(Validator::sanitize($this->getPost('receipt_number', '')));
        if ($receiptNo === '') {
            Flash::error('Receipt number is required — please enter it manually.');
            redirect('fees/collect?student_id=' . $studentId);
            return;
        }

        $sessId = (int)$this->getPost('session_id', $this->sessionId);
        $txn = [
            'session_id'         => $sessId,
            'payment_date'       => $this->getPost('payment_date', date('Y-m-d')),
            'payment_method'     => Validator::sanitize($this->getPost('payment_method', 'Cash')),
            'receipt_number'     => $receiptNo,
            'bank_account_id'    => !empty($this->getPost('bank_account_id')) ? (int)$this->getPost('bank_account_id') : null,
            'cheque_number'      => Validator::sanitize($this->getPost('cheque_number', '')),
            'cheque_date'        => $this->getPost('cheque_date', '') ?: null,
            'upi_transaction_id' => Validator::sanitize($this->getPost('upi_transaction_id', '')),
            'dd_number'          => Validator::sanitize($this->getPost('dd_number', '')),
            'remarks'            => Validator::sanitize($this->getPost('remarks', '')),
            'collected_by'       => (int)Session::get('user_id'),
        ];

        try {
            $txnId = $this->fee->processPayment($txn, $items);
            Flash::success('Payment collected successfully.');
            redirect('fees/receipt?id=' . $txnId);
        } catch (Exception $e) {
            Flash::error('Payment failed: ' . $e->getMessage());
            redirect('fees/collect?student_id=' . $studentId);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // RECEIPT
    // ─────────────────────────────────────────────────────────────

    public function receipt(): void
    {
        Permission::check('fees.view');
        $txnId   = (int)$this->getGet('id', 0);
        $details = $this->fee->getReceiptDetails($txnId);
        if (!$details) {
            Flash::error('Receipt not found.');
            redirect('fees/receipts');
            return;
        }
        $school = $this->getSchoolInfo();
        $this->view('fees/receipt', ['txn' => $details, 'school' => $school]);
    }

    public function receipts(): void
    {
        Permission::check('fees.view');
        $sessId  = (int)$this->getGet('session_id', $this->sessionId);
        $page    = max(1, (int)$this->getGet('page', 1));
        $filters = [
            'receipt_number' => $this->getGet('receipt_number', ''),
            'payment_method' => $this->getGet('payment_method', ''),
            'status'         => $this->getGet('status', ''),
            'date_from'      => $this->getGet('date_from', ''),
            'date_to'        => $this->getGet('date_to', ''),
            'class_id'       => (int)$this->getGet('class_id', 0) ?: null,
        ];
        $result   = $this->fee->getReceiptList($sessId, $filters, $page);
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $classes  = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $this->view('fees/receipts', array_merge($result, compact('filters','sessions','classes','sessId','page')));
    }

    public function cancelReceipt(): void
    {
        Permission::check('fees.cancel');
        $this->requirePost('fees/receipts');
        $txnId  = (int)$this->getPost('id', 0);
        $reason = Validator::sanitize(trim($this->getPost('reason', '')));
        if (!$reason) {
            Flash::error('Cancellation reason is required.');
            redirect('fees/receipt?id=' . $txnId);
            return;
        }
        try {
            $this->fee->cancelReceipt($txnId, $reason, (int)Session::get('user_id'));
            Flash::success('Receipt cancelled successfully.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/receipts');
    }

    // ─────────────────────────────────────────────────────────────
    // STUDENT LEDGER
    // ─────────────────────────────────────────────────────────────

    public function ledger(): void
    {
        Permission::check('fees.view');
        $studentId = (int)$this->getGet('student_id', 0);
        $sessId    = (int)$this->getGet('session_id', $this->sessionId);
        $student = $ledger = $months = null;
        $outstanding = 0.0;
        if ($studentId) {
            $student     = $this->loadStudent($studentId);
            $ledger      = $this->fee->getStudentLedger($studentId, $sessId);
            $months      = $this->fee->getStudentMonthStatus($studentId, $sessId);
            $outstanding = $this->fee->getStudentOutstanding($studentId, $sessId);
        }
        $classes  = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/ledger', compact('student','ledger','months','outstanding','classes','sessions','sessId','studentId'));
    }

    // ─────────────────────────────────────────────────────────────
    // DISCOUNTS
    // ─────────────────────────────────────────────────────────────

    public function discounts(): void
    {
        Permission::check('fees.manage');
        $studentId = (int)$this->getGet('student_id', 0);
        $sessId    = (int)$this->getGet('session_id', $this->sessionId);
        $student = $discounts = null;
        if ($studentId) {
            $student   = $this->loadStudent($studentId);
            $discounts = $this->fee->getStudentDiscounts($studentId, $sessId);
        }
        $heads    = $this->fee->getHeads();
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/discounts', compact('student','discounts','heads','sessions','sessId','studentId'));
    }

    public function saveDiscount(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/discounts');
        $studentId = (int)$this->getPost('student_id', 0);
        $sessId    = (int)$this->getPost('session_id', $this->sessionId);
        try {
            $id = $this->fee->saveDiscount([
                'id'              => (int)$this->getPost('id', 0),
                'student_id'      => $studentId,
                'session_id'      => $sessId,
                'fee_category_id' => $this->getPost('fee_category_id', '') ?: null,
                'discount_type'   => Validator::sanitize($this->getPost('discount_type', 'Fixed')),
                'discount_value'  => (float)$this->getPost('discount_value', 0),
                'reason'          => Validator::sanitize($this->getPost('reason', '')),
                'approved_by'     => (int)Session::get('user_id'),
                'valid_from'      => $this->getPost('valid_from', '') ?: null,
                'valid_until'     => $this->getPost('valid_until', '') ?: null,
            ]);
            Audit::log('fees', 'discount_saved', $id, ['student_id' => $studentId]);
            Flash::success('Discount saved successfully.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect("fees/discounts?student_id=$studentId&session_id=$sessId");
    }

    public function deleteDiscount(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/discounts');
        $studentId = (int)$this->getPost('student_id', 0);
        $sessId    = (int)$this->getPost('session_id', $this->sessionId);
        try {
            $this->fee->deleteDiscount((int)$this->getPost('id', 0));
            Flash::success('Discount removed.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect("fees/discounts?student_id=$studentId&session_id=$sessId");
    }

    // ─────────────────────────────────────────────────────────────
    // ADDITIONAL CHARGES
    // ─────────────────────────────────────────────────────────────

    public function additionalCharges(): void
    {
        Permission::check('fees.collect');
        $studentId = (int)$this->getGet('student_id', 0);
        if (!$studentId) { redirect('fees'); return; }
        $student = $this->loadStudent($studentId);
        $charges = $this->fee->getAdditionalCharges($studentId, $this->sessionId);
        $this->view('fees/additional_charges', compact('student','charges'));
    }

    public function markChargesPaid(): void
    {
        Permission::check('fees.collect');
        $this->requirePost('fees');
        $studentId = (int)$this->getPost('student_id', 0);
        try {
            $this->fee->markAdditionalChargePaid((int)$this->getPost('id', 0));
            Flash::success('Charge marked as paid.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/additionalCharges?student_id=' . $studentId);
    }

    public function saveAdditionalCharge(): void
    {
        Permission::check('fees.collect');
        $this->requirePost('fees/collect');
        $studentId = (int)$this->getPost('student_id', 0);
        try {
            $this->fee->saveAdditionalCharge([
                'student_id'  => $studentId,
                'session_id'  => $this->sessionId,
                'charge_type' => Validator::sanitize($this->getPost('charge_type', '')),
                'head_label'  => Validator::sanitize($this->getPost('head_label', '')),
                'amount'      => (float)$this->getPost('amount', 0),
                'description' => Validator::sanitize($this->getPost('description', '')),
                'charge_date' => $this->getPost('charge_date', date('Y-m-d')),
                'created_by'  => (int)Session::get('user_id'),
            ]);
            Flash::success('Additional charge added.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/collect?student_id=' . $studentId);
    }

    // ─────────────────────────────────────────────────────────────
    // FAMILY PAYMENT
    // ─────────────────────────────────────────────────────────────

    public function familyPayment(): void
    {
        Permission::check('fees.collect');
        $studentId = (int)$this->getGet('student_id', 0);
        if (!$studentId) { redirect('fees'); return; }
        $student  = $this->loadStudent($studentId);
        $siblings = $this->fee->getSiblings($studentId, $this->sessionId);
        $allStudents = array_merge([$student], $siblings);
        $payData = [];
        foreach ($allStudents as $s) {
            $sid = (int)$s['id'];
            $payData[$sid] = [
                'student'     => $s,
                'structure'   => $this->fee->getClassStructure((int)$s['class_id'], $this->sessionId),
                'months'      => $this->fee->getCollectionGrid($sid, $this->sessionId),
                'outstanding' => $this->fee->getStudentOutstanding($sid, $this->sessionId),
            ];
        }
        $accounts = (new Model())->raw(
            "SELECT id, account_name, bank_name FROM bank_accounts WHERE is_active=1 ORDER BY account_name"
        );
        $this->view('fees/family_payment', compact('payData','accounts','studentId') + ['sessionId' => $this->sessionId]);
    }

    // ─────────────────────────────────────────────────────────────
    // SESSION LOCK / UNLOCK
    // ─────────────────────────────────────────────────────────────

    public function lockSession(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees');
        $sessId = (int)$this->getPost('session_id', $this->sessionId);
        (new Model())->query("UPDATE academic_sessions SET is_fee_locked=1 WHERE id=:id", ['id' => $sessId]);
        Audit::log('fees', 'session_locked', $sessId, []);
        Flash::success('Fee session locked.');
        redirect('fees');
    }

    public function unlockSession(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees');
        $sessId = (int)$this->getPost('session_id', $this->sessionId);
        (new Model())->query("UPDATE academic_sessions SET is_fee_locked=0 WHERE id=:id", ['id' => $sessId]);
        Audit::log('fees', 'session_unlocked', $sessId, []);
        Flash::success('Fee session unlocked.');
        redirect('fees');
    }

    // ─────────────────────────────────────────────────────────────
    // REPORTS
    // ─────────────────────────────────────────────────────────────

    public function reports(): void
    {
        Permission::check('fees.reports');
        $this->view('fees/reports/index', ['sessionId' => $this->sessionId]);
    }

    public function reportOutstanding(): void
    {
        Permission::check('fees.reports');
        $sessId  = (int)$this->getGet('session_id', $this->sessionId);
        $classId = (int)$this->getGet('class_id', 0) ?: null;
        $data    = $this->fee->getOutstandingReport($sessId, $classId);
        $classes = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $sessions= (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/reports/outstanding', compact('data','classes','sessions','sessId','classId'));
    }

    public function reportDaily(): void
    {
        Permission::check('fees.reports');
        $sessId = (int)$this->getGet('session_id', $this->sessionId);
        $date   = $this->getGet('date', date('Y-m-d'));
        $data   = $this->fee->getDailyCollection($date, $sessId);
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/reports/daily', compact('data','date','sessions','sessId'));
    }

    public function reportMonthly(): void
    {
        Permission::check('fees.reports');
        $sessId    = (int)$this->getGet('session_id', $this->sessionId);
        $monthYear = $this->getGet('month_year', date('Y-m'));
        $classId   = (int)$this->getGet('class_id', 0) ?: null;
        $data      = $this->fee->getMonthlyReport($monthYear, $sessId, $classId);
        $classes   = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $sessions  = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/reports/monthly', compact('data','monthYear','classes','sessions','sessId','classId'));
    }

    public function reportDiscounts(): void
    {
        Permission::check('fees.reports');
        $sessId   = (int)$this->getGet('session_id', $this->sessionId);
        $data     = $this->fee->getDiscountReport($sessId);
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/reports/discounts', compact('data','sessions','sessId'));
    }

    public function reportRefunds(): void
    {
        Permission::check('fees.reports');
        $sessId   = (int)$this->getGet('session_id', $this->sessionId);
        $data     = $this->fee->getRefundReport($sessId);
        $sessions = (new Model())->raw("SELECT id, name FROM academic_sessions ORDER BY id DESC");
        $this->view('fees/reports/refunds', compact('data','sessions','sessId'));
    }

    // ─────────────────────────────────────────────────────────────
    // AJAX
    // ─────────────────────────────────────────────────────────────

    public function getStudentInfo(): void
    {
        Permission::check('fees.view');
        $studentId = (int)$this->getGet('student_id', 0);
        if (!$studentId) { $this->json(['error' => 'Missing student_id']); return; }
        $student     = $this->loadStudent($studentId);
        $outstanding = $this->fee->getStudentOutstanding($studentId, $this->sessionId);
        $pending     = $this->fee->getPendingMonths($studentId, $this->sessionId);
        $credit      = $this->fee->getCreditBalance($studentId, $this->sessionId);
        $this->json(compact('student','outstanding','pending','credit'));
    }

    public function ajaxLateFee(): void
    {
        Permission::check('fees.view');
        $classId    = (int)$this->getGet('class_id', 0);
        $categoryId = (int)$this->getGet('category_id', 0) ?: null;
        $monthYear  = $this->getGet('month_year', '');
        $charged    = (float)$this->getGet('charged', 0);
        $payDate    = $this->getGet('payment_date', date('Y-m-d'));
        $lf = $this->fee->calculateLateFee($this->sessionId, $classId, $categoryId, $monthYear, $charged, $payDate);
        $this->json(['late_fee' => $lf]);
    }

    public function searchStudents(): void
    {
        Permission::check('fees.view');
        $q       = '%' . Validator::sanitize($this->getGet('q', '')) . '%';
        $classId = (int)$this->getGet('class_id', 0);
        $where   = ['s.status="Active"'];
        $params  = ['q' => $q, 'q2' => $q, 'q3' => $q];
        if ($classId) { $where[] = 's.class_id=:cid'; $params['cid'] = $classId; }
        $where[] = "(s.first_name LIKE :q OR s.last_name LIKE :q2 OR s.admission_number LIKE :q3)";
        $w = implode(' AND ', $where);
        $students = (new Model())->raw(
            "SELECT s.id, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS name,
                    s.admission_number, c.name AS class_name, sec.name AS section_name
             FROM students s
             JOIN classes c ON s.class_id=c.id
             LEFT JOIN sections sec ON s.section_id=sec.id
             WHERE $w ORDER BY s.first_name LIMIT 20",
            $params
        );
        $this->json($students);
    }

    public function ajaxClassStructure(): void
    {
        Permission::check('fees.view');
        $classId = (int)$this->getGet('class_id', 0);
        $sessId  = (int)$this->getGet('session_id', $this->sessionId);
        $this->json($this->fee->getClassStructure($classId, $sessId));
    }

    /** AJAX: active students in a class for the current session (id + display name). */
    public function studentsByClass(): void
    {
        Permission::check('fees.view');
        $classId   = (int)$this->getGet('class_id', 0);
        $sectionId = (int)$this->getGet('section_id', 0);
        if (!$classId) { $this->json([]); return; }
        $where  = "class_id = :cid AND session_id = :sess AND status = 'Active'";
        $params = ['cid' => $classId, 'sess' => $this->sessionId];
        if ($sectionId) { $where .= " AND section_id = :sec"; $params['sec'] = $sectionId; }
        $rows = (new Model())->raw(
            "SELECT id,
                    TRIM(CONCAT(first_name,' ',COALESCE(last_name,''))) AS name,
                    admission_number,
                    COALESCE(roll_number,'') AS roll_number
             FROM students
             WHERE $where
             ORDER BY CAST(roll_number AS UNSIGNED), first_name",
            $params
        );
        $this->json($rows);
    }

    // ─────────────────────────────────────────────────────────────
    // STUDENT LEDGER  /  MONTH STATUS  /  FAMILY DASHBOARD
    // ─────────────────────────────────────────────────────────────

    public function studentLedger(): void
    {
        Permission::check('fees.view');
        $classes   = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $studentId = (int)$this->getGet('student_id', 0);
        $student = null; $ledger = []; $outstanding = 0.0;
        if ($studentId) {
            $student = $this->loadStudent($studentId);
            $ledger  = array_map(function ($e) {
                $e['category_name'] = $e['head_name'] ?? null;
                return $e;
            }, $this->fee->getStudentLedger($studentId, $this->sessionId));
            $outstanding = $this->fee->getStudentOutstanding($studentId, $this->sessionId);
        }
        $this->view('fees/student_ledger', compact('classes', 'student', 'ledger', 'outstanding', 'studentId'));
    }

    public function monthStatus(): void
    {
        Permission::check('fees.view');
        $classes   = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $studentId = (int)$this->getGet('student_id', 0);
        $student = null; $monthData = [];
        if ($studentId) {
            $student   = $this->loadStudent($studentId);
            $monthData = $this->fee->getCollectionGrid($studentId, $this->sessionId);
            // The view reads $md['categories']; the grid exposes per-head rows as $md['heads'].
            foreach ($monthData as &$md) {
                $md['categories'] = array_map(static fn($h) => [
                    'category_name'  => $h['head_name'] ?? 'Fee',
                    'paid_amount'    => $h['paid_amount'],
                    'charged_amount' => $h['charged_amount'],
                ], $md['heads'] ?? []);
            }
            unset($md);
        }
        $this->view('fees/month_status', compact('classes', 'student', 'monthData', 'studentId'));
    }

    public function familyDashboard(): void
    {
        Permission::check('fees.view');
        $parents  = (new Model())->raw("SELECT id, father_name, mother_name FROM parents ORDER BY father_name");
        $parentId = (int)$this->getGet('parent_id', 0);
        $data = [];
        if ($parentId) {
            $students = $this->fee->getFamilyStudents($parentId, $this->sessionId);
            $rows = []; $grandDues = 0.0; $grandPaid = 0.0;
            $m = new Model();
            foreach ($students as $st) {
                $sid = (int)$st['id'];
                $st['outstanding']  = $this->fee->getStudentOutstanding($sid, $this->sessionId);
                $st['credit']       = $this->fee->getCreditBalance($sid, $this->sessionId);
                $st['month_status'] = $this->fee->getStudentMonthStatus($sid, $this->sessionId);
                $paid = (float)($m->rawOne(
                    "SELECT COALESCE(SUM(fpi.paid_amount),0) AS p
                     FROM fee_payment_items fpi
                     JOIN fee_payment_transactions fpt ON fpi.transaction_id = fpt.id
                     WHERE fpi.student_id = :sid AND fpi.session_id = :sess AND fpt.status = 'Active'",
                    ['sid' => $sid, 'sess' => $this->sessionId]
                )['p'] ?? 0);
                $st['receipts'] = $m->raw(
                    "SELECT DISTINCT fpt.id, fpt.receipt_number, fpt.payment_date, fpt.total_amount, fpt.payment_method
                     FROM fee_payment_transactions fpt
                     JOIN fee_payment_items fpi ON fpi.transaction_id = fpt.id
                     WHERE fpi.student_id = :sid AND fpt.session_id = :sess AND fpt.status = 'Active'
                     ORDER BY fpt.payment_date DESC, fpt.id DESC LIMIT 5",
                    ['sid' => $sid, 'sess' => $this->sessionId]
                );
                $grandDues += $st['outstanding'];
                $grandPaid += $paid;
                $rows[] = $st;
            }
            $data = [
                'grand_total_dues' => $grandDues,
                'grand_total_paid' => $grandPaid,
                'students'         => $rows,
            ];
        }
        $this->view('fees/family_dashboard', compact('parents', 'parentId', 'data'));
    }

    // ─────────────────────────────────────────────────────────────
    // LATE FEE RULES
    // ─────────────────────────────────────────────────────────────

    public function lateFeRules(): void { $this->lateFeeRules(); }

    public function lateFeeRules(): void
    {
        Permission::check('fees.manage');
        $rules      = $this->fee->getLateFeeRules($this->sessionId);
        $classes    = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $categories = $this->fee->getHeads();
        $this->view('fees/late_fee_rules', compact('rules', 'classes', 'categories'));
    }

    public function saveLateFeeRule(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/lateFeeRules');
        try {
            $id = $this->fee->saveLateFeeRule($_POST, $this->sessionId);
            Audit::log('fees', 'late_fee_rule_saved', $id, []);
            Flash::success('Late fee rule saved.');
        } catch (Exception $e) {
            Flash::error('Error: ' . $e->getMessage());
        }
        redirect('fees/lateFeeRules');
    }

    // ─────────────────────────────────────────────────────────────
    // FEE CONFIG (settings + session locking)
    // ─────────────────────────────────────────────────────────────

    public function feeConfig(): void
    {
        Permission::check('fees.manage');
        $settings = (new Settings())->getAll();
        $sessions = (new Model())->raw(
            "SELECT id, name, is_fee_locked FROM academic_sessions ORDER BY id DESC"
        );
        $this->view('fees/fee_config', compact('settings', 'sessions'));
    }

    public function saveFeeConfig(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/feeConfig');
        $keys = [
            'fee_allow_advance_payment', 'fee_allow_skip_older_dues', 'fee_auto_allocate',
            'fee_enable_late_fees', 'fee_enable_transport', 'fee_receipt_reset_per_session',
            'fee_require_payment_confirm', 'fee_require_cancel_reason', 'fee_warn_older_dues',
        ];
        $settings = new Settings();
        foreach ($keys as $k) {
            $settings->set($k, isset($_POST[$k]) ? '1' : '0');
        }
        Audit::log('fees', 'fee_config_saved', 0, []);
        Flash::success('Fee configuration saved.');
        redirect('fees/feeConfig');
    }

    // ─────────────────────────────────────────────────────────────
    // FEE ALLOCATION (class × fee head fixed amounts = fee_structures)
    // ─────────────────────────────────────────────────────────────

    public function allocation(): void
    {
        Permission::check('fees.manage');
        $classId    = (int)$this->getGet('class_id', 0);
        $classes    = (new Model())->raw("SELECT id, name FROM classes ORDER BY numeric_value");
        $categories = $this->fee->getHeads();
        $params = ['sess' => $this->sessionId];
        $clause = '';
        if ($classId) { $clause = ' AND fs.class_id = :cid'; $params['cid'] = $classId; }
        $allocations = (new Model())->raw(
            "SELECT fs.id, fs.class_id, fs.fee_category_id, fs.amount,
                    c.name AS class_name, fc.name AS category_name, fc.is_mandatory
             FROM fee_structures fs
             JOIN classes c ON fs.class_id = c.id
             JOIN fee_categories fc ON fs.fee_category_id = fc.id
             WHERE fs.session_id = :sess{$clause}
             ORDER BY c.numeric_value, fc.sort_order, fc.name",
            $params
        );
        $this->view('fees/allocation', compact('allocations', 'classes', 'categories', 'classId'));
    }

    public function saveAllocation(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/allocation');
        try {
            $this->fee->saveStructure([
                'id'              => (int)$this->getPost('id', 0),
                'class_id'        => (int)$this->getPost('class_id', 0),
                'session_id'      => $this->sessionId,
                'fee_category_id' => (int)$this->getPost('fee_category_id', 0),
                'amount'          => (float)$this->getPost('amount', 0),
                'frequency'       => 'Monthly',
            ]);
            Flash::success('Fee allocation saved.');
        } catch (Exception $e) {
            Flash::error('Error: ' . $e->getMessage());
        }
        redirect('fees/allocation');
    }

    public function deleteAllocation(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/allocation');
        try {
            $this->fee->deleteStructure((int)$this->getPost('id', 0));
            Flash::success('Fee allocation deleted.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/allocation');
    }

    // ─────────────────────────────────────────────────────────────
    // CASH CLOSING
    // ─────────────────────────────────────────────────────────────

    public function cashClosing(): void
    {
        Permission::check('fees.manage');
        $date     = $this->getGet('date', date('Y-m-d'));
        $auto     = $this->fee->getCashClosingAuto($date, $this->sessionId);
        $list     = $this->fee->getCashClosings($this->sessionId);
        $cashiers = (new Model())->raw(
            "SELECT id, full_name FROM users WHERE is_active = 1 ORDER BY full_name"
        );
        $this->view('fees/cash_closing', compact('date', 'auto', 'list', 'cashiers'));
    }

    public function saveCashClosing(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/cashClosing');
        try {
            $this->fee->saveCashClosing($_POST, $this->sessionId);
            Audit::log('fees', 'cash_closing_submitted', 0, ['date' => $this->getPost('closing_date')]);
            Flash::success('Cash closing submitted.');
        } catch (Exception $e) {
            Flash::error('Error: ' . $e->getMessage());
        }
        redirect('fees/cashClosing');
    }

    public function approveCashClosing(): void
    {
        Permission::check('fees.manage');
        $this->requirePost('fees/cashClosing');
        try {
            $this->fee->approveCashClosing((int)$this->getPost('id', 0), (int)Session::get('user_id'));
            Audit::log('fees', 'cash_closing_approved', (int)$this->getPost('id', 0), []);
            Flash::success('Cash closing approved.');
        } catch (Exception $e) {
            Flash::error($e->getMessage());
        }
        redirect('fees/cashClosing');
    }

    // ─────────────────────────────────────────────────────────────
    // BANK RECONCILIATION (read-only daily breakdown)
    // ─────────────────────────────────────────────────────────────

    public function bankReconciliation(): void
    {
        Permission::check('fees.manage');
        $date           = $this->getGet('date', date('Y-m-d'));
        $byMethod       = $this->fee->getCollectionsByMethod($date, $this->sessionId);
        $pendingCheques = $this->fee->getPendingCheques($this->sessionId);
        $this->view('fees/bank_reconciliation', compact('date', 'byMethod', 'pendingCheques'));
    }

    // ─────────────────────────────────────────────────────────────
    // RECONCILIATION (items vs transaction headers)
    // ─────────────────────────────────────────────────────────────

    public function reconciliation(): void
    {
        Permission::check('fees.manage');
        $result = null;
        if ($this->isPost()) {
            $result = $this->fee->runReconciliation($this->sessionId, (int)Session::get('user_id'));
            Audit::log('fees', 'reconciliation_run', 0, ['status' => $result['status']]);
        }
        $history = $this->fee->getReconciliationHistory($this->sessionId);
        $this->view('fees/reconciliation', compact('result', 'history'));
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────────

    private function loadStudent(int $id): array
    {
        $s = (new Model())->rawOne(
            "SELECT s.*, CONCAT(s.first_name,' ',COALESCE(s.last_name,'')) AS full_name,
                    c.name AS class_name, sec.name AS section_name,
                    COALESCE(NULLIF(p.father_name,''), p.mother_name, p.guardian_name) AS parent_name
             FROM students s
             JOIN classes c ON s.class_id=c.id
             LEFT JOIN sections sec ON s.section_id=sec.id
             LEFT JOIN parents p ON s.parent_id=p.id
             WHERE s.id=:id LIMIT 1",
            ['id' => $id]
        );
        if (!$s) { Flash::error('Student not found.'); redirect('fees'); exit; }
        return $s;
    }

    private function getSchoolInfo(): array
    {
        $rows = (new Model())->raw(
            "SELECT setting_key, setting_value FROM settings
             WHERE setting_key IN ('school_name','school_address','school_phone','school_email','school_logo')"
        );
        $info = [];
        foreach ($rows as $r) { $info[$r['setting_key']] = $r['setting_value']; }
        return $info;
    }

}
