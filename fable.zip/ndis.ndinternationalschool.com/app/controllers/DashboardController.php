<?php
/**
 * Dashboard Controller
 */
class DashboardController extends Controller
{
    public function index(): void
    {
        $dashboardModel = new Dashboard();
        $stats = $dashboardModel->getStats();
        $notices = $dashboardModel->getRecentNotices();
        $exams = $dashboardModel->getUpcomingExams();

        $sessionId = Session::get('active_session_id');
        $feeChartData = $dashboardModel->getMonthlyFeeChart($sessionId ?? 0);
        $attendanceChartData = $dashboardModel->getMonthlyAttendanceChart($sessionId ?? 0);

        $this->view('dashboard/index', [
            'pageTitle' => 'Dashboard',
            'stats' => $stats,
            'notices' => $notices,
            'exams' => $exams,
            'feeChartData' => $feeChartData,
            'attendanceChartData' => $attendanceChartData,
        ]);
    }
}
