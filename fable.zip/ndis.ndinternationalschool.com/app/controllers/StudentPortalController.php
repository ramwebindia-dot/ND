﻿<?php
class StudentPortalController extends Controller
{
    public function index(): void
    {
        $this->dashboard();
    }

    public function dashboard(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id');
        $studentDetail = $studentModel->getStudentWithDetails($student['id']);
        $outstanding = $studentModel->getOutstandingBalance($student['id'], $sessionId ?? 0);

        // Recent homework
        $homeworkModel = new Homework();
        $homework = $homeworkModel->raw("SELECT h.*, s.name as subject_name FROM homework h JOIN subjects s ON h.subject_id = s.id WHERE h.class_id = :cid AND h.session_id = :sid ORDER BY h.deadline DESC LIMIT 5", ['cid' => $student['class_id'], 'sid' => $sessionId ?? 0]);

        // Recent notices
        $commModel = new Communication();
        $notices = $commModel->getActiveNotices('Student');

        // Upcoming exams
        $examModel = new Exam();
        $exams = $examModel->raw("SELECT e.*, c.name as class_name FROM exams e JOIN classes c ON e.class_id = c.id WHERE e.class_id = :cid AND e.session_id = :sid AND e.status IN ('Upcoming', 'Ongoing') ORDER BY e.start_date LIMIT 5", ['cid' => $student['class_id'], 'sid' => $sessionId ?? 0]);

        $this->view('student-portal/dashboard', [
            'pageTitle' => 'Student Dashboard',
            'student' => $studentDetail,
            'outstanding' => $outstanding,
            'homework' => $homework,
            'notices' => $notices,
            'exams' => $exams
        ]);
    }

    public function attendance(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $month = $this->getGet('month', date('m'));
        $year = $this->getGet('year', date('Y'));

        $attendanceModel = new Attendance();
        $attendance = $attendanceModel->raw("SELECT * FROM student_attendance WHERE student_id = :sid AND MONTH(date) = :month AND YEAR(date) = :year ORDER BY date", ['sid' => $student['id'], 'month' => $month, 'year' => $year]);

        $this->view('student-portal/attendance', [
            'pageTitle' => 'My Attendance',
            'student' => $student,
            'attendance' => $attendance,
            'month' => $month,
            'year' => $year
        ]);
    }

    public function results(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id');
        $markModel = new Mark();
        $marks = $markModel->raw("SELECT m.*, e.name as exam_name, e.exam_type, s.name as subject_name FROM marks m JOIN exams e ON m.exam_id = e.id JOIN subjects s ON m.subject_id = s.id WHERE m.student_id = :sid AND e.session_id = :sess ORDER BY e.start_date, s.name", ['sid' => $student['id'], 'sess' => $sessionId ?? 0]);

        $this->view('student-portal/results', [
            'pageTitle' => 'My Results',
            'student' => $student,
            'marks' => $marks
        ]);
    }

    public function homework(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id');
        $homeworkModel = new Homework();
        $homework = $homeworkModel->raw("SELECT h.*, s.name as subject_name, hs.status as submission_status, hs.submitted_at FROM homework h JOIN subjects s ON h.subject_id = s.id LEFT JOIN homework_submissions hs ON hs.homework_id = h.id AND hs.student_id = :stid WHERE h.class_id = :cid AND h.session_id = :sid ORDER BY h.deadline DESC", ['stid' => $student['id'], 'cid' => $student['class_id'], 'sid' => $sessionId ?? 0]);

        $this->view('student-portal/homework', [
            'pageTitle' => 'My Homework',
            'student' => $student,
            'homework' => $homework
        ]);
    }

    public function fees(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id');
        $ledger = $studentModel->getStudentFeeLedger($student['id'], $sessionId ?? 0);
        $outstanding = $studentModel->getOutstandingBalance($student['id'], $sessionId ?? 0);

        $this->view('student-portal/fees', [
            'pageTitle' => 'My Fees',
            'student' => $student,
            'ledger' => $ledger,
            'outstanding' => $outstanding
        ]);
    }

    public function materials(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $sessionId = Session::get('active_session_id');
        $materialModel = new Material();
        $materials = $materialModel->getMaterials($sessionId ?? 0, (int)$student['class_id']);

        $this->view('student-portal/materials', [
            'pageTitle' => 'Learning Materials',
            'student' => $student,
            'materials' => $materials
        ]);
    }

    public function timetable(): void
    {
        $userId = Session::get('user_id');
        $studentModel = new Student();
        $student = $studentModel->findBy('user_id', $userId);
        if (!$student) { Flash::error('Student profile not found. Please contact the administrator.'); redirect('dashboard'); return; }

        $timetableModel = new Timetable();
        $timetable = $timetableModel->raw("SELECT t.*, s.name as subject_name, CONCAT(te.first_name, ' ', te.last_name) as teacher_name FROM timetables t JOIN subjects s ON t.subject_id = s.id JOIN teachers te ON t.teacher_id = te.id WHERE t.class_id = :cid AND t.section_id = :secid ORDER BY t.day_of_week, t.period_number", ['cid' => $student['class_id'], 'secid' => $student['section_id'] ?? 0]);

        $this->view('student-portal/timetable', [
            'pageTitle' => 'My Timetable',
            'student' => $student,
            'timetable' => $timetable
        ]);
    }
}

