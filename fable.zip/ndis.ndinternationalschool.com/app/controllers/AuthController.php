<?php
/**
 * Auth Controller
 */
class AuthController extends Controller
{
    protected string $layout = 'login';

    private int $maxAttempts   = 5;
    private int $lockoutMins   = 15;

    public function index(): void
    {
        redirect('auth/login');
    }

    public function login(): void
    {
        if (Session::isLoggedIn()) {
            $this->redirectByRole();
            return;
        }

        if ($this->isPost()) {
            $email    = trim($this->getPost('email', ''));
            $password = $this->getPost('password', '');
            $ip       = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

            $validator = new Validator($_POST);
            $validator->required('email', 'Email')->email('email')->required('password', 'Password');

            if (!$validator->validate()) {
                Flash::error($validator->getFirstError());
                redirect('auth/login');
                return;
            }

            $userModel = new User();

            // Load lockout config from settings
            $settingsModel = new Settings();
            $this->maxAttempts = (int) ($settingsModel->get('login_max_attempts') ?? 5);
            $this->lockoutMins = (int) ($settingsModel->get('login_lockout_minutes') ?? 15);

            // Brute-force check
            $attempts = $userModel->getRecentAttempts($email, $ip, $this->lockoutMins);
            if ($attempts >= $this->maxAttempts) {
                Flash::error("Too many failed attempts. Please try again after {$this->lockoutMins} minutes.");
                redirect('auth/login');
                return;
            }

            $user = $userModel->findByEmail($email);

            if (!$user || !$user['is_active'] || !password_verify($password, $user['password'])) {
                $userModel->recordLoginAttempt($email, $ip);
                Flash::error('Invalid email or password.');
                redirect('auth/login');
                return;
            }

            // Successful login — clear attempts, update last_login
            $userModel->clearLoginAttempts($email, $ip);
            $userModel->updateLastLogin((int) $user['id']);

            Session::loginUser($user);
            $this->redirectByRole();
            return;
        }

        $this->view('auth/login');
    }

    public function logout(): void
    {
        Auth::logout();
        redirect('auth/login');
    }

    // ── Forgot Password ────────────────────────────────────────────

    public function forgotPassword(): void
    {
        if ($this->isPost()) {
            $email = trim($this->getPost('email', ''));

            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                Flash::error('Please enter a valid email address.');
                redirect('auth/forgot-password');
                return;
            }

            $userModel = new User();
            $user = $userModel->findByEmail($email);

            // Always show success message to prevent email enumeration
            if ($user && $user['is_active']) {
                $token = $userModel->createResetToken((int) $user['id']);
                $this->sendResetEmail($user, $token);
            }

            Flash::success('If this email is registered, a password reset link has been sent.');
            redirect('auth/forgot-password');
            return;
        }

        $this->view('auth/forgot-password');
    }

    public function resetPassword(): void
    {
        $token = trim($this->getGet('token', ''));

        if (empty($token)) {
            Flash::error('Invalid or missing reset token.');
            redirect('auth/forgot-password');
            return;
        }

        $userModel = new User();
        $tokenRow  = $userModel->findValidResetToken($token);

        if (!$tokenRow) {
            Flash::error('This password reset link is invalid or has expired. Please request a new one.');
            redirect('auth/forgot-password');
            return;
        }

        if ($this->isPost()) {
            $newPassword     = $this->getPost('new_password', '');
            $confirmPassword = $this->getPost('confirm_password', '');

            if (strlen($newPassword) < 6) {
                Flash::error('Password must be at least 6 characters.');
                redirect('auth/reset-password?token=' . urlencode($token));
                return;
            }

            if ($newPassword !== $confirmPassword) {
                Flash::error('Passwords do not match.');
                redirect('auth/reset-password?token=' . urlencode($token));
                return;
            }

            $userModel->resetPassword((int) $tokenRow['user_id'], $newPassword);

            Flash::success('Your password has been reset successfully. Please log in.');
            redirect('auth/login');
            return;
        }

        $this->view('auth/reset-password', ['token' => $token, 'email' => $tokenRow['email']]);
    }

    // ── Change Password (logged-in user) ──────────────────────────

    public function changePassword(): void
    {
        if ($this->isPost()) {
            $current = $this->getPost('current_password', '');
            $new     = $this->getPost('new_password', '');
            $confirm = $this->getPost('confirm_password', '');

            if ($new !== $confirm) {
                Flash::error('New passwords do not match.');
                redirect('settings/profile');
                return;
            }

            if (strlen($new) < 6) {
                Flash::error('New password must be at least 6 characters.');
                redirect('settings/profile');
                return;
            }

            $userId    = Session::get('user_id');
            $userModel = new User();
            $user      = $userModel->findById($userId);

            if (!$user || !password_verify($current, $user['password'])) {
                Flash::error('Current password is incorrect.');
                redirect('settings/profile');
                return;
            }

            $userModel->update($userId, ['password' => password_hash($new, PASSWORD_BCRYPT, ['cost' => HASH_COST])]);
            Flash::success('Password changed successfully.');
            redirect('settings/profile');
            return;
        }
        redirect('settings/profile');
    }

    // ── AJAX: session check ───────────────────────────────────────

    public function checkSession(): void
    {
        if (Session::isLoggedIn()) {
            $this->json(['active' => true]);
        } else {
            http_response_code(401);
            $this->json(['active' => false]);
        }
    }

    // ── Private helpers ───────────────────────────────────────────

    private function redirectByRole(): void
    {
        $role = Session::get('role_name');
        if ($role === 'Student') redirect('student-portal');
        elseif ($role === 'Parent') redirect('parent');
        else redirect('dashboard');
    }

    private function sendResetEmail(array $user, string $token): void
    {
        $resetUrl = url('auth/reset-password') . '?token=' . urlencode($token);
        $name     = e($user['full_name'] ?? 'User');

        $body = Mailer::buildTemplate('Password Reset Request', "
            <p>Dear {$name},</p>
            <p>We received a request to reset the password for your account at <strong>" . e(APP_NAME) . "</strong>.</p>
            <p>Click the button below to reset your password. This link is valid for <strong>1 hour</strong>.</p>
            <p><a href='{$resetUrl}' class='btn'>Reset My Password</a></p>
            <hr class='divider'>
            <p style='font-size:13px;color:#888;'>If you did not request a password reset, please ignore this email. Your password will not change.</p>
            <p style='font-size:13px;color:#888;'>If the button above doesn't work, copy and paste this link into your browser:<br>
            <a href='{$resetUrl}' style='color:#1565C0;word-break:break-all;'>{$resetUrl}</a></p>
        ");

        $mailer = new Mailer();
        $mailer->send($user['email'], $user['full_name'] ?? 'User', 'Password Reset - ' . APP_NAME, $body);
    }
}
