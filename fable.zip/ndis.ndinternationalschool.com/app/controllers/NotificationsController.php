<?php
class NotificationsController extends Controller
{
    public function index(): void
    {
        $userId = Session::get('user_id');
        $notificationModel = new Notification();
        $notifications = $notificationModel->raw("SELECT * FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT 50", ['uid' => $userId]);
        $unreadCount = $notificationModel->getUnreadCount($userId);

        $this->view('notifications/index', [
            'pageTitle' => 'Notifications',
            'notifications' => $notifications,
            'unreadCount' => $unreadCount
        ]);
    }

    public function markRead(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $notificationModel = new Notification();
        $notificationModel->markRead($id);
        $link = $this->getGet('redirect');
        redirect($link ?: 'notifications');
    }

    public function markAllRead(): void
    {
        $userId = Session::get('user_id');
        $notificationModel = new Notification();
        $notificationModel->markAllRead($userId);
        Flash::success('All notifications marked as read.');
        redirect('notifications');
    }

    public function getUnreadCount(): void
    {
        $userId = Session::get('user_id');
        $notificationModel = new Notification();
        $count = $notificationModel->getUnreadCount($userId);
        $this->json(['count' => $count]);
    }

    public function getRecent(): void
    {
        $userId = Session::get('user_id');
        $notificationModel = new Notification();
        $notifications = $notificationModel->getUnread($userId);
        $this->json(['notifications' => $notifications]);
    }
}
