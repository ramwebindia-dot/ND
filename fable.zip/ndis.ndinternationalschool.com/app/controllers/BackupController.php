<?php
class BackupController extends Controller
{
    // Store backups OUTSIDE webroot so they're not publicly accessible
    private function backupDir(): string
    {
        // One level above APP_ROOT keeps it outside the public directory
        $dir = dirname(APP_ROOT) . '/backups';
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
            // Write an index.php just in case it ends up inside webroot
            file_put_contents($dir . '/index.php', '<?php exit; ?>');
        }
        return $dir;
    }

    public function index(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $backupDir = $this->backupDir();
        $backups   = [];
        $files     = glob($backupDir . '/*.sql') ?: [];
        foreach ($files as $file) {
            $backups[] = [
                'name' => basename($file),
                'size' => filesize($file),
                'date' => date('Y-m-d H:i:s', filemtime($file)),
            ];
        }
        usort($backups, fn($a, $b) => strtotime($b['date']) - strtotime($a['date']));

        $this->view('backup/index', [
            'pageTitle' => 'Database Backup',
            'backups'   => $backups,
        ]);
    }

    public function create(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        if (!$this->isPost()) { redirect('backup'); return; }

        $filename = 'backup_' . date('Y-m-d_His') . '.sql';
        $filepath = $this->backupDir() . '/' . $filename;

        try {
            $this->generateSQLBackup($filepath);
            Audit::log('backup', 'create', null, ['filename' => $filename]);
            Flash::success("Backup created: $filename");
        } catch (Exception $e) {
            Flash::error('Error creating backup: ' . $e->getMessage());
        }
        redirect('backup');
    }

    public function download(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);
        $filename = $this->getGet('file', '');
        if (!$this->isValidFilename($filename)) {
            Flash::error('Invalid backup file.');
            redirect('backup');
            return;
        }

        $filepath = $this->backupDir() . '/' . $filename;
        if (!file_exists($filepath)) {
            Flash::error('Backup file not found.');
            redirect('backup');
            return;
        }

        Audit::log('backup', 'download', null, ['filename' => $filename]);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }

    public function delete(): void
    {
        $this->requireRole(['Super Admin']);
        if (!$this->isPost()) { redirect('backup'); return; }

        $filename = $this->getPost('file', '');
        if (!$this->isValidFilename($filename)) {
            Flash::error('Invalid backup file.');
            redirect('backup');
            return;
        }

        $filepath = $this->backupDir() . '/' . $filename;
        if (file_exists($filepath)) {
            unlink($filepath);
            Audit::log('backup', 'delete', null, ['filename' => $filename]);
            Flash::success('Backup deleted successfully.');
        } else {
            Flash::error('Backup file not found.');
        }
        redirect('backup');
    }

    /**
     * Restore — shows a confirmation page on GET, executes on POST
     */
    public function restore(): void
    {
        $this->requireRole(['Super Admin']);

        $filename = $this->getGet('file', '') ?: $this->getPost('file', '');
        if (!$this->isValidFilename($filename)) {
            Flash::error('Invalid backup file.');
            redirect('backup');
            return;
        }

        $filepath = $this->backupDir() . '/' . $filename;
        if (!file_exists($filepath)) {
            Flash::error('Backup file not found.');
            redirect('backup');
            return;
        }

        // GET → show confirmation page
        if (!$this->isPost()) {
            $info = [
                'name' => $filename,
                'size' => filesize($filepath),
                'date' => date('Y-m-d H:i:s', filemtime($filepath)),
            ];
            $this->view('backup/confirm-restore', [
                'pageTitle' => 'Confirm Restore',
                'info'      => $info,
            ]);
            return;
        }

        // POST → execute restore
        try {
            $this->executeSQLRestore($filepath);
            Audit::log('backup', 'restore', null, ['filename' => $filename]);
            Flash::success('Database restored successfully from ' . $filename);
        } catch (Exception $e) {
            Flash::error('Restore failed: ' . $e->getMessage());
        }
        redirect('backup');
    }

    // ── Private helpers ────────────────────────────────────────────

    private function isValidFilename(string $filename): bool
    {
        return (bool) preg_match('/^backup_\d{4}-\d{2}-\d{2}_\d{6}\.sql$/', $filename);
    }

    private function generateSQLBackup(string $filepath): void
    {
        $model  = new Model();
        $tables = $model->raw("SHOW TABLES");

        $handle = fopen($filepath, 'w');
        if (!$handle) throw new Exception("Cannot write to backup path.");

        fwrite($handle, "-- ND International School Dinod - Database Backup\n");
        fwrite($handle, "-- Generated: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Server: " . DB_HOST . " | DB: " . DB_NAME . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($handle, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");
        fwrite($handle, "SET NAMES utf8mb4;\n\n");

        foreach ($tables as $tableRow) {
            $tableName = array_values($tableRow)[0];

            $createRow = $model->rawOne("SHOW CREATE TABLE `$tableName`");
            $createSQL = $createRow['Create Table'] ?? '';

            fwrite($handle, "-- -----------------------------------------------\n");
            fwrite($handle, "-- Table: `$tableName`\n");
            fwrite($handle, "-- -----------------------------------------------\n");
            fwrite($handle, "DROP TABLE IF EXISTS `$tableName`;\n");
            fwrite($handle, $createSQL . ";\n\n");

            // Fetch rows in chunks to avoid memory issues on large tables
            $offset = 0;
            $chunk  = 500;
            while (true) {
                $rows = $model->raw("SELECT * FROM `$tableName` LIMIT $chunk OFFSET $offset");
                if (empty($rows)) break;

                foreach ($rows as $row) {
                    $cols = '`' . implode('`, `', array_keys($row)) . '`';
                    $vals = implode(', ', array_map([$this, 'escapeValue'], array_values($row)));
                    fwrite($handle, "INSERT INTO `$tableName` ($cols) VALUES ($vals);\n");
                }
                $offset += $chunk;
                if (count($rows) < $chunk) break;
            }
            fwrite($handle, "\n");
        }

        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);
    }

    /**
     * Properly escape a value for SQL INSERT using PDO quoting (via the DB connection)
     */
    private function escapeValue($val): string
    {
        if ($val === null) return 'NULL';
        // Use hex encoding for binary safety
        return "'" . str_replace(
            ["\\", "'", "\n", "\r", "\x00", "\x1a"],
            ["\\\\", "\\'", "\\n", "\\r", "\\0", "\\Z"],
            (string) $val
        ) . "'";
    }

    /**
     * Execute a SQL file by splitting on statement delimiters — works with PDO
     * which does not support multi-statement execute by default.
     */
    private function executeSQLRestore(string $filepath): void
    {
        $sql = file_get_contents($filepath);
        if ($sql === false) throw new Exception("Cannot read backup file.");

        $model = new Model();

        // Split into individual statements (handles ; inside quoted strings)
        $statements = $this->splitSQL($sql);

        // NOTE: no transaction — DDL (DROP/CREATE TABLE) auto-commits in MySQL, so a
        // wrapping transaction is meaningless and hid the real bug. FK checks are
        // disabled here explicitly (not just relying on the dump) so table drops in
        // any order succeed.
        $model->query('SET FOREIGN_KEY_CHECKS=0');
        try {
            foreach ($statements as $stmt) {
                // Strip -- comment lines FIRST. The dump prefixes each DROP TABLE with a
                // comment block; splitSQL bundles them together, and the old check
                // (skip if it starts with '--') was throwing away the actual DROP/SET
                // statements, so restore silently failed with "table already exists".
                $stmt = trim(preg_replace('/^\s*--.*$/m', '', $stmt));
                if ($stmt === '') continue;
                $model->query($stmt);
            }
        } finally {
            $model->query('SET FOREIGN_KEY_CHECKS=1');
        }
    }

    /**
     * Split SQL file into individual statements, respecting quoted strings.
     */
    private function splitSQL(string $sql): array
    {
        $statements = [];
        $current    = '';
        $inSingle   = false;
        $inDouble   = false;
        $len        = strlen($sql);

        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];
            $prev = $i > 0 ? $sql[$i - 1] : '';

            if ($char === "'" && !$inDouble && $prev !== '\\') {
                $inSingle = !$inSingle;
            } elseif ($char === '"' && !$inSingle && $prev !== '\\') {
                $inDouble = !$inDouble;
            }

            if ($char === ';' && !$inSingle && !$inDouble) {
                $current = trim($current);
                if ($current !== '') $statements[] = $current;
                $current = '';
            } else {
                $current .= $char;
            }
        }

        $current = trim($current);
        if ($current !== '') $statements[] = $current;

        return $statements;
    }
}
