<?php
class StudentsController extends Controller
{
    public function index(): void
    {
        $this->requirePermission('students.view');
        $studentModel = new Student();
        $sessionId = Session::get('active_session_id');
        $search = $this->getGet('search', '');
        $classId = (int) $this->getGet('class_id', 0);
        $page = (int) $this->getGet('page', 1);

        $result = $studentModel->getStudentsWithDetails($sessionId ?? 0, $page, 20, $search, $classId ?: null);

        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        $this->view('students/index', [
            'pageTitle' => 'Students', 'students' => $result['data'], 'pagination' => $result,
            'classes' => $classes, 'search' => $search, 'classId' => $classId
        ]);
    }

    public function create(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            // Validate required fields first
            $this->validateOrFail($_POST, [
                'first_name' => ['required', 'max:100'],
                'class_id'   => ['required'],
                'gender'     => ['required'],
            ], 'students/create');

            // Whitelist only real `students` columns
            $data = [
                'first_name' => Validator::sanitize($this->getPost('first_name', '')),
                'last_name' => Validator::sanitize($this->getPost('last_name', '')) ?: null,
                'dob' => $this->getPost('date_of_birth') ?: null,
                'gender' => $this->getPost('gender'),
                'blood_group' => $this->getPost('blood_group') ?: null,
                'category' => $this->getPost('category') ?: null,
                'religion' => Validator::sanitize($this->getPost('religion', '')) ?: null,
                'phone' => $this->getPost('mobile') ?: null,
                'email' => $this->getPost('email') ?: null,
                'address' => Validator::sanitize($this->getPost('address', '')) ?: null,
                'class_id' => $this->getPost('class_id') ?: null,
                'section_id' => $this->getPost('section_id') ?: null,
                'roll_number' => $this->getPost('roll_number') ?: null,
                'previous_school' => Validator::sanitize($this->getPost('previous_school', '')) ?: null,
                'session_id' => $sessionId,
                'admission_number' => trim($this->getPost('admission_number', '')) ?: null,
                'admission_date' => $this->getPost('admission_date') ?: date('Y-m-d'),
                'status' => 'Active',
            ];

            // Handle photo upload
            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'students');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }

            // Parent data
            $parentData = [
                'father_name' => $this->getPost('father_name'),
                'father_phone' => $this->getPost('father_phone'),
                'father_email' => $this->getPost('father_email'),
                'father_occupation' => $this->getPost('father_occupation'),
                'mother_name' => $this->getPost('mother_name'),
                'mother_phone' => $this->getPost('mother_phone'),
                'address' => $this->getPost('parent_address'),
            ];

            try {
                $studentModel = new Student();
                $id = $studentModel->createStudent($data, $parentData);
                Audit::log('students', 'create', $id, $data);
                Flash::success('Student added successfully.');
                redirect('students');
            } catch (Exception $e) {
                Flash::error('Error adding student: ' . $e->getMessage());
            }
        }

        $this->view('students/create', ['pageTitle' => 'Add Student', 'classes' => $classes]);
    }

    public function profile(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($id);
        if (!$student) { Flash::error('Student not found.'); redirect('students'); return; }

        $sessionId = Session::get('active_session_id');
        $outstanding = $studentModel->getOutstandingBalance($id, $sessionId ?? 0);

        $this->view('students/profile', ['pageTitle' => 'Student Profile', 'student' => $student, 'outstanding' => $outstanding]);
    }

    public function edit(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $studentModel = new Student();
        $student = $studentModel->findById($id);
        if (!$student) { Flash::error('Student not found.'); redirect('students'); return; }

        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->isPost()) {
            $data = [
                'first_name' => Validator::sanitize($this->getPost('first_name', '')),
                'last_name' => Validator::sanitize($this->getPost('last_name', '')) ?: null,
                'dob' => $this->getPost('date_of_birth') ?: null,
                'gender' => $this->getPost('gender'),
                'blood_group' => $this->getPost('blood_group') ?: null,
                'category' => $this->getPost('category') ?: null,
                'religion' => Validator::sanitize($this->getPost('religion', '')) ?: null,
                'phone' => $this->getPost('mobile') ?: null,
                'email' => $this->getPost('email') ?: null,
                'address' => Validator::sanitize($this->getPost('address', '')) ?: null,
                'class_id' => $this->getPost('class_id') ?: null,
                'section_id' => $this->getPost('section_id') ?: null,
                'roll_number' => $this->getPost('roll_number') ?: null,
                'admission_number' => trim($this->getPost('admission_number', '')) ?: null,
            ];
            if (!empty($_FILES['photo']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadImage($_FILES['photo'], 'students');
                if ($result['success']) $data['photo'] = $result['file_path'];
            }
            $studentModel->update($id, $data);
            Audit::log('students', 'update', $id, $data);
            Flash::success('Student updated successfully.');
            redirect('students/profile?id=' . $id);
        }

        $sectionModel = new Section();
        $sections = $sectionModel->getByClass($student['class_id'] ?? 0);
        $this->view('students/edit', ['pageTitle' => 'Edit Student', 'student' => $student, 'classes' => $classes, 'sections' => $sections]);
    }

    public function delete(): void
    {
        $this->requirePost('students');
        $id = (int) ($this->getPost('id') ?? 0);
        $studentModel = new Student();
        $studentModel->update($id, ['status' => 'Dropout']);
        Audit::log('students', 'delete', $id);
        Flash::success('Student deactivated successfully.');
        redirect('students');
    }

    public function feeLedger(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $sessionId = Session::get('active_session_id');
        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($id);
        if (!$student) { Flash::error('Student not found.'); redirect('students'); return; }

        $ledger = $studentModel->getStudentFeeLedger($id, $sessionId ?? 0);
        $outstanding = $studentModel->getOutstandingBalance($id, $sessionId ?? 0);

        $this->view('students/fee-ledger', ['pageTitle' => 'Fee Ledger', 'student' => $student, 'ledger' => $ledger, 'outstanding' => $outstanding]);
    }

    public function idCard(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($id);
        if (!$student) { Flash::error('Student not found.'); redirect('students'); return; }
        $this->view('students/id-card', ['pageTitle' => 'Student ID Card', 'student' => $student]);
    }

    public function transferCertificate(): void
    {
        $id = (int) ($this->getGet('id') ?? 0);
        $studentModel = new Student();
        $student = $studentModel->getStudentWithDetails($id);
        if (!$student) { Flash::error('Student not found.'); redirect('students'); return; }

        if ($this->isPost()) {
            $tcNumber = $this->getPost('transfer_certificate_number');
            $studentModel->update($id, ['status' => 'Transfer Certificate', 'transfer_certificate_number' => $tcNumber]);
            Audit::log('students', 'transfer_certificate', $id);
            Flash::success('Transfer certificate issued.');
            redirect('students');
        }

        $this->view('students/transfer-certificate', ['pageTitle' => 'Transfer Certificate', 'student' => $student]);
    }

    public function import(): void
    {
        $importResult = null;
        if ($this->isPost() && !empty($_FILES['csv_file']['name'])) {
            $file      = $_FILES['csv_file']['tmp_name'];
            $handle    = fopen($file, 'r');
            $header    = array_map('trim', fgetcsv($handle));
            $sessionId = Session::get('active_session_id');
            $studentModel = new Student();
            $imported = 0; $failed = 0; $skipped = 0; $errors = [];
            $lineNum  = 1;

            while (($row = fgetcsv($handle)) !== false) {
                $lineNum++;
                if (count($row) !== count($header)) { $skipped++; continue; }
                $data = array_combine($header, array_map('trim', $row));
                if (empty($data['first_name'])) { $skipped++; continue; }

                $data['session_id']    = $sessionId;
                $data['status']        = 'Active';
                $data['admission_date'] = date('Y-m-d');
                if (empty($data['admission_number'])) {
                    $data['admission_number'] = Helper::generateAdmissionNumber($sessionId ?? 0);
                }
                // Map date_of_birth
                if (!empty($data['date_of_birth'])) $data['dob'] = $data['date_of_birth'];

                // Handle parent data separately
                $parentFields = ['father_name','father_phone','mother_name','mother_phone'];
                $parentData = array_intersect_key($data, array_flip($parentFields));
                foreach ($parentFields as $f) unset($data[$f]);

                try {
                    $studentId = $studentModel->create($data);
                    // Link parent if father_name given
                    if (!empty($parentData['father_name'])) {
                        $parentModel = new Model(); $parentModel->table = 'parents';
                        $parentId = $parentModel->create(array_merge($parentData, ['session_id' => $sessionId]));
                        $studentModel->update($studentId, ['parent_id' => $parentId]);
                    }
                    $imported++;
                } catch (Exception $e) {
                    $failed++;
                    $errors[] = "Row $lineNum: " . $e->getMessage();
                }
            }
            fclose($handle);
            $importResult = compact('imported','failed','skipped','errors');
            if ($imported) Flash::success("$imported students imported successfully.");
            if ($failed)   Flash::error("$failed rows failed. See details below.");
        }
        $this->view('students/import', ['pageTitle' => 'Import Students', 'importResult' => $importResult]);
    }

    public function importTemplate(): void
    {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="students_import_template.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['first_name','last_name','gender','date_of_birth','class_id','section_id','roll_number','father_name','father_phone','mother_name','address','blood_group','religion','category','email']);
        fputcsv($out, ['Rahul','Sharma','Male','2010-05-15','1','1','101','Ramesh Sharma','9876543210','Sunita Sharma','123 Main Street','B+','Hindu','General','']);
        fputcsv($out, ['Priya','Verma','Female','2011-08-20','1','2','102','Suresh Verma','9812345678','Meena Verma','45 Gandhi Nagar','O+','Hindu','OBC','']);
        fclose($out);
        exit;
    }
}