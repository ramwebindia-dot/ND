<?php
class SearchController extends Controller
{
    public function index(): void
    {
        header('Content-Type: application/json');
        // Prevent any output buffering / layout wrapping
        if (ob_get_level()) ob_clean();

        $q         = trim($this->getGet('q') ?? '');
        $sessionId = (int)(Session::get('active_session_id') ?? 0);

        if (strlen($q) < 2) {
            echo json_encode(['results' => []]);
            exit;
        }

        $like    = '%' . $q . '%';
        $results = [];
        $db      = new Model();

        // ── Students ──
        try {
            $students = $db->raw(
                "SELECT s.id, s.first_name, s.last_name, s.admission_number, c.name AS class_name
                 FROM students s
                 LEFT JOIN classes c ON s.class_id = c.id
                 WHERE s.session_id = :sid AND s.status = 'Active'
                   AND (s.first_name LIKE :q1 OR s.last_name LIKE :q2
                        OR s.admission_number LIKE :q3
                        OR CONCAT(s.first_name,' ',s.last_name) LIKE :q4)
                 LIMIT 6",
                ['sid' => $sessionId, 'q1' => $like, 'q2' => $like, 'q3' => $like, 'q4' => $like]
            );
            foreach ($students as $s) {
                $results[] = [
                    'type'  => 'student',
                    'icon'  => 'fas fa-user-graduate',
                    'label' => $s['first_name'] . ' ' . $s['last_name'],
                    'sub'   => 'Adm: ' . $s['admission_number'] . ' · ' . ($s['class_name'] ?? '—'),
                    'url'   => url('students/profile?id=' . $s['id']),
                ];
            }
        } catch (Exception $e) {}

        // ── Teachers ──
        try {
            $teachers = $db->raw(
                "SELECT id, first_name, last_name, employee_id, subject_specialization
                 FROM teachers
                 WHERE status = 'Active'
                   AND (first_name LIKE :q1 OR last_name LIKE :q2
                        OR employee_id LIKE :q3
                        OR CONCAT(first_name,' ',last_name) LIKE :q4)
                 LIMIT 4",
                ['q1' => $like, 'q2' => $like, 'q3' => $like, 'q4' => $like]
            );
            foreach ($teachers as $t) {
                $results[] = [
                    'type'  => 'teacher',
                    'icon'  => 'fas fa-chalkboard-teacher',
                    'label' => $t['first_name'] . ' ' . $t['last_name'],
                    'sub'   => 'ID: ' . $t['employee_id'] . ' · ' . ($t['subject_specialization'] ?? 'Teacher'),
                    'url'   => url('teachers/profile?id=' . $t['id']),
                ];
            }
        } catch (Exception $e) {}

        // ── Fee Receipts ──
        try {
            $receipts = $db->raw(
                "SELECT fc.id, fc.receipt_number, fc.paid_amount, s.first_name, s.last_name
                 FROM fee_collections fc
                 JOIN students s ON fc.student_id = s.id
                 WHERE fc.session_id = :sid AND fc.receipt_number LIKE :q1
                 LIMIT 3",
                ['sid' => $sessionId, 'q1' => $like]
            );
            foreach ($receipts as $r) {
                $results[] = [
                    'type'  => 'receipt',
                    'icon'  => 'fas fa-receipt',
                    'label' => 'Receipt #' . $r['receipt_number'],
                    'sub'   => $r['first_name'] . ' ' . $r['last_name'] . ' · ₹' . number_format($r['paid_amount'], 2),
                    'url'   => url('fees/receipt?id=' . $r['id']),
                ];
            }
        } catch (Exception $e) {}

        echo json_encode(['results' => $results]);
        exit;
    }
}
