<?php
class AuditController extends Controller
{
    public function index(): void
    {
        $this->requireRole(['Super Admin', 'School Admin']);

        $auditModel = new Audit();
        $filters = [
            'module' => $this->getGet('module'),
            'action' => $this->getGet('action'),
            'user_id' => $this->getGet('user_id'),
            'date_from' => $this->getGet('date_from'),
            'date_to' => $this->getGet('date_to'),
        ];
        $page = (int) $this->getGet('page', 1);
        $logs = $auditModel->getFiltered(array_filter($filters), $page, 25);

        $modules = $auditModel->raw("SELECT DISTINCT module FROM audit_logs ORDER BY module");

        $this->view('audit/index', [
            'pageTitle' => 'Audit Logs',
            'logs' => $logs['data'],
            'pagination' => $logs,
            'filters' => $filters,
            'modules' => $modules
        ]);
    }

    public function detail(): void
    {
        $this->requireRole(['Super Admin']);
        $id = (int) ($this->getGet('id') ?? 0);
        $auditModel = new Audit();
        $log = $auditModel->findById($id);
        if (!$log) { Flash::error('Log entry not found.'); redirect('audit'); return; }

        $userModel = new User();
        $user = $userModel->findById($log['user_id']);

        $this->view('audit/view', [
            'pageTitle' => 'Audit Log Detail',
            'log' => $log,
            'user' => $user
        ]);
    }

    public function export(): void
    {
        $this->requireRole(['Super Admin']);
        $auditModel = new Audit();
        $filters = [
            'module' => $this->getGet('module'),
            'action' => $this->getGet('action'),
            'user_id' => $this->getGet('user_id'),
            'date_from' => $this->getGet('date_from'),
            'date_to' => $this->getGet('date_to'),
        ];
        $logs = $auditModel->getFiltered(array_filter($filters), 1, 10000);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=audit_logs_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'User', 'Module', 'Action', 'Record ID', 'IP Address', 'Date']);
        foreach ($logs['data'] as $log) {
            fputcsv($output, [
                $log['id'],
                $log['user_name'] ?? 'System',
                $log['module'],
                $log['action'],
                $log['record_id'] ?? '',
                $log['ip_address'] ?? '',
                $log['created_at']
            ]);
        }
        fclose($output);
        exit;
    }
}
