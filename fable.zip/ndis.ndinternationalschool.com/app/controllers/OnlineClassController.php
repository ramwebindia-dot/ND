<?php
class OnlineClassController extends Controller
{
    public function index(): void
    {
        $model = new Model();
        $classId  = $this->getGet('class_id');
        $status   = $this->getGet('status');
        $dateFrom = $this->getGet('date_from') ?: date('Y-m-01');
        $dateTo   = $this->getGet('date_to')   ?: date('Y-m-t');

        $where = "WHERE oc.scheduled_at BETWEEN :df AND :dt";
        $params = ['df' => $dateFrom . ' 00:00:00', 'dt' => $dateTo . ' 23:59:59'];
        if ($classId) { $where .= " AND oc.class_id = :cid"; $params['cid'] = $classId; }
        if ($status)  { $where .= " AND oc.status = :st";    $params['st']  = $status; }

        $classes = $this->getClasses();
        $online_classes = $model->raw(
            "SELECT oc.*, c.name AS class_name, s.name AS subject_name,
                    sec.name AS section_name,
                    CONCAT(t.first_name,' ',COALESCE(t.last_name,'')) AS teacher_name
             FROM online_classes oc
             LEFT JOIN classes c ON oc.class_id = c.id
             LEFT JOIN subjects s ON oc.subject_id = s.id
             LEFT JOIN sections sec ON oc.section_id = sec.id
             LEFT JOIN teachers t ON oc.teacher_id = t.id
             $where
             ORDER BY oc.scheduled_at DESC", $params
        );

        $this->view('online-class/index', [
            'pageTitle'      => 'Online Classes',
            'online_classes' => $online_classes,
            'classes'        => $classes,
            'filters'        => compact('classId','status','dateFrom','dateTo'),
        ]);
    }

    public function create(): void
    {
        if ($this->isPost()) {
            $data = [
                'title'           => trim($this->getPost('title')),
                'class_id'        => (int)$this->getPost('class_id'),
                'section_id'      => $this->getPost('section_id') ?: null,
                'subject_id'      => $this->getPost('subject_id') ?: null,
                'teacher_id'      => (int)$this->getPost('teacher_id'),
                'scheduled_at'    => $this->getPost('scheduled_at'),
                'duration_mins'   => (int)$this->getPost('duration_mins', 45),
                'platform'        => $this->getPost('platform', 'Google Meet'),
                'meeting_link'    => trim($this->getPost('meeting_link')),
                'meeting_id'      => trim($this->getPost('meeting_id') ?: ''),
                'meeting_password'=> trim($this->getPost('meeting_password') ?: ''),
                'description'     => trim($this->getPost('description') ?: ''),
                'status'          => 'Scheduled',
                'created_by'      => Session::get('user_id'),
            ];
            if (!$data['title'] || !$data['class_id'] || !$data['teacher_id'] || !$data['meeting_link'] || !$data['scheduled_at']) {
                Flash::error('Please fill all required fields.');
                redirect('online-class/create');
                return;
            }
            $model = new Model(); $model->table = 'online_classes';
            $id = $model->create($data);
            // Notify students
            $this->notifyStudents($data['class_id'], $data['section_id'], $data['title'], $data['scheduled_at']);
            Audit::log('online_class', 'create', $id, $data);
            Flash::success('Online class scheduled successfully.');
            redirect('online-class');
        }

        $classes  = $this->getClasses();
        $teachers = (new Teacher())->getActiveTeachers();
        $this->view('online-class/create', [
            'pageTitle' => 'Schedule Online Class',
            'classes'   => $classes,
            'teachers'  => $teachers,
        ]);
    }

    public function show(): void
    {
        $id    = (int)($this->getGet('id') ?? 0);
        $model = new Model(); $model->table = 'online_classes';
        $oc = (new Model())->rawOne(
            "SELECT oc.*, c.name AS class_name, s.name AS subject_name,
                    sec.name AS section_name,
                    CONCAT(t.first_name,' ',COALESCE(t.last_name,'')) AS teacher_name
             FROM online_classes oc
             LEFT JOIN classes c ON oc.class_id = c.id
             LEFT JOIN subjects s ON oc.subject_id = s.id
             LEFT JOIN sections sec ON oc.section_id = sec.id
             LEFT JOIN teachers t ON oc.teacher_id = t.id
             WHERE oc.id = :id", ['id' => $id]
        );
        if (!$oc) { Flash::error('Class not found.'); redirect('online-class'); return; }

        // Attendance
        $attendance = (new Model())->raw(
            "SELECT oca.*, CONCAT(st.first_name,' ',COALESCE(st.last_name,'')) AS student_name,
                    st.admission_number
             FROM online_class_attendance oca
             JOIN students st ON oca.student_id = st.id
             WHERE oca.online_class_id = :id ORDER BY st.first_name", ['id' => $id]
        );

        // Students of this class (for marking attendance)
        $students = (new Model())->raw(
            "SELECT id, first_name, last_name, admission_number FROM students
             WHERE class_id = :cid AND status = 'Active' ORDER BY first_name",
            ['cid' => $oc['class_id']]
        );

        $this->view('online-class/view', [
            'pageTitle'  => 'Online Class Details',
            'oc'         => $oc,
            'attendance' => $attendance,
            'students'   => $students,
        ]);
    }

    public function edit(): void
    {
        $id    = (int)($this->getGet('id') ?? 0);
        $model = new Model(); $model->table = 'online_classes';
        $oc    = $model->findById($id);
        if (!$oc) { Flash::error('Class not found.'); redirect('online-class'); return; }

        if ($this->isPost()) {
            $data = [
                'title'           => trim($this->getPost('title')),
                'scheduled_at'    => $this->getPost('scheduled_at'),
                'duration_mins'   => (int)$this->getPost('duration_mins', 45),
                'platform'        => $this->getPost('platform', 'Google Meet'),
                'meeting_link'    => trim($this->getPost('meeting_link')),
                'meeting_id'      => trim($this->getPost('meeting_id') ?: ''),
                'meeting_password'=> trim($this->getPost('meeting_password') ?: ''),
                'description'     => trim($this->getPost('description') ?: ''),
                'recording_link'  => trim($this->getPost('recording_link') ?: ''),
                'status'          => $this->getPost('status', $oc['status']),
            ];
            $model->update($id, $data);
            Audit::log('online_class', 'update', $id, $data);
            Flash::success('Online class updated.');
            redirect('online-class');
        }

        $teachers = (new Teacher())->getActiveTeachers();
        $classes  = $this->getClasses();
        $this->view('online-class/edit', [
            'pageTitle' => 'Edit Online Class',
            'oc'        => $oc,
            'teachers'  => $teachers,
            'classes'   => $classes,
        ]);
    }

    public function delete(): void
    {
        $this->requirePost('online-class');
        $id = (int)($this->getPost('id') ?? 0);
        $model = new Model(); $model->table = 'online_classes';
        $model->delete($id);
        Audit::log('online_class', 'delete', $id);
        Flash::success('Online class deleted.');
        redirect('online-class');
    }

    public function updateStatus(): void
    {
        $this->requirePost('online-class');
        $id     = (int)$this->getPost('id');
        $status = $this->getPost('status');
        if (!in_array($status, ['Scheduled','Live','Completed','Cancelled'])) {
            Flash::error('Invalid status.'); redirect('online-class'); return;
        }
        $model = new Model(); $model->table = 'online_classes';
        $model->update($id, ['status' => $status]);
        Audit::log('online_class', 'status_change', $id, ['status' => $status]);
        Flash::success("Class marked as $status.");
        redirect('online-class/show?id=' . $id);
    }

    public function markAttendance(): void
    {
        $this->requirePost('online-class');
        $ocId       = (int)$this->getPost('online_class_id');
        $studentIds = $this->getPost('student_ids', []);
        $model = new Model(); $model->table = 'online_class_attendance';

        // Get all students in class first to mark absent
        $oc = (new Model())->rawOne("SELECT class_id FROM online_classes WHERE id = :id", ['id' => $ocId]);
        if (!$oc) { Flash::error('Class not found.'); redirect('online-class'); return; }

        $allStudents = (new Model())->raw(
            "SELECT id FROM students WHERE class_id = :cid AND status = 'Active'",
            ['cid' => $oc['class_id']]
        );

        foreach ($allStudents as $st) {
            $status = in_array($st['id'], (array)$studentIds) ? 'Present' : 'Absent';
            // upsert
            $existing = $model->rawOne(
                "SELECT id FROM online_class_attendance WHERE online_class_id = :oid AND student_id = :sid",
                ['oid' => $ocId, 'sid' => $st['id']]
            );
            if ($existing) {
                $model->update($existing['id'], ['status' => $status]);
            } else {
                $model->create(['online_class_id' => $ocId, 'student_id' => $st['id'], 'status' => $status]);
            }
        }

        Audit::log('online_class', 'mark_attendance', $ocId);
        Flash::success('Attendance saved successfully.');
        redirect('online-class/show?id=' . $ocId);
    }

    // Student portal: see their classes
    public function myClasses(): void
    {
        $userId    = Session::get('user_id');
        $student   = (new Model())->rawOne("SELECT id, class_id FROM students WHERE user_id = :uid", ['uid' => $userId]);
        if (!$student) { Flash::error('Student not found.'); redirect('dashboard'); return; }

        $classes = (new Model())->raw(
            "SELECT oc.*, c.name AS class_name, s.name AS subject_name,
                    CONCAT(t.first_name,' ',COALESCE(t.last_name,'')) AS teacher_name
             FROM online_classes oc
             LEFT JOIN classes c ON oc.class_id = c.id
             LEFT JOIN subjects s ON oc.subject_id = s.id
             LEFT JOIN teachers t ON oc.teacher_id = t.id
             WHERE oc.class_id = :cid AND oc.status IN ('Scheduled','Live')
             ORDER BY oc.scheduled_at ASC", ['cid' => $student['class_id']]
        );
        $this->view('online-class/my-classes', [
            'pageTitle' => 'My Online Classes',
            'classes'   => $classes,
        ]);
    }

    private function getClasses(): array
    {
        $sessionId = Session::get('active_session_id') ?? 0;
        return (new ClassModel())->getBySession($sessionId);
    }

    private function notifyStudents(int $classId, ?int $sectionId, string $title, string $scheduledAt): void
    {
        try {
            $students = (new Model())->raw(
                "SELECT user_id FROM students WHERE class_id = :cid AND status = 'Active' AND user_id IS NOT NULL",
                ['cid' => $classId]
            );
            foreach ($students as $st) {
                if ($st['user_id']) {
                    NotificationService::add(
                        (int)$st['user_id'],
                        'online_class',
                        "Online class scheduled: $title on " . date('d M Y h:i A', strtotime($scheduledAt))
                    );
                }
            }
        } catch (Exception $e) { error_log('Online class notify: ' . $e->getMessage()); }
    }
}
