<?php
class ReportsController extends Controller
{
    public function index(): void
    {
        $this->view('reports/index', ['pageTitle' => 'Reports']);
    }

    public function studentList(): void
    {
        $sessionId = Session::get('active_session_id');
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $status = $this->getGet('status', 'Active');

        $studentModel = new Student();
        $params = ['sid' => $sessionId ?? 0, 'status' => $status];
        $where = "s.session_id = :sid AND s.status = :status";
        if ($classId) { $where .= " AND s.class_id = :cid"; $params['cid'] = $classId; }

        $students = $studentModel->raw("SELECT s.*, c.name as class_name, sec.name as section_name FROM students s LEFT JOIN classes c ON s.class_id = c.id LEFT JOIN sections sec ON s.section_id = sec.id WHERE $where ORDER BY c.numeric_value, s.first_name", $params);

        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('student_list', $students, ['admission_number', 'first_name', 'last_name', 'class_name', 'section_name', 'gender', 'mobile', 'status']);
            return;
        }

        $this->view('reports/student-list', [
            'pageTitle' => 'Student List Report',
            'students' => $students,
            'classes' => $classes,
            'classId' => $classId,
            'status' => $status
        ]);
    }

    public function attendanceReport(): void
    {
        $sessionId = Session::get('active_session_id');
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));

        $attendanceModel = new Attendance();
        $report = [];
        if ($classId) {
            $report = $attendanceModel->raw("SELECT s.id, s.first_name, s.last_name, s.admission_number,
                COUNT(sa.id) as total_days,
                SUM(CASE WHEN sa.status = 'Present' THEN 1 ELSE 0 END) as present_days,
                SUM(CASE WHEN sa.status = 'Absent' THEN 1 ELSE 0 END) as absent_days,
                SUM(CASE WHEN sa.status = 'Late' THEN 1 ELSE 0 END) as late_days
                FROM students s LEFT JOIN student_attendance sa ON s.id = sa.student_id AND sa.date BETWEEN :from AND :to
                WHERE s.class_id = :cid AND s.session_id = :sid AND s.status = 'Active'
                GROUP BY s.id ORDER BY s.first_name", ['cid' => $classId, 'sid' => $sessionId ?? 0, 'from' => $dateFrom, 'to' => $dateTo]);
        }

        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('attendance_report', $report, ['admission_number', 'first_name', 'last_name', 'total_days', 'present_days', 'absent_days', 'late_days']);
            return;
        }

        $this->view('reports/attendance', [
            'pageTitle' => 'Attendance Report',
            'report' => $report,
            'classes' => $classes,
            'classId' => $classId,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function feeReport(): void
    {
        $sessionId = Session::get('active_session_id');
        $dateFrom  = $this->getGet('date_from', date('Y-m-01'));
        $dateTo    = $this->getGet('date_to',   date('Y-m-d'));

        $feeModel = new Fee();

        // Daily breakdown from fee_payment_transactions (ledger-based)
        $collections = $feeModel->raw(
            "SELECT fpt.id, fpt.receipt_number, fpt.payment_date, fpt.payment_method,
                    fpt.total_amount, fpt.status,
                    GROUP_CONCAT(DISTINCT s.first_name ORDER BY s.first_name SEPARATOR ', ') AS student_names,
                    GROUP_CONCAT(DISTINCT s.admission_number ORDER BY s.first_name SEPARATOR ', ') AS admission_numbers,
                    GROUP_CONCAT(DISTINCT COALESCE(fc.name,'Transport') ORDER BY fc.name SEPARATOR ', ') AS fee_types
             FROM fee_payment_transactions fpt
             JOIN fee_payment_items fpi ON fpi.transaction_id = fpt.id
             JOIN students s ON fpi.student_id = s.id
             LEFT JOIN fee_categories fc ON fpi.fee_category_id = fc.id
             WHERE fpt.session_id = :sid AND fpt.status = 'Active'
               AND fpt.payment_date BETWEEN :from AND :to
             GROUP BY fpt.id
             ORDER BY fpt.payment_date DESC, fpt.id DESC",
            ['sid' => $sessionId ?? 0, 'from' => $dateFrom, 'to' => $dateTo]
        );

        $totals = $feeModel->rawOne(
            "SELECT COALESCE(SUM(total_amount),0) AS total_collected,
                    COUNT(*) AS receipt_count
             FROM fee_payment_transactions
             WHERE session_id = :sid AND status = 'Active'
               AND payment_date BETWEEN :from AND :to",
            ['sid' => $sessionId ?? 0, 'from' => $dateFrom, 'to' => $dateTo]
        );

        $methodBreakdown = $feeModel->raw(
            "SELECT payment_method, COUNT(*) AS count, SUM(total_amount) AS total
             FROM fee_payment_transactions
             WHERE session_id = :sid AND status = 'Active'
               AND payment_date BETWEEN :from AND :to
             GROUP BY payment_method",
            ['sid' => $sessionId ?? 0, 'from' => $dateFrom, 'to' => $dateTo]
        );

        $totalOutstanding = $feeModel->getTotalOutstanding($sessionId ?? 0);

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('fee_report_' . $dateFrom . '_' . $dateTo, $collections, [
                'receipt_number','student_names','admission_numbers','fee_types',
                'total_amount','payment_method','payment_date'
            ]);
            return;
        }

        $this->view('reports/fee', [
            'pageTitle'        => 'Fee Collection Report',
            'collections'      => $collections,
            'totalCollected'   => (float)($totals['total_collected'] ?? 0),
            'receiptCount'     => (int)($totals['receipt_count'] ?? 0),
            'totalOutstanding' => $totalOutstanding,
            'methodBreakdown'  => $methodBreakdown,
            'dateFrom'         => $dateFrom,
            'dateTo'           => $dateTo,
        ]);
    }

    public function dailyCollection(): void
    {
        $sessionId = Session::get('active_session_id');
        $date      = $this->getGet('date', date('Y-m-d'));
        $feeModel  = new Fee();

        $daily   = $feeModel->getDailyCollection($date, $sessionId ?? 0);
        $rows    = $daily['receipts'] ?? [];
        $methods = $feeModel->getDailySummaryByMethod($date, $sessionId ?? 0);

        $this->view('reports/daily_collection', [
            'pageTitle' => 'Daily Fee Collection – ' . date('d M Y', strtotime($date)),
            'rows'      => $rows,
            'methods'   => $methods,
            'date'      => $date,
        ]);
    }

    public function monthlyCollection(): void
    {
        $sessionId = Session::get('active_session_id');
        $year      = (int)$this->getGet('year',  date('Y'));
        $month     = (int)$this->getGet('month', date('n'));
        $feeModel  = new Fee();

        $rows = $feeModel->getMonthlyCollection($year, $month, $sessionId ?? 0);

        $this->view('reports/monthly_collection', [
            'pageTitle' => 'Monthly Fee Collection',
            'rows'      => $rows,
            'year'      => $year,
            'month'     => $month,
        ]);
    }

    public function outstandingReport(): void
    {
        $sessionId = Session::get('active_session_id');
        $classId   = (int)$this->getGet('class_id', 0) ?: null;
        $feeModel  = new Fee();

        $rows = $feeModel->getOutstandingDetails($sessionId ?? 0, $classId);
        $classModel = new ClassModel();

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('outstanding_' . date('Y-m-d'), $rows, [
                'admission_number','first_name','last_name','class_name',
                'total_charged','total_paid','total_discount','outstanding'
            ]);
            return;
        }

        $this->view('reports/outstanding', [
            'pageTitle' => 'Outstanding Fees Report',
            'rows'      => $rows,
            'classes'   => $classModel->getBySession($sessionId ?? 0),
            'classId'   => $classId,
        ]);
    }

    public function examReport(): void
    {
        $sessionId = Session::get('active_session_id');
        $examId = (int) ($this->getGet('exam_id') ?? 0);
        $classId = (int) ($this->getGet('class_id') ?? 0);

        $examModel = new Exam();
        $exams = $examModel->raw("SELECT * FROM exams WHERE session_id = :sid ORDER BY start_date DESC", ['sid' => $sessionId ?? 0]);

        $report = [];
        if ($examId && $classId) {
            $report = $examModel->raw("SELECT m.*, s.first_name, s.last_name, s.admission_number, sub.name as subject_name, m.marks_obtained, m.total_marks, m.grade
                FROM marks m JOIN students s ON m.student_id = s.id JOIN subjects sub ON m.subject_id = sub.id
                WHERE m.exam_id = :eid AND s.class_id = :cid ORDER BY s.first_name, sub.name", ['eid' => $examId, 'cid' => $classId]);
        }

        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('exam_report', $report, ['admission_number', 'first_name', 'last_name', 'subject_name', 'marks_obtained', 'total_marks', 'grade']);
            return;
        }

        $this->view('reports/exam', [
            'pageTitle' => 'Exam Report',
            'exams' => $exams,
            'classes' => $classes,
            'examId' => $examId,
            'classId' => $classId,
            'report' => $report
        ]);
    }

    public function financialReport(): void
    {
        $dateFrom = $this->getGet('date_from', date('Y-m-01'));
        $dateTo = $this->getGet('date_to', date('Y-m-d'));

        $accountingModel = new Accounting();
        $summary = $accountingModel->getFinancialSummary($dateFrom, $dateTo);
        $cashBalance = $accountingModel->getCashBalance();
        $totalBankBalance = $accountingModel->getTotalBankBalance();

        $this->view('reports/financial', [
            'pageTitle' => 'Financial Report',
            'summary' => $summary,
            'cashBalance' => $cashBalance,
            'totalBankBalance' => $totalBankBalance,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }

    public function teacherReport(): void
    {
        $teacherModel = new Teacher();
        $teachers = $teacherModel->raw("SELECT t.*, d.name as department_name FROM teachers t LEFT JOIN departments d ON t.department_id = d.id WHERE t.status = 'Active' ORDER BY t.first_name");

        if ($this->getGet('export') === 'csv') {
            $this->exportCSV('teacher_list', $teachers, ['employee_id', 'first_name', 'last_name', 'department_name', 'designation', 'phone', 'email']);
            return;
        }

        $this->view('reports/teacher', [
            'pageTitle' => 'Teacher Report',
            'teachers' => $teachers
        ]);
    }

    public function libraryReport(): void
    {
        $libraryModel = new Library();
        $issued = $libraryModel->getIssuedBooks(1, 1000);
        $overdue = $libraryModel->getOverdueBooks();

        $model = new Model();
        $model->table = 'books';
        $totalBooks = $model->count();
        $availableBooks = $model->count('available_quantity > 0');

        $this->view('reports/library', [
            'pageTitle' => 'Library Report',
            'issued' => $issued['data'],
            'overdue' => $overdue,
            'totalBooks' => $totalBooks,
            'availableBooks' => $availableBooks
        ]);
    }

    private function exportCSV(string $filename, array $data, array $columns, array $headers = []): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename . '_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');
        // BOM for Excel UTF-8 compatibility
        fwrite($output, "\xEF\xBB\xBF");
        fputcsv($output, !empty($headers) ? $headers : $columns);
        foreach ($data as $row) {
            $csvRow = [];
            foreach ($columns as $col) {
                $csvRow[] = $row[$col] ?? '';
            }
            fputcsv($output, $csvRow);
        }
        fclose($output);
        exit;
    }

    /**
     * Export as Excel XML (opens correctly in Excel without a library)
     */
    private function exportExcel(string $filename, array $data, array $columns, array $headers = []): void
    {
        $displayHeaders = !empty($headers) ? $headers : $columns;
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename . '_' . date('Y-m-d') . '.xls');
        header('Cache-Control: max-age=0');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' . "\n";
        echo '<Worksheet ss:Name="Report"><Table>' . "\n";
        // Header row
        echo '<Row>';
        foreach ($displayHeaders as $h) {
            echo '<Cell ss:StyleID="header"><Data ss:Type="String">' . htmlspecialchars($h) . '</Data></Cell>';
        }
        echo '</Row>' . "\n";
        // Data rows
        foreach ($data as $row) {
            echo '<Row>';
            foreach ($columns as $col) {
                $val = $row[$col] ?? '';
                $type = is_numeric($val) && !empty($val) ? 'Number' : 'String';
                echo '<Cell><Data ss:Type="'.$type.'">' . htmlspecialchars((string)$val) . '</Data></Cell>';
            }
            echo '</Row>' . "\n";
        }
        echo '</Table></Worksheet></Workbook>';
        exit;
    }

    /** Generic Excel export endpoint */
    public function exportExcelReport(): void
    {
        $type = $this->getGet('type') ?: 'students';
        $sessionId = Session::get('active_session_id') ?? 0;

        switch ($type) {
            case 'students':
                $rows = (new Student())->raw(
                    "SELECT s.admission_number, CONCAT(s.first_name,' ',IFNULL(s.last_name,'')) as name,
                            c.name as class_name, sec.name as section_name, s.gender, s.phone, s.status
                     FROM students s
                     LEFT JOIN classes c ON s.class_id = c.id
                     LEFT JOIN sections sec ON s.section_id = sec.id
                     WHERE s.session_id = :sid ORDER BY c.name, s.first_name",
                    ['sid' => $sessionId]
                );
                $this->exportExcel('students', $rows,
                    ['admission_number','name','class_name','section_name','gender','phone','status'],
                    ['Adm No','Name','Class','Section','Gender','Phone','Status']);
                break;

            case 'fees':
                $from = $this->getGet('from') ?: date('Y-m-01');
                $to   = $this->getGet('to')   ?: date('Y-m-d');
                $rows = (new Fee())->raw(
                    "SELECT fpt.receipt_number, CONCAT(s.first_name,' ',IFNULL(s.last_name,'')) as student_name,
                            c.name as class_name, fpt.payment_date, fpt.total_amount, fpt.payment_mode, fpt.status
                     FROM fee_payment_transactions fpt
                     JOIN students s ON fpt.student_id = s.id
                     LEFT JOIN classes c ON s.class_id = c.id
                     WHERE fpt.payment_date BETWEEN :f AND :t AND fpt.session_id = :sid
                     ORDER BY fpt.payment_date DESC",
                    ['f' => $from, 't' => $to, 'sid' => $sessionId]
                );
                $this->exportExcel('fee_collection_'.$from.'_'.$to, $rows,
                    ['receipt_number','student_name','class_name','payment_date','total_amount','payment_mode','status'],
                    ['Receipt No','Student','Class','Date','Amount','Mode','Status']);
                break;

            case 'attendance':
                $month = $this->getGet('month') ?: date('Y-m');
                $rows = (new Attendance())->raw(
                    "SELECT s.admission_number, CONCAT(s.first_name,' ',IFNULL(s.last_name,'')) as name,
                            c.name as class_name,
                            COUNT(CASE WHEN a.status='Present' THEN 1 END) as present,
                            COUNT(CASE WHEN a.status='Absent' THEN 1 END) as absent,
                            COUNT(a.id) as total
                     FROM students s
                     LEFT JOIN student_attendance a ON a.student_id=s.id AND DATE_FORMAT(a.date,'%Y-%m')=:month
                     LEFT JOIN classes c ON s.class_id=c.id
                     WHERE s.session_id=:sid AND s.status='Active'
                     GROUP BY s.id ORDER BY c.name,s.first_name",
                    ['month' => $month, 'sid' => $sessionId]
                );
                $this->exportExcel('attendance_'.$month, $rows,
                    ['admission_number','name','class_name','present','absent','total'],
                    ['Adm No','Name','Class','Present','Absent','Total Days']);
                break;

            default:
                Flash::error('Unknown export type.');
                redirect('reports');
        }
    }
}
