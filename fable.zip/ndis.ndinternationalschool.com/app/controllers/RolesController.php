<?php
class RolesController extends Controller
{
    public function index(): void
    {
        $this->requireRole(['Super Admin']);
        $roleModel = new Role();
        $roles = $roleModel->getRolesWithUserCount();

        $this->view('roles/index', [
            'pageTitle' => 'Role & Permission Management',
            'roles' => $roles
        ]);
    }

    public function permissions(): void
    {
        $this->requireRole(['Super Admin']);
        $roleId = (int) ($this->getGet('id') ?? 0);
        $roleModel = new Role();
        $role = $roleModel->findById($roleId);
        if (!$role) { Flash::error('Role not found.'); redirect('roles'); return; }

        // Get current permissions from database
        $dbPermissions = $roleModel->raw("SELECT permission_name FROM role_permissions WHERE role_id = :rid", ['rid' => $roleId]);
        $currentPermissions = array_column($dbPermissions, 'permission_name');

        // Get all available permissions from the Permission class
        $allPermissions = Permission::getAllPermissions();

        if ($this->isPost()) {
            $raw = $_POST['permissions'] ?? [];
            $permissions = is_array($raw) ? array_map('strval', array_filter($raw, 'is_string')) : [];
            try {
                $roleModel->updatePermissions($roleId, $permissions);
                Audit::log('roles', 'update_permissions', $roleId, ['permissions' => $permissions]);
                Flash::success('Permissions updated successfully.');
                redirect('roles');
                return;
            } catch (Exception $e) {
                Flash::error('Error updating permissions: ' . $e->getMessage());
            }
        }

        $this->view('roles/permissions', [
            'pageTitle' => 'Manage Permissions - ' . $role['name'],
            'role' => $role,
            'currentPermissions' => $currentPermissions,
            'allPermissions' => $allPermissions
        ]);
    }

    public function create(): void
    {
        $this->requireRole(['Super Admin']);
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            try {
                $roleModel = new Role();
                $id = $roleModel->create($data);
                Audit::log('roles', 'create', $id, $data);
                Flash::success('Role created successfully.');
            } catch (Exception $e) {
                Flash::error('Error creating role: ' . $e->getMessage());
            }
        }
        redirect('roles');
    }

    public function update(): void
    {
        $this->requireRole(['Super Admin']);
        if ($this->isPost()) {
            $id = (int) $this->getPost('id');
            $data = ['name' => $this->getPost('name'), 'description' => $this->getPost('description')];
            try {
                $roleModel = new Role();
                $roleModel->update($id, $data);
                Audit::log('roles', 'update', $id, $data);
                Flash::success('Role updated successfully.');
            } catch (Exception $e) {
                Flash::error('Error updating role: ' . $e->getMessage());
            }
        }
        redirect('roles');
    }

    public function delete(): void
    {
        $this->requireRole(['Super Admin']);
        $this->requirePost('roles');

        $id = (int)$this->getPost('id');

        // Safety: don't delete if users exist
        $count = (new Model())->rawOne("SELECT COUNT(*) AS cnt FROM users WHERE role_id = :rid", ['rid' => $id]);
        if ((int)($count['cnt'] ?? 0) > 0) {
            Flash::error('Cannot delete role that has users assigned.');
            redirect('roles');
            return;
        }

        (new Model())->query("DELETE FROM role_permissions WHERE role_id = :id", ['id' => $id]);
        (new Model())->query("DELETE FROM roles WHERE id = :id", ['id' => $id]);

        Audit::log('roles', 'delete', $id);
        Flash::success('Role deleted.');
        redirect('roles');
    }
}
