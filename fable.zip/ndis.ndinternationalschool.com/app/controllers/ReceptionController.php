<?php
/**
 * Reception / Front Desk module — admission enquiries, visitor gate-pass,
 * phone-call log and complaint/query register.
 */
class ReceptionController extends Controller
{
    private function m(string $table): Model
    {
        $m = new Model(); $m->table = $table; return $m;
    }

    // ── Overview ──────────────────────────────────────────────────
    public function index(): void
    {
        $this->requirePermission('reception.view');
        Permission::check('reception.view');
        $db = new Model();
        $stats = [
            'open_enquiries'   => (int)($db->rawOne("SELECT COUNT(*) c FROM reception_enquiries WHERE status IN ('Open','Contacted')")['c'] ?? 0),
            'today_visitors'   => (int)($db->rawOne("SELECT COUNT(*) c FROM reception_visitors WHERE visit_date = CURDATE()")['c'] ?? 0),
            'inside_visitors'  => (int)($db->rawOne("SELECT COUNT(*) c FROM reception_visitors WHERE visit_date = CURDATE() AND out_time IS NULL")['c'] ?? 0),
            'today_calls'      => (int)($db->rawOne("SELECT COUNT(*) c FROM reception_calls WHERE call_date = CURDATE()")['c'] ?? 0),
            'open_complaints'  => (int)($db->rawOne("SELECT COUNT(*) c FROM reception_complaints WHERE status <> 'Resolved'")['c'] ?? 0),
        ];
        $this->view('reception/index', ['pageTitle' => 'Reception', 'stats' => $stats]);
    }

    // ── Admission Enquiries ───────────────────────────────────────
    public function enquiries(): void
    {
        Permission::check('reception.view');
        if ($this->isPost()) {
            $this->requirePost('reception/enquiries');
            Permission::check('reception.manage');
            $name = trim($this->getPost('parent_name', ''));
            $phone = trim($this->getPost('phone', ''));
            if ($name === '' || $phone === '') { Flash::error('Parent name and phone are required.'); redirect('reception/enquiries'); return; }
            $this->m('reception_enquiries')->create([
                'enquiry_date'     => $this->getPost('enquiry_date', date('Y-m-d')),
                'parent_name'      => Validator::sanitize($name),
                'student_name'     => Validator::sanitize($this->getPost('student_name', '')),
                'class_interested' => Validator::sanitize($this->getPost('class_interested', '')),
                'phone'            => Validator::sanitize($phone),
                'email'            => Validator::sanitize($this->getPost('email', '')),
                'source'           => Validator::sanitize($this->getPost('source', 'Walk-in')),
                'remarks'          => Validator::sanitize($this->getPost('remarks', '')),
                'follow_up_date'   => $this->getPost('follow_up_date') ?: null,
                'status'           => 'Open',
                'handled_by'       => (int)Session::get('user_id'),
            ]);
            Audit::log('reception', 'enquiry_add', null);
            Flash::success('Enquiry recorded.');
            redirect('reception/enquiries');
            return;
        }
        $rows = (new Model())->raw("SELECT * FROM reception_enquiries ORDER BY enquiry_date DESC, id DESC LIMIT 300");
        $this->view('reception/enquiries', ['pageTitle' => 'Admission Enquiries', 'rows' => $rows]);
    }

    public function updateEnquiry(): void
    {
        $this->requirePost('reception/enquiries');
        Permission::check('reception.manage');
        $id = (int)$this->getPost('id', 0);
        $status = Validator::sanitize($this->getPost('status', 'Open'));
        $this->m('reception_enquiries')->update($id, [
            'status'         => $status,
            'follow_up_date' => $this->getPost('follow_up_date') ?: null,
            'remarks'        => Validator::sanitize($this->getPost('remarks', '')),
        ]);
        Flash::success('Enquiry updated.');
        redirect('reception/enquiries');
    }

    // ── Visitors / Gate Pass ──────────────────────────────────────
    public function visitors(): void
    {
        Permission::check('reception.view');
        if ($this->isPost()) {
            $this->requirePost('reception/visitors');
            Permission::check('reception.manage');
            $name = trim($this->getPost('visitor_name', ''));
            if ($name === '') { Flash::error('Visitor name is required.'); redirect('reception/visitors'); return; }
            $this->m('reception_visitors')->create([
                'visit_date'    => date('Y-m-d'),
                'visitor_name'  => Validator::sanitize($name),
                'phone'         => Validator::sanitize($this->getPost('phone', '')),
                'whom_to_meet'  => Validator::sanitize($this->getPost('whom_to_meet', '')),
                'purpose'       => Validator::sanitize($this->getPost('purpose', '')),
                'id_proof'      => Validator::sanitize($this->getPost('id_proof', '')),
                'no_of_persons' => (int)$this->getPost('no_of_persons', 1) ?: 1,
                'in_time'       => date('Y-m-d H:i:s'),
                'remarks'       => Validator::sanitize($this->getPost('remarks', '')),
                'created_by'    => (int)Session::get('user_id'),
            ]);
            Audit::log('reception', 'visitor_in', null);
            Flash::success('Visitor checked in.');
            redirect('reception/visitors');
            return;
        }
        $rows = (new Model())->raw("SELECT * FROM reception_visitors ORDER BY id DESC LIMIT 300");
        $this->view('reception/visitors', ['pageTitle' => 'Visitor Log', 'rows' => $rows]);
    }

    public function visitorOut(): void
    {
        $this->requirePost('reception/visitors');
        Permission::check('reception.manage');
        $id = (int)$this->getPost('id', 0);
        $this->m('reception_visitors')->update($id, ['out_time' => date('Y-m-d H:i:s')]);
        Flash::success('Visitor checked out.');
        redirect('reception/visitors');
    }

    // ── Phone Call Log ────────────────────────────────────────────
    public function calls(): void
    {
        Permission::check('reception.view');
        if ($this->isPost()) {
            $this->requirePost('reception/calls');
            Permission::check('reception.manage');
            $name = trim($this->getPost('caller_name', ''));
            if ($name === '') { Flash::error('Caller name is required.'); redirect('reception/calls'); return; }
            $this->m('reception_calls')->create([
                'call_date'   => $this->getPost('call_date', date('Y-m-d')),
                'caller_name' => Validator::sanitize($name),
                'phone'       => Validator::sanitize($this->getPost('phone', '')),
                'direction'   => Validator::sanitize($this->getPost('direction', 'Incoming')),
                'purpose'     => Validator::sanitize($this->getPost('purpose', '')),
                'remarks'     => Validator::sanitize($this->getPost('remarks', '')),
                'created_by'  => (int)Session::get('user_id'),
            ]);
            Audit::log('reception', 'call_add', null);
            Flash::success('Call logged.');
            redirect('reception/calls');
            return;
        }
        $rows = (new Model())->raw("SELECT * FROM reception_calls ORDER BY call_date DESC, id DESC LIMIT 300");
        $this->view('reception/calls', ['pageTitle' => 'Phone Call Log', 'rows' => $rows]);
    }

    // ── Complaints / Queries ──────────────────────────────────────
    public function complaints(): void
    {
        Permission::check('reception.view');
        if ($this->isPost()) {
            $this->requirePost('reception/complaints');
            Permission::check('reception.manage');
            $name = trim($this->getPost('complainant_name', ''));
            $subject = trim($this->getPost('subject', ''));
            if ($name === '' || $subject === '') { Flash::error('Name and subject are required.'); redirect('reception/complaints'); return; }
            $this->m('reception_complaints')->create([
                'complaint_date'   => $this->getPost('complaint_date', date('Y-m-d')),
                'complainant_name' => Validator::sanitize($name),
                'phone'            => Validator::sanitize($this->getPost('phone', '')),
                'subject'          => Validator::sanitize($subject),
                'details'          => Validator::sanitize($this->getPost('details', '')),
                'status'           => 'Open',
                'handled_by'       => (int)Session::get('user_id'),
            ]);
            Audit::log('reception', 'complaint_add', null);
            Flash::success('Complaint recorded.');
            redirect('reception/complaints');
            return;
        }
        $rows = (new Model())->raw("SELECT * FROM reception_complaints ORDER BY (status='Resolved'), complaint_date DESC, id DESC LIMIT 300");
        $this->view('reception/complaints', ['pageTitle' => 'Complaints / Queries', 'rows' => $rows]);
    }

    public function resolveComplaint(): void
    {
        $this->requirePost('reception/complaints');
        Permission::check('reception.manage');
        $id = (int)$this->getPost('id', 0);
        $this->m('reception_complaints')->update($id, [
            'status'     => Validator::sanitize($this->getPost('status', 'Resolved')),
            'resolution' => Validator::sanitize($this->getPost('resolution', '')),
        ]);
        Flash::success('Complaint updated.');
        redirect('reception/complaints');
    }
}
