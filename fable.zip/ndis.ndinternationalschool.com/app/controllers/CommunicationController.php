<?php
class CommunicationController extends Controller
{
    public function index(): void
    {
        $this->notices();
    }

    public function notices(): void
    {
        $model = new Model();
        $model->table = 'notices';
        $page = (int) $this->getGet('page', 1);
        $notices = $model->paginate($page, 20, '', [], 'created_at DESC');

        $this->view('communication/notices', [
            'pageTitle' => 'Notice Board',
            'notices' => $notices['data'],
            'pagination' => $notices
        ]);
    }

    public function saveNotice(): void
    {
        if ($this->isPost()) {
            $data = Validator::sanitizeArray($_POST);
            $data['posted_by'] = Session::get('user_id');
            $data['is_active'] = isset($data['is_active']) ? 1 : 0;

            // Handle attachment
            if (!empty($_FILES['attachment']['name'])) {
                $upload = new FileUpload();
                $result = $upload->uploadDocument($_FILES['attachment'], 'documents');
                if ($result['success']) $data['attachment'] = $result['file_path'];
            }

            try {
                $model = new Model();
                $model->table = 'notices';
                if (!empty($data['id'])) {
                    $model->update((int)$data['id'], $data);
                    Audit::log('communication', 'update_notice', (int)$data['id'], $data);
                    Flash::success('Notice updated successfully.');
                } else {
                    $id = $model->create($data);
                    Audit::log('communication', 'create_notice', $id, $data);
                    Flash::success('Notice posted successfully.');
                }
            } catch (Exception $e) {
                Flash::error('Error saving notice: ' . $e->getMessage());
            }
        }
        redirect('communication/notices');
    }

    public function deleteNotice(): void
    {
        $this->requirePost('communication/notices');
        $id = (int) ($this->getPost('id') ?? 0);
        $model = new Model();
        $model->table = 'notices';
        $model->delete($id);
        Audit::log('communication', 'delete_notice', $id);
        Flash::success('Notice deleted successfully.');
        redirect('communication/notices');
    }

    public function messages(): void
    {
        $type = $this->getGet('type', 'inbox');
        $userId = Session::get('user_id');
        $commModel = new Communication();
        $messages = $commModel->getMessages($userId, $type);

        $this->view('communication/messages', [
            'pageTitle' => 'Messages',
            'messages' => $messages,
            'type' => $type
        ]);
    }

    public function sendMessage(): void
    {
        if ($this->isPost()) {
            $receiverId = (int) $this->getPost('receiver_id');
            $subject = $this->getPost('subject');
            $message = $this->getPost('message');
            $senderId = Session::get('user_id');

            try {
                $commModel = new Communication();
                $id = $commModel->sendMessage($senderId, $receiverId, $subject, $message);
                Audit::log('communication', 'send_message', $id);
                Flash::success('Message sent successfully.');
            } catch (Exception $e) {
                Flash::error('Error sending message: ' . $e->getMessage());
            }
        }
        redirect('communication/messages');
    }

    public function compose(): void
    {
        $userModel = new User();
        $users = $userModel->findAll('full_name');

        $this->view('communication/compose', [
            'pageTitle' => 'Compose Message',
            'users' => $users
        ]);
    }

    public function viewMessage(): void
    {
        $id    = (int)($this->getGet('id') ?? 0);
        $model = new Model();
        $message = $model->rawOne(
            "SELECT m.*,
                    s.full_name AS sender_name,
                    r.full_name AS receiver_name
             FROM messages m
             JOIN users s ON s.id = m.sender_id
             JOIN users r ON r.id = m.receiver_id
             WHERE m.id = :id",
            ['id' => $id]
        );
        if (!$message) { Flash::error('Message not found.'); redirect('communication/messages'); return; }

        // Security: only sender or receiver can view
        $userId = (int)Session::get('user_id');
        if ($message['sender_id'] != $userId && $message['receiver_id'] != $userId) {
            Flash::error('Access denied.'); redirect('communication/messages'); return;
        }

        // Mark as read
        if ($message['receiver_id'] == $userId && !$message['is_read']) {
            $model->table = 'messages';
            $model->update($id, ['is_read' => 1]);
        }

        $this->view('communication/view-message', [
            'pageTitle' => 'View Message',
            'message'   => $message,
        ]);
    }

    public function reply(): void
    {
        $this->requirePost('communication/messages');
        $receiverId = (int)$this->getPost('receiver_id');
        $subject    = trim($this->getPost('subject', 'Re: (no subject)'));
        $body       = trim($this->getPost('message', ''));
        $senderId   = (int)Session::get('user_id');

        if (!$receiverId || !$body) { Flash::error('Reply cannot be empty.'); redirect('communication/messages'); return; }

        $commModel = new Communication();
        $commModel->sendMessage($senderId, $receiverId, $subject, $body);
        Audit::log('communication', 'reply', 0, ['receiver_id' => $receiverId]);
        Flash::success('Reply sent.');
        redirect('communication/messages');
    }

    /** Broadcast — send a message to an entire class or role */
    public function broadcast(): void
    {
        if ($this->isPost()) {
            $subject   = trim($this->getPost('subject', ''));
            $body      = trim($this->getPost('message', ''));
            $classId   = (int)($this->getPost('class_id') ?? 0);
            $roleId    = $this->getPost('target_role') ?: null;
            $senderId  = (int)Session::get('user_id');
            $sessionId = Session::get('active_session_id') ?? 0;

            if (!$subject || !$body) { Flash::error('Subject and message are required.'); redirect('communication/broadcast'); return; }

            $commModel = new Communication();
            $recipients = [];

            if ($classId) {
                // All students in class
                $students = (new Student())->raw(
                    "SELECT u.id as user_id FROM students s JOIN users u ON s.user_id = u.id
                     WHERE s.class_id = :cid AND s.session_id = :sid AND s.status='Active' AND s.user_id IS NOT NULL",
                    ['cid' => $classId, 'sid' => $sessionId]
                );
                $recipients = array_column($students, 'user_id');
            } elseif ($roleId) {
                // All users with role
                $users = (new Model())->raw(
                    "SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = :role AND u.is_active = 1",
                    ['role' => $roleId]
                );
                $recipients = array_column($users, 'id');
            }

            $sent = 0;
            foreach ($recipients as $rid) {
                if ($rid != $senderId) {
                    $commModel->sendMessage($senderId, (int)$rid, $subject, $body);
                    $sent++;
                }
            }

            Audit::log('communication', 'broadcast', 0, ['subject' => $subject, 'recipients' => $sent]);
            Flash::success("Broadcast sent to $sent recipient(s).");
            redirect('communication/broadcast');
            return;
        }

        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);
        $roles     = ['Teacher', 'Student', 'Parent', 'Principal', 'Accountant'];

        $this->view('communication/broadcast', [
            'pageTitle' => 'Broadcast Message',
            'classes'   => $classes,
            'roles'     => $roles,
        ]);
    }
}
