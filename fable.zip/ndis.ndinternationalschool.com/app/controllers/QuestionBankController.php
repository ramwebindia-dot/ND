<?php
class QuestionBankController extends Controller
{
    public function index(): void
    {
        $classId   = $this->getGet('class_id');
        $subjectId = $this->getGet('subject_id');
        $type      = $this->getGet('type');
        $difficulty= $this->getGet('difficulty');

        $where  = "WHERE 1=1";
        $params = [];
        if ($classId)   { $where .= " AND qb.class_id = :cid";    $params['cid'] = $classId; }
        if ($subjectId) { $where .= " AND qb.subject_id = :sid";   $params['sid'] = $subjectId; }
        if ($type)      { $where .= " AND qb.question_type = :tp"; $params['tp']  = $type; }
        if ($difficulty){ $where .= " AND qb.difficulty = :df";    $params['df']  = $difficulty; }

        $questions = (new Model())->raw(
            "SELECT qb.*, c.name AS class_name, s.name AS subject_name
             FROM question_bank qb
             LEFT JOIN classes c ON qb.class_id = c.id
             LEFT JOIN subjects s ON qb.subject_id = s.id
             $where ORDER BY qb.created_at DESC LIMIT 200", $params
        );

        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);
        $subjects  = (new Model())->raw("SELECT id, name FROM subjects ORDER BY name");

        $this->view('question-bank/index', [
            'pageTitle' => 'Question Bank',
            'questions' => $questions,
            'classes'   => $classes,
            'subjects'  => $subjects,
            'filters'   => compact('classId','subjectId','type','difficulty'),
        ]);
    }

    public function create(): void
    {
        if (!Permission::check('questionbank.create')) { Flash::error('Permission denied.'); redirect('question-bank'); return; }
        if ($this->isPost()) {
            $data = [
                'class_id'      => (int)$this->getPost('class_id'),
                'subject_id'    => (int)$this->getPost('subject_id'),
                'chapter'       => trim($this->getPost('chapter') ?: ''),
                'question_text' => trim($this->getPost('question_text')),
                'question_type' => $this->getPost('question_type', 'Short Answer'),
                'option_a'      => trim($this->getPost('option_a') ?: ''),
                'option_b'      => trim($this->getPost('option_b') ?: ''),
                'option_c'      => trim($this->getPost('option_c') ?: ''),
                'option_d'      => trim($this->getPost('option_d') ?: ''),
                'correct_answer'=> trim($this->getPost('correct_answer') ?: ''),
                'marks'         => (float)$this->getPost('marks', 1),
                'difficulty'    => $this->getPost('difficulty', 'Medium'),
                'created_by'    => Session::get('user_id'),
            ];
            if (!$data['class_id'] || !$data['subject_id'] || !$data['question_text']) {
                Flash::error('Class, Subject and Question are required.');
                redirect('question-bank/create');
                return;
            }
            $model = new Model(); $model->table = 'question_bank';
            $id = $model->create($data);
            Audit::log('question_bank', 'create', $id, ['class_id' => $data['class_id'], 'subject_id' => $data['subject_id']]);
            Flash::success('Question added to bank.');

            if ($this->getPost('add_another')) redirect('question-bank/create?class_id=' . $data['class_id'] . '&subject_id=' . $data['subject_id']);
            else redirect('question-bank');
        }

        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);
        $this->view('question-bank/create', [
            'pageTitle'   => 'Add Question',
            'classes'     => $classes,
            'prefillClass'=> $this->getGet('class_id'),
            'prefillSubject' => $this->getGet('subject_id'),
        ]);
    }

    public function edit(): void
    {
        if (!Permission::check('questionbank.create')) { Flash::error('Permission denied.'); redirect('question-bank'); return; }
        $id    = (int)($this->getGet('id') ?? 0);
        $model = new Model(); $model->table = 'question_bank';
        $q     = $model->findById($id);
        if (!$q) { Flash::error('Question not found.'); redirect('question-bank'); return; }

        if ($this->isPost()) {
            $data = [
                'chapter'       => trim($this->getPost('chapter') ?: ''),
                'question_text' => trim($this->getPost('question_text')),
                'question_type' => $this->getPost('question_type', 'Short Answer'),
                'option_a'      => trim($this->getPost('option_a') ?: ''),
                'option_b'      => trim($this->getPost('option_b') ?: ''),
                'option_c'      => trim($this->getPost('option_c') ?: ''),
                'option_d'      => trim($this->getPost('option_d') ?: ''),
                'correct_answer'=> trim($this->getPost('correct_answer') ?: ''),
                'marks'         => (float)$this->getPost('marks', 1),
                'difficulty'    => $this->getPost('difficulty', 'Medium'),
            ];
            $model->update($id, $data);
            Audit::log('question_bank', 'update', $id);
            Flash::success('Question updated.');
            redirect('question-bank');
        }

        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);
        $subjects  = (new Model())->raw("SELECT DISTINCT s.id, s.name FROM subjects s JOIN class_subjects cs ON cs.subject_id = s.id WHERE cs.class_id = :cid ORDER BY s.name", ['cid' => $q['class_id']]);

        $this->view('question-bank/edit', [
            'pageTitle' => 'Edit Question',
            'q'         => $q,
            'classes'   => $classes,
            'subjects'  => $subjects,
        ]);
    }

    public function delete(): void
    {
        $this->requirePost('question-bank');
        $id = (int)($this->getPost('id') ?? 0);
        $model = new Model(); $model->table = 'question_bank';
        $model->delete($id);
        Audit::log('question_bank', 'delete', $id);
        Flash::success('Question deleted.');
        redirect('question-bank');
    }

    // ── Question Paper Generator ────────────────────────────────────

    public function papers(): void
    {
        $papers = (new Model())->raw(
            "SELECT qp.*, c.name AS class_name, s.name AS subject_name,
                    (SELECT COUNT(*) FROM question_paper_items WHERE paper_id = qp.id) AS question_count
             FROM question_papers qp
             LEFT JOIN classes c ON qp.class_id = c.id
             LEFT JOIN subjects s ON qp.subject_id = s.id
             ORDER BY qp.created_at DESC"
        );
        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);

        $this->view('question-bank/papers', [
            'pageTitle' => 'Question Papers',
            'papers'    => $papers,
            'classes'   => $classes,
        ]);
    }

    public function generatePaper(): void
    {
        $sessionId = Session::get('active_session_id') ?? 0;
        $classes   = (new ClassModel())->getBySession($sessionId);

        if ($this->isPost()) {
            $classId   = (int)$this->getPost('class_id');
            $subjectId = (int)$this->getPost('subject_id');
            $title     = trim($this->getPost('title'));
            $totalMarks= (float)$this->getPost('total_marks', 100);
            $duration  = (int)$this->getPost('duration_mins', 180);
            $examType  = $this->getPost('exam_type', '');
            $instructions = trim($this->getPost('instructions') ?: '');

            // Section criteria from POST
            $sections = $this->getPost('sections', []);
            // sections[0][name], sections[0][type], sections[0][difficulty], sections[0][count], sections[0][marks_each]

            if (!$classId || !$subjectId || !$title || empty($sections)) {
                Flash::error('Please fill all required fields and at least one section.');
                redirect('question-bank/generate-paper');
                return;
            }

            // Create paper
            $paperModel = new Model(); $paperModel->table = 'question_papers';
            $paperId = $paperModel->create([
                'title'        => $title,
                'class_id'     => $classId,
                'subject_id'   => $subjectId,
                'exam_type'    => $examType,
                'total_marks'  => $totalMarks,
                'duration_mins'=> $duration,
                'instructions' => $instructions,
                'status'       => 'Draft',
                'created_by'   => Session::get('user_id'),
            ]);

            // Auto-pick questions per section
            $itemModel = new Model(); $itemModel->table = 'question_paper_items';
            $usedIds   = [];
            $orderNo   = 1;

            foreach ($sections as $sec) {
                $sName  = $sec['name']       ?? 'Section A';
                $qType  = $sec['type']       ?? '';
                $diff   = $sec['difficulty'] ?? '';
                $count  = (int)($sec['count'] ?? 5);
                $mEach  = (float)($sec['marks_each'] ?? 1);

                $qWhere  = "WHERE class_id = :cid AND subject_id = :sid";
                $qParams = ['cid' => $classId, 'sid' => $subjectId];
                if ($qType) { $qWhere .= " AND question_type = :qt"; $qParams['qt'] = $qType; }
                if ($diff)  { $qWhere .= " AND difficulty = :df";    $qParams['df'] = $diff; }
                if ($usedIds) {
                    $qWhere .= " AND id NOT IN (" . implode(',', array_map('intval', $usedIds)) . ")";
                }

                $picked = (new Model())->raw(
                    "SELECT id, marks FROM question_bank $qWhere ORDER BY RAND() LIMIT $count",
                    $qParams
                );

                foreach ($picked as $pq) {
                    $itemModel->create([
                        'paper_id'       => $paperId,
                        'question_id'    => $pq['id'],
                        'section_name'   => $sName,
                        'order_no'       => $orderNo++,
                        'marks_override' => $mEach,
                    ]);
                    $usedIds[] = $pq['id'];
                }
            }

            Audit::log('question_bank', 'paper_generate', $paperId);
            Flash::success('Question paper generated successfully.');
            redirect('question-bank/view-paper?id=' . $paperId);
        }

        $this->view('question-bank/generate-paper', [
            'pageTitle' => 'Generate Question Paper',
            'classes'   => $classes,
        ]);
    }

    public function viewPaper(): void
    {
        $id    = (int)($this->getGet('id') ?? 0);
        $paper = (new Model())->rawOne(
            "SELECT qp.*, c.name AS class_name, s.name AS subject_name
             FROM question_papers qp
             LEFT JOIN classes c ON qp.class_id = c.id
             LEFT JOIN subjects s ON qp.subject_id = s.id
             WHERE qp.id = :id", ['id' => $id]
        );
        if (!$paper) { Flash::error('Paper not found.'); redirect('question-bank/papers'); return; }

        $items = (new Model())->raw(
            "SELECT qpi.*, qb.question_text, qb.question_type, qb.option_a, qb.option_b,
                    qb.option_c, qb.option_d, qb.correct_answer, qb.marks, qb.difficulty, qb.chapter
             FROM question_paper_items qpi
             JOIN question_bank qb ON qpi.question_id = qb.id
             WHERE qpi.paper_id = :pid ORDER BY qpi.section_name, qpi.order_no",
            ['pid' => $id]
        );

        // Group by section
        $sections = [];
        foreach ($items as $item) {
            $sections[$item['section_name']][] = $item;
        }

        $this->view('question-bank/view-paper', [
            'pageTitle' => 'Question Paper: ' . $paper['title'],
            'paper'     => $paper,
            'sections'  => $sections,
            'items'     => $items,
        ]);
    }

    public function printPaper(): void
    {
        $id    = (int)($this->getGet('id') ?? 0);
        $paper = (new Model())->rawOne(
            "SELECT qp.*, c.name AS class_name, s.name AS subject_name
             FROM question_papers qp
             LEFT JOIN classes c ON qp.class_id = c.id
             LEFT JOIN subjects s ON qp.subject_id = s.id
             WHERE qp.id = :id", ['id' => $id]
        );
        if (!$paper) { Flash::error('Paper not found.'); redirect('question-bank/papers'); return; }

        $items = (new Model())->raw(
            "SELECT qpi.*, qb.question_text, qb.question_type, qb.option_a, qb.option_b,
                    qb.option_c, qb.option_d, qb.marks, qb.difficulty, qb.chapter
             FROM question_paper_items qpi
             JOIN question_bank qb ON qpi.question_id = qb.id
             WHERE qpi.paper_id = :pid ORDER BY qpi.section_name, qpi.order_no",
            ['pid' => $id]
        );
        $sections = [];
        foreach ($items as $item) { $sections[$item['section_name']][] = $item; }

        $this->view('question-bank/print-paper', [
            'pageTitle' => $paper['title'],
            'paper'     => $paper,
            'sections'  => $sections,
        ]);
    }

    public function deletePaper(): void
    {
        $this->requirePost('question-bank/papers');
        $id = (int)($this->getPost('id') ?? 0);
        $model = new Model(); $model->table = 'question_papers';
        $model->delete($id);
        Audit::log('question_bank', 'paper_delete', $id);
        Flash::success('Paper deleted.');
        redirect('question-bank/papers');
    }

    public function finalizePaper(): void
    {
        $this->requirePost('question-bank/papers');
        $id = (int)($this->getPost('id') ?? 0);
        $model = new Model(); $model->table = 'question_papers';
        $model->update($id, ['status' => 'Final']);
        Flash::success('Paper finalized.');
        redirect('question-bank/view-paper?id=' . $id);
    }

    public function removeQuestion(): void
    {
        $this->requirePost('question-bank/papers');
        $itemId  = (int)$this->getPost('item_id');
        $paperId = (int)$this->getPost('paper_id');
        $model = new Model(); $model->table = 'question_paper_items';
        $model->delete($itemId);
        Flash::success('Question removed from paper.');
        redirect('question-bank/view-paper?id=' . $paperId);
    }
}
