<?php
class AttendanceController extends Controller
{
    public function index(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $this->view('attendance/index', ['pageTitle' => 'Attendance', 'classes' => $classes]);
    }

    public function mark(): void
    {
        $sessionId = Session::get('active_session_id');
        $classId = (int) $this->getGet('class_id', $this->getPost('class_id', 0));
        $sectionId = (int) $this->getGet('section_id', $this->getPost('section_id', 0));

        if ($this->isPost()) {
            $date = $this->getPost('date', $this->getPost('attendance_date', date('Y-m-d')));
            $attendanceData = $this->getPost('attendance', []);
            $attendanceModel = new Attendance();
            $count = $attendanceModel->markBulk($attendanceData, $sessionId, $classId, $sectionId ?: null, $date, Auth::id());
            Audit::log('attendance', 'mark', null, ['class_id' => $classId, 'date' => $date, 'count' => $count]);
            Flash::success('Attendance marked successfully.');

            // Notify absent students and their parents
            try {
                $studentModel = new Student();
                foreach ($attendanceData as $studentId => $status) {
                    if ($status === 'Absent') {
                        $student = $studentModel->findById((int)$studentId);
                        if ($student && $student['user_id']) {
                            NotificationService::studentMarkedAbsent(
                                (int)$student['user_id'],
                                trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')),
                                $date
                            );
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Attendance notification error: " . $e->getMessage());
            }

            redirect("attendance/mark?class_id=$classId&section_id=$sectionId&date=$date");
            return;
        }

        $date = $this->getGet('date', date('Y-m-d'));
        $studentModel = new Student();
        $students = $studentModel->getStudentsWithDetails($sessionId ?? 0, 1, 100, '', $classId);
        $existingAttendance = (new Attendance())->getClassAttendance($classId, $date, $sessionId ?? 0);

        $this->view('attendance/mark', ['pageTitle' => 'Mark Attendance', 'students' => $students['data'], 'classId' => $classId, 'sectionId' => $sectionId, 'date' => $date, 'existingAttendance' => $existingAttendance]);
    }

    /**
     * AJAX endpoint: list students for a given class (used by the attendance index page)
     * GET attendance/get-students?class_id=
     */
    public function getStudents(): void
    {
        $sessionId = Session::get('active_session_id');
        $classId = (int) ($this->getGet('class_id') ?? 0);
        $studentModel = new Student();
        $students = $classId ? $studentModel->getStudentsWithDetails($sessionId ?? 0, 1, 200, '', $classId) : ['data' => []];
        $this->json($students['data']);
    }

    public function report(): void
    {
        $sessionId = Session::get('active_session_id');
        $classModel = new ClassModel();
        $classes = $classModel->getBySession($sessionId ?? 0);
        $report = [];
        $type = $this->getGet('type', $this->getPost('type', 'student'));

        if ($this->isPost() || isset($_GET['from_date']) || isset($_GET['to_date']) || isset($_GET['class_id']) || isset($_GET['type'])) {
            $fromDate = $this->getGet('from_date', $this->getPost('from_date', date('Y-m-01')));
            $toDate = $this->getGet('to_date', $this->getPost('to_date', date('Y-m-d')));
            $attendanceModel = new Attendance();

            if ($type === 'teacher') {
                $report = $attendanceModel->getTeacherAttendanceReport($fromDate, $toDate);
            } else {
                $classIdRaw = $this->getGet('class_id', $this->getPost('class_id', ''));
                $classId = ($classIdRaw === '' || $classIdRaw === null) ? null : (int) $classIdRaw;
                $report = $attendanceModel->getAttendanceReport($classId, $sessionId ?? 0, $fromDate, $toDate);
            }
        }

        $this->view('attendance/report', ['pageTitle' => 'Attendance Report', 'classes' => $classes, 'report' => $report, 'type' => $type]);
    }

    public function teacher(): void
    {
        if ($this->isPost()) {
            $date = $this->getPost('date', date('Y-m-d'));
            $attendanceData = $this->getPost('attendance', []);
            $attendanceModel = new Attendance();
            $count = $attendanceModel->markTeacherAttendance($attendanceData, $date, Auth::id());
            Audit::log('attendance', 'teacher_mark', null, ['date' => $date, 'count' => $count]);
            Flash::success('Teacher attendance marked.');
            redirect('attendance/teacher?date=' . $date);
            return;
        }
        $date = $this->getGet('date', date('Y-m-d'));
        $teacherModel = new Teacher();
        $teachers = $teacherModel->getActiveTeachers();
        $attendanceModel = new Attendance();
        $existingAttendance = $attendanceModel->getTeacherAttendanceByDate($date);
        $this->view('attendance/teacher', ['pageTitle' => 'Teacher Attendance', 'teachers' => $teachers, 'date' => $date, 'existingAttendance' => $existingAttendance]);
    }

    /** Monthly attendance report for a class */
    public function monthlyReport(): void
    {
        $sessionId = Session::get('active_session_id') ?? 0;
        $classId   = (int)($this->getGet('class_id') ?? 0);
        $month     = $this->getGet('month') ?: date('Y-m');
        $classModel = new ClassModel();
        $classes    = $classModel->getBySession($sessionId);

        $report = [];
        $workingDays = 0;
        if ($classId && $month) {
            $attModel = new Attendance();
            $report = $attModel->raw(
                "SELECT s.id, CONCAT(s.first_name,' ',IFNULL(s.last_name,'')) as name, s.roll_number,
                        COUNT(CASE WHEN a.status='Present' THEN 1 END) as present,
                        COUNT(CASE WHEN a.status='Absent' THEN 1 END) as absent,
                        COUNT(CASE WHEN a.status='Late' THEN 1 END) as late,
                        COUNT(a.id) as total_days
                 FROM students s
                 LEFT JOIN student_attendance a ON a.student_id = s.id AND DATE_FORMAT(a.date,'%Y-%m') = :month
                 WHERE s.class_id = :cid AND s.session_id = :sid AND s.status = 'Active'
                 GROUP BY s.id ORDER BY s.roll_number",
                ['month' => $month, 'cid' => $classId, 'sid' => $sessionId]
            );
            $wdRow = $attModel->rawOne(
                "SELECT COUNT(DISTINCT date) as days FROM student_attendance WHERE class_id = :cid AND DATE_FORMAT(date,'%Y-%m') = :month",
                ['cid' => $classId, 'month' => $month]
            );
            $workingDays = (int)($wdRow['days'] ?? 0);
        }

        $this->view('attendance/monthly-report', [
            'pageTitle'   => 'Monthly Attendance Report',
            'classes'     => $classes,
            'classId'     => $classId,
            'month'       => $month,
            'report'      => $report,
            'workingDays' => $workingDays,
        ]);
    }

    /** Send SMS to parents of absent students for a given date & class */
    public function sendAbsentSms(): void
    {
        $this->requirePost('attendance');
        $date    = $this->getPost('date') ?: date('Y-m-d');
        $classId = (int)($this->getPost('class_id') ?? 0);
        $sessionId = Session::get('active_session_id') ?? 0;

        $attModel = new Attendance();
        $absentStudents = $attModel->raw(
            "SELECT s.first_name, s.last_name, p.father_phone, p.mother_phone
             FROM student_attendance sa
             JOIN students s ON sa.student_id = s.id
             LEFT JOIN parents p ON s.parent_id = p.id
             WHERE sa.date = :date AND sa.status = 'Absent' AND s.class_id = :cid AND s.session_id = :sid",
            ['date' => $date, 'cid' => $classId, 'sid' => $sessionId]
        );

        $sent = 0;
        foreach ($absentStudents as $st) {
            $phone = $st['father_phone'] ?: $st['mother_phone'];
            if (!$phone) continue;
            $name = trim($st['first_name'].' '.($st['last_name']??''));
            $msg  = "Dear Parent, $name was absent on ".date('d-m-Y', strtotime($date)).". - ".APP_NAME;
            SMS::send($phone, $msg);
            $sent++;
        }

        Flash::success("SMS sent to $sent parent(s) for absent students.");
        redirect('attendance?date=' . $date);
    }

    /** Bulk mark all students in a class as Present (quick action) */
    public function bulkMarkPresent(): void
    {
        $this->requirePost('attendance');
        $date      = $this->getPost('date') ?: date('Y-m-d');
        $classId   = (int)($this->getPost('class_id') ?? 0);
        $sessionId = Session::get('active_session_id') ?? 0;

        $studentModel = new Student();
        $students = $studentModel->findAllBy('class_id', $classId);

        $attModel = new Attendance();
        $count = 0;
        foreach ($students as $s) {
            if ($s['session_id'] != $sessionId || $s['status'] !== 'Active') continue;
            // Skip if already marked
            $exists = $attModel->rawOne(
                "SELECT id FROM student_attendance WHERE student_id = :sid AND date = :dt",
                ['sid' => $s['id'], 'dt' => $date]
            );
            if (!$exists) {
                $attModel->create([
                    'student_id' => $s['id'],
                    'class_id'   => $classId,
                    'session_id' => $sessionId,
                    'date'       => $date,
                    'status'     => 'Present',
                    'marked_by'  => Session::get('user_id'),
                ]);
                $count++;
            }
        }
        Flash::success("$count students marked Present.");
        redirect('attendance?date=' . $date . '&class_id=' . $classId);
    }
}