# ND International School ERP — Fresh Installation Guide

## System Requirements

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| PHP         | 8.0+    | 8.2+        |
| MySQL       | 5.7+    | 8.0+        |
| Web Server  | Apache / Nginx | Apache with mod_rewrite |
| RAM         | 512 MB  | 2 GB        |
| Disk Space  | 500 MB  | 5 GB        |

---

## Step 1: Upload Files

### cPanel / Shared Hosting
1. Download / zip the project folder.
2. Log in to cPanel → **File Manager**.
3. Navigate to `public_html` (or your target subdomain folder).
4. Upload and extract the zip there.
5. Ensure the project root contains `index.php`, `config.php`, `app/`, `assets/`, `database/`.

### VPS / Dedicated Server
```bash
# Upload via SCP
scp -r ./a1.ndinternationalschool.com user@yourserver:/var/www/html/school

# Or clone from Git
git clone <repo-url> /var/www/html/school
```

---

## Step 2: Create Database

### cPanel
1. cPanel → **MySQL Databases**
2. Create a new database: e.g. `school_db`
3. Create a database user with a strong password
4. Add user to database with **ALL PRIVILEGES**
5. Note: hostname, database name, username, password

### VPS (MySQL)
```sql
CREATE DATABASE school_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'school_user'@'localhost' IDENTIFIED BY 'StrongPassword123!';
GRANT ALL PRIVILEGES ON school_db.* TO 'school_user'@'localhost';
FLUSH PRIVILEGES;
```

---

## Step 3: Import Database (2 files — no migrations needed)

The schema is fully consolidated into a single file, so a fresh install is just
two imports **in this order**:

1. `database/toni_schema.sql` — all tables (pure `CREATE TABLE`, no `ALTER`s)
2. `database/toni_data.sql` — default roles + logins + seed settings

Default logins (change the passwords right after first login):
`superadmin@ndinternationalschool.com` / `Admin@123`

### cPanel → phpMyAdmin
1. Open **phpMyAdmin** → select your database
2. Click **Import** tab → choose `database/toni_schema.sql` → **Go**
3. Import again → choose `database/toni_data.sql` → **Go**

### VPS / Terminal
```bash
mysql -u school_user -p school_db < database/toni_schema.sql
mysql -u school_user -p school_db < database/toni_data.sql
```

---

## Step 4: Configure the Application

Open **`config.php`** in the project root and update:

```php
// Database
define('DB_HOST', 'localhost');        // Usually localhost
define('DB_NAME', 'school_db');        // Your database name
define('DB_USER', 'school_user');      // Your DB username
define('DB_PASS', 'StrongPassword123!'); // Your DB password

// Application URL — NO trailing slash
define('APP_URL', 'https://yourschool.com');   // or http://localhost/school

// Application name
define('APP_NAME', 'ND International School Dinod');
```

---

## Step 5: Set File Permissions

```bash
# On Linux/VPS:
chmod -R 755 /var/www/html/school
chmod -R 777 /var/www/html/school/assets/uploads
chmod -R 777 /var/www/html/school/assets/uploads/students
chmod -R 777 /var/www/html/school/assets/uploads/teachers
chmod -R 777 /var/www/html/school/assets/uploads/homework
chmod -R 777 /var/www/html/school/assets/uploads/documents
```

On cPanel, right-click each folder in File Manager → **Change Permissions** → set `uploads` and sub-folders to **777**.

---

## Step 6: Web Server Configuration

### Apache (.htaccess — already included in project root)
The project includes an `.htaccess` file. Make sure `mod_rewrite` is enabled:
```bash
# Ubuntu/Debian
sudo a2enmod rewrite
sudo systemctl restart apache2
```

The `.htaccess` file routes all requests through `index.php`:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?url=$1 [QSA,L]
```

### Nginx
```nginx
server {
    listen 80;
    server_name yourschool.com;
    root /var/www/html/school;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?url=$uri&$query_string;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
}
```

---

## Step 7: Create First Admin Account

After importing the database, a default Super Admin is created:

| Field    | Value              |
|----------|--------------------|
| Email    | `admin@school.com` |
| Password | `Admin@123`        |
| Role     | Super Admin        |

**Change this password immediately after first login** → Settings → My Profile → Change Password.

---

## Step 8: Initial Configuration (First Login)

After logging in as Super Admin, complete these steps in order:

### 8.1 School Settings
**Settings → School Settings**
- School name, address, phone, email
- Upload school logo (recommended: 300×100 px PNG with transparent background)
- Affiliate board, registration number

### 8.2 Academic Session
**Academic → Sessions**
- Click **Add Session** → e.g. `2025-26`
- Set start date and end date
- Click **Set Active** to make it the current session

### 8.3 Classes & Sections
**Academic → Classes**
- Add classes: Nursery, LKG, UKG, I, II, … XII

**Academic → Sections**
- Add sections per class: A, B, C

### 8.4 Subjects
**Academic → Subjects**
- Add subjects linked to each class
- Set subject code and type (Theory / Practical)

### 8.5 Fee Structure
**Finance → Fee Management**
- Create fee categories (Tuition Fee, Transport Fee, etc.)
- Set monthly/annual amounts per class

**Settings → Fee Config**
- Set late fee per day, grace period, due date

### 8.6 Add Teachers
**People → Teachers → Add Teacher**
- Fill in details
- Create login account (Teacher Profile → Login Account → Create Login)

### 8.7 Add Students
**People → Students → Add Student** (one by one)  
OR  
**People → Students → Import** (bulk CSV — download template first)

### 8.8 Fee Allocation
**Finance → Fee Allocation**
- Assign fee structures to each class for the active session

### 8.9 Timetable
**Timetable**
- Add schedule per class/section/day

### 8.10 SMS Configuration (Optional)
**Settings → SMS Settings**
- Provider: Fast2SMS or MSG91
- Enter API key
- Test SMS

### 8.11 Email / SMTP (Optional)
**Settings → Email / SMTP**
- Enter SMTP server details for forgot password emails

---

## Step 9: Module Reference

| Module | URL Path | Description |
|--------|----------|-------------|
| Dashboard | `/dashboard` | School overview with stats |
| Students | `/students` | Admission, profile, ID card, TC |
| Teachers | `/teachers` | Staff management, leave, salary |
| Attendance | `/attendance` | Daily, teacher, monthly report |
| Timetable | `/timetable` | Class schedule management |
| Examinations | `/exams` | Exam schedule, marks entry, results |
| Fees | `/fees` | Collection, receipts, outstanding |
| Refunds | `/refunds` | Fee refund with approval flow |
| Accounting | `/accounting` | Cash/bank book, journal, P&L |
| Payroll | `/payroll` | Salary processing, salary slips |
| Library | `/library` | Books, issue/return, fines |
| Homework | `/homework` | Assignments, submissions, grading |
| Transport | `/transport` | Routes, vehicles, fee integration |
| Communication | `/communication` | Messages, notices, broadcast |
| Reports | `/reports` | Excel/PDF reports for all modules |
| Settings | `/settings` | School config, SMS, email, fees |
| Audit Logs | `/audit` | Complete action history |
| Backup | `/backup` | Database backup/restore |

---

## Step 10: User Roles

| Role | Access |
|------|--------|
| Super Admin | Full access to everything |
| School Admin | All modules except some system settings |
| Principal | Students, teachers, academics, reports |
| Teacher | Attendance, homework, marks, timetable |
| Accountant | Fees, refunds, accounting, payroll |
| Receptionist | Students (view/create), attendance view |
| Librarian | Library module only |
| Student | Student portal (own data only) |
| Parent | Parent portal (child's data) |

---

## Troubleshooting

### "404 Not Found" on all pages
- Ensure `mod_rewrite` is enabled
- Check `.htaccess` exists in project root
- Check `AllowOverride All` in Apache's `httpd.conf`

### "Access Denied" database error
- Verify `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` in `config.php`
- Check DB user has correct privileges

### Uploads not saving
- Check `assets/uploads/` folder exists and has write permission (777)
- PHP `upload_max_filesize` and `post_max_size` must be ≥ 5MB
  - Edit `php.ini`: `upload_max_filesize = 10M` and `post_max_size = 12M`

### Sessions expiring too fast
- Increase `SESSION_LIFETIME` in `config.php` (default: 3600 = 1 hour)

### Forgot password email not sending
- Configure SMTP in **Settings → Email / SMTP**
- Test using **Test Email** button

---

## File Structure Overview

```
/
├── index.php              ← Entry point (routes all requests)
├── config.php             ← Database & app configuration
├── .htaccess              ← Apache URL rewriting
├── INSTALLATION_GUIDE.md  ← This file
├── app/
│   ├── core/              ← Framework: App, Controller, Model, View, Auth...
│   ├── controllers/       ← One controller per module
│   ├── models/            ← Database models
│   └── views/             ← PHP view templates
├── assets/
│   ├── css/               ← Stylesheets
│   ├── js/                ← JavaScript
│   └── uploads/           ← User-uploaded files (must be writable)
└── database/
    ├── toni_schema.sql     ← Full database schema (import first)
    └── toni_data.sql       ← Default roles, logins & seed data (import second)
```

---

## Support

- Developer: Ashish (ramwebindia@gmail.com)
- System: ND International School ERP v1.0
- Built: PHP MVC (custom framework), MySQL, Bootstrap 5
